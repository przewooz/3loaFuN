#pragma once



//tools
#include  "atlstr.h"  //CString

//system
#include  "system_hefan.h"



namespace HEFAN
{

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary> 
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CMainHefanForm : public System::Windows::Forms::Form
	{	
	public:
		CMainHefanForm(CString  sInParameters)
		{
			pc_system  =  new  CHefanSystem;
			pc_system->sInParameters = sInParameters;
			InitializeComponent();
		}
  
	protected:
		void Dispose(Boolean disposing)
		{
			delete  pc_system;
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}





	private: System::Windows::Forms::OpenFileDialog *  openFileDialog1;

	private:
		CHefanSystem  *pc_system;



	private: System::Windows::Forms::GroupBox *  groupBox2;
	private: System::Windows::Forms::GroupBox *  groupBox3;
	private: System::Windows::Forms::ListBox *  list_comm;
	private: System::Windows::Forms::GroupBox *  groupBox1;
	private: System::Windows::Forms::Button *  but_cancel;
	private: System::Windows::Forms::Button *  but_load_set_of_files;
	private: System::Windows::Forms::Button *  but_load_1file;
	private: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::ListBox *  list_params;
	private: System::Windows::Forms::Button*  but_run_graph;
	private: System::Windows::Forms::Button*  but_get_ct_create_num;






			 /// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container * components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->openFileDialog1 = (new System::Windows::Forms::OpenFileDialog());
			this->groupBox2 = (new System::Windows::Forms::GroupBox());
			this->groupBox4 = (new System::Windows::Forms::GroupBox());
			this->list_params = (new System::Windows::Forms::ListBox());
			this->groupBox1 = (new System::Windows::Forms::GroupBox());
			this->but_get_ct_create_num = (new System::Windows::Forms::Button());
			this->but_run_graph = (new System::Windows::Forms::Button());
			this->but_cancel = (new System::Windows::Forms::Button());
			this->but_load_set_of_files = (new System::Windows::Forms::Button());
			this->but_load_1file = (new System::Windows::Forms::Button());
			this->groupBox3 = (new System::Windows::Forms::GroupBox());
			this->list_comm = (new System::Windows::Forms::ListBox());
			this->groupBox2->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->groupBox4);
			this->groupBox2->Controls->Add(this->groupBox1);
			this->groupBox2->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox2->Location = System::Drawing::Point(0, 0);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(560, 296);
			this->groupBox2->TabIndex = 7;
			this->groupBox2->TabStop = false;
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->list_params);
			this->groupBox4->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox4->Location = System::Drawing::Point(3, 16);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(386, 277);
			this->groupBox4->TabIndex = 14;
			this->groupBox4->TabStop = false;
			// 
			// list_params
			// 
			this->list_params->Dock = System::Windows::Forms::DockStyle::Fill;
			this->list_params->Location = System::Drawing::Point(3, 16);
			this->list_params->Name = S"list_params";
			this->list_params->Size = System::Drawing::Size(380, 251);
			this->list_params->TabIndex = 6;
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->but_get_ct_create_num);
			this->groupBox1->Controls->Add(this->but_run_graph);
			this->groupBox1->Controls->Add(this->but_cancel);
			this->groupBox1->Controls->Add(this->but_load_set_of_files);
			this->groupBox1->Controls->Add(this->but_load_1file);
			this->groupBox1->Dock = System::Windows::Forms::DockStyle::Right;
			this->groupBox1->Location = System::Drawing::Point(389, 16);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(168, 277);
			this->groupBox1->TabIndex = 13;
			this->groupBox1->TabStop = false;
			// 
			// but_get_ct_create_num
			// 
			this->but_get_ct_create_num->Location = System::Drawing::Point(11, 193);
			this->but_get_ct_create_num->Name = S"but_get_ct_create_num";
			this->but_get_ct_create_num->Size = System::Drawing::Size(136, 23);
			this->but_get_ct_create_num->TabIndex = 17;
			this->but_get_ct_create_num->Text = S"Get CT create number";
			this->but_get_ct_create_num->Click += new System::EventHandler(this, &CMainHefanForm::but_get_ct_create_num_Click);
			// 
			// but_run_graph
			// 
			this->but_run_graph->Location = System::Drawing::Point(11, 164);
			this->but_run_graph->Name = S"but_run_graph";
			this->but_run_graph->Size = System::Drawing::Size(136, 23);
			this->but_run_graph->TabIndex = 16;
			this->but_run_graph->Text = S"Create test configs";
			this->but_run_graph->Click += new System::EventHandler(this, &CMainHefanForm::but_run_graph_Click);
			// 
			// but_cancel
			// 
			this->but_cancel->Location = System::Drawing::Point(72, 120);
			this->but_cancel->Name = S"but_cancel";
			this->but_cancel->Size = System::Drawing::Size(75, 23);
			this->but_cancel->TabIndex = 15;
			this->but_cancel->Text = S"Cancel";
			this->but_cancel->Click += new System::EventHandler(this, &CMainHefanForm::but_cancel_Click);
			// 
			// but_load_set_of_files
			// 
			this->but_load_set_of_files->Location = System::Drawing::Point(16, 56);
			this->but_load_set_of_files->Name = S"but_load_set_of_files";
			this->but_load_set_of_files->Size = System::Drawing::Size(136, 23);
			this->but_load_set_of_files->TabIndex = 14;
			this->but_load_set_of_files->Text = S"Load set of files";
			this->but_load_set_of_files->Click += new System::EventHandler(this, &CMainHefanForm::but_load_set_of_files_Click);
			// 
			// but_load_1file
			// 
			this->but_load_1file->Location = System::Drawing::Point(16, 24);
			this->but_load_1file->Name = S"but_load_1file";
			this->but_load_1file->Size = System::Drawing::Size(136, 23);
			this->but_load_1file->TabIndex = 13;
			this->but_load_1file->Text = S"Load 1 file";
			this->but_load_1file->Click += new System::EventHandler(this, &CMainHefanForm::but_load_1file_Click);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->list_comm);
			this->groupBox3->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox3->Location = System::Drawing::Point(0, 296);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(560, 165);
			this->groupBox3->TabIndex = 8;
			this->groupBox3->TabStop = false;
			// 
			// list_comm
			// 
			this->list_comm->Dock = System::Windows::Forms::DockStyle::Fill;
			this->list_comm->Location = System::Drawing::Point(3, 16);
			this->list_comm->Name = S"list_comm";
			this->list_comm->Size = System::Drawing::Size(554, 134);
			this->list_comm->TabIndex = 6;
			// 
			// CMainHefanForm
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(560, 461);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox2);
			this->Name = S"CMainHefanForm";
			this->Text = S"Form1";
			this->Shown += new System::EventHandler(this, &CMainHefanForm::CMainHefanForm_Shown);
			this->groupBox2->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox1->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->ResumeLayout(false);

		}	
	private: System::Void but_cancel_Click(System::Object *  sender, System::EventArgs *  e)
			 {
				 DialogResult  =  DialogResult::Cancel;
				 Close();
			 }

private: System::Void but_load_1file_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_load_set_of_files_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void v_create_test_config_muppets(bool  bTuning);
private: System::Void v_get_case_names(vector<CString>  *pvCaseNames, bool  bTuning);

private: System::Void but_run_graph_Click(System::Object*  sender, System::EventArgs*  e);
private: System::Void CMainHefanForm_Shown(System::Object*  sender, System::EventArgs*  e);
private: System::Void but_get_ct_create_num_Click(System::Object*  sender, System::EventArgs*  e);
};
};//namespace HEFAN


