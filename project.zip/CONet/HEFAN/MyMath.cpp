
#include  "stdafx.h"
#include  "MyMath.h"
using namespace  MyMath;




//sets random seed
int  MyMath::iRandomize()
{
	unsigned int i_seed;
	i_seed = (unsigned)time( NULL );
	//i_seed = 55;
	srand(i_seed);
	return(i_seed);
}//void  vRandomize()





//returns number from 0 to RAND_MAX
int  MyMath::iRand()
{
	return(rand());
}//int  iRand()






long  MyMath::lRand(int iNumberOfPossibilities)
{

	double  d_rand;
	double  d_div;

	long    l_result;

	d_rand  =  rand();

	d_div  =  RAND_MAX;
	d_div++;//it is in order to never achieve the result of 1 after the division

	d_rand  =  d_rand / d_div;


	d_rand  *=  iNumberOfPossibilities;

	l_result  =  (long) d_rand;
	
	
	
	return(l_result);

}//int  iRand(int iNumberOfPossibilities)







//returns number from 0 to 1 (excluding 1)
double  MyMath::dRand()
{
	double  d_rand, d_div;

	d_rand  =  rand();
	d_div   =  RAND_MAX;
	d_div++;

	return(d_rand / d_div);
}//double  dRand()








long MyMath::lRound(double dvalue)
{
    
    double dint, dfract;
    long li;
    

	dfract  =  modf(dvalue,&dint);
	li  =  (long)  dint;

	if  (dfract >= 0.5)  li++;
	else
		if  (dfract <= -0.5)  li--;

    return li;        
};


CTimeCounter::CTimeCounter()
{
	b_start_inited  =  false;
	b_finish_inited  =  false;
}//CTimeCounter::CTimeCounter()



void  CTimeCounter::vSetStartNow()
{
	b_start_inited  =  true;
	QueryPerformanceFrequency(&li_freq);
	QueryPerformanceCounter(&li_start_position);
	QueryThreadCycleTime(GetCurrentThread(), &li_start_position_qpc);	

	d_cpu_start_time = dGetCPUTime();
}//void  CTimeCounter::vSetStartNow()


//if returned value is false it means the timer was not set on start
bool  CTimeCounter::bGetTimePassed(double  *pdTimePassedSec)
{
	if  (b_start_inited  ==  false)  return(false);

	LARGE_INTEGER  li_now;
	QueryPerformanceCounter(&li_now);

	double  d_result;

	d_result  =  (li_now.QuadPart  -  li_start_position.QuadPart);
	d_result  =  d_result  /  li_freq.QuadPart;
	
	*pdTimePassedSec  =  d_result;

	return(true);
}//bool  CTimeCounter::bGetTimePassed(double  *pdTimePassedMs)


bool  CTimeCounter::bGetTimePassedQTCT(double  *pdTickQPC)
{
	if  (b_start_inited  ==  false)  return(false);

	unsigned __int64 li_cycles;
	QueryThreadCycleTime(GetCurrentThread(), &li_cycles);
	double  d_result;

	*pdTickQPC  =  li_cycles - li_start_position_qpc;

	return(true);
}//bool  CTimeCounter::bGetTimePassedQTCT(double  *pdTimePassedMs)



bool  CTimeCounter::bGetTimePassedCPUTime(double  *pdTimePassedSec)
{
	if  (b_start_inited  ==  false)  return(false);

	double  d_cpu_time_cur;
	d_cpu_time_cur = dGetCPUTime();

	*pdTimePassedSec  =  d_cpu_time_cur - d_cpu_start_time;

	return(true);
}//bool  CTimeCounter::bGetTimePassedCPUTime(double  *pdTimePassedSec)



double CTimeCounter::dGetCPUTime()
{
    FILETIME createTime;
    FILETIME exitTime;
    FILETIME kernelTime;
    FILETIME userTime;

    if ( 
		GetProcessTimes( GetCurrentProcess( ),
        &createTime, &exitTime, &kernelTime, &userTime ) != -1 
		)
    {
        SYSTEMTIME userSystemTime;
        if (FileTimeToSystemTime( &kernelTime, &userSystemTime ) != -1)
		{
            return
				(
				(double)userSystemTime.wHour * 3600.0 +
				(double)userSystemTime.wMinute * 60.0 +
				(double)userSystemTime.wSecond +
				(double)userSystemTime.wMilliseconds / 1000.0
				);
		}//if (FileTimeToSystemTime( &userTime, &userSystemTime ) != -1)
    }//if (
}//double CTimeCounter::dGetCPUTime()



bool  CTimeCounter::bSetFinishOn(double  dTimeToFinishSec)
{
	if  ( (b_start_inited  ==  false)||(dTimeToFinishSec <= 0) )  return(false);

	b_finish_inited  =  true;

	li_finish_position.QuadPart  =  
		li_start_position.QuadPart  
		+  
		li_freq.QuadPart * dTimeToFinishSec;

	return(true);
}//bool  CTimeCounter::bSetFinishOn(double  dTimeToFinishMs)


bool  CTimeCounter::bIsFinished()
{
	if  ( (b_start_inited  !=  true)||(b_finish_inited  !=  true) )
		return(true);

	LARGE_INTEGER  li_now;
	QueryPerformanceCounter(&li_now);
	if  (li_now.QuadPart  >  li_finish_position.QuadPart)
		return(true);
	else
		return(false);
};//bool  CTimeCounter::bIsFinished()






