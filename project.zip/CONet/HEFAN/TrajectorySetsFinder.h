#pragma once



//tools
#include  "atlstr.h"  //CString
#include <windows.h>
#include  "tools.h"


//error
#include  "..\\CONetAdmin\\error.h"


//system tools
#include  "list.h"
#include  "MyMath.h"

//net components...
#include  "NETsimulator.h"
#include  "TopologyTranslator.h"

//vector
#include  <vector>
#include  <iostream>
#include  <functional>
#include  <algorithm>

using namespace std;
using  namespace  TopologyTranslator;
using  namespace  System;



#define  TSF_LL_DRIVEN_INIT   1
#define  TSF_PEACH   1


#define  VGA_PARAM_PARENT_SELECTION_STRATEGY_PENALIZED 0
#define  VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED 1
#define  VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED_INCR_TOURNAMENT 2
#define  VGA_PARAM_PARENT_SELECTION_STRATEGY_DIVIDED_RANKING 3


namespace  TrajectorySetsFinder
{


	class  CVirtualWayDatabase;//CVirtualWay must know it
	class  CTrajectorySetsFinder;

	class  CMessyGene;//predefinition
	class  CMessyIndividual;//predefinition
	class  CMessyPattern;//predefinition

	class  CDSM;//predefinition
	class  CLinkageScrap;//predefinition
	class  CLTreeNode;//predefinition
	class  CLTree;//predefinition
	class  C_IC_PSO_Distribution;//predefinition
	class  C_IC_PSO_Gene_Probability;//predefinition
	
	
	class  CBrainStormSupervisor
	{
	public:

		CBrainStormSupervisor();
		~CBrainStormSupervisor();


		bool  bSetUpConfig
			(
			long  lNumOfGenToAvr,
			double  dMinInc,//turn on trigger
			long  lTimeLen,  long  lFinishTime,//full turn on state time and turning off time
			long  lMinBreak//time between tuning off and turning on again
			);

		double  dGetNextGenerationState(double  dActGenFOM);
		int     iGetCurrentState(){return(i_current_state);};


	private:

		double  *pd_previous_pops,  *pd_actual_pops;
		double  d_previous_pops_sum,  d_actual_pops_sum;



		//inoutted setup data
		long  l_num_of_gen_to_avr;
		double  d_min_inc;//turn on trigger
		long  l_time_len,  l_finish_time;//full turn on state time and turning off time
		long  l_min_break;//time between tuning off and turning on again


		//local compute data
		long  l_actual_gen_counter;//counts a number of generations in a current state
		int   i_current_state;//0 - turned off 1 - turning off 2 - turned on

	};//class  CBrainStormSupervisor












	class  CVirtualWay
	{

	public:

		int  iId;

		int   iGetWay(long  **plWay);
		bool  bSetWay(long  *plNewWay,  int  iNewWayLength);


		int  iLoadWay(FILE  *pfSource, CTopologyTranslator *pcTranslator, bool  bTranslate);
		void  vCreateReportFile(FILE  *pfReport);

		double  dCountFOM(CNETsimulator  *pcNetSim);


		bool  operator==(CVirtualWay  &pcOther);

		CVirtualWay();
		~CVirtualWay();

		//the offsprings pointers are returned but handling them is the task of CVirtualWaysDatabase
		int  iCross
			(
			CVirtualWay *pcFather,  CVirtualWay **pcChild1, CVirtualWay **pcChild2,
			CVirtualWayDatabase  *pCVirtualWays,
			CNETsimulator  *pcNetSim  =  NULL
			);

		int  iMutate
			(
			CVirtualWay  **pcNewWay,
			CVirtualWayDatabase  *pCVirtualWays,
			CNETsimulator  *pcNetSim  =  NULL
			);


	private:

		long  *pl_way;
		int   i_way_length;

		void  v_remove_loops_from_way();

	};//class  CVirtualWay








	class  CVirtualWaysSingleSet
	{
	friend  class  CVirtualWayDatabase;//needed for acces to virtual ways list when cloning


	public:

		CVirtualWay*  pcGetVirtualWayAtOffset(int  iOffset);
		CVirtualWay   *pcGetVirtualWay();
		bool  bGet2VirtualWaysWithLowLevelFOM(CNETsimulator  *pcNetSim, CVirtualWay  **pcMother,  CVirtualWay  **pcFather  =  NULL,  bool  bTranslated = false);


		int   iLoadVirtualWays(FILE  *pfSource, CTopologyTranslator *pcTranslator,  bool bTranslate);
		int   iInputNewVirtWay(CVirtualWay  *pcNewWay,  CTopologyTranslator  *pcTransltor,
								CVirtualWay  **pcTheSameWayAsNew = NULL);//**pcTheSameWayAsNew is used for returning an addres of the way that is the same in the database

		//information methods
		long  lGetNumberOfWays(long  **plLengthSets, int *piTableLen);
		void  vCreateReportFile(FILE  *pfReport);


		CVirtualWaysSingleSet();
		~CVirtualWaysSingleSet();


	private:


		CMyList  c_virtual_ways;

	};//class  CVirtualWaysSingleSet






	class  CVirtualWayDatabase
	{

	public:

		int   iLoadVirtualWays
			(CString  sFileName, CTopologyTranslator *pcTranslator,  bool  bTranslate);
		

		int   iCloneVirtualWays(long lStartNode = -1);
		//start node is needed when we want to generate new ways for a specialized node


		int   iInputNewVirtWay
			(CVirtualWay  *pcNewWay,  long  lStartNode,  long  lFinishNode,
			CVirtualWay  **pcTheSameWayAsNew = NULL, bool bTranslated = true);//**pcTheSameWayAsNew is used for returning an addres of the way that is the same in the database);
		

		int   iGetVirtualWaysNumber(long  lStartNode,  long  lFinishNode,  bool  bTranslated = true);
		CVirtualWay   *pcGetVirtualWay(long  lStartNode,  long  lFinishNode,  bool  bTranslated = true);
		CVirtualWay*  pcGetVirtualWayAtOffset(long  lStartNode, long lFinishNode, int iOffset, bool  bTranslated = true);
		bool  bGet2VirtualWaysWithLowLevelFOM(CNETsimulator  *pcNetSim,  long  lStartNode, long lFinishNode, CVirtualWay  **pcMother,  CVirtualWay  **pcFather  =  NULL,  bool  bTranslated = true);


		CVirtualWayDatabase();
		~CVirtualWayDatabase();



		int  iCreateReportFile(CString  sFileName);
		int  iCreateStatisticsReportFile(CString  sFileName);



	private:



		int   i_input_new_virt_way
			(CVirtualWay  *pcNewWay,  long  lTranslatedStartNode,  long  lTranslatedFinishNode,
			CVirtualWay  **pcTheSameWayAsNew);//**pcTheSameWayAsNew is used for returning an addres of the way that is the same in the database);

		int  i_clone_two_lists(CMyList  *pcStartList,  CMyList  *pcFinishList,  CMyList  *pcDestList);


		CVirtualWaysSingleSet  **pc_virtual_ways_sets;

		CTopologyTranslator  *pc_translator;


		long  l_number_of_nodes;



	};//class  CVirtualWayDatabase












	class  CMessyIndividual
	{
	friend class  CSingleTrajectorySet;
	public:
		CMessyIndividual(int  iFenotypeLength);
		~CMessyIndividual();

		double  dComputeFitness
			(
			CVirtualWay  **piCompetetiveTemplate,
			CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty,
			CNETsimulator  *pcNetSim,
			int iParentSelection
			);
		
		void  vSetGenotype(vector  <CMessyGene  *>  *pvNewGenotype);
		void  vAddGenotype(vector  <CMessyGene  *>  *pvNewGenotype);
		void  vFlushGentoype();
		void  vRemoveUnimportantGenes(CVirtualWay  **pcCompetetiveTemplate);
		void  vShowFenotypeDiffr(CVirtualWay  **pcCompetetiveTemplate, CString  sReportFileName);

		CError  eReport(FILE  *pfReport,  bool  bTemplate  =  false);
		CError  eReport
			(
			FILE  *pfReport,
			CVirtualWay  **piCompetetiveTemplate,  
			CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty,
			CNETsimulator  *pcNetSim
			);

		void  operator=(CMessyIndividual  &cOther);

		CError  eCut
			(
			double  dCutProb,  
			CMessyIndividual  *pcPart1,  CMessyIndividual  *pcPart2,
			int  *piReturnedPartsNumber
			);

		void  vSplice(CMessyIndividual  *pcSplicedIndividual);
		CError  eSplice //this individual will be a splice result...
			(
			double  dSpliceProb,  
			CMessyIndividual  *pcSplicedIndividual,
			bool  *pbSpliced
			);

		void  vMutateRemGene(double  dProbMutRemGene);
		void  vMutate
			(
			CNETsimulator  *pcNetSim, CVirtualWay  **pcCompetetiveTemplate, long  *plCapacities,
			double  dProbMut, long *plStartFinishPairs, CVirtualWayDatabase  *pcVirtualWays
			);
		void  vMutateAddGene(double  dProbMutAddGene,  int  iTemplLength, long *plStartFinishPairs, CVirtualWayDatabase  *pcVirtualWays);
		void  vLowLevelCross
			(
			long *plStartFinishPairs, CVirtualWayDatabase  *pcVirtualWays, CVirtualWay  **pcCompetetiveTemplate, 
			CNETsimulator  *pcNetSim,
			long  *plCapacities
			);
		
		void  CMessyIndividual::vLowLevelMutate
			(
			long *plStartFinishPairs, CVirtualWayDatabase  *pcVirtualWays, 
			CVirtualWay  **pcCompetetiveTemplate, 
			CNETsimulator  *pcNetSim,
			long  *plCapacities
			);

		void  vRemoveRandomGene();


		vector  <CMessyGene  *>  *pvGetGenotype()  {return(&v_genotype);};
		CVirtualWay  **pcGetFenotype()  {return(pc_fenotype);};
		CVirtualWay  **pcGetEffectiveFenotype()  {return(pc_effective_fenotype);};

		int  iGetFenotypeLength();

		bool  bCompareFenotypes(CMessyIndividual  *pcOther);

		int  iCompareAlles(CMessyIndividual  *pcOther);

		double  dGetPatternEntrophyFittnes(int  *piGeneFreqTable);

		double  dGetRankingWeighted(vector<double> *pvObjective, vector<double> *pvPenalty, double dWeight, double  *pdObjective, double  *pdPenalty);
		double  dGetRankingObjective(vector<double> *pvObjective);
		double  dGetRankingPenalty(vector<double> *pvPenalty);

	protected:
		int  i_effective_fenotype_length;

	private:

		double  d_get_ranking(vector<double> *pvRanks, double  dValue);

		void  v_create_effective_fenotype(CVirtualWay  **pcCompetetiveTemplate);
		void  v_create_fenotype();

		vector  <CMessyGene  *>  v_genotype;
		CVirtualWay  **pc_fenotype;
		CVirtualWay  **pc_effective_fenotype;
		
		int  i_fenotype_length;//information for templates usage

		bool  b_fenotype_actual;
		//bool  b_effective_fenotype_actual;

		double  d_fitness_penalized;
		double  d_fitness_pure;
		double  d_penalty_pure;
	};//class  CMessyIndividual


	class  CMessyPattern  :  public  CMessyIndividual
	{
	public:
		CMessyPattern(int  iFenotypeLength);
		~CMessyPattern();

		void  operator=(CMessyIndividual  &cMessyIndiv);
		void  operator=(CMessyPattern  &cOther);

		bool operator<(CMessyPattern  &cOther)  {return(i_pattern_multiple  <  cOther.i_pattern_multiple);};
		bool operator>(CMessyPattern  &cOther)  {return(i_pattern_multiple  >  cOther.i_pattern_multiple);};
		bool operator==(CMessyPattern  &cOther)  {return(i_pattern_multiple  ==  cOther.i_pattern_multiple);};

		int  iGetMultiple()  {return(i_pattern_multiple);};
		void  vIncMultiple()  {i_pattern_multiple++;};

		bool  bGetNew()  {if (i_old  ==  0) return(true);  return(false);};
		void  vSetOld()  {i_old++;};

		CError  eReportSimple(FILE  *pfReport);
		CError  eReport(FILE  *pfReport,  bool  bTemplate  =  false);
		CError  eReport
			(
			FILE  *pfReport,
			CVirtualWay  **piCompetetiveTemplate,  
			CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty,
			CNETsimulator  *pcNetSim
			);

	private:

		int  i_pattern_multiple;
		int  i_old;
	
	};//class  CMessyPattern  :  public  CMessyIndividual



	class  CMessyGene
	{
	friend class  CTrajectorySetsFinder;
	friend class  CSingleTrajectorySet;
	friend class  CMessyIndividual;
	public:
		CMessyGene();
		CMessyGene(CVirtualWay  *pcGeneVal,  int  iGenePos);
		CMessyGene(CMessyGene  *pcOther);
		~CMessyGene();

	private:

		CVirtualWay  *pc_gene_val;
		int  i_gene_pos;	
	};//class  CMessyGene












	class  CSingleTrajectorySet
	{
	friend class CSingleIslandPopulation;
	friend  class CTrajectorySetsFinder;
	friend class  C3LOalg;
	friend class  CIcPsoAlg;
	
	public:

		CSingleTrajectorySet();
		~CSingleTrajectorySet();

		bool  bInit
			(long *plStartFinishPairs, int  iNumberOfPairs,  CVirtualWayDatabase  *pcWaysDatabase, CNETsimulator  *pcNetSim,  CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty);
		
		void  vInitPSO_ParticleData(double  dScalingFactor, CSingleTrajectorySet  *pcNewLocalBest, CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty);
		void  vUpdatePSO(double  dScalingFactor, CSingleTrajectorySet  *pcGlobalBest, CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty);
		void  vPSOgoTowardsBest(double  dScalingFactor, CSingleTrajectorySet  *pcBest);
	private:
		void  v_supplement_distribution();
		void  v_update_velocities(CSingleTrajectorySet  *pcConsideredBest);
		void  v_update_position(double  dScalingFactor, CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty);

	public:


		//set of operators with not fully unintegrated low level
		bool  bMutate(long *plCapacities);
		bool  bCross
			(
			CSingleTrajectorySet *pcFather,  
			CSingleTrajectorySet *pcChild1, CSingleTrajectorySet  *pcChild2,  double  dRandomCrossPossibility,
			long *plCapacities
			);

		bool  bCrossLowLevel(CSingleTrajectorySet *pcOther, long *plCapacities);
		bool  bMutateLowLevel(long *plCapacities);

		
		//set of operators with highly unintegrated low level
		//LLD  =  low level desintegrated
		bool  bMutateLLD(long *plCapacities);
		bool  bCrossLowLevelLLD(long *plCapacities);
		bool  bMutateLowLevelLLD(long *plCapacities);


		void  vSetNewFOM(CFOMfunction  *pcFOMcounter)  {pc_fitness_counter  =  pcFOMcounter;};
		double  dCountFOM(CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty);//bPenalty is used to turn off the penalty when the cpacity is extended
		double  dCountFOM_Baldwin(CSingleTrajectorySet  *pcContext,  CFOMfunction *pcFOMcounter, long *plCapacities,  long  lPenalty, vector<int>  *pvOrder = NULL);
		private: double  d_optimize_virt_way_greedy(int  iVirtWayOffset,  CVirtualWay  *pcNewVirtWay, CFOMfunction *pcFOMcounter, long *plCapacities,  long  lPenalty);
		private: double  d_switch_virt_way(int  iVirtWayOffset,  CVirtualWay  *pcNewVirtWay, CFOMfunction *pcFOMcounter, long *plCapacities,  long  lPenalty);
		private: void  v_create_opt_order(vector<int>  *pvOrder);
	public:
		void  vSaveScraps(CString  sDest);
		void  vSaveScraps(FILE  *pfDest);
		void  vGetLinkageScraps(CSingleTrajectorySet  *pcContext,  CSingleTrajectorySet  *pcBuffer, CSingleTrajectorySet  *pcBest, CFOMfunction *pcFOMcounter, long *plCapacities,  long  lPenalty, vector<int>  *pvOrder = NULL);
		void  vCreateLT(int  iLinkageScrap);
		void  vCreateLT_Random(int  iLinkageScrap);
		int  iOptimalMixing(C3LOalg  *pcMethod, CSingleTrajectorySet  *pcSource, CLTree  *pcLTree, CSingleTrajectorySet  *pcBuffer, double dMutatePossibilityLowLevel, CFOMfunction *pcFOMcounter, long *plCapacities,  long  lPenalty);
		int  iOptimalMixing(C3LOalg  *pcMethod, CSingleTrajectorySet  *pcSource, CLTree  *pcLTree, CLTreeNode  *pcLTreeNode, CSingleTrajectorySet  *pcBuffer, double dMutatePossibilityLowLevel, CFOMfunction *pcFOMcounter, long *plCapacities,  long  lPenalty);



		double  dGetRankingWeighted(vector<double> *pvObjective, vector<double> *pvPenalty, double dWeight, double  *pdObjective, double  *pdPenalty, CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty);
		double  dGetBestResultOnTheRunFitness()  {return(d_best_solution_on_the_run_fitness);}

		CSingleTrajectorySet&  operator=(CSingleTrajectorySet &pcOther);

		bool  operator==(CSingleTrajectorySet *pcOther);
		void  vCopy(CSingleTrajectorySet *pcOther);
		void  vTakeRandomGenes(CSingleTrajectorySet *pcOther);

		void  vGetPathStats(double  *pdAvr, int  *piMin, int  *piMax);
		CString  sReportPathLens(int  iMaxPathLen);
		void  vReport(FILE  *pfReportFile,  bool  bFullReport,  long *plCapacities, long  lPenalty);
		//void  vSetFOMLevel(double  dNewFOMLevel)  {d_fom_level  =  dNewFOMLevel;};
		double  dGetFOMLevel();


		void  vSetWhenCreated(long  lGenNum)  {l_population_when_created  =  lGenNum;};
		long  lGetWhenCreated()  {return(l_population_when_created);};


		int   iLoadFromOldIniFile(CTopologyTranslator  *pcTranslator, FILE  *pfSource,  long  *plCapacities,  bool  bTranslate);
		int   iLoadFromIniFile(CTopologyTranslator  *pcTranslator, FILE  *pfSource,  long  *plCapacities,  bool  bTranslate);
		int   iLoadFromFulFile(CTopologyTranslator  *pcTranslator, FILE  *pfSource,  long  *plCapacities);

		bool  b_set_all_conns(long *plCapacities);


		void  vRandomize(long *plCapacities, double  dProbInitMut);
		void  vRandomize_LLDSI(CTrajectorySetsFinder  *pcVGA);

		
		void  vRestoreCT(CTrajectorySetsFinder  *pcVGA);

		void  vSaveBestSolutionOnTheRun(long *plCapacities,  long  lPenalty);
		void  vSaveBestSolutionOnTheRun(CTrajectorySetsFinder  *pcVGA);
		CLTree  *pcGetLTree()  {return(pc_ltree);}
	private:

		long  l_get_start_node(CString  sLine);
		long  l_get_end_node(CString  sLine);
		long  l_get_node_num(CString  sLine);
		long  l_get_node(CString  sLine, int iNodeIndex);

		
		CNETsimulator  *pc_net_sim;
		CFOMfunction  *pc_fitness_counter;

		CVirtualWayDatabase  *pc_virtual_ways;

		long  *pl_start_finish_pairs;
		int   i_number_of_pairs;

		bool  b_fom_lvl_actual;
		double  d_fom_level_penalized;
		double  d_fom_level_pure;
		double  d_penalty_pure;


		long    l_population_when_created;//statistical information
		bool    b_capacity_extending;

		int  i_p3_level;
		CLTree  *pc_ltree;
		vector<CLinkageScrap>  v_link_scraps;
		vector<int>  v_opt_order;
		CVirtualWay  **pc_trajectories;

		CMessyIndividual  *pc_best_found;
		CMessyIndividual  *pc_infection_history;//history of all infections in a row

		CMessyIndividual  *pc_tool;//for ranked fitness computation

		//only for ranking use at virus crossing...
		vector<double>  v_objective;
		vector<double>  v_penalty;


		//PSO-like data
		double  d_ranking_objective_weight;


		vector<C_IC_PSO_Distribution *>  v_pso_distributions;
		CSingleTrajectorySet  *pc_local_best;


		//vmea
	public:
		CError  eVirConfigure
			(
			bool  bGlueInfectionRows,
			int  iVirusGen,  int  iVirusPopSize,
			double  dPopReductionJuxtapositional,
			double  dVirProbCut,  double  dVirProbSplice,  double  dVirProbMut,
			double  dProbMutRemGene,	double  dProbMutAddGene,
			double  dProbLowLevelCross, double  dProbLowLevelMut,
			double  dProbInitMut
			);

		int  iGetNumberOfDiffrGenes(CMessyPattern  *pcPattern,  CSingleTrajectorySet  *pcOther);
		int  iGetNumberOfDiffrGenesToOtherBest(CMessyPattern  *pcPattern,  CSingleTrajectorySet  *pcOther);

		CMessyPattern*  pcGetPatternByDifference(CSingleTrajectorySet  *pcOther);
		bool  bIsTheSame(CSingleTrajectorySet  *pcOther);
		bool  bGetDifferences(CSingleTrajectorySet  *pcOther, CMessyPattern  *pcPattern);

		bool  bGetVirgin()  {return(b_virgin_init);};

		CError  eVirReGeneratePopulation(CTrajectorySetsFinder  *pcVGA,  bool  bVirInitDifferentToTemplate);//the template and CT is randomly chosen for every virus

		vector  <CMessyIndividual  *>  *pv_population;

		CError  eVirRun(vector  <CMessyPattern  *>  *pvInfectionHistory,  CTrajectorySetsFinder  *pcVGA,  int  *piInitDone, int iParentSelection, bool bRestoreCTifNoImprovement = true);

		CError  e_juxtapositional_phase(int  *piGenNum,  vector  <CMessyPattern  *>  *pvInfectionHistory, CTrajectorySetsFinder  *pcVGA, int iParentSelection, bool bRestoreCTifNoImprovement = true);

		CMessyIndividual*  pc_get_parent_tournament(int  iTournamentSize,  long  *plCapacities, long  lPenalty,  int iParentSelection = 0, bool  bBetterTakesAll  =  false);
		CMessyIndividual*  pc_get_parent_tournament(int  iIndiv1Offset,  int  iIndiv2Offset,  long  *plCapacities, long  lPenalty, int iParentSelection = 0, bool  bBetterTakesAll  =  false);

		void  v_find_best_indiv(CTrajectorySetsFinder  *pcVGA, int iParentSelection);

		void  v_try_pattern_and_template_insert(CTrajectorySetsFinder  *pcVGA,  int  *piInitDone,  long  *plCapacities, long  lPenalty);

		void  v_infect_competetive_template(CTrajectorySetsFinder  *pcVGA, CMessyIndividual  *pcBestFound, long  *plCapacities, long  lPenalty);

		CError  eReport(FILE  *pfReport);

		CMessyIndividual  *pcGetLastInfection()  {return(pc_best_found);};
		CMessyIndividual  *pcGetInfectionHistory()  {return(pc_infection_history);};

		double  dGetCompTemplateFitnessBeforeCrossing()  {return(d_templ_fittness_before_crossing);};

		void  vSetInfectionHistory(CMessyIndividual  *pcInfectionHistory);

	

	private:
		bool  b_virgin_init;

		bool  b_glue_infection_rows;
		double  d_prob_cut;
		double  d_prob_splice;
		double  d_prob_mut;

		double  d_prob_mut_rem_gene;
		double  d_prob_mut_add_gene;
		double  d_prob_low_level_cross;
		double  d_prob_low_level_mut;
		double  d_prob_init_mut;

		int  i_generations;
		int  i_pop_size;

		double  d_pop_reduction_juxtapositional;

		CVirtualWay  **pc_competetive_template_before_insert;

		double  d_templ_fittness_before_insert;
		double  d_templ_fittness_before_crossing;//used for remembering the fittness before crossing 2 CmGA individuals; SET OUTSIDE, BY CVirusGA


		CVirtualWay  **pc_best_solution_on_the_run;
		double  d_best_solution_on_the_run_fitness;


	};//class  CSingleTrajectorySet



	class  CSingleIslandPopulation
	{
	friend class CTrajectorySetsFinder;
	public:
		CSingleIslandPopulation(CTrajectorySetsFinder  *pcParent);
		~CSingleIslandPopulation();

		CError  eCreatePop(long lPopulationNumberDiv4, long lPenalty);
		CError  eCreatePop
			(long lPopulationNumberDiv4, long lPenalty, vector  <CMessyPattern  *>  *pvPatternPool, vector  <CSingleIslandPopulation  *>  *pvIslands);
		CError  eCreatePop
			(long lPopulationNumberDiv4, long lPenalty, double dNewCtDisturbedGeneDisturbedProb, vector  <CSingleIslandPopulation  *>  *pvIslands);

		CError  eRunPop
			(
			System::Windows::Forms::ListBox *  listComm,
			int  iIsland, 
			long  lPenalty,
			double  dCrossPossibility,  double  dMutatePossibility,
			double  dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
			double  dRandomCrossPossibility,
			int iLinkageGenWay,
			long lGenNum
			);

	private:
		CSingleTrajectorySet  *pc_island_pop;
		CSingleTrajectorySet  *pc_best;
		bool  b_best_improved;
		double d_avr_fit;
		int  i_pop_size;
		CTrajectorySetsFinder  *pc_parent;
	};//class  CSingleIslandPopulation



	class  C_IC_PSO_SingleGeneProbabilityDistribution
	{
		friend class C_IC_PSO_Distribution;
		friend class CSingleTrajectorySet;
	public:
		C_IC_PSO_SingleGeneProbabilityDistribution();
		~C_IC_PSO_SingleGeneProbabilityDistribution();

	private:
		CVirtualWay  *pc_virt_way;
		double  d_probability;
		double  d_speed;
	};//class  C_IC_PSO_SingleGeneProbabilityDistribution


	class  C_IC_PSO_Distribution
	{
		friend class CSingleTrajectorySet;
	public:
		C_IC_PSO_Distribution();
		~C_IC_PSO_Distribution();

		void  vAddVWay(CVirtualWay *pcNewWay, double  dProbability = -1, double  dSpeed = -1);
		double  dGetProbabilityForGeneValue(CVirtualWay *pcWay);
		void  vUpdateSpeed(double  dProbabilityOfTheBestValue);
		void  vApplySpeed();
		void  vGoTowardsBest(double  dScalingFactor, CVirtualWay *pcWayToGoTowards);

		void  vNormalize();
		CVirtualWay*  pcGetWay();

	private:
		vector<C_IC_PSO_SingleGeneProbabilityDistribution *>  v_probabilities;	
	};//class  C_IC_PSO_Distribution

	class  CLTNodePair
	{
	public:
		bool  bNodeInside(CLTreeNode  *pcNodeToCheck)  {if  (pc_node_0 == pcNodeToCheck)  return(true); if  (pc_node_1 == pcNodeToCheck)  return(true); return(false);};

		int  iReplaceNodeWithNode(CLTreeNode  *pcNodeToCheck, CLTreeNode  *pcNewNode);

		CLTreeNode  *pc_node_0;
		CLTreeNode  *pc_node_1;
		double  d_dist;		
	};//class  CLTNodePair

	class  CLTreeNode
	{
		friend class  CLTree;
	public:
		CLTreeNode() {i_succ_crossings=0;};
		~CLTreeNode() {};

		CString  sGetAsString();
		double  dGetDist(CLTreeNode  *pcOtherNode, CDSM *pdDsm);
		bool  bAnyCommonGenes(CLTreeNode  *pcOther);
		bool  bDoIContain(int iOffset);

		CLTreeNode  *pcJoinNodes(CLTreeNode  *pcOther);

		int  iGetSuccCross() {return(i_succ_crossings);};
		void  vIncrSuccCross()  {i_succ_crossings++;};
		vector<int>  *pvGetGenes()  {return(&v_genes);};
	private:
		vector<int>  v_genes;
		int  i_succ_crossings;
	};//class  CLTreeNode


	class  CLTree
	{
	public:
		CLTree() {};
		~CLTree();

		void  vCopyFrom(CLTree  *pcSource);
		void  vFlushTree();
		void  vShuffleNodes();

		vector<CLTreeNode *>  *pvGetNodes()  {return(&v_nodes);};
		bool  bCreateLT(vector<CLinkageScrap>  *pvLinkScraps, int iLinkageScrap, int iNumberOfPairs);
		void  vGenerateRandomLT(int  iLinkageScrap, int iNumberOfPairs);

		bool  bCreateFromDSM(CDSM  *pcDsm);
		void  vSave(CString  sDest);
		void  vSave(FILE  *pfDest);

	private:
		
		vector<CLTreeNode *>  v_nodes;
	
	};//class  CLTree


	class  CDSM
	{
		friend class CLinkageScrap;
		friend class CLTreeNode;
	public:
		CDSM();
		~CDSM();
		bool  bSetSize(int  iSize);

		int  iGetSize()  {return(i_size);};

		bool  bZeroDSM();
		bool  vFillRandomly();

		void  vSave(CString  sDest);
		void  vSave(FILE  *pfDest);

	private:
		double  **pd_dsm;
		int  i_size;
	};//class  CDSM
	
	class CLinkageScrap
	{
	public:
		CLinkageScrap() {};
		~CLinkageScrap() {};

		bool  bUpdateDSM(CDSM  *pcDest);
		void  vSetScrap(vector<int> *pvLinkScrap) {v_link_scrap = *pvLinkScrap;};
		void  vSave(FILE  *pfDest);
		vector<int>  *pvGetScrap()  {return(&v_link_scrap);}
	private:

		vector<int>  v_link_scrap;
	
	};//class CLinkageScrap


	class  C3LOalg
	{
	public:
		C3LOalg(CTrajectorySetsFinder  *pcParent);
		~C3LOalg();

		CError  eConfigure(long lPopulationNumberDiv4, int  iLeaveIndAtLevel, int iRandomLinkage, int iLinkageScrap, int  iLinkageScrapCreateEffectScrap,  int iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScrap, long lPenalty);
		
		CError  eRunPopFlat
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lPenalty,
			double  dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
			long lGenNum
			);

		CError  eRunPop
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lPenalty,
			double  dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
			long lGenNum
			);

		int  iGetPopSize()  {return(v_pop.size());}
		CSingleTrajectorySet  *pcGetBest() {return(pc_best);}

		bool  bCheckPopulationIfExists(CSingleTrajectorySet  *pcNewInd);
		int  iGetIndNumber();

		vector<CLinkageScrap>  *pvGetGlobalScraps()  {return(&v_link_scraps_global);}
		void  vIncSuccOms()  {i_succ_oms++;};

		int  iLinkageScrapCreateEffectScrap() {return(i_linkage_scrap_create_effect_scrap);}
		int  iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScracp() {return(i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp);}

	private:
		void  v_add_level(CSingleTrajectorySet  *pcNewInd, long  lPenalty);
		bool  b_run_for_level(int  iLevel, CSingleTrajectorySet  *pcNewInd, double dMutatePossibilityLowLevel, long  lPenalty);

		CLTree  c_ltree_global;
		vector<CLinkageScrap>  v_link_scraps_global;


		CSingleTrajectorySet*  pc_add_new_ind(vector<CSingleTrajectorySet *> *pvDest, long  lPenalty);
		vector<CSingleTrajectorySet *> v_pop_flat;


		vector<vector<CSingleTrajectorySet *>> v_pop;
		CSingleTrajectorySet  *pc_best;
		CSingleTrajectorySet  *pc_best_prev;
		CSingleTrajectorySet *pc_ind_buf;

		int  i_random_linkage;
		int  i_linkage_scrap;
		int  i_linkage_scrap_create_effect_scrap;
		int  i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp;
		int  i_the_same_checks;
		int  i_succ_oms;
		int  i_leave_ind_at_level;

		bool  b_best_improved;
		double d_avr_fit;
		CTrajectorySetsFinder  *pc_parent;
	};//class  C3LOalg




	class  CIcPsoAlg
	{
	public:
		CIcPsoAlg(CTrajectorySetsFinder  *pcParent);
		~CIcPsoAlg();

		CError  eConfigure(int  iPopSize, double dPsi_1, double dPsi_2, double dOmega, double dScalingFactor, int  iNoImprovementsUntilReset, long lPenalty);


		CError  eRunIteration
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lPenalty,
			double  dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
			long lGenNum
			);

		int  iGetPopSize()  {return(v_pop.size());}
		CSingleTrajectorySet  *pcGetBest() {return(pc_best);}


	private:
		void  v_update_global_best(CFOMfunction  *pcFOMcounter, long *plCapacities,  long  lPenalty);


		vector<CSingleTrajectorySet *> v_pop;
		CSingleTrajectorySet  *pc_best;

		int i_no_best_improvement_iterations;

		double d_psi_1;
		double d_psi_2;
		double d_omega;
		int  i_no_improvements_until_reset;
		int  i_pop_size;
		double  d_scaling_factor;

		bool  b_best_improved;
		double d_avr_fit;
		CTrajectorySetsFinder  *pc_parent;
	};//class  CIcPsoAlg


	





	#define  VGA_PARAM_IM_ISLAND_NUMBER		"island number"
	#define  VGA_PARAM_IM_MIGRATION_FREQ		"migration freq"
	#define  VGA_PARAM_IM_LINKAGE_GEN		"linkage generation (0-nolinkage; 1-at migration; 2-at best improvement)"

	#define  VGA_PARAM_IM_LINKAGE_GEN_NO_LINKAGE	0
	#define  VGA_PARAM_IM_LINKAGE_GEN_NO_AT_MIGRATION	1
	#define  VGA_PARAM_IM_LINKAGE_GEN_NO_AT_BEST_IMPROVEMENT	2

	#define  VGA_PARAM_MAX_TIME			"max time"
	#define  VGA_PARAM_JUXTA_GENERATIONS	"juxta generations"
	#define  VGA_PARAM_POP_SIZE			"population size"
	#define  VGA_PARAM_INFECTED_POP_SIZE	"infected pop size"
	#define  VGA_PARAM_PROB_CROSS		"crossing"
	#define  VGA_PARAM_STATIC_CROSS		"static crossing"
	#define  VGA_PARAM_CROSS_TYPE		"crossing type//0-tournament size 2; 1-tournament size 2 + chance for tournament size 3 with difference-fitness"
	#define  VGA_PARAM_CHANCE_FOR_3_PARENT_DIFFR_TOURNAMENT		"chance for size 3 diffrence fitness tournament//important ONLY for tournament type 1"
	#define  VGA_PARAM_GLUE_INFECTIONS	"glue infections"
	#define  VGA_PARAM_TEMPL_FITNESS_CHECK	"template fitness check"
	#define  VGA_PARAM_PATTERN_POOL_SIZE	"pattern pool size"
	#define  VGA_PARAM_SAME_PATTERN_CHECK	"the same pattern check"
	#define  VGA_PARAM_PREFERRED_PATTERN_LENGTH	"preferred pattern length"
	#define  VGA_PARAM_MINIMAL_PATTERN_LEN	"minimal pattern length"
	#define  VGA_PARAM_LEN_OR_ENTROPHY	"length or entrophy at pattern number check"

	#define  VGA_PARAM_P3_LEAVE_COPY_AT_LEVEL  "p3 leave copy at level"
	#define  VGA_PARAM_RANDOM_LINKAGE  "randomLinkage"
	#define  VGA_PARAM_LINKAGE_SCRAPS  "ScrapLinkage"
	#define  VGA_PARAM_LINKAGE_SCRAPS_EFFECT_SCRAP  "ScrapLinkageEffectScrap"
	#define  VGA_PARAM_LINKAGE_SCRAPS_EFFECT_SCRAP_PROVOKING_SCRAP  "ScrapLinkageEffectScrapPlusProvokingScrap"

	#define  VGA_PARAM_PSO_PSI_1  "Psi_1"
	#define  VGA_PARAM_PSO_PSI_2  "Psi_2"
	#define  VGA_PARAM_PSO_OMEGA  "Omega"
	#define  VGA_PARAM_PSO_SCALING_FACTOR  "scalingFactor"
	#define  VGA_PARAM_PSO_GB_NO_IMPROVEMENT_POP_RESET "GBestNoImprovementPopReset"
	


	#define  VGA_PARAM_USE_TEMPL_AT_VIRUS_INIT		"use templates at virus init"
	#define  VGA_PARAM_VIR_INIT_DIFFERENT_TO_TEMPLATE		"init viruses genes as opposite to competetive template"
	
	#define  VGA_PARAM_VIR_GENERATIONS		"virus generations"
	#define  VGA_PARAM_VIR_POP			"virus population"
	#define  VGA_PARAM_VIR_POP_RED		"virus population reduction"
	#define  VGA_PARAM_VIR_PROB_CUT		"virus prob cut"
	#define  VGA_PARAM_VIR_PROB_SPLICE	"virus prob splice"
	#define  VGA_PARAM_VIR_PROB_MUT		"virus prob mutation"
	#define  VGA_PARAM_VIR_REM_GENE		"virus prob rem gene"
	#define  VGA_PARAM_VIR_ADD_GENE		"virus prob add gene"
	#define  VGA_PARAM_VIR_LOW_CROSS	"virus prob low cross"
	#define  VGA_PARAM_VIR_LOW_MUT		"virus prob low mut"
	#define  VGA_PARAM_VIR_INIT_MUT		"virus prob init mut"

	#define  VGA_PARAM_VIR_VIRGINITY_ROUNDS  "virus virginity rounds"
		

	#define  VGA_PARAM_FMGA_POP_RED_RATE		"fmga primordial pop red rate"
	#define  VGA_PARAM_FMGA_POP_RED_PERIOD		"fmga primordial pop red period"
	#define  VGA_PARAM_FMGA_INDIV_TO_CHECK		"fmga primordial individuals to check"
	#define  VGA_PARAM_FMGA_THRESHOLD_MULTIPLE		"fmga primordial threshold multiple"



	class  CTrajectorySetsFinder
	{
	friend  class  CSingleTrajectorySet;
	friend class CSingleIslandPopulation;
	friend class C3LOalg;
	friend class CIcPsoAlg;
	
	public:

		CError  eGetIniFitness(CString  sIniFile, double  *pdFitness, long  lPenalty);
		int   iInputTrajectorySetToFind
			(long  *plNodePairs,  long  *plCapacities,  int  iNumberOfPairs);


		int  iResultsCompare
			(
			System::Windows::Forms::ListBox *  listComm,
			CString  sReportFileName,
			CString  sTopologyFile, CString  sConFile, CString  sConName, CString  sFOMFuncMain, CString  sFOMFunc2,

			CString  sAlg1Name, CString  sAlg1File,
			CString  sAlg2Name, CString  sAlg2File,
			long  lPenalty
			);

		int  iFindBestSet_Standard_EA
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lNumberOfGenerations, long  lPopulationNumberDiv4, double dTimeRestriction, 
			double dCrossPossibility,  double  dMutatePossibility,
			double dRandomCrossPossibility,//it affects high level crossing way
			long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
						//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
			CString  sIniFile,
			long  lNumberOfSpeciesToPresent,  CString  sReportFileName,
			CString  sPopulationFOMtrackingFile, FILE *pfResFile,
			bool  bUseOldPopulation ,
			long  lCapaIncr,  long  lCapaGenIncr,
			 
			//brainstorming
			long  lBrainAvrLen,  double  dBrainMinInc,
			long  lBrainTimeLen,  long  lBrainFinishTime,
			long  lBrainMinBreak
			);

		int   iFindBestSet_1_0
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lNumberOfGenerations, long  lPopulationNumberDiv4, double dTimeRestriction, 
			double dCrossPossibility,  double  dMutatePossibility,
			double dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
			double dRandomCrossPossibility,//it affects high level crossing way
			long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
						//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
			CString  sIniFile,
			long  lNumberOfSpeciesToPresent,  CString  sReportFileName,
			CString  sPopulationFOMtrackingFile, FILE *pfResFile,
			bool  bUseOldPopulation ,
			long  lCapaIncr,  long  lCapaGenIncr,
			 
			//brainstorming
			long  lBrainAvrLen,  double  dBrainMinInc,
			long  lBrainTimeLen,  long  lBrainFinishTime,
			long  lBrainMinBreak
			);


		int   iFindBestSet_1_1
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lNumberOfGenerations, long  lPopulationNumberDiv4, double dTimeRestriction, 
			double dCrossPossibility,  double  dMutatePossibility,
			double dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
			double dRandomCrossPossibility,//it affects high level crossing way
			long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
						//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
			CString  sIniFile,
			long  lNumberOfSpeciesToPresent,  CString  sReportFileName,
			CString  sPopulationFOMtrackingFile, FILE *pfResFile,
			bool  bUseOldPopulation ,
			long  lCapaIncr,  long  lCapaGenIncr,
			 
			//brainstorming
			long  lBrainAvrLen,  double  dBrainMinInc,
			long  lBrainTimeLen,  long  lBrainFinishTime,
			long  lBrainMinBreak
			);

		
		int   iFindBestSet_2_0_or_2_1_or_2_2
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lNumberOfGenerations, long  lPopulationNumberDiv4, double dTimeRestriction, 
			double dCrossPossibility,  double  dMutatePossibility,
			double dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
			double dRandomCrossPossibility,//it affects high level crossing way
			long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
						//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
			CString  sIniFile,
			long  lNumberOfSpeciesToPresent,  CString  sReportFileName, 
			CString  sPopulationFOMtrackingFile,FILE  *pfResFile, 
			bool  bUseOldPopulation ,
			long  lCapaIncr,  long  lCapaGenIncr,
			 
			//brainstorming
			long  lBrainAvrLen,  double  dBrainMinInc,
			long  lBrainTimeLen,  long  lBrainFinishTime,
			long  lBrainMinBreak,
			int  iAlgorithmVersion  //0- 2.0; 1- 2.1
			);


		CError  eFindBestSet_3LO_alg
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lPenalty,
			CString  sIniFile,
			CString  sReportFileName,
			CString  sFileSummarize,
			double dTimeRestriction, 

			long lPopulationNumberDiv4, 
			int  i_p3_leave_ind_at_level,
			int  iRandomLinkage, int iLinkageScrap, int  iLinkageScrapCreateEffectScrap,  int iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScrap,
			double dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel
			);


		CError  eFindBestSet_IC_PSO
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lPenalty,
			CString  sIniFile,
			CString  sReportFileName,
			CString  sFileSummarize,
			double dTimeRestriction, 

			int  iPopSize, 
			double dPsi_1, double dPsi_2, double dOmega,
			double  dScalingFactor,
			int  iNoImprovementsUntilReset,

			double dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel
			);
	

		CError  eFindBestSet_IslandGa
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lPenalty,
			CString  sIniFile,
			CString  sReportFileName,
			CString  sFileSummarize,
			double dTimeRestriction, 

			int  iPatternPoolSize, int  iMinimalTemplateLength,

			int  iCtStrategy,
			int  iLinkageGenWay, int iMigrationFreq, 
			long lPopulationNumberDiv4, 
			double dCrossPossibility,  double  dMutatePossibility,
			double dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
			double dRandomCrossPossibility,//it affects high level crossing way			

			int  iNewCtDisturbedCopy, int iNewCtDisturbedLLDSI,
			double  dNewCtDisturbedGeneDisturbedProb
			);

		CError  eFindBestSet_vmEA
			(
			System::Windows::Forms::ListBox *  listComm,
			long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
						//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
			CString  sIniFile,
			CString  sReportFileName,
			CString  sFileSummarize,



			int  iGen,
			bool  bGlueInfectionRows,//it glueas all infection in a row until the individual is stucked
			bool  bFitnessChangeTemplCheck,
			int  iPatternPoolSize,
			int  iTheSameTemplateCheck,//the number of templates checked with new. If any is the same, new template is NOT accepted
			int  iPreferredTemplateLength,
			int  iMinimalTemplateLength,
			bool  bPatternCheckLengthEntophy,

			bool  bUseTemplatesAtVirusPopInit,

			int  iVirusGen,
			int  iVirusPopSize, 
			double  dPopReductionJuxtapositional,
			double  dVirProbCut,  double  dVirProbSplice,
			double  dVirProbMut,
			double  dVirProbMutRemGene,
			double  dVirProbMutAddGene,
			double  dVirProbLowCross,
			double  dVirProbLowMut,
			double  dVirProbInitMut,
			int  iVirginityRounds,
			int  iNoNewCt,
			int  iParentSelection,
			int  iNewCtDisturbedCopy,
			int  iNewCtDisturbedLLDSI,
			double  dNewCtDisturbedGeneDisturbedProb
			);





		//Virtual way database loader
		int   iLoadVirtualWays(CString  sFileName,  bool  bTranslate = true);
		int   iCloneVirtualWays(long  lStartNode = -1)  
					{
						if  (lStartNode  ==  -1)
							return(c_virtual_ways.iCloneVirtualWays(lStartNode));
						else
							return(c_virtual_ways.iCloneVirtualWays(c_translator.lTranslateLinkNum(lStartNode)) );
					};
		int   iCreateVirtualWayReportFile(CString  sFileName)  
					{return(c_virtual_ways.iCreateReportFile(sFileName));};

		int   iSetFOMfunction(CString  sFuncName,  CString  sFileName = "") {return(c_translator.iSetFOMfunction(sFuncName,sFileName));};


		//topology loader
		int   iLoadNetTopology(CString  sFileName);
		int   iCreateTopologyReportFile(CString  sFileName)  
					{return(c_translator.iCreateReportFile(sFileName));};
		bool  bAllowCapacityOverloading(bool  bAllow)  
					{return(c_translator.bAllowCapacityOverloading(bAllow));};


		int   iCreateBasicVirtualDatabaseFile(CString  sFileName)
					{return(c_translator.iCreateBasicVirtualDatabaseFile(sFileName));};

		int  iGetShortestWays(int  iShortestWaysNumber, System::Windows::Forms::ListBox *  listComm = NULL);
		int  iGetShortestWaysForNodes(int iStartNodeId, int iFinishNodeId, int  iShortestWaysNumber, vector <long *> *pvWays, vector <long> *pvWaysLenghts)
			{return(c_translator.iGetShortestWaysForNodes(iStartNodeId, iFinishNodeId, iShortestWaysNumber, pvWays, pvWaysLenghts));};
		
		bool  b_the_same_templates_check(CMessyIndividual  *pcTemplCandidate);
			
		CTrajectorySetsFinder();
		~CTrajectorySetsFinder();


	private:


		CVirtualWayDatabase  c_virtual_ways;
		CTopologyTranslator  c_translator;



		//variables for genetic algorithm:
		long  *pl_start_finish_pairs;
		long  *pl_capacities;
		int   i_number_of_pairs;

		
		vector  <CSingleIslandPopulation  *>  v_islands;

		CSingleTrajectorySet  *pc_population;
		CSingleTrajectorySet  *pc_new_population;
		CSingleTrajectorySet  *pc_best_species;


		//double  d_population_fom;
		long  l_population_number;
		CBrainStormSupervisor  c_brain_storm_superv;

		//genetic algorithm methods & tools
		bool  b_init_population(CSingleTrajectorySet  *pcPopulation, long lPopSize, long  lPenalty);
		bool  CTrajectorySetsFinder::b_input_defined_specie
			(
			CSingleTrajectorySet  *pcDefinedSpecie, CString  sIniFile,  bool  bTranslate
			);
		bool  b_input_defined_species(CString  sIniFile,  bool  bTranslate = true);
		bool  b_count_fom(CSingleTrajectorySet *pcPopulation, long lPopSize, double *pdAvrPopFitness, long  lPenalty);
		bool  b_select_best_species(CSingleTrajectorySet  *pcPopulation, long lPopSize, long  lNumberOfSpeciesToSelect, CSingleTrajectorySet **pcThisPopBest = NULL);
		void  v_input_best_species(long  lNumberOfSpecies);

		bool  b_cross_population_tournament(CSingleTrajectorySet  **pcPopulation, long lPopSize, double  dCrossPossibility,  double  dRandomCrossPossibility, long lGenNum, long  lPenalty);
		bool  b_cross_population(double  dCrossPossibility,  long  lGenNum,  double  dRandomCrossPossibility,  double dPopFitAvr, double dFOMmodifier);
		bool  b_cross_population_1_1(double  dCrossPossibility,  long  lGenNum,  double  dRandomCrossPossibility,  double dPopFitAvr, double dFOMmodifier);
		bool  b_mutate_population(CSingleTrajectorySet  *pcPopulation, long lPopSize, double  dMutatePossibility,  long  lGenNum);
		bool  b_mutate_population_2_0(double  dMutatePossibility,  long  lGenNum);
		bool  b_cross_population_low_level(double  dCrossPossibility, long  lGenNum,  double dPopFitAvr, double dFOMmodifier);
		bool  b_cross_population_low_level_2_0(double  dCrossPossibility, long  lGenNum,  double dPopFitAvr, double dFOMmodifier);
		bool  b_cross_population_low_level_2_1(double  dCrossPossibility, long  lGenNum,  double dPopFitAvr, double dFOMmodifier);
		bool  b_cross_population_low_level_2_1_tournament(CSingleTrajectorySet  **pcPopulation, long lPopSize, double  dCrossPossibility, long  lGenNum);
		bool  b_mutate_population_low_level(CSingleTrajectorySet  *pcPopulation, long lPopSize, double  dMutatePossibility,  long  lGenNum);
		bool  b_mutate_population_low_level_2_0(double  dMutatePossibility,  long  lGenNum);

		void  v_find_parents(long *plMother, long  *plFather,  double dPopFitnessAvr, double  dFOMmodifier);
		void  v_find_parents_tournament(CSingleTrajectorySet *pcPopulation, long lPopSize,  long *plMother, long  *plFather);
		long  l_find_one_parent(double  dFitnessAvr, double dFOMmodifier);
		long  l_find_one_parent_tournament(CSingleTrajectorySet *pcPopulation, long lPopSize);


		//report for genetic algorithm
		int  i_create_report_files(CString  sFileName, FILE  *pfResFile,  double  dFitAvr, long lNumberToPresent, long  lPenalty);

		//input files methods
		int  i_check_header(CString  sIniFile);





		//vmEA data
		long  l_penalty;
		vector  <CSingleTrajectorySet  *>  v_memo_cts;
		vector  <CSingleTrajectorySet  *>  *pv_population;
		vector  <CMessyPattern  *>  *pv_pattern_pool;
		void  v_add_new_ct(CString  sIniFile, int iCtStrategy);
		void  v_remove_the_same_ct();
		void  v_remove_all_ct_except_best();
		void  v_remove_all_ct_except_best_and_remember();
		void  v_remove_all_ct_except_best_and_remember_and_remove_one_randomly();
		

		void  vSaveParameters3LO_ltga(FILE  *pfReport);
		void  vSaveParameters_IcPso(FILE  *pfReport);
		void  vSaveParameters(FILE  *pfReport);

		public: CMessyPattern*  pc_get_random_pattern();
				CSingleTrajectorySet*  pc_get_parent_tournament_normal(int  iIndiv1Offset,  int  iIndiv2Offset,  bool  bBetterTakesAll  =  false);
				CSingleTrajectorySet*  pc_get_parent_tournament_normal(int  iTournamentSize,  bool  bBetterTakesAll  = false);
				CSingleTrajectorySet*  pc_get_parent_tournament(bool  bBetterTakesAll  =  false);
				CSingleTrajectorySet*  pc_get_parent_tournament_normal_for_pattern_different(CMessyPattern  *pcPattern,  CSingleTrajectorySet  *pcParentTaker);
		private:

		void  v_get_new_patterns();

		void  v_pattern_number_control_new(bool  bLengthEntrophy);
		void  v_islands_number_manage(int  iCtStrategy, long lPopulationNumberDiv4, long lPenalty);
		void  v_standard_migration(System::Windows::Forms::ListBox *  listComm, int  iPopSize, long lPenalty, int iLinkageGenWay);
		void  v_im_get_linkage_at_migration(System::Windows::Forms::ListBox *  listComm);
		CSingleTrajectorySet  *pc_get_random_best(CSingleTrajectorySet  *pcPopulation, int  iPopSize, long lPenalty);
		void  v_execute_evolution_for_single_pop
			(
			System::Windows::Forms::ListBox *  listComm,
			CSingleTrajectorySet **pcBest, double *pdPopAvrFitness,
			CSingleTrajectorySet **pcPopulation, long lPopulationSizeDiv4,
			int  iIsland, 
			long  lPenalty,
			double  dCrossPossibility,  double  dMutatePossibility,
			double  dCrossPossibilityLowLevel,  double  dMutatePossibilityLowLevel,
			double  dRandomCrossPossibility,
			long lGenNum
			);


		CError  eConfigure
			(
			int  iGen,
			bool  bGlueInfectionRows,//it glueas all infection in a row until the individual is stucked
			bool  bFitnessChangeTemplCheck,
			int  iPatternPoolSize,
			int  iTheSameTemplateCheck,//the number of templates checked with new. If any is the same, new template is NOT accepted
			int  iPreferredTemplateLength,
			int  iMinimalTemplateLength,
			bool  bPatternCheckLengthEntophy,

			bool  bUseTemplatesAtVirusPopInit,

			int  iVirusGen,
			int  iVirusPopSize, 
			double  dPopReductionJuxtapositional,
			double  dVirProbCut,  double  dVirProbSplice,
			double  dVirProbMut,
			double  dVirProbMutRemGene,
			double  dVirProbMutAddGene,
			double  dVirProbLowCross,
			double  dVirProbLowMut,
			double  dVirProbInitMut,
			int  iVirginityRounds,
			int  iNewCtDisturbedCopy,
			int  iNewCtDisturbedLLDSI,
			double  dNewCtDisturbedGeneDisturbedProb
			);

		int  i_gen;
		int  i_pop_size;
		double  d_prob_cross;
		bool  b_static_cross;

		bool  b_glue_infection_rows;
		bool  b_fitness_change_templ_check;
		int  i_max_infections_considered_at_crossing;
		int  i_the_same_template_check;
		int  i_preferred_template_length;
		int  i_minimal_template_length;
		bool  b_pattern_check_length_entrophy;

		bool  b_use_templates_at_virus_pop_init;

		int  i_virus_gen;
		int  i_virus_pop_size;
		double  d_pop_reduction_juxtapositional;
		double  d_vir_prob_cut;
		double  d_vir_prob_splice;
		double  d_vir_prob_mut;
		double  d_prob_mut_rem_gene;
		double  d_prob_mut_add_gene;
		double  d_prob_low_level_cross;
		double  d_prob_low_level_mut;

		int  i_virginity_rounds;

		double  d_prob_init_mut;

		int  i_new_ct_disturbed_copy;//new ct is random (disturbed copy = 0), new ct is a disturbed copy of other CT (disturbed copy = 1)
		int  i_new_ct_disturbed_LLDSI;//use linkage at making a disturbed copy
		double  d_new_ct_disturbed_gene_disturbed_prob;//if using a new distrubed CT without LLDSI - the probability of gene change

		int  i_p3_leave_ind_at_level;
	

	};//class  CTrajectorySetsFinder










};//namespace  TrajectorySetsFinder



