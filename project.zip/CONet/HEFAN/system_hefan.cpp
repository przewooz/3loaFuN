#include  "stdafx.h"
#include  "system_hefan.h"



using  namespace  TrajectorySetsFinder;


#pragma warning(disable:4996)



CHefanSystem::CHefanSystem()
{

	pl_capa  =  NULL;
	pl_pairs  =  NULL;

	pc_finder  =  NULL;

}//CHefanSystem::CHefanSystem()




/*
CHefanSystem::~CHefanSystem()
{

	if  (pl_capa  !=  NULL)  delete  []  pl_capa;
	if  (pl_pairs  !=  NULL)  delete  []  pl_pairs;

	if  (pc_finder  !=  NULL)  delete  pc_finder;

}//CHefanSystem::~CHefanSystem()

*/






CError  CHefanSystem::eReadPairs(CString  sPairsFile)
{

	CError  c_err;

	
	FILE  *pf_pairs;
	CString  s_comments;

	//pf_pairs  =  fopen( (LPCSTR)  sPairsFile,  "r+");

	CTopologyTranslator::lReadComments(sPairsFile, &pf_pairs, &s_comments);

	CString  s_buf;
	if  (pf_pairs  ==  NULL)  
	{
		s_buf.Format("Unable to open file (%s)",sPairsFile);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_pairs  ==  NULL)  



	long  l_num_of_pairs;

	fscanf(pf_pairs,"%ld\n", &l_num_of_pairs);
	l_pairs_num  =  l_num_of_pairs;


	if  (pl_capa  !=  NULL)  delete  []  pl_capa;
	if  (pl_pairs  !=  NULL)  delete  []  pl_pairs;

	pl_capa  =  new  long[l_num_of_pairs];
	pl_pairs  =  new  long[l_num_of_pairs * 2];


	long  l_buf;
	for  (long  li = 0; li < l_num_of_pairs; li++)
	{

		fscanf(pf_pairs, "%ld\n", &l_buf);


		fscanf(pf_pairs, "%ld", &l_buf);
		pl_pairs[li * 2] = l_buf;

		fscanf(pf_pairs, "%ld", &l_buf);
		pl_pairs[li * 2 + 1] = l_buf;

		fscanf(pf_pairs, "%ld\n", &l_buf);
		//l_buf = l_buf / 4;//prw remove
		//if  (l_buf <= 0)  l_buf = 1;//prw remove
		pl_capa[li] = l_buf;
		//pl_capa[li] = 10;//l_buf;
		
	
	}//for  (long  li = 0; li < l_num_of_pairs; li++)



	
	fclose(pf_pairs);

	return(c_err);

};//int  CHefanSystem::iCreatePairs(CString  sPairsFile)



CError  CHefanSystem::e_run_for_hefan_header_1_0
	(
	CString  sSettingsFile,
	System::Windows::Forms::ListBox *  listParams,
	System::Windows::Forms::ListBox *  listComm
	)
{
	CError  c_err;
	CString  s_buf;

	FILE  *pf_settings_file;

	listComm->Items->Clear();
	listComm->Items->Add(S"Opening file...");
	//lbControl->Items->RemoveAt(lbControl->Items->get_Count()-1);
	pf_settings_file  =  fopen(sSettingsFile, "r+");
	if  (pf_settings_file  ==  NULL)
	{
		s_buf.Format("Unable to open file (%s)", (LPCSTR)  sSettingsFile);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_source  ==  NULL)

	listComm->Items->Add(S"...successful");

	
	CString  s_info,  s_comment;
	long  l_buf;

	CString  s_topology, s_vw_file, s_con_file;
	CString  s_fom_func, s_res_file, s_pop_fom_watch, s_ini_file;
	bool  b_allow_capacity_overloading;
	long  l_clo_rep,  l_res_num, l_capa_penalty, l_capa_incr, l_capa_gen_incr;
	double  d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross;
	long  l_pop_num,  l_gen_num;
	long  l_brain_avr_len;
	double  d_brain_min_inc;
	long  l_brain_time_len,  l_brain_finish_time,  l_brain_min_break;


	listComm->Items->Add(S"Reading params...");
			

	vReadLine(pf_settings_file, &s_topology,  &s_comment);
	vReadLine(pf_settings_file, &s_vw_file,  &s_comment);
	vReadLine(pf_settings_file, &s_con_file,  &s_comment);
	vReadLine(pf_settings_file, &s_ini_file,  &s_comment);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	
	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_buf  =  atol( (LPCSTR) s_info);
	if  (l_buf  ==  0)  s_fom_func  =  "MWP";
	if  (l_buf  ==  1)  s_fom_func  =  "LFN";
	if  (l_buf  ==  2)  s_fom_func  =  "LFL";

	vReadLine(pf_settings_file, &s_res_file,  &s_comment);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_res_num  =  atol( (LPCSTR)  s_info );

	vReadLine(pf_settings_file, &s_pop_fom_watch,  &s_comment);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	if  (s_info  ==  "przekraczaj")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );
	
	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_capa_incr  =  atol( (LPCSTR)  s_info);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_capa_gen_incr  =  atol( (LPCSTR)  s_info);


	vReadLine(pf_settings_file, &s_info,  &s_comment);
	d_high_cross  =  atof( (LPCSTR)  s_info);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	d_high_mut  =  atof( (LPCSTR)  s_info);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	d_low_cross  =  atof( (LPCSTR)  s_info);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	d_low_mut  =  atof( (LPCSTR)  s_info);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	d_random_cross  =  atof( (LPCSTR)  s_info);

	

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_pop_num  =  atol( (LPCSTR)  s_info);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_gen_num  =  atol( (LPCSTR)  s_info);


	//brainstorm parameters
	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_brain_avr_len  =  atol( (LPCSTR)  s_info);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	d_brain_min_inc  =  atof( (LPCSTR)  s_info);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_brain_time_len  =  atol( (LPCSTR)  s_info);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_brain_finish_time  =  atol( (LPCSTR)  s_info);

	vReadLine(pf_settings_file, &s_info,  &s_comment);
	l_brain_min_break  =  atol( (LPCSTR)  s_info);
	
		
	fclose(pf_settings_file);
	listComm->Items->Add(S"...successful");


	//now inserting params into the params window
	listParams->Items->Clear();

	//general data
	s_buf.Format("Fit function: %s", (LPCSTR) s_fom_func);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Topology: %s", (LPCSTR) s_topology);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Connections : %s", (LPCSTR) s_con_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Ini file: %s", (LPCSTR) s_ini_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Virtual ways: %s", (LPCSTR) s_vw_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Result: %s", (LPCSTR) s_res_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population fit watch file: %s", (LPCSTR) s_pop_fom_watch);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Cloner repetations: %d", l_clo_rep);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Resulting individuals number: %d", l_res_num);
	listParams->Items->Add( (System::String *) s_buf);


	//capacity overloading
	if  (b_allow_capacity_overloading)
	{
		s_buf.Format("Capacity overloading: Allowed (PENALTY: %d)", l_capa_penalty);
		listParams->Items->Add( (System::String *) s_buf);

	}//if  (b_allow_capacity_overloading)
	else
		listParams->Items->Add(S"Capacity overloading: NOT allowed");

	s_buf.Format("Capacity increase/generations: %d/%d", l_capa_incr, l_capa_gen_incr);
	listParams->Items->Add( (System::String *) s_buf);


		
	//algorithm parameters
	s_buf.Format("High lvl: cross/mutation: %lf/%lf", d_high_cross,  d_high_mut);
	listParams->Items->Add( (System::String *) s_buf);
	s_buf.Format("High lvl: random crossing: %lf", d_random_cross);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Low lvl: cross/mutation: %lf/%lf", d_low_cross,  d_low_mut);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Generation number: %d", l_gen_num);
	listParams->Items->Add( (System::String *) s_buf);


	//brainstorm
	s_buf.Format("Brainstorm averaging window length: %d", l_brain_avr_len);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Brainstorm minimum required increase: %lf", d_brain_min_inc);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Brainstorm: ON time/Turning off time/Minimum break: %d/%d/%d", l_brain_time_len,  l_brain_finish_time,  l_brain_min_break);
	listParams->Items->Add( (System::String *) s_buf);
	
	listComm->Refresh();
	listParams->Refresh();

	c_err  =  eReadPairs(s_con_file);
	if  (c_err)  return(c_err);

	
	vRunAlgorithm_HEFAN_1_0
		(
		listComm,
		s_topology, s_vw_file, s_ini_file, 
		l_clo_rep,0,
		s_fom_func, 
		d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross,
		l_capa_penalty, l_pop_num,  l_gen_num,  0/*time restriction*/, l_res_num,
		s_res_file, s_pop_fom_watch, NULL,
		l_capa_incr, l_capa_gen_incr,
		b_allow_capacity_overloading,
		l_brain_avr_len,  d_brain_min_inc,	l_brain_time_len,  l_brain_finish_time,  l_brain_min_break
		);

	return(c_err);
}//CError  CHefanSystem::e_load_for_hefan_1_0()









CError  CHefanSystem::e_run_for_hefan_2_0_or_2_1_or_2_2_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm,
		CString  sAlgorithmName
		)
{
	CError  c_err;

	CString  s_info, s_buf;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;
	long  l_capa_incr, l_capa_gen_incr;
	double  d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross;
	long  l_pop_num,  l_gen_num;
	double  d_time_restriction;

	long  l_brain_avr_len;
	double  d_brain_min_inc;
	long  l_brain_time_len,  l_brain_finish_time,  l_brain_min_break;


	listComm->Items->Add(S"Reading params...");

	c_err  =  eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "flow increase", &s_info);
	if  (c_err)  return(c_err);
	l_capa_incr  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "flow increase every x generations", &s_info);
	if  (c_err)  return(c_err);
	l_capa_gen_incr  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "High level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_high_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "High level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_high_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "Low level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_low_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "Low level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_low_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "High level crossing unordered", &s_info);
	if  (c_err)  return(c_err);
	d_random_cross  =  atof( (LPCSTR)  s_info);

	c_err  =  eReadValue(pfSettingsFile,  "Population size", &s_info);
	if  (c_err)  return(c_err);
	l_pop_num  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Generation number", &s_info);
	if  (c_err)  return(c_err);
	l_gen_num  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Time restriction", &s_info);
	if  (c_err)  return(c_err);
	d_time_restriction  =  atof( (LPCSTR)  s_info);


	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm radius", &s_info);
	if  (c_err)  return(c_err);
	l_brain_avr_len  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm turn on perc", &s_info);
	if  (c_err)  return(c_err);
	d_brain_min_inc  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm duration", &s_info);
	if  (c_err)  return(c_err);
	l_brain_time_len  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm turning off", &s_info);
	if  (c_err)  return(c_err);
	l_brain_finish_time  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm min break", &s_info);
	if  (c_err)  return(c_err);
	l_brain_min_break  =  atol( (LPCSTR)  s_info );

	fclose(pfSettingsFile);
				
	listComm->Items->Add(S"...successful");

	//the population size nedds to be divided by 4 first
	l_pop_num  =  l_pop_num / 4;


	int  i_file_index;
	i_file_index = Tools::iGetProperFileIndex(sSettingsFileDir  +  "\\"  +  s_res_file + "_%.2d.txt");
	s_buf.Format("_%.2d.txt", i_file_index);
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file + s_buf;
	FILE  *pf_res_file;
	pf_res_file = fopen(s_res_file, "w+");
	//s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch + s_buf;

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;
	//s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch;


	//::MessageBox(NULL, sInParameters, sInParameters, MB_OK);
	if  (sInParameters !=  "")
	{
		s_pop_fom_watch.Format("%s_out.txt", sInParameters);
	}//if  (sInParameters !=  "")

	//now inserting params into the params window
	listParams->Items->Clear();


	//general data
	s_buf.Format("Algorithm: %s", sAlgorithmName);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Fit function: %s", (LPCSTR) s_fom_func);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Topology: %s", (LPCSTR) s_topology);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Connections : %s", (LPCSTR) s_con_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Ini file: %s", (LPCSTR) s_ini_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Virtual ways: %s", (LPCSTR) s_vw_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Result: %s", (LPCSTR) s_res_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population fit watch file: %s", (LPCSTR) s_pop_fom_watch);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Cloner repetations: %d", l_clo_rep);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Inited shortest ways between nodes: %d", l_shortest_ways_number);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Resulting individuals number: %d", l_res_num);
	listParams->Items->Add( (System::String *) s_buf);


	//capacity overloading
	if  (b_allow_capacity_overloading)
	{
		s_buf.Format("Capacity overloading: Allowed (PENALTY: %d)", l_capa_penalty);
		listParams->Items->Add( (System::String *) s_buf);

	}//if  (b_allow_capacity_overloading)
	else
		listParams->Items->Add(S"Capacity overloading: NOT allowed");

	s_buf.Format("Capacity increase/generations: %d/%d", l_capa_incr, l_capa_gen_incr);
	listParams->Items->Add( (System::String *) s_buf);


		
	//algorithm parameters
	s_buf.Format("High lvl: cross/mutation: %lf/%lf", d_high_cross,  d_high_mut);
	listParams->Items->Add( (System::String *) s_buf);
	s_buf.Format("High lvl: random crossing: %lf", d_random_cross);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Low lvl: cross/mutation: %lf/%lf", d_low_cross,  d_low_mut);
	listParams->Items->Add( (System::String *) s_buf);

	if  (d_time_restriction  >  0)
		s_buf.Format("Time restriction: %lf", d_time_restriction);
	else
		s_buf.Format("Number of generations: %ld", l_gen_num);
    	
	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Generation number: %d", l_gen_num);
	listParams->Items->Add( (System::String *) s_buf);


	//brainstorm
	s_buf.Format("Brainstorm averaging window length: %d", l_brain_avr_len);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Brainstorm minimum required increase: %lf", d_brain_min_inc);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Brainstorm: ON time/Turning off time/Minimum break: %d/%d/%d", l_brain_time_len,  l_brain_finish_time,  l_brain_min_break);
	listParams->Items->Add( (System::String *) s_buf);
	
	listComm->Refresh();
	listParams->Refresh();

	c_err  =  eReadPairs(s_con_file);
	if  (c_err)  return(c_err);




	
	
	if  (sAlgorithmName  ==  HEFAN_2_0_NAME)
		vRunAlgorithm_HEFAN_2_0_or_2_1_or_2_2
			(
			listComm,
			s_topology, s_vw_file, s_ini_file, 
			l_clo_rep, l_shortest_ways_number,
			s_fom_func, 
			d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross,
			l_capa_penalty, l_pop_num,  l_gen_num,  d_time_restriction,
			l_res_num,
			s_res_file, s_pop_fom_watch, pf_res_file, 
			l_capa_incr, l_capa_gen_incr,
			b_allow_capacity_overloading,
			l_brain_avr_len,  d_brain_min_inc,	l_brain_time_len,  l_brain_finish_time,  l_brain_min_break,
			0
			);

	if  (sAlgorithmName  ==  HEFAN_2_1_NAME)
		vRunAlgorithm_HEFAN_2_0_or_2_1_or_2_2
			(
			listComm,
			s_topology, s_vw_file, s_ini_file, 
			l_clo_rep, l_shortest_ways_number,
			s_fom_func, 
			d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross,
			l_capa_penalty, l_pop_num,  l_gen_num,  d_time_restriction,
			l_res_num,
			s_res_file, s_pop_fom_watch, pf_res_file, 
			l_capa_incr, l_capa_gen_incr,
			b_allow_capacity_overloading,
			l_brain_avr_len,  d_brain_min_inc,	l_brain_time_len,  l_brain_finish_time,  l_brain_min_break,
			1
			);

	if  (sAlgorithmName  ==  HEFAN_2_2_NAME)
		vRunAlgorithm_HEFAN_2_0_or_2_1_or_2_2
			(
			listComm,
			s_topology, s_vw_file, s_ini_file, 
			l_clo_rep, l_shortest_ways_number,
			s_fom_func, 
			d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross,
			l_capa_penalty, l_pop_num,  l_gen_num,  d_time_restriction,
			l_res_num,
			s_res_file, s_pop_fom_watch, pf_res_file, 
			l_capa_incr, l_capa_gen_incr,
			b_allow_capacity_overloading,
			l_brain_avr_len,  d_brain_min_inc,	l_brain_time_len,  l_brain_finish_time,  l_brain_min_break,
			2
			);

	fclose(pf_res_file);

	return(c_err);
}//CError  CHefanSystem::e_run_for_hefan_2_0_header_2_0









CError  CHefanSystem::e_run_for_hefan_1_1_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		)
{
	CError  c_err;

	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number,  l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;
	long  l_capa_incr, l_capa_gen_incr;
	double  d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross;
	long  l_pop_num,  l_gen_num;
	double  d_time_restriction;

	long  l_brain_avr_len;
	double  d_brain_min_inc;
	long  l_brain_time_len,  l_brain_finish_time,  l_brain_min_break;


	listComm->Items->Add(S"Reading params...");

	c_err  =  eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "flow increase", &s_info);
	if  (c_err)  return(c_err);
	l_capa_incr  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "flow increase every x generations", &s_info);
	if  (c_err)  return(c_err);
	l_capa_gen_incr  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "High level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_high_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "High level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_high_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "Low level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_low_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "Low level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_low_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "High level crossing unordered", &s_info);
	if  (c_err)  return(c_err);
	d_random_cross  =  atof( (LPCSTR)  s_info);

	c_err  =  eReadValue(pfSettingsFile,  "Population size", &s_info);
	if  (c_err)  return(c_err);
	l_pop_num  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Generation number", &s_info);
	if  (c_err)  return(c_err);
	l_gen_num  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Time restriction", &s_info);
	if  (c_err)  return(c_err);
	d_time_restriction  =  atof( (LPCSTR)  s_info);

	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm radius", &s_info);
	if  (c_err)  return(c_err);
	l_brain_avr_len  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm turn on perc", &s_info);
	if  (c_err)  return(c_err);
	d_brain_min_inc  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm duration", &s_info);
	if  (c_err)  return(c_err);
	l_brain_time_len  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm turning off", &s_info);
	if  (c_err)  return(c_err);
	l_brain_finish_time  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm min break", &s_info);
	if  (c_err)  return(c_err);
	l_brain_min_break  =  atol( (LPCSTR)  s_info );

	fclose(pfSettingsFile);
				
	listComm->Items->Add(S"...successful");

	//the population size nedds to be divided by 4 first
	l_pop_num  =  l_pop_num / 4;

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch;

	//now inserting params into the params window
	listParams->Items->Clear();


	CString  s_buf;
	//general data
	s_buf.Format("Algorithm: %s", HEFAN_1_1_NAME);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Fit function: %s", (LPCSTR) s_fom_func);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Topology: %s", (LPCSTR) s_topology);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Connections : %s", (LPCSTR) s_con_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Ini file: %s", (LPCSTR) s_ini_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Virtual ways: %s", (LPCSTR) s_vw_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Result: %s", (LPCSTR) s_res_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population fit watch file: %s", (LPCSTR) s_pop_fom_watch);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Cloner repetations: %d", l_clo_rep);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Inited shortest ways between nodes: %d", l_shortest_ways_number);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Resulting individuals number: %d", l_res_num);
	listParams->Items->Add( (System::String *) s_buf);


	//capacity overloading
	if  (b_allow_capacity_overloading)
	{
		s_buf.Format("Capacity overloading: Allowed (PENALTY: %d)", l_capa_penalty);
		listParams->Items->Add( (System::String *) s_buf);

	}//if  (b_allow_capacity_overloading)
	else
		listParams->Items->Add(S"Capacity overloading: NOT allowed");

	s_buf.Format("Capacity increase/generations: %d/%d", l_capa_incr, l_capa_gen_incr);
	listParams->Items->Add( (System::String *) s_buf);


		
	//algorithm parameters
	s_buf.Format("High lvl: cross/mutation: %lf/%lf", d_high_cross,  d_high_mut);
	listParams->Items->Add( (System::String *) s_buf);
	s_buf.Format("High lvl: random crossing: %lf", d_random_cross);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Low lvl: cross/mutation: %lf/%lf", d_low_cross,  d_low_mut);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);

	if  (d_time_restriction  >  0)
		s_buf.Format("Time restriction: %lf", d_time_restriction);
	else
		s_buf.Format("Number of generations: %ld", l_gen_num);
    	
	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);
	

	//brainstorm
	s_buf.Format("Brainstorm averaging window length: %d", l_brain_avr_len);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Brainstorm minimum required increase: %lf", d_brain_min_inc);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Brainstorm: ON time/Turning off time/Minimum break: %d/%d/%d", l_brain_time_len,  l_brain_finish_time,  l_brain_min_break);
	listParams->Items->Add( (System::String *) s_buf);
	
	listComm->Refresh();
	listParams->Refresh();

	c_err  =  eReadPairs(s_con_file);
	if  (c_err)  return(c_err);

	
	vRunAlgorithm_HEFAN_1_1
		(
		listComm,
		s_topology, s_vw_file, s_ini_file, 
		l_clo_rep, l_shortest_ways_number,
		s_fom_func, 
		d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross,
		l_capa_penalty, l_pop_num,  l_gen_num,  d_time_restriction,  l_res_num,
		s_res_file, s_pop_fom_watch, NULL, 
		l_capa_incr, l_capa_gen_incr,
		b_allow_capacity_overloading,
		l_brain_avr_len,  d_brain_min_inc,	l_brain_time_len,  l_brain_finish_time,  l_brain_min_break
		);


	return(c_err);
}//CError  CHefanSystem::e_run_for_hefan_1_1_header_2_0




CError  CHefanSystem::e_run_for_hefan_1_0_header_2_0
	(
	FILE  *pfSettingsFile,
	CString  sMotherDir,  CString  sSettingsFileDir,
	System::Windows::Forms::ListBox *  listParams,
	System::Windows::Forms::ListBox *  listComm
	)
{
	CError  c_err;

	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;
	long  l_capa_incr, l_capa_gen_incr;
	double  d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross;
	long  l_pop_num,  l_gen_num;
	double  d_time_restriction;

	long  l_brain_avr_len;
	double  d_brain_min_inc;
	long  l_brain_time_len,  l_brain_finish_time,  l_brain_min_break;


	listComm->Items->Add(S"Reading params...");

	c_err  =  eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "flow increase", &s_info);
	if  (c_err)  return(c_err);
	l_capa_incr  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "flow increase every x generations", &s_info);
	if  (c_err)  return(c_err);
	l_capa_gen_incr  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "High level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_high_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "High level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_high_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "Low level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_low_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "Low level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_low_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "High level crossing unordered", &s_info);
	if  (c_err)  return(c_err);
	d_random_cross  =  atof( (LPCSTR)  s_info);

	c_err  =  eReadValue(pfSettingsFile,  "Population size", &s_info);
	if  (c_err)  return(c_err);
	l_pop_num  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Generation number", &s_info);
	if  (c_err)  return(c_err);
	l_gen_num  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Time restriction", &s_info);
	if  (c_err)  return(c_err);
	d_time_restriction  =  atof( (LPCSTR)  s_info);

	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm radius", &s_info);
	if  (c_err)  return(c_err);
	l_brain_avr_len  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm turn on perc", &s_info);
	if  (c_err)  return(c_err);
	d_brain_min_inc  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm duration", &s_info);
	if  (c_err)  return(c_err);
	l_brain_time_len  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm turning off", &s_info);
	if  (c_err)  return(c_err);
	l_brain_finish_time  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm min break", &s_info);
	if  (c_err)  return(c_err);
	l_brain_min_break  =  atol( (LPCSTR)  s_info );

	fclose(pfSettingsFile);
				
	listComm->Items->Add(S"...successful");

	//the population size nedds to be divided by 4 first
	l_pop_num  =  l_pop_num / 4;

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch;

	//now inserting params into the params window
	listParams->Items->Clear();


	CString  s_buf;
	//general data
	s_buf.Format("Algorithm: %s", HEFAN_1_0_NAME);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Fit function: %s", (LPCSTR) s_fom_func);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Topology: %s", (LPCSTR) s_topology);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Connections : %s", (LPCSTR) s_con_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Ini file: %s", (LPCSTR) s_ini_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Virtual ways: %s", (LPCSTR) s_vw_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Result: %s", (LPCSTR) s_res_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population fit watch file: %s", (LPCSTR) s_pop_fom_watch);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Cloner repetations: %d", l_clo_rep);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Inited shortest ways between nodes: %d", l_shortest_ways_number);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Resulting individuals number: %d", l_res_num);
	listParams->Items->Add( (System::String *) s_buf);


	//capacity overloading
	if  (b_allow_capacity_overloading)
	{
		s_buf.Format("Capacity overloading: Allowed (PENALTY: %d)", l_capa_penalty);
		listParams->Items->Add( (System::String *) s_buf);

	}//if  (b_allow_capacity_overloading)
	else
		listParams->Items->Add(S"Capacity overloading: NOT allowed");

	s_buf.Format("Capacity increase/generations: %d/%d", l_capa_incr, l_capa_gen_incr);
	listParams->Items->Add( (System::String *) s_buf);


		
	//algorithm parameters
	s_buf.Format("High lvl: cross/mutation: %lf/%lf", d_high_cross,  d_high_mut);
	listParams->Items->Add( (System::String *) s_buf);
	s_buf.Format("High lvl: random crossing: %lf", d_random_cross);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Low lvl: cross/mutation: %lf/%lf", d_low_cross,  d_low_mut);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);

	if  (d_time_restriction  >  0)
		s_buf.Format("Time restriction: %lf", d_time_restriction);
	else
		s_buf.Format("Number of generations: %ld", l_gen_num);
    	
	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);


	//brainstorm
	s_buf.Format("Brainstorm averaging window length: %d", l_brain_avr_len);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Brainstorm minimum required increase: %lf", d_brain_min_inc);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Brainstorm: ON time/Turning off time/Minimum break: %d/%d/%d", l_brain_time_len,  l_brain_finish_time,  l_brain_min_break);
	listParams->Items->Add( (System::String *) s_buf);
	
	listComm->Refresh();
	listParams->Refresh();

	c_err  =  eReadPairs(s_con_file);
	if  (c_err)  return(c_err);

	
	vRunAlgorithm_HEFAN_1_0
		(
		listComm,
		s_topology, s_vw_file, s_ini_file, 
		l_clo_rep, l_shortest_ways_number, 
		s_fom_func, 
		d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross,
		l_capa_penalty, l_pop_num,  l_gen_num,  d_time_restriction, l_res_num,
		s_res_file, s_pop_fom_watch, NULL,
		l_capa_incr, l_capa_gen_incr,
		b_allow_capacity_overloading,
		l_brain_avr_len,  d_brain_min_inc,	l_brain_time_len,  l_brain_finish_time,  l_brain_min_break
		);


	return(c_err);
}//CError  CHefanSystem::e_run_for_hefan_1_0_header_2_0



CError  CHefanSystem::e_run_for_3LO_alg_header_2_0
	(
	FILE  *pfSettingsFile,
	CString  sMotherDir,  CString  sSettingsFileDir,
	System::Windows::Forms::ListBox *  listParams,
	System::Windows::Forms::ListBox *  listComm
	)
{
	CError  c_err;
	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;




	listComm->Items->Add(S"Reading params...");

	c_err  =  eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	

	CString  s_setting_name,  s_buf;

	int  i_max_time;
	int  i_max_infections_considered_at_crossing;
	int  i_minimal_template_length;


	int  i_island_number, i_migration_freq, i_im_linkage_gen;
	int  i_pop_size, i_p3_leave_ind_at_level, i_random_linkage;
	int  i_linkage_scrap, i_linkage_scrap_create_effect_scrap, i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp;
	double  d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross;
	
	int  i_ct_strategy;


	i_max_time  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_MAX_TIME)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_MAX_TIME, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_pop_size =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_POP_SIZE)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_POP, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_p3_leave_ind_at_level =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_P3_LEAVE_COPY_AT_LEVEL)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_P3_LEAVE_COPY_AT_LEVEL, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)



	i_random_linkage =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_RANDOM_LINKAGE)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_RANDOM_LINKAGE, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_RANDOM_LINKAGE)


	i_linkage_scrap =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_LINKAGE_SCRAPS)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_LINKAGE_SCRAPS, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_LINKAGE_SCRAPS)



	i_linkage_scrap_create_effect_scrap =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_LINKAGE_SCRAPS_EFFECT_SCRAP)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_LINKAGE_SCRAPS_EFFECT_SCRAP, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_LINKAGE_SCRAPS)


	i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_LINKAGE_SCRAPS_EFFECT_SCRAP_PROVOKING_SCRAP)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_LINKAGE_SCRAPS_EFFECT_SCRAP_PROVOKING_SCRAP, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_LINKAGE_SCRAPS)


	

	d_low_cross  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  "Low level crossing")
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", "Low level crossing", s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  "Low level mutation")



	d_low_mut  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  "Low level mutation")
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", "Low level mutation", s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  "Low level mutation")




	fclose(pfSettingsFile);
				
	listComm->Items->Add(S"...successful");

	

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;


	int  i_file_index;
	i_file_index = Tools::iGetProperFileIndex(sSettingsFileDir  +  "\\"  +  s_res_file + "_%.2d.txt");
	s_buf.Format("_%.2d.txt", i_file_index);
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file + s_buf;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch + s_buf;

	//now inserting params into the params window
	listParams->Items->Clear();


	//general data
	s_buf.Format("Algorithm: 3LO_ltga");
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Fit function: %s", (LPCSTR) s_fom_func);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Topology: %s", (LPCSTR) s_topology);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Connections : %s", (LPCSTR) s_con_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Ini file: %s", (LPCSTR) s_ini_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Virtual ways: %s", (LPCSTR) s_vw_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Result: %s", (LPCSTR) s_res_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population fit watch file: %s", (LPCSTR) s_pop_fom_watch);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Cloner repetations: %d", l_clo_rep);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Inited shortest ways between nodes: %d", l_shortest_ways_number);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Resulting individuals number: %d", l_res_num);
	listParams->Items->Add( (System::String *) s_buf);


	//capacity overloading
	if  (b_allow_capacity_overloading)
	{
		s_buf.Format("Capacity overloading: Allowed (PENALTY: %d)", l_capa_penalty);
		listParams->Items->Add( (System::String *) s_buf);

	}//if  (b_allow_capacity_overloading)
	else
		listParams->Items->Add(S"Capacity overloading: NOT allowed");

	
	listComm->Refresh();
	listParams->Refresh();

	c_err  =  eReadPairs(s_con_file);
	if  (c_err)  return(c_err);


	
	vRunAlgorithm_3LO_alg
		(
		listComm,
		s_topology, s_vw_file, s_ini_file, 
		b_allow_capacity_overloading,
		l_clo_rep, l_shortest_ways_number, 
		s_fom_func, 
		l_capa_penalty, 
		
		s_res_file, s_pop_fom_watch, 

		i_max_time, i_pop_size, i_p3_leave_ind_at_level, i_random_linkage, 
		i_linkage_scrap, i_linkage_scrap_create_effect_scrap, i_linkage_scrap_create_effect_scrap_and_concatenated_with_provoking_scracp,
		d_low_cross,  d_low_mut
		);


	return(c_err);
}//CError  CHefanSystem::e_run_for_3LO_ltga_header_2_0




CError  CHefanSystem::e_run_for_ic_pso_header_2_0
	(
	FILE  *pfSettingsFile,
	CString  sMotherDir,  CString  sSettingsFileDir,
	System::Windows::Forms::ListBox *  listParams,
	System::Windows::Forms::ListBox *  listComm
	)
{
	CError  c_err;
	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;




	listComm->Items->Add(S"Reading params...");

	c_err  =  eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	

	CString  s_setting_name,  s_buf;

	int  i_max_time;
	int  i_max_infections_considered_at_crossing;
	int  i_minimal_template_length;


	int  i_island_number, i_migration_freq, i_im_linkage_gen;
	int  i_pop_size;
	double  d_psi_1, d_psi_2, d_omega;
	double  d_scaling_factor;
	double  d_low_cross,  d_low_mut, d_random_cross;
	int  i_no_improvements_until_reset;

	
	int  i_ct_strategy;


	i_max_time  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_MAX_TIME)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_MAX_TIME, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_pop_size =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_POP_SIZE)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_POP, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	d_psi_1 =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_PSO_PSI_1)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_PSO_PSI_1, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_PSO_PSI_1)


	d_psi_2 =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_PSO_PSI_2)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_PSO_PSI_2, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_PSO_PSI_2)


	d_omega =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_PSO_OMEGA)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_PSO_OMEGA, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_PSO_OMEGA)


	d_scaling_factor =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_PSO_SCALING_FACTOR)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_PSO_SCALING_FACTOR, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_PSO_SCALING_FACTOR)


	i_no_improvements_until_reset =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_PSO_GB_NO_IMPROVEMENT_POP_RESET)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_PSO_GB_NO_IMPROVEMENT_POP_RESET, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_PSO_GB_NO_IMPROVEMENT_POP_RESET)






	
	

	d_low_cross  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  "Low level crossing")
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", "Low level crossing", s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  "Low level mutation")



	d_low_mut  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  "Low level mutation")
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", "Low level mutation", s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  "Low level mutation")




	fclose(pfSettingsFile);
				
	listComm->Items->Add(S"...successful");

	

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;


	int  i_file_index;
	i_file_index = Tools::iGetProperFileIndex(sSettingsFileDir  +  "\\"  +  s_res_file + "_%.2d.txt");
	s_buf.Format("_%.2d.txt", i_file_index);
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file + s_buf;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch + s_buf;

	//now inserting params into the params window
	listParams->Items->Clear();


	//general data
	s_buf.Format("Algorithm: 3LO_ltga");
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Fit function: %s", (LPCSTR) s_fom_func);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Topology: %s", (LPCSTR) s_topology);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Connections : %s", (LPCSTR) s_con_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Ini file: %s", (LPCSTR) s_ini_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Virtual ways: %s", (LPCSTR) s_vw_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Result: %s", (LPCSTR) s_res_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population fit watch file: %s", (LPCSTR) s_pop_fom_watch);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Cloner repetations: %d", l_clo_rep);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Inited shortest ways between nodes: %d", l_shortest_ways_number);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Resulting individuals number: %d", l_res_num);
	listParams->Items->Add( (System::String *) s_buf);


	//capacity overloading
	if  (b_allow_capacity_overloading)
	{
		s_buf.Format("Capacity overloading: Allowed (PENALTY: %d)", l_capa_penalty);
		listParams->Items->Add( (System::String *) s_buf);

	}//if  (b_allow_capacity_overloading)
	else
		listParams->Items->Add(S"Capacity overloading: NOT allowed");

	
	listComm->Refresh();
	listParams->Refresh();

	c_err  =  eReadPairs(s_con_file);
	if  (c_err)  return(c_err);


	
	vRunAlgorithm_IC_PSO
		(
		listComm,
		s_topology, s_vw_file, s_ini_file, 
		b_allow_capacity_overloading,
		l_clo_rep, l_shortest_ways_number, 
		s_fom_func, 
		l_capa_penalty, 
		
		s_res_file, s_pop_fom_watch, 

		i_max_time, i_pop_size, 
		d_psi_1, d_psi_2, d_omega,
		d_scaling_factor,
		i_no_improvements_until_reset,

		d_low_cross,  d_low_mut
		);


	return(c_err);
}//CError  CHefanSystem::e_run_for_3LO_ltga_header_2_0





CError  CHefanSystem::e_run_for_island_model_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		)
{
	CError  c_err;
	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;

	int  i_new_ct_disturbed_copy;//new ct is random (disturbed copy = 0), new ct is a disturbed copy of other CT (disturbed copy = 1)
	int  i_new_ct_disturbed_LLDSI;//use linkage at making a disturbed copy
	double  d_new_ct_disturbed_gene_disturbed_prob;//if using a new distrubed CT without LLDSI - the probability of gene change

	


	listComm->Items->Add(S"Reading params...");

	c_err  =  eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	

	CString  s_setting_name,  s_buf;

	int  i_max_time;
	int  i_max_infections_considered_at_crossing;
	int  i_minimal_template_length;


	int  i_island_number, i_migration_freq, i_im_linkage_gen;
	int  i_pop_size;
	double  d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross;
	
	int  i_ct_strategy;


	i_max_time  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_MAX_TIME)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_MAX_TIME, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_im_linkage_gen  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_IM_LINKAGE_GEN)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_IM_LINKAGE_GEN, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)

	i_max_infections_considered_at_crossing  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_PATTERN_POOL_SIZE)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_PATTERN_POOL_SIZE, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	
	i_minimal_template_length  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_MINIMAL_PATTERN_LEN)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_MINIMAL_PATTERN_LEN, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	
	//NOT NECESSARY - CT STRATEGY HAS IT INSIDE!
	/*i_island_number  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_IM_ISLAND_NUMBER)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_IM_ISLAND_NUMBER, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)*/


	i_migration_freq  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_IM_MIGRATION_FREQ)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_IM_MIGRATION_FREQ, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_pop_size =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_POP_SIZE)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_POP, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	

	d_high_cross  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  "High level crossing")
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", "High level crossing", s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	d_high_mut  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  "High level mutation")
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", "High level mutation", s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  "High level mutation")


	d_low_cross  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  "Low level crossing")
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", "Low level crossing", s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  "Low level mutation")



	d_low_mut  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  "Low level mutation")
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", "Low level mutation", s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  "Low level mutation")


	d_random_cross  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  "High level crossing unordered")
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", "High level crossing unordered", s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  "Low level mutation")



	i_ct_strategy  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_CT_STRATEGY)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_CT_STRATEGY, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_new_ct_disturbed_copy  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_NEW_CT_IS_A_DISTURBED_COPY)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_NEW_CT_IS_A_DISTURBED_COPY, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_NEW_CT_IS_A_DISTURBED_COPY)


	i_new_ct_disturbed_LLDSI  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_NEW_CT_LLDSI)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_NEW_CT_LLDSI, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_NEW_CT_LLDSI)


	d_new_ct_disturbed_gene_disturbed_prob  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_NEW_CT_GENE_DISTURB_PROB)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_NEW_CT_GENE_DISTURB_PROB, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_NEW_CT_GENE_DISTURB_PROB)




	

	fclose(pfSettingsFile);
				
	listComm->Items->Add(S"...successful");

	

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;


	int  i_file_index;
	i_file_index = Tools::iGetProperFileIndex(sSettingsFileDir  +  "\\"  +  s_res_file + "_%.2d.txt");
	s_buf.Format("_%.2d.txt", i_file_index);
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file + s_buf;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch + s_buf;

	//now inserting params into the params window
	listParams->Items->Clear();


	//general data
	s_buf.Format("Algorithm: vmEA");
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Fit function: %s", (LPCSTR) s_fom_func);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Topology: %s", (LPCSTR) s_topology);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Connections : %s", (LPCSTR) s_con_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Ini file: %s", (LPCSTR) s_ini_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Virtual ways: %s", (LPCSTR) s_vw_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Result: %s", (LPCSTR) s_res_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population fit watch file: %s", (LPCSTR) s_pop_fom_watch);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Cloner repetations: %d", l_clo_rep);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Inited shortest ways between nodes: %d", l_shortest_ways_number);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Resulting individuals number: %d", l_res_num);
	listParams->Items->Add( (System::String *) s_buf);

	CString  s_version;
	s_version = "unknown strategy";
	if  (i_ct_strategy > 0)  s_version.Format("%d", i_ct_strategy);
	if  (i_ct_strategy == -1)  s_version = "Classic";
	if  (i_ct_strategy == -2)  s_version = "Active";
	if  (i_ct_strategy == -3)  s_version = "Memo";
	if  (i_ct_strategy == -4)  s_version = "Total Memo";
	if  (i_ct_strategy == -5)  s_version = "Total Memo With Exchange";
		
	s_buf.Format("MuPPetS version: ");
	s_buf += s_version;
	listParams->Items->Add( (System::String *) s_buf);


	//capacity overloading
	if  (b_allow_capacity_overloading)
	{
		s_buf.Format("Capacity overloading: Allowed (PENALTY: %d)", l_capa_penalty);
		listParams->Items->Add( (System::String *) s_buf);

	}//if  (b_allow_capacity_overloading)
	else
		listParams->Items->Add(S"Capacity overloading: NOT allowed");


	s_buf.Format("Disturbed copy: %d", i_new_ct_disturbed_copy);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("LLDSI: %d", i_new_ct_disturbed_LLDSI);
	listParams->Items->Add( (System::String *) s_buf);

		
	/*//algorithm parameters
	s_buf.Format("High lvl: cross/mutation: %lf/%lf", d_high_cross,  d_high_mut);
	listParams->Items->Add( (System::String *) s_buf);
	s_buf.Format("High lvl: random crossing: %lf", d_random_cross);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);

	if  (d_time_restriction  >  0)
		s_buf.Format("Time restriction: %lf", d_time_restriction);
	else
		s_buf.Format("Number of generations: %ld", l_gen_num);
    	
	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);


	*/
	
	listComm->Refresh();
	listParams->Refresh();

	c_err  =  eReadPairs(s_con_file);
	if  (c_err)  return(c_err);


	
	vRunAlgorithm_IslandModel
		(
		listComm,
		s_topology, s_vw_file, s_ini_file, 
		b_allow_capacity_overloading,
		l_clo_rep, l_shortest_ways_number, 
		s_fom_func, 
		l_capa_penalty, 
		
		s_res_file, s_pop_fom_watch, 

		i_max_time,
		i_max_infections_considered_at_crossing, i_minimal_template_length,
	
		i_ct_strategy,
		i_im_linkage_gen, i_migration_freq,	i_pop_size,
		d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross,

		i_new_ct_disturbed_copy, i_new_ct_disturbed_LLDSI, d_new_ct_disturbed_gene_disturbed_prob
		);


	return(c_err);
}//CError  CHefanSystem::e_run_for_vmea_header_2_0








CError  CHefanSystem::e_run_for_vmea_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		)
{
	CError  c_err;
	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;

	


	listComm->Items->Add(S"Reading params...");

	c_err  =  eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	

	CString  s_setting_name,  s_buf;

	int  i_gen;
	bool  b_glue_infection_rows;//it glueas all infection in a row until the individual is stucked
	bool  b_fitness_change_templ_check;//if true then every template must cause any fitness change in the next population if not the template candidate is not considered
	int  i_max_infections_considered_at_crossing;
	int  i_the_same_template_check;
	int  i_preferred_template_length;
	int  i_minimal_template_length;

	bool  b_pattern_check_length_entrophy;  //pattern number check based on: true - length based pattern fitnes; false - entrophy based pattern fitnes;
	bool  b_use_templates_at_virus_pop_init;//when true the viruses are inited using one of templates
	bool  b_vir_init_different_to_template;//if this is set then all virus genes during init phase are set value opposite to competetive template gene's value

	int  i_virus_gen;
	int  i_virus_pop_size;
	double  d_pop_reduction_juxtapositional;
	double  d_vir_prob_cut;
	double  d_vir_prob_splice;
	double  d_vir_prob_mut;
	double  d_prob_mut_rem_gene;
	double  d_prob_mut_add_gene;
	double  d_prob_low_level_cross;
	double  d_prob_low_level_mut;
	double  d_prob_init_mut;
	int  i_virginity_rounds;
	int  i_ct_strategy;
	int  i_parent_selection;//0-clasical with penalty; 1-fitness divided into pure optimized function and penalty; 2-dividsion on fitness and penalty + additional incremental individuals tournament to tell equal individuals

	int  i_new_ct_disturbed_copy;//new ct is random (disturbed copy = 0), new ct is a disturbed copy of other CT (disturbed copy = 1)
	int  i_new_ct_disturbed_LLDSI;//use linkage at making a disturbed copy
	double  d_new_ct_disturbed_gene_disturbed_prob;//if using a new distrubed CT without LLDSI - the probability of gene change



	i_gen  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_MAX_TIME)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_MAX_TIME, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	b_glue_infection_rows  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_GLUE_INFECTIONS)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_GLUE_INFECTIONS, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	b_fitness_change_templ_check  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_TEMPL_FITNESS_CHECK)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_TEMPL_FITNESS_CHECK, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_max_infections_considered_at_crossing  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_PATTERN_POOL_SIZE)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_PATTERN_POOL_SIZE, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_the_same_template_check  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_SAME_PATTERN_CHECK)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_SAME_PATTERN_CHECK, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_preferred_template_length  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_PREFERRED_PATTERN_LENGTH)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_PREFERRED_PATTERN_LENGTH, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)



	i_minimal_template_length  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_MINIMAL_PATTERN_LEN)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_MINIMAL_PATTERN_LEN, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)



	b_pattern_check_length_entrophy  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_LEN_OR_ENTROPHY)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_LEN_OR_ENTROPHY, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	b_use_templates_at_virus_pop_init  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_USE_TEMPL_AT_VIRUS_INIT)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_USE_TEMPL_AT_VIRUS_INIT, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)



	/*b_vir_init_different_to_template  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_INIT_DIFFERENT_TO_TEMPLATE)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_INIT_DIFFERENT_TO_TEMPLATE, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)*/



	i_virus_gen  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_GENERATIONS)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_GENERATIONS, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_virus_pop_size  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_POP)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_POP, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	d_pop_reduction_juxtapositional  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_POP_RED)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_POP_RED, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	d_vir_prob_cut  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_PROB_CUT)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_PROB_CUT, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	d_vir_prob_splice  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_PROB_SPLICE)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_PROB_SPLICE, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	d_vir_prob_mut  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_PROB_MUT)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_PROB_MUT, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	d_prob_mut_rem_gene  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_REM_GENE)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_REM_GENE, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	d_prob_mut_add_gene  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_ADD_GENE)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_ADD_GENE, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)



	d_prob_low_level_cross  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_LOW_CROSS)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_LOW_CROSS, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)



	d_prob_low_level_mut  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_LOW_MUT)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_LOW_MUT, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)



	d_prob_init_mut  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_INIT_MUT)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_INIT_MUT, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_virginity_rounds  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_VIRGINITY_ROUNDS)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_VIRGINITY_ROUNDS, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_ct_strategy  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_VIR_CT_STRATEGY)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_VIR_CT_STRATEGY, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)



	i_parent_selection  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_PARENT_SELECTION_STRATEGY)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_PARENT_SELECTION_STRATEGY, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_GENERATIONS)


	i_new_ct_disturbed_copy  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_NEW_CT_IS_A_DISTURBED_COPY)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_NEW_CT_IS_A_DISTURBED_COPY, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_NEW_CT_IS_A_DISTURBED_COPY)


	i_new_ct_disturbed_LLDSI  =  Tools::iReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_NEW_CT_LLDSI)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_NEW_CT_LLDSI, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_NEW_CT_LLDSI)


	d_new_ct_disturbed_gene_disturbed_prob  =  Tools::dReadLine(pfSettingsFile, &s_setting_name);
	if  (s_setting_name  !=  VGA_PARAM_NEW_CT_GENE_DISTURB_PROB)
	{
		s_buf.Format("Error at reading (%s) parameter read:(%s)", VGA_PARAM_NEW_CT_GENE_DISTURB_PROB, s_setting_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (s_setting_name  !=  VGA_PARAM_NEW_CT_GENE_DISTURB_PROB)




	





	fclose(pfSettingsFile);
				
	listComm->Items->Add(S"...successful");

	

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;


	int  i_file_index;
	i_file_index = Tools::iGetProperFileIndex(sSettingsFileDir  +  "\\"  +  s_res_file + "_%.2d.txt");
	s_buf.Format("_%.2d.txt", i_file_index);
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file + s_buf;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch + s_buf;

	//now inserting params into the params window
	listParams->Items->Clear();


	//general data
	s_buf.Format("Algorithm: vmEA");
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Fit function: %s", (LPCSTR) s_fom_func);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Topology: %s", (LPCSTR) s_topology);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Connections : %s", (LPCSTR) s_con_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Ini file: %s", (LPCSTR) s_ini_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Virtual ways: %s", (LPCSTR) s_vw_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Result: %s", (LPCSTR) s_res_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population fit watch file: %s", (LPCSTR) s_pop_fom_watch);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Cloner repetations: %d", l_clo_rep);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Inited shortest ways between nodes: %d", l_shortest_ways_number);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Resulting individuals number: %d", l_res_num);
	listParams->Items->Add( (System::String *) s_buf);

	CString  s_version;
	s_version = "unknown strategy";
	if  (i_ct_strategy > 0)  s_version.Format("%d", i_ct_strategy);
	if  (i_ct_strategy == -1)  s_version = "Classic";
	if  (i_ct_strategy == -2)  s_version = "Active";
	if  (i_ct_strategy == -3)  s_version = "Memo";
	if  (i_ct_strategy == -4)  s_version = "Total Memo";
	if  (i_ct_strategy == -5)  s_version = "Total Memo With Exchange";
		
	s_buf.Format("MuPPetS version: ");
	s_buf += s_version;
	listParams->Items->Add( (System::String *) s_buf);


	//capacity overloading
	if  (b_allow_capacity_overloading)
	{
		s_buf.Format("Capacity overloading: Allowed (PENALTY: %d)", l_capa_penalty);
		listParams->Items->Add( (System::String *) s_buf);

	}//if  (b_allow_capacity_overloading)
	else
		listParams->Items->Add(S"Capacity overloading: NOT allowed");


	s_buf.Format("Disturbed copy: %d", i_new_ct_disturbed_copy);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("LLDSI: %d", i_new_ct_disturbed_LLDSI);
	listParams->Items->Add( (System::String *) s_buf);


		
	/*//algorithm parameters
	s_buf.Format("High lvl: cross/mutation: %lf/%lf", d_high_cross,  d_high_mut);
	listParams->Items->Add( (System::String *) s_buf);
	s_buf.Format("High lvl: random crossing: %lf", d_random_cross);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);

	if  (d_time_restriction  >  0)
		s_buf.Format("Time restriction: %lf", d_time_restriction);
	else
		s_buf.Format("Number of generations: %ld", l_gen_num);
    	
	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);


	*/
	
	listComm->Refresh();
	listParams->Refresh();

	c_err  =  eReadPairs(s_con_file);
	if  (c_err)  return(c_err);


	
	vRunAlgorithm_vmES
		(
		listComm,
		s_topology, s_vw_file, s_ini_file, 
		l_clo_rep, l_shortest_ways_number, 
		s_fom_func, 
		l_capa_penalty, 
		
		s_res_file, s_pop_fom_watch, 
		b_allow_capacity_overloading,

		
		i_gen,
		b_glue_infection_rows,//it glueas all infection in a row until the individual is stucked
		b_fitness_change_templ_check,//if true then every template must cause any fitness change in the next population if not the template candidate is not considered
		i_max_infections_considered_at_crossing,
		i_the_same_template_check,
		i_preferred_template_length,
		i_minimal_template_length,

		b_pattern_check_length_entrophy,  //pattern number check based on: true - length based pattern fitnes, false - entrophy based pattern fitnes,
		b_use_templates_at_virus_pop_init,//when true the viruses are inited using one of templates
		b_vir_init_different_to_template,//if this is set then all virus genes during init phase are set value opposite to competetive template gene's value

		i_virus_gen,
		i_virus_pop_size,
		d_pop_reduction_juxtapositional,
		d_vir_prob_cut,
		d_vir_prob_splice,
		d_vir_prob_mut,
		d_prob_mut_rem_gene,
		d_prob_mut_add_gene,
		d_prob_low_level_cross,
		d_prob_low_level_mut,
		d_prob_init_mut,
		i_virginity_rounds,
		i_ct_strategy,
		i_parent_selection,

		i_new_ct_disturbed_copy,
		i_new_ct_disturbed_LLDSI,
		d_new_ct_disturbed_gene_disturbed_prob
		);


	

	return(c_err);
}//CError  CHefanSystem::e_run_for_vmea_header_2_0





CError  CHefanSystem::e_run_for_result_comparison
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		)
{
	CError  c_err;

	CString  s_info;

	CString  s_fom_func1, s_fom_func2;
	CString  s_topology, s_con_file, s_con_name;
	CString  s_alg_1_name, s_alg_1_file;
	CString  s_alg_2_name, s_alg_2_file;
	CString  s_res_file;
			
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;
	


	listComm->Items->Add(S"Reading params...");

	c_err  =  eReadValue(pfSettingsFile,  "cost function", &s_fom_func1);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "cost function", &s_fom_func2);
	if  (c_err)  return(c_err);


	c_err  =  eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);


	c_err  =  eReadValue(pfSettingsFile,  "algorithm 1 name", &s_alg_1_name);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "algorithm 1 file", &s_alg_1_file);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "algorithm 2 name", &s_alg_2_name);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "algorithm 2 file", &s_alg_2_file);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "result file", &s_res_file);
	if  (c_err)  return(c_err);
	

	c_err  =  eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	fclose(pfSettingsFile);
				
	listComm->Items->Add(S"...successful");

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_name = s_con_file;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_alg_1_file  !=  "")
		s_alg_1_file  =  sMotherDir  +  "\\"  +  s_alg_1_file;
	if  (s_alg_2_file  !=  "")
		s_alg_2_file  =  sMotherDir  +  "\\"  +  s_alg_2_file;
	s_res_file  =  sMotherDir  +  "\\"  +  s_res_file;

	//now inserting params into the params window
	listParams->Items->Clear();


	CString  s_buf;
	//general data
	s_buf.Format("Algorithm: %s", RESULT_COMPARISON);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Fit function 1: %s", (LPCSTR) s_fom_func1);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Fit function 2: %s", (LPCSTR) s_fom_func2);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Topology: %s", (LPCSTR) s_topology);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Connections : %s", (LPCSTR) s_con_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Algorithm 1: %s", (LPCSTR) s_alg_1_name);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Algorithm 1 file: %s", (LPCSTR) s_alg_1_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Algorithm 2: %s", (LPCSTR) s_alg_2_name);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Algorithm 2 file: %s", (LPCSTR) s_alg_2_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Result: %s", (LPCSTR) s_res_file);
	listParams->Items->Add( (System::String *) s_buf);


	//capacity overloading
	if  (b_allow_capacity_overloading)
	{
		s_buf.Format("Capacity overloading: Allowed (PENALTY: %d)", l_capa_penalty);
		listParams->Items->Add( (System::String *) s_buf);

	}//if  (b_allow_capacity_overloading)
	else
		listParams->Items->Add(S"Capacity overloading: NOT allowed");

	
	listComm->Refresh();
	listParams->Refresh();

	c_err  =  eReadPairs(s_con_file);
	if  (c_err)  return(c_err);
	
	
	vRunAlgorithmCompare
		(
		listComm,
		s_res_file,
		s_topology, s_con_file, s_con_name, s_fom_func1, s_fom_func2, 


		s_alg_1_name, s_alg_1_file,
		s_alg_2_name, s_alg_2_file,
		
		l_capa_penalty,
		b_allow_capacity_overloading
		);

	return(c_err);
}//CError  CHefanSystem::e_run_for_result_comparison




CError  CHefanSystem::e_run_for_standard_ea_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		)
{
	CError  c_err;

	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;
	long  l_capa_incr, l_capa_gen_incr;
	double  d_high_cross,  d_high_mut,  d_random_cross;
	long  l_pop_num,  l_gen_num;
	double  d_time_restriction;

	long  l_brain_avr_len;
	double  d_brain_min_inc;
	long  l_brain_time_len,  l_brain_finish_time,  l_brain_min_break;


	listComm->Items->Add(S"Reading params...");

	c_err  =  eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "flow increase", &s_info);
	if  (c_err)  return(c_err);
	l_capa_incr  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "flow increase every x generations", &s_info);
	if  (c_err)  return(c_err);
	l_capa_gen_incr  =  atol( (LPCSTR)  s_info );

	c_err  =  eReadValue(pfSettingsFile,  "High level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_high_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "High level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_high_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "High level crossing unordered", &s_info);
	if  (c_err)  return(c_err);
	d_random_cross  =  atof( (LPCSTR)  s_info);

	c_err  =  eReadValue(pfSettingsFile,  "Population size", &s_info);
	if  (c_err)  return(c_err);
	l_pop_num  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Generation number", &s_info);
	if  (c_err)  return(c_err);
	l_gen_num  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Time restriction", &s_info);
	if  (c_err)  return(c_err);
	d_time_restriction  =  atof( (LPCSTR)  s_info);

	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm radius", &s_info);
	if  (c_err)  return(c_err);
	l_brain_avr_len  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm turn on perc", &s_info);
	if  (c_err)  return(c_err);
	d_brain_min_inc  =  atof( (LPCSTR)  s_info);
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm duration", &s_info);
	if  (c_err)  return(c_err);
	l_brain_time_len  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm turning off", &s_info);
	if  (c_err)  return(c_err);
	l_brain_finish_time  =  atol( (LPCSTR)  s_info );
	c_err  =  eReadValue(pfSettingsFile,  "Brainstorm min break", &s_info);
	if  (c_err)  return(c_err);
	l_brain_min_break  =  atol( (LPCSTR)  s_info );

	fclose(pfSettingsFile);
				
	listComm->Items->Add(S"...successful");

	//the population size nedds to be divided by 4 first
	l_pop_num  =  l_pop_num / 4;

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch;

	//now inserting params into the params window
	listParams->Items->Clear();


	CString  s_buf;
	//general data
	s_buf.Format("Algorithm: %s", HEFAN_1_0_NAME);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Fit function: %s", (LPCSTR) s_fom_func);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Topology: %s", (LPCSTR) s_topology);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Connections : %s", (LPCSTR) s_con_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Ini file: %s", (LPCSTR) s_ini_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Virtual ways: %s", (LPCSTR) s_vw_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Result: %s", (LPCSTR) s_res_file);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population fit watch file: %s", (LPCSTR) s_pop_fom_watch);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Cloner repetations: %d", l_clo_rep);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Inited shortest ways between nodes: %d", l_shortest_ways_number);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Resulting individuals number: %d", l_res_num);
	listParams->Items->Add( (System::String *) s_buf);


	//capacity overloading
	if  (b_allow_capacity_overloading)
	{
		s_buf.Format("Capacity overloading: Allowed (PENALTY: %d)", l_capa_penalty);
		listParams->Items->Add( (System::String *) s_buf);

	}//if  (b_allow_capacity_overloading)
	else
		listParams->Items->Add(S"Capacity overloading: NOT allowed");

	s_buf.Format("Capacity increase/generations: %d/%d", l_capa_incr, l_capa_gen_incr);
	listParams->Items->Add( (System::String *) s_buf);


		
	//algorithm parameters
	s_buf.Format("High lvl: cross/mutation: %lf/%lf", d_high_cross,  d_high_mut);
	listParams->Items->Add( (System::String *) s_buf);
	s_buf.Format("High lvl: random crossing: %lf", d_random_cross);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);

	if  (d_time_restriction  >  0)
		s_buf.Format("Time restriction: %lf", d_time_restriction);
	else
		s_buf.Format("Number of generations: %ld", l_gen_num);
    	
	s_buf.Format("Population size: %d", l_pop_num * 4);
	listParams->Items->Add( (System::String *) s_buf);


	//brainstorm
	s_buf.Format("Brainstorm averaging window length: %d", l_brain_avr_len);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Brainstorm minimum required increase: %lf", d_brain_min_inc);
	listParams->Items->Add( (System::String *) s_buf);

	s_buf.Format("Brainstorm: ON time/Turning off time/Minimum break: %d/%d/%d", l_brain_time_len,  l_brain_finish_time,  l_brain_min_break);
	listParams->Items->Add( (System::String *) s_buf);
	
	listComm->Refresh();
	listParams->Refresh();

	c_err  =  eReadPairs(s_con_file);
	if  (c_err)  return(c_err);

	
	vRunAlgorithm_Standard_EA
		(
		listComm,
		s_topology, s_vw_file, s_ini_file, 
		l_clo_rep, l_shortest_ways_number, 
		s_fom_func, 
		d_high_cross,  d_high_mut,  d_random_cross,
		l_capa_penalty, l_pop_num,  l_gen_num,  d_time_restriction, l_res_num,
		s_res_file, s_pop_fom_watch, NULL,
		l_capa_incr, l_capa_gen_incr,
		b_allow_capacity_overloading,
		l_brain_avr_len,  d_brain_min_inc,	l_brain_time_len,  l_brain_finish_time,  l_brain_min_break
		);


	return(c_err);
}//CError  CHefanSystem::e_run_for_standard_ea_header_2_0



CError  CHefanSystem::e_run_for_hefan_header_2_0
	(
	CString  sSettingsFile,
	System::Windows::Forms::ListBox *  listParams,
	System::Windows::Forms::ListBox *  listComm
	)
{
	CError  c_err;
	CString  s_buf;

	CString  s_mother_directory,  s_settings_file_directory;

	FileInfo  *pc_fi;
	pc_fi  =  new  FileInfo(sSettingsFile);
	s_settings_file_directory  =  pc_fi->Directory->FullName;
	//s_mother_directory  =  (Directory::GetParent(s_settings_file_directory))->FullName;
	s_mother_directory  =  s_settings_file_directory;


	FILE  *pf_settings_file;

	listComm->Items->Clear();

	int  i_seed;
	i_seed = MyMath::iRandomize();
	s_buf.Format("SEED: %d", i_seed);
	listComm->Items->Add( (System::String *) s_buf);

	listComm->Items->Add(S"Opening file...");
	pf_settings_file  =  fopen(sSettingsFile, "r+");
	if  (pf_settings_file  ==  NULL)
	{
		s_buf.Format("Unable to open file (%s)", (LPCSTR)  sSettingsFile);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_source  ==  NULL)

	listComm->Items->Add(S"...successful");
	
	
		
	CString  s_info,  s_comment;
	vReadLine(pf_settings_file, &s_info, &s_comment);//script version...
	vReadLine(pf_settings_file, &s_info, &s_comment);


	if  (s_comment.MakeLower()  !=  "algorithm")
	{
        c_err.vPutError("'algorithm' definition expected");	
		return(c_err);
	}//if  (s_comment.MakeLower()  !=  "algorithm")

	bool  b_algorithm_type_found  =  false;
	if  (s_info.MakeUpper()  ==  EA_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_run_for_standard_ea_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			listParams,  listComm
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)


	if  (s_info.MakeUpper()  ==  ISLAND_MODEL_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_run_for_island_model_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			listParams,  listComm
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)




	if  (s_info.MakeUpper()  ==  _3LO_ALG_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_run_for_3LO_alg_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			listParams,  listComm
			);
	}//if  (s_info.MakeUpper()  ==  _3LO_LTGA_NAME)



	if  (s_info.MakeUpper()  ==  _IC_PSO_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_run_for_ic_pso_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			listParams,  listComm
			);
	}//if  (s_info.MakeUpper()  ==  _IC_PSO_NAME)


	

	if  (s_info.MakeUpper()  ==  VMEA_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_run_for_vmea_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			listParams,  listComm
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)


		
    if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_run_for_hefan_1_0_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			listParams,  listComm
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)

	
	if  (s_info.MakeUpper()  ==  HEFAN_1_1_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_run_for_hefan_1_1_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			listParams,  listComm
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)


	if  ( (s_info.MakeUpper()  ==  HEFAN_2_0_NAME)||(s_info.MakeUpper()  ==  HEFAN_2_1_NAME)||(s_info.MakeUpper()  ==  HEFAN_2_2_NAME) )
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_run_for_hefan_2_0_or_2_1_or_2_2_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			listParams,  listComm,
			s_info.MakeUpper()
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)


	if  (s_info.MakeUpper()  ==  RESULT_COMPARISON)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_run_for_result_comparison
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			listParams,  listComm
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)



	if  (b_algorithm_type_found  ==  false)
	{
		s_buf.Format("Algorithm named '%s' not found", (LPCSTR) s_info.MakeUpper());
		c_err.vPutError(s_buf);
		fclose(pf_settings_file);
		return(c_err);	
	}//if  (b_algorithm_type_found  ==  false)

	fclose(pf_settings_file);
	return(c_err);
}//CError  CHefanSystem::e_load_for_hefan_1_1()







CError  CHefanSystem::eRunFile
	(
	CString  sSettingsFile,
	System::Windows::Forms::ListBox *  listParams,
	System::Windows::Forms::ListBox *  listComm
	)
{
	CError  c_err;
	CString  s_buf;
	

	int  i_header_type;
	c_err  =  eCheckHeader(sSettingsFile, &i_header_type); 
	if  (c_err)  return(c_err);

	
	if  (i_header_type  ==  HEADER_TYPE_HEFAN_1_0)
	{
		c_err  =  e_run_for_hefan_header_1_0(sSettingsFile, listParams, listComm);
	}//if  (i_header_type  ==  HEADER_TYPE_HEFAN_1_0)


	if  (i_header_type  ==  HEADER_TYPE_HEFAN_2_0)
	{
		c_err  =  e_run_for_hefan_header_2_0(sSettingsFile, listParams, listComm);
	}//if  (i_header_type  ==  HEADER_TYPE_HEFAN_1_1)


	return(c_err);
}//CError  CHefanSystem::eRunFile(CString  sSettingsFile)



CError  CHefanSystem::eRunSetOfFiles(CString  sSettingsFile, vector  <CString>  *pvSetOfFiles)
{
	CError  c_err;

	return(c_err);
}//CError  CHefanSystem::eLoadSetOfFiles(CString  sSettingsFile, vector  <CString>  *pvSetOfFiles)




CError  CHefanSystem::eGetSolutionFitness
	(
	CString  sTopologyFile,  CString  sConFile,  CString  sIniFile, CString  sFOMFunc,
	double  *pdFitness, long  lPenalty
	)
{
	CError  c_err;

	if  (pc_finder  !=  NULL)  delete  pc_finder;
	pc_finder  =  new  CTrajectorySetsFinder;
	if  (pc_finder  ==  NULL)
	{
		c_err.vPutError("Memory allocation problems");
		return(c_err);	
	}//if  (pc_finder  ==  NULL)


	if  ( (sTopologyFile == "")||(pc_finder->iLoadNetTopology(sTopologyFile)  !=  1) )
	{
		c_err.vPutError("Topoplogy loading was unsuccesfull...");
		return(c_err);
	}//if  (c_finder.iLoadNetTopology(sTopologyFile)  !=  1)


	if  (pc_finder->iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)
	{
		c_err.vPutError("Couldn't neither load nor create basic virtual ways database");
		return(c_err);
	}//if  (c_finder.iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)

	if  (pc_finder->iLoadVirtualWays("temp.cod", false)  !=  1)
	{
		c_err.vPutError("Couldn't load basic virtual ways database");
		return(c_err);
	}//if  (c_finder.iLoadVirtualWays("temp.cod")  !=  1)
		
		
	if  (pc_finder->iSetFOMfunction(sFOMFunc)  !=  1)
	{
		c_err.vPutError("Bad FOM function name");
		return(c_err);
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)


	c_err  =  eReadPairs(sConFile);
	if  (c_err)  return(c_err);

	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{
		c_err.vPutError("Couldn't input trajectory pairs to find");
		return(c_err);		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)


	c_err  =  pc_finder->eGetIniFitness(sIniFile, pdFitness, lPenalty);


	return(c_err);
}//CError  CHefanSystem::eGetSolutionFitness








void  CHefanSystem::vRunAlgorithm_HEFAN_2_0_or_2_1_or_2_2
		(System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,
		double  dHighCross,  double  dHighMut,
		double  dLowCross,  double  dLowMut,
		double  dRandomCross,//influences the high level crossing shape
		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		long  lPopNum,  long  lGenNum,  double  dTimeRestriction, 
		long  lResNum,
		CString  sResFile,  CString  sPopFOMTrackingFile, FILE  *pfResFile,
		long  lCapaIncr,  long  lCapaGenIncr,
		bool  bAllowCapacityOverloading,

		//brainstorming
		long  lBrainAvrLen,  double  dBrainMinInc,
		long  lBrainTimeLen,  long  lBrainFinishTime,
		long  lBrainMinBreak,
		int  iAlgorithmVersion  //0- 2.0; 1- 2.1; 2- 2.2
		)
{

	if  (pc_finder  !=  NULL)  delete  pc_finder;
	pc_finder  =  new  CTrajectorySetsFinder;
	if  (pc_finder  ==  NULL)
	{
		listComm->Items->Add(S"ERROR\n Memory allocation problems");
		return;	
	}//if  (pc_finder  ==  NULL)


	listComm->Items->Add(S"Loading topoplogy...");


	if  ( (sTopologyFile == "")||(pc_finder->iLoadNetTopology(sTopologyFile)  !=  1) )
	{
		listComm->Items->Add(S"Topoplogy loading was unsuccesfull...");
		return;
	}//if  (c_finder.iLoadNetTopology(sTopologyFile)  !=  1)


	if  ( (sVWFile  ==  "")||(pc_finder->iLoadVirtualWays(sVWFile, true)  !=  1) )
	{
		listComm->Items->Add(S"Virtual ways loading was unsuccesfull...\n Creating basic database");

		if  (pc_finder->iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't neither load nor create basic virtual ways database");
			return;
		}//if  (c_finder.iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)


		if  (pc_finder->iLoadVirtualWays("temp.cod", false)  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't load basic virtual ways database");
			return;
		}//if  (c_finder.iLoadVirtualWays("temp.cod")  !=  1)
		
	}//if  (c_finder.iLoadVirtualWays(sVWFile, true)  !=  1)


	//now cloning
	CString  s_buf;
	for  (long  li = 0; li < lCloneRoundsNumber; li++)
	{
		s_buf.Format("Cloning operation - %ld round in progres.", li+1);
		
		listComm->Items->Add( (System::String *) s_buf);

		
		if  (pc_finder->iCloneVirtualWays()  !=  1)
		{
			listComm->Items->Add(S"ERROR\n While cloning Virtual Ways Database");
		
		}//if  (c_finder.iCloneVirtualWays()  !=  1)
	
	}//for  (long  li = 0; li < lCloneRoundsNumber; li++)


	if  (pc_finder->iGetShortestWays(iShortestWaysNumber, listComm)  !=  1)  
	{
		listComm->Items->Add(S"Unable to generate shortest ways...");
		return;
	}//if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)
	
	



	if  (pc_finder->iSetFOMfunction(sFOMFunc)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Bad FOM function name");
		return;
	
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)






	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Couldn't input trajectory pairs to find");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)



	if  (
		bAllowCapacityOverloading  !=  pc_finder->bAllowCapacityOverloading(bAllowCapacityOverloading)
		)  
	{
		listComm->Items->Add(S"ERROR\n Couldn't setr proper capacity overloading allowment");
		return;
	}//if  (


	if  (
		pc_finder->iFindBestSet_2_0_or_2_1_or_2_2
			(
			listComm,
			lGenNum, lPopNum, dTimeRestriction, 
			dHighCross,  dHighMut,
			dLowCross,  dLowMut,
			dRandomCross,
			lPenalty,
			sIniFile,
			lResNum,
			sResFile, sPopFOMTrackingFile, pfResFile, 
			false,
			lCapaIncr,  lCapaGenIncr,

			//brainstorming
			lBrainAvrLen,  dBrainMinInc,
			lBrainTimeLen,  lBrainFinishTime,
			lBrainMinBreak,
			iAlgorithmVersion
			)
		!=  1
		)
	{

		listComm->Items->Add(S"ERROR\n Couldn't search for trajectories because of UNKNOWN ERROR");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)


};//void  CHefanSystem::vRunAlgorithm_HEFAN_2_0
















void  CHefanSystem::vRunAlgorithm_HEFAN_1_1
		(System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,
		double  dHighCross,  double  dHighMut,
		double  dLowCross,  double  dLowMut,
		double  dRandomCross,//influences the high level crossing shape
		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		long  lPopNum,  long  lGenNum,  double  dTimeRestriction, 
		long  lResNum,
		CString  sResFile,  CString  sPopFOMTrackingFile, FILE *pfResFile,
		long  lCapaIncr,  long  lCapaGenIncr,
		bool  bAllowCapacityOverloading,

		//brainstorming
		long  lBrainAvrLen,  double  dBrainMinInc,
		long  lBrainTimeLen,  long  lBrainFinishTime,
		long  lBrainMinBreak
		)
{

	if  (pc_finder  !=  NULL)  delete  pc_finder;
	pc_finder  =  new  CTrajectorySetsFinder;
	if  (pc_finder  ==  NULL)
	{
		listComm->Items->Add(S"ERROR\n Memory allocation problems");
		return;	
	}//if  (pc_finder  ==  NULL)


	listComm->Items->Add(S"Loading topoplogy...");


	if  ( (sTopologyFile == "")||(pc_finder->iLoadNetTopology(sTopologyFile)  !=  1) )
	{
		listComm->Items->Add(S"Topoplogy loading was unsuccesfull...");
		return;
	}//if  (c_finder.iLoadNetTopology(sTopologyFile)  !=  1)


	if  ( (sVWFile  ==  "")||(pc_finder->iLoadVirtualWays(sVWFile, true)  !=  1) )
	{
		listComm->Items->Add(S"Virtual ways loading was unsuccesfull...\n Creating basic database");

		if  (pc_finder->iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't neither load nor create basic virtual ways database");
			return;
		}//if  (c_finder.iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)


		if  (pc_finder->iLoadVirtualWays("temp.cod", false)  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't load basic virtual ways database");
			return;
		}//if  (c_finder.iLoadVirtualWays("temp.cod")  !=  1)
		
	}//if  (c_finder.iLoadVirtualWays(sVWFile, true)  !=  1)


		
	//now cloning
	CString  s_buf;
	for  (long  li = 0; li < lCloneRoundsNumber; li++)
	{
		s_buf.Format("Cloning operation - %ld round in progres.", li+1);
		
		listComm->Items->Add( (System::String *) s_buf);

		
		if  (pc_finder->iCloneVirtualWays()  !=  1)
		{
			listComm->Items->Add(S"ERROR\n While cloning Virtual Ways Database");
		
		}//if  (c_finder.iCloneVirtualWays()  !=  1)
	
	}//for  (long  li = 0; li < lCloneRoundsNumber; li++)


	if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  
	{
		listComm->Items->Add(S"Unable to generate shortest ways...");
		return;
	}//if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  


	
	

	if  (pc_finder->iSetFOMfunction(sFOMFunc)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Bad FOM function name");
		return;
	
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)






	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Couldn't input trajectory pairs to find");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)



	if  (
		bAllowCapacityOverloading  !=  pc_finder->bAllowCapacityOverloading(bAllowCapacityOverloading)
		)  
	{
		listComm->Items->Add(S"ERROR\n Couldn't setr proper capacity overloading allowment");
		return;
	}//if  (


	if  (
		pc_finder->iFindBestSet_1_1
			(
			listComm,
			lGenNum, lPopNum, dTimeRestriction, 
			dHighCross,  dHighMut,
			dLowCross,  dLowMut,
			dRandomCross,
			lPenalty,
			sIniFile,
			lResNum,
			sResFile, sPopFOMTrackingFile, pfResFile,
			false,
			lCapaIncr,  lCapaGenIncr,

			//brainstorming
			lBrainAvrLen,  dBrainMinInc,
			lBrainTimeLen,  lBrainFinishTime,
			lBrainMinBreak
			)
		!=  1
		)
	{

		listComm->Items->Add(S"ERROR\n Couldn't search for trajectories because of UNKNOWN ERROR");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)


};//void  CHefanSystem::vRunAlgorithm_HEFAN_1_1






void  CHefanSystem::vRunAlgorithm_HEFAN_1_0
		(System::Windows::Forms::ListBox *  listComm,  
		 CString  sTopologyFile,  CString  sVWFile,
		 CString  sIniFile,
		 long lCloneRoundsNumber, int  iShortestWaysNumber,
		 CString  sFOMFunc,
		 double  dHighCross,  double  dHighMut,
		 double  dLowCross,  double  dLowMut,
		 double  dRandomCross,//it affects high level crossing way
		 long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		 long  lPopNum,  long  lGenNum,  double  dTimeRestriction, 
		 long  lResNum,
		 CString  sResFile,  CString  sPopFOMTrackingFile, FILE *pfResFile,
		 long  lCapaIncr,  long  lCapaGenIncr,
		 bool  bAllowCapacityOverloading,

		 //brainstorming
		 long  lBrainAvrLen,  double  dBrainMinInc,
		 long  lBrainTimeLen,  long  lBrainFinishTime,
		 long  lBrainMinBreak
		 )
{

	if  (pc_finder  !=  NULL)  delete  pc_finder;
	pc_finder  =  new  CTrajectorySetsFinder;
	if  (pc_finder  ==  NULL)
	{
		listComm->Items->Add(S"ERROR\n Memory allocation problems");
		return;	
	}//if  (pc_finder  ==  NULL)


	listComm->Items->Add(S"Loading topoplogy...");


	if  ( (sTopologyFile == "")||(pc_finder->iLoadNetTopology(sTopologyFile)  !=  1) )
	{
		listComm->Items->Add(S"Topoplogy loading was unsuccesfull...");
		return;
	}//if  (c_finder.iLoadNetTopology(sTopologyFile)  !=  1)


	
	if  ( (sVWFile  ==  "")||(pc_finder->iLoadVirtualWays(sVWFile, true)  !=  1) )
	{
		listComm->Items->Add(S"Virtual ways loading was unsuccesfull...\n Creating basic database");

		if  (pc_finder->iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't neither load nor create basic virtual ways database");
			return;
		}//if  (c_finder.iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)


		if  (pc_finder->iLoadVirtualWays("temp.cod", false)  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't load basic virtual ways database");
			return;
		}//if  (c_finder.iLoadVirtualWays("temp.cod")  !=  1)
		
	}//if  (c_finder.iLoadVirtualWays(sVWFile, true)  !=  1)


	
	//now cloning
	CString  s_buf;
	for  (long  li = 0; li < lCloneRoundsNumber; li++)
	{
		s_buf.Format("Cloning operation - %ld round in progres.", li+1);
		
		listComm->Items->Add( (System::String *) s_buf);

		
		if  (pc_finder->iCloneVirtualWays()  !=  1)
		{
			listComm->Items->Add(S"ERROR\n While cloning Virtual Ways Database");
		
		}//if  (c_finder.iCloneVirtualWays()  !=  1)
	
	}//for  (long  li = 0; li < lCloneRoundsNumber; li++)


	if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  
	{
		listComm->Items->Add(S"Unable to generate shortest ways...");
		return;
	}//if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  

	

	if  (pc_finder->iSetFOMfunction(sFOMFunc)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Bad FOM function name");
		return;
	
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)






	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Couldn't input trajectory pairs to find");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)



	if  (
		bAllowCapacityOverloading  !=  pc_finder->bAllowCapacityOverloading(bAllowCapacityOverloading)
		)  
	{
		listComm->Items->Add(S"ERROR\n Couldn't setr proper capacity overloading allowment");
		return;
	}//if  (


	if  (
		pc_finder->iFindBestSet_1_0
			(
			listComm,
			lGenNum, lPopNum, dTimeRestriction, 
			dHighCross,  dHighMut,
			dLowCross,  dLowMut,
			dRandomCross,
			lPenalty,
			sIniFile,
			lResNum,
			sResFile, sPopFOMTrackingFile, pfResFile,
			false,
			lCapaIncr,  lCapaGenIncr,

			//brainstorming
			lBrainAvrLen,  dBrainMinInc,
			lBrainTimeLen,  lBrainFinishTime,
			lBrainMinBreak
			)
		!=  1
		)
	{

		listComm->Items->Add(S"ERROR\n Couldn't search for trajectories because of UNKNOWN ERROR");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)


};//void  CHefanSystem::vRunAlgorithm_HEFAN_1_0


void  CHefanSystem::vRunAlgorithm_3LO_alg
		(
		System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		bool  bAllowCapacityOverloading,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,

		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		CString  sResFile,  CString  sPopFOMTrackingFile,
		
		int  iMaxTime,
		int  i_pop_size,
		int  i_p3_leave_ind_at_level,
		int  iRandomLinkage, 
		int iLinkageScrap, int iLinkageScrapCreateEffectScrap,  int  iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScrap,
		double d_low_cross,  double d_low_mut
		)
{
	if  (pc_finder  !=  NULL)  delete  pc_finder;
	pc_finder  =  new  CTrajectorySetsFinder;
	if  (pc_finder  ==  NULL)
	{
		listComm->Items->Add(S"ERROR\n Memory allocation problems");
		return;	
	}//if  (pc_finder  ==  NULL)


	listComm->Items->Add(S"Loading topoplogy...");


	if  ( (sTopologyFile == "")||(pc_finder->iLoadNetTopology(sTopologyFile)  !=  1) )
	{
		listComm->Items->Add(S"Topoplogy loading was unsuccesfull...");
		return;
	}//if  (c_finder.iLoadNetTopology(sTopologyFile)  !=  1)


	
	if  ( (sVWFile  ==  "")||(pc_finder->iLoadVirtualWays(sVWFile, true)  !=  1) )
	{
		listComm->Items->Add(S"Virtual ways loading was unsuccesfull...\n Creating basic database");

		if  (pc_finder->iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't neither load nor create basic virtual ways database");
			return;
		}//if  (c_finder.iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)


		if  (pc_finder->iLoadVirtualWays("temp.cod", false)  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't load basic virtual ways database");
			return;
		}//if  (c_finder.iLoadVirtualWays("temp.cod")  !=  1)
		
	}//if  (c_finder.iLoadVirtualWays(sVWFile, true)  !=  1)


	
	//now cloning
	CString  s_buf;
	for  (long  li = 0; li < lCloneRoundsNumber; li++)
	{
		s_buf.Format("Cloning operation - %ld round in progres.", li+1);
		
		listComm->Items->Add( (System::String *) s_buf);

		
		if  (pc_finder->iCloneVirtualWays()  !=  1)
		{
			listComm->Items->Add(S"ERROR\n While cloning Virtual Ways Database");
		
		}//if  (c_finder.iCloneVirtualWays()  !=  1)
	
	}//for  (long  li = 0; li < lCloneRoundsNumber; li++)


	if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  
	{
		listComm->Items->Add(S"Unable to generate shortest ways...");
		return;
	}//if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  

	

	if  (pc_finder->iSetFOMfunction(sFOMFunc)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Bad FOM function name");
		return;
	
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)






	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Couldn't input trajectory pairs to find");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)



	if  (
		bAllowCapacityOverloading  !=  pc_finder->bAllowCapacityOverloading(bAllowCapacityOverloading)
		)  
	{
		listComm->Items->Add(S"ERROR\n Couldn't setr proper capacity overloading allowment");
		return;
	}//if  (


	CString  s_file_summarize;
	s_file_summarize = "";
	if  (sInParameters !=  "")
	{
		s_file_summarize.Format("%s_out.txt", sInParameters);
	}//if  (sInParameters !=  "")


	CError  c_err;

	c_err = pc_finder->eFindBestSet_3LO_alg
			(
			listComm,
			lPenalty,
			sIniFile,
			sResFile, s_file_summarize,
			

			iMaxTime,

			i_pop_size, i_p3_leave_ind_at_level, iRandomLinkage, 
			iLinkageScrap, iLinkageScrapCreateEffectScrap,  iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScrap,
			d_low_cross,  d_low_mut
			);

	if  (c_err)
	{
		c_err.vShowWindow();

		listComm->Items->Add(S"ERROR\n Couldn't search for trajectories because of UNKNOWN ERROR");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
}//void  CHefanSystem::vRunAlgorithm_3LO_ltga




void  CHefanSystem::vRunAlgorithm_IC_PSO
	(
	System::Windows::Forms::ListBox *  listComm,  
	CString  sTopologyFile,  CString  sVWFile,
	CString  sIniFile,
	bool  bAllowCapacityOverloading,
	long lCloneRoundsNumber,  int  iShortestWaysNumber,
	CString  sFOMFunc,

	long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
				//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
	CString  sResFile,  CString  sPopFOMTrackingFile,
	
	int  iMaxTime,
	int  i_pop_size,
	double d_psi_1, double d_psi_2, double d_omega,
	double  d_scaling_factor,
	int  iNoImprovementsUntilReset,
	double d_low_cross,  double d_low_mut
	)
{
	if  (pc_finder  !=  NULL)  delete  pc_finder;
	pc_finder  =  new  CTrajectorySetsFinder;
	if  (pc_finder  ==  NULL)
	{
		listComm->Items->Add(S"ERROR\n Memory allocation problems");
		return;	
	}//if  (pc_finder  ==  NULL)


	listComm->Items->Add(S"Loading topoplogy...");


	if  ( (sTopologyFile == "")||(pc_finder->iLoadNetTopology(sTopologyFile)  !=  1) )
	{
		listComm->Items->Add(S"Topoplogy loading was unsuccesfull...");
		return;
	}//if  (c_finder.iLoadNetTopology(sTopologyFile)  !=  1)


	
	if  ( (sVWFile  ==  "")||(pc_finder->iLoadVirtualWays(sVWFile, true)  !=  1) )
	{
		listComm->Items->Add(S"Virtual ways loading was unsuccesfull...\n Creating basic database");

		if  (pc_finder->iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't neither load nor create basic virtual ways database");
			return;
		}//if  (c_finder.iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)


		if  (pc_finder->iLoadVirtualWays("temp.cod", false)  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't load basic virtual ways database");
			return;
		}//if  (c_finder.iLoadVirtualWays("temp.cod")  !=  1)
		
	}//if  (c_finder.iLoadVirtualWays(sVWFile, true)  !=  1)


	
	//now cloning
	CString  s_buf;
	for  (long  li = 0; li < lCloneRoundsNumber; li++)
	{
		s_buf.Format("Cloning operation - %ld round in progres.", li+1);
		
		listComm->Items->Add( (System::String *) s_buf);

		
		if  (pc_finder->iCloneVirtualWays()  !=  1)
		{
			listComm->Items->Add(S"ERROR\n While cloning Virtual Ways Database");
		
		}//if  (c_finder.iCloneVirtualWays()  !=  1)
	
	}//for  (long  li = 0; li < lCloneRoundsNumber; li++)


	if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  
	{
		listComm->Items->Add(S"Unable to generate shortest ways...");
		return;
	}//if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  

	

	if  (pc_finder->iSetFOMfunction(sFOMFunc)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Bad FOM function name");
		return;
	
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)






	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Couldn't input trajectory pairs to find");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)



	if  (
		bAllowCapacityOverloading  !=  pc_finder->bAllowCapacityOverloading(bAllowCapacityOverloading)
		)  
	{
		listComm->Items->Add(S"ERROR\n Couldn't setr proper capacity overloading allowment");
		return;
	}//if  (


	CString  s_file_summarize;
	s_file_summarize = "";
	if  (sInParameters !=  "")
	{
		s_file_summarize.Format("%s_out.txt", sInParameters);
	}//if  (sInParameters !=  "")


	CError  c_err;

	c_err = pc_finder->eFindBestSet_IC_PSO
			(
			listComm,
			lPenalty,
			sIniFile,
			sResFile, s_file_summarize,
			

			iMaxTime,

			i_pop_size, 
			d_psi_1, d_psi_2, d_omega,
			d_scaling_factor,
			iNoImprovementsUntilReset,

			d_low_cross,  d_low_mut
			);

	if  (c_err)
	{
		c_err.vShowWindow();

		listComm->Items->Add(S"ERROR\n Couldn't search for trajectories because of UNKNOWN ERROR");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
}//void  CHefanSystem::vRunAlgorithm_IC_PSO





void  CHefanSystem::vRunAlgorithm_IslandModel
		(
		System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		bool  bAllowCapacityOverloading,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,

		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		CString  sResFile,  CString  sPopFOMTrackingFile,
		
		int  iMaxTime,
		int  iMaxInfectionsConsideredAtCrossing, int i_minimal_template_length,
	
		int  iCtStrategy,
		int  i_im_linkage_gen, int  i_migration_freq,	int  i_pop_size,
		double d_high_cross,  double d_high_mut,  double d_low_cross,  double d_low_mut, double d_random_cross,

		int  i_new_ct_disturbed_copy,//new ct is random (disturbed copy = 0), new ct is a disturbed copy of other CT (disturbed copy = 1)
		int  i_new_ct_disturbed_LLDSI,//use linkage at making a disturbed copy
		double  d_new_ct_disturbed_gene_disturbed_prob//if using a new distrubed CT without LLDSI - the probability of gene change
		)
{
	if  (pc_finder  !=  NULL)  delete  pc_finder;
	pc_finder  =  new  CTrajectorySetsFinder;
	if  (pc_finder  ==  NULL)
	{
		listComm->Items->Add(S"ERROR\n Memory allocation problems");
		return;	
	}//if  (pc_finder  ==  NULL)


	listComm->Items->Add(S"Loading topoplogy...");


	if  ( (sTopologyFile == "")||(pc_finder->iLoadNetTopology(sTopologyFile)  !=  1) )
	{
		listComm->Items->Add(S"Topoplogy loading was unsuccesfull...");
		return;
	}//if  (c_finder.iLoadNetTopology(sTopologyFile)  !=  1)


	
	if  ( (sVWFile  ==  "")||(pc_finder->iLoadVirtualWays(sVWFile, true)  !=  1) )
	{
		listComm->Items->Add(S"Virtual ways loading was unsuccesfull...\n Creating basic database");

		if  (pc_finder->iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't neither load nor create basic virtual ways database");
			return;
		}//if  (c_finder.iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)


		if  (pc_finder->iLoadVirtualWays("temp.cod", false)  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't load basic virtual ways database");
			return;
		}//if  (c_finder.iLoadVirtualWays("temp.cod")  !=  1)
		
	}//if  (c_finder.iLoadVirtualWays(sVWFile, true)  !=  1)


	
	//now cloning
	CString  s_buf;
	for  (long  li = 0; li < lCloneRoundsNumber; li++)
	{
		s_buf.Format("Cloning operation - %ld round in progres.", li+1);
		
		listComm->Items->Add( (System::String *) s_buf);

		
		if  (pc_finder->iCloneVirtualWays()  !=  1)
		{
			listComm->Items->Add(S"ERROR\n While cloning Virtual Ways Database");
		
		}//if  (c_finder.iCloneVirtualWays()  !=  1)
	
	}//for  (long  li = 0; li < lCloneRoundsNumber; li++)


	if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  
	{
		listComm->Items->Add(S"Unable to generate shortest ways...");
		return;
	}//if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  

	

	if  (pc_finder->iSetFOMfunction(sFOMFunc)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Bad FOM function name");
		return;
	
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)






	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Couldn't input trajectory pairs to find");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)



	if  (
		bAllowCapacityOverloading  !=  pc_finder->bAllowCapacityOverloading(bAllowCapacityOverloading)
		)  
	{
		listComm->Items->Add(S"ERROR\n Couldn't setr proper capacity overloading allowment");
		return;
	}//if  (


	CString  s_file_summarize;
	s_file_summarize = "";
	if  (sInParameters !=  "")
	{
		s_file_summarize.Format("%s_out.txt", sInParameters);
	}//if  (sInParameters !=  "")


	CError  c_err;

	c_err = pc_finder->eFindBestSet_IslandGa
			(
			listComm,
			lPenalty,
			sIniFile,
			sResFile, s_file_summarize,
			

			iMaxTime,

			iMaxInfectionsConsideredAtCrossing, i_minimal_template_length,

			iCtStrategy,	
			i_im_linkage_gen, i_migration_freq,	i_pop_size,
			d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross,

			i_new_ct_disturbed_copy, i_new_ct_disturbed_LLDSI, d_new_ct_disturbed_gene_disturbed_prob
			);

	if  (c_err)
	{
		c_err.vShowWindow();

		listComm->Items->Add(S"ERROR\n Couldn't search for trajectories because of UNKNOWN ERROR");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)

}//void  CHefanSystem::void  vRunAlgorithm_IslandModel




void  CHefanSystem::vRunAlgorithm_vmES
		(
		System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,

		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		CString  sResFile,  CString  sPopFOMTrackingFile,
		bool  bAllowCapacityOverloading,

		int  i_gen,
		bool  b_glue_infection_rows,//it glueas all infection in a row until the individual is stucked
		bool  b_fitness_change_templ_check,//if true then every template must cause any fitness change in the next population if not the template candidate is not considered
		int  i_max_infections_considered_at_crossing,
		int  i_the_same_template_check,
		int  i_preferred_template_length,
		int  i_minimal_template_length,

		bool  b_pattern_check_length_entrophy,  //pattern number check based on: true - length based pattern fitnes, false - entrophy based pattern fitnes,
		bool  b_use_templates_at_virus_pop_init,//when true the viruses are inited using one of templates
		bool  b_vir_init_different_to_template,//if this is set then all virus genes during init phase are set value opposite to competetive template gene's value

		int  i_virus_gen,
		int  i_virus_pop_size,
		double  d_pop_reduction_juxtapositional,
		double  d_vir_prob_cut,
		double  d_vir_prob_splice,
		double  d_vir_prob_mut,
		double  d_prob_mut_rem_gene,
		double  d_prob_mut_add_gene,
		double  d_prob_low_level_cross,
		double  d_prob_low_level_mut,
		double  d_prob_init_mut,
		int  i_virginity_rounds,
		int  iCtStrategy,
		int  iParentSelection,
		int  i_new_ct_disturbed_copy,
		int  i_new_ct_disturbed_LLDSI,
		double  d_new_ct_disturbed_gene_disturbed_prob
		)
{
	if  (pc_finder  !=  NULL)  delete  pc_finder;
	pc_finder  =  new  CTrajectorySetsFinder;
	if  (pc_finder  ==  NULL)
	{
		listComm->Items->Add(S"ERROR\n Memory allocation problems");
		return;	
	}//if  (pc_finder  ==  NULL)


	listComm->Items->Add(S"Loading topoplogy...");


	if  ( (sTopologyFile == "")||(pc_finder->iLoadNetTopology(sTopologyFile)  !=  1) )
	{
		listComm->Items->Add(S"Topoplogy loading was unsuccesfull...");
		return;
	}//if  (c_finder.iLoadNetTopology(sTopologyFile)  !=  1)


	
	if  ( (sVWFile  ==  "")||(pc_finder->iLoadVirtualWays(sVWFile, true)  !=  1) )
	{
		listComm->Items->Add(S"Virtual ways loading was unsuccesfull...\n Creating basic database");

		if  (pc_finder->iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't neither load nor create basic virtual ways database");
			return;
		}//if  (c_finder.iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)


		if  (pc_finder->iLoadVirtualWays("temp.cod", false)  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't load basic virtual ways database");
			return;
		}//if  (c_finder.iLoadVirtualWays("temp.cod")  !=  1)
		
	}//if  (c_finder.iLoadVirtualWays(sVWFile, true)  !=  1)


	
	//now cloning
	CString  s_buf;
	for  (long  li = 0; li < lCloneRoundsNumber; li++)
	{
		s_buf.Format("Cloning operation - %ld round in progres.", li+1);
		
		listComm->Items->Add( (System::String *) s_buf);

		
		if  (pc_finder->iCloneVirtualWays()  !=  1)
		{
			listComm->Items->Add(S"ERROR\n While cloning Virtual Ways Database");
		
		}//if  (c_finder.iCloneVirtualWays()  !=  1)
	
	}//for  (long  li = 0; li < lCloneRoundsNumber; li++)


	if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  
	{
		listComm->Items->Add(S"Unable to generate shortest ways...");
		return;
	}//if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  

	

	if  (pc_finder->iSetFOMfunction(sFOMFunc)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Bad FOM function name");
		return;
	
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)






	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Couldn't input trajectory pairs to find");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)



	if  (
		bAllowCapacityOverloading  !=  pc_finder->bAllowCapacityOverloading(bAllowCapacityOverloading)
		)  
	{
		listComm->Items->Add(S"ERROR\n Couldn't setr proper capacity overloading allowment");
		return;
	}//if  (


	CString  s_file_summarize;
	s_file_summarize = "";
	if  (sInParameters !=  "")
	{
		s_file_summarize.Format("%s_out.txt", sInParameters);
	}//if  (sInParameters !=  "")


	if  (
		pc_finder->eFindBestSet_vmEA
			(
			listComm,
			lPenalty,
			sIniFile,
			sResFile, s_file_summarize,
			

			i_gen,
			b_glue_infection_rows,//it glueas all infection in a row until the individual is stucked
			b_fitness_change_templ_check,//if true then every template must cause any fitness change in the next population if not the template candidate is not considered
			i_max_infections_considered_at_crossing,
			i_the_same_template_check,
			i_preferred_template_length,
			i_minimal_template_length,

			b_pattern_check_length_entrophy,  //pattern number check based on: true - length based pattern fitnes, false - entrophy based pattern fitnes,
			b_use_templates_at_virus_pop_init,//when true the viruses are inited using one of templates

			i_virus_gen,
			i_virus_pop_size,
			d_pop_reduction_juxtapositional,
			d_vir_prob_cut,
			d_vir_prob_splice,
			d_vir_prob_mut,
			d_prob_mut_rem_gene,
			d_prob_mut_add_gene,
			d_prob_low_level_cross,
			d_prob_low_level_mut,
			d_prob_init_mut,
			i_virginity_rounds,
			iCtStrategy,
			iParentSelection,
			i_new_ct_disturbed_copy,
			i_new_ct_disturbed_LLDSI,
			d_new_ct_disturbed_gene_disturbed_prob
			)
		!=  1
		)
	{

		listComm->Items->Add(S"ERROR\n Couldn't search for trajectories because of UNKNOWN ERROR");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
};//void  CHefanSystem::vRunAlgorithm_vmES



void  CHefanSystem::vRunAlgorithmCompare
		(
		System::Windows::Forms::ListBox *  listComm,  
		CString  sReportFileName,
		CString  sTopologyFile, CString  sConFile, CString  sConName, CString  sFOMFuncMain, CString  sFOMFunc2,

		CString  sAlg1Name, CString  sAlg1File,
		CString  sAlg2Name, CString  sAlg2File,

		long  lPenalty,
		bool  bAllowCapacityOverloading
		)
{
	if  (pc_finder  !=  NULL)  delete  pc_finder;
	pc_finder  =  new  CTrajectorySetsFinder;
	if  (pc_finder  ==  NULL)
	{
		listComm->Items->Add(S"ERROR\n Memory allocation problems");
		return;	
	}//if  (pc_finder  ==  NULL)


	listComm->Items->Add(S"Loading topoplogy...");


	if  ( (sTopologyFile == "")||(pc_finder->iLoadNetTopology(sTopologyFile)  !=  1) )
	{
		listComm->Items->Add(S"Topoplogy loading was unsuccesfull...");
		return;
	}//if  (c_finder.iLoadNetTopology(sTopologyFile)  !=  1)


	
	//zaladowanie sciezek musi byc zeby zainicjowal baze sceizek
	if  (pc_finder->iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)
	{
		listComm->Items->Add(S"ERROR!\n Couldn't neither load nor create basic virtual ways database");
		return;
	}//if  (c_finder.iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)

	if  (pc_finder->iLoadVirtualWays("temp.cod", false)  !=  1)
	{
		listComm->Items->Add(S"ERROR!\n Couldn't load basic virtual ways database");
		return;
	}//if  (c_finder.iLoadVirtualWays("temp.cod")  !=  1)


	if  (pc_finder->iGetShortestWays(4, listComm)  !=  1)  
	{
		listComm->Items->Add(S"Unable to generate shortest ways...");
		return;
	}//if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)

	
	if  (pc_finder->iSetFOMfunction(sFOMFuncMain)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Bad FOM function name");
		return;
	
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)



	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Couldn't input trajectory pairs to find");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)



	if  (
		bAllowCapacityOverloading  !=  pc_finder->bAllowCapacityOverloading(bAllowCapacityOverloading)
		)  
	{
		listComm->Items->Add(S"ERROR\n Couldn't setr proper capacity overloading allowment");
		return;
	}//if  (

	
	if  (
		pc_finder->iResultsCompare
			(
			listComm,
			sReportFileName,
			sTopologyFile, sConFile, sConName, sFOMFuncMain, sFOMFunc2,
						
			sAlg1Name, sAlg1File,
			sAlg2Name, sAlg2File,

			lPenalty
			)
		!=  1
		)
	{

		listComm->Items->Add(S"ERROR\n Couldn't search for trajectories because of UNKNOWN ERROR");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)


}//void  CHefanSystem::vRunAlgorithmCompare



void  CHefanSystem::vRunAlgorithm_Standard_EA
		(System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,
		double  dHighCross,  double  dHighMut,
		double  dRandomCross,//influences the high level crossing shape
		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		long  lPopNum,  long  lGenNum,  double  dTimeRestriction, 
		long  lResNum,
		CString  sResFile,  CString  sPopFOMTrackingFile, FILE *pfResFile,
		long  lCapaIncr,  long  lCapaGenIncr,
		bool  bAllowCapacityOverloading,

		//brainstorming
		long  lBrainAvrLen,  double  dBrainMinInc,
		long  lBrainTimeLen,  long  lBrainFinishTime,
		long  lBrainMinBreak
		)
{
	if  (pc_finder  !=  NULL)  delete  pc_finder;
	pc_finder  =  new  CTrajectorySetsFinder;
	if  (pc_finder  ==  NULL)
	{
		listComm->Items->Add(S"ERROR\n Memory allocation problems");
		return;	
	}//if  (pc_finder  ==  NULL)


	listComm->Items->Add(S"Loading topoplogy...");


	if  ( (sTopologyFile == "")||(pc_finder->iLoadNetTopology(sTopologyFile)  !=  1) )
	{
		listComm->Items->Add(S"Topoplogy loading was unsuccesfull...");
		return;
	}//if  (c_finder.iLoadNetTopology(sTopologyFile)  !=  1)


	
	if  ( (sVWFile  ==  "")||(pc_finder->iLoadVirtualWays(sVWFile, true)  !=  1) )
	{
		listComm->Items->Add(S"Virtual ways loading was unsuccesfull...\n Creating basic database");

		if  (pc_finder->iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't neither load nor create basic virtual ways database");
			return;
		}//if  (c_finder.iCreateBasicVirtualDatabaseFile("temp.cod")  !=  1)


		if  (pc_finder->iLoadVirtualWays("temp.cod", false)  !=  1)
		{
			listComm->Items->Add(S"ERROR!\n Couldn't load basic virtual ways database");
			return;
		}//if  (c_finder.iLoadVirtualWays("temp.cod")  !=  1)
		
	}//if  (c_finder.iLoadVirtualWays(sVWFile, true)  !=  1)


	
	//now cloning
	CString  s_buf;
	for  (long  li = 0; li < lCloneRoundsNumber; li++)
	{
		s_buf.Format("Cloning operation - %ld round in progres.", li+1);
		
		listComm->Items->Add( (System::String *) s_buf);

		
		if  (pc_finder->iCloneVirtualWays()  !=  1)
		{
			listComm->Items->Add(S"ERROR\n While cloning Virtual Ways Database");
		
		}//if  (c_finder.iCloneVirtualWays()  !=  1)
	
	}//for  (long  li = 0; li < lCloneRoundsNumber; li++)


	if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  
	{
		listComm->Items->Add(S"Unable to generate shortest ways...");
		return;
	}//if  (pc_finder->iGetShortestWays(iShortestWaysNumber)  !=  1)  

	

	if  (pc_finder->iSetFOMfunction(sFOMFunc)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Bad FOM function name");
		return;
	
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)






	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{

		listComm->Items->Add(S"ERROR\n Couldn't input trajectory pairs to find");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)



	if  (
		bAllowCapacityOverloading  !=  pc_finder->bAllowCapacityOverloading(bAllowCapacityOverloading)
		)  
	{
		listComm->Items->Add(S"ERROR\n Couldn't setr proper capacity overloading allowment");
		return;
	}//if  (


	if  (
		pc_finder->iFindBestSet_Standard_EA
			(
			listComm,
			lGenNum, lPopNum, dTimeRestriction, 
			dHighCross,  dHighMut,
			dRandomCross,
			lPenalty,
			sIniFile,
			lResNum,
			sResFile, sPopFOMTrackingFile, pfResFile,
			false,
			lCapaIncr,  lCapaGenIncr,

			//brainstorming
			lBrainAvrLen,  dBrainMinInc,
			lBrainTimeLen,  lBrainFinishTime,
			lBrainMinBreak
			)
		!=  1
		)
	{

		listComm->Items->Add(S"ERROR\n Couldn't search for trajectories because of UNKNOWN ERROR");
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)

}//void  CHefanSystem::vRunAlgorithm_Standard_EA














void  CHefanSystem::vRunAlgorithmPrevPop
		(
		 System::Windows::Forms::ListBox *  listComm, 
		 CString  sFOMFunc,
		 double  dHighCross,  double  dHighMut,
		 double  dLowCross,  double  dLowMut,
		 double  dRandomCross,//influences the high level crossing shape
		 long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		 long  lGenNum,
		 long  lResNum,
		 CString  sResFile,  CString  sPopFOMTrackingFile, FILE *pfResFile,
		 long  lCapaIncr,  long  lCapaGenIncr,
		 bool  bAllowCapacityOverloading,

		 //brainstorming
		 long  lBrainAvrLen,  double  dBrainMinInc,
		 long  lBrainTimeLen,  long  lBrainFinishTime,
		 long  lBrainMinBreak
		 )
{

			
	if  (pc_finder->iSetFOMfunction(sFOMFunc)  !=  1)
	{

		//pcWnd->lab_communictaion_text->Text  =  S"ERROR\n Bad FOM function name.";
		return;
	
	}//if  (c_finder.iSetFOMfunction(sFOMFunc)  !=  1)






	if  (pc_finder->iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)
	{

		//pcWnd->lab_communictaion_text->Text  =  S"ERROR\n Couldn't input trajectory pairs to find.";
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)


	if  (
		bAllowCapacityOverloading  !=  pc_finder->bAllowCapacityOverloading(bAllowCapacityOverloading)
		)  
		return;



	if  (
		pc_finder->iFindBestSet_1_0
			(
			listComm,
			lGenNum, 0, lResNum + 2, //lResNum + 2 - it's always at least 2 and it's always greater then lResNum...
			dHighCross,  dHighMut,
			dLowCross,  dLowMut,
			dRandomCross,
			lPenalty,
			"",//no ini file if we use the previous population
			lResNum,
			sResFile, sPopFOMTrackingFile, pfResFile,
			true,
			lCapaIncr,  lCapaGenIncr,

			//brainstorming
			lBrainAvrLen,  dBrainMinInc,
			lBrainTimeLen,  lBrainFinishTime,
			lBrainMinBreak
			)
		!=  1
		)
	{

		//pcWnd->lab_communictaion_text->Text  =  S"ERROR\n Couldn't search for trajectories because of UNKNOWN ERROR.";
		return;
		
	}//if  (c_finder.iInputTrajectorySetToFind(pl_pairs, pl_capa, l_pairs_num)  !=  1)



	

 




};//void  void  CHefanSystem::vRunAlgorithmPrevPop









