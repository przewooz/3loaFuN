#pragma once
#include  "stdafx.h"

//tools
#include  "atlstr.h"  //CString
#include <windows.h>
#include  "..\\CONetAdmin\\error.h"

#include  <vector>
#include  <iostream>

//tools
#include  "list.h"
#include  "MyMath.h"

#include  "NETsimulator.h"

#include  "TopologyTranslator.h"
#include  "TrajectorySetsFinder.h"

#include  "tools.h"

using  namespace  NETsimulator;
using  namespace  TopologyTranslator;
using  namespace  TrajectorySetsFinder;

using namespace std;
using namespace System::IO;


#pragma warning(disable:4996)



#define  SCRIPT_VER_1_0		"#SCRIPT VER. 1.0"

#define  HEADER_TYPE_HEFAN_1_0	0
#define  HEADER_TYPE_HEFAN_2_0	1

#define  RESULT_COMPARISON		"COMPARISON"
#define  VMEA_NAME				"VMEA HEFAN"
#define  ISLAND_MODEL_NAME		"ISLAND_MODEL"
#define  EA_NAME				"STANDARD EA"
#define  HEFAN_1_0_NAME			"HEFAN 1.0"
#define  HEFAN_1_1_NAME			"HEFAN 1.1"
#define  HEFAN_2_0_NAME			"HEFAN 2.0"
#define  HEFAN_2_1_NAME			"HEFAN 2.1"
#define  HEFAN_2_2_NAME			"HEFAN 2.2"

#define  _3LO_ALG_NAME			"3LO_ALG"
#define  _IC_PSO_NAME			"IC_PSO"







	#define  VGA_CT_CROSS_TYPE_NORMAL_SIZE_2	0
	#define  VGA_CT_CROSS_TYPE_NORMAL_SIZE_2_AND_DIFFRENCE_SIZE_3	1

	#define  VGA_PARAM_MAX_TIME			"max time"
	#define  VGA_PARAM_JUXTA_GENERATIONS	"juxta generations"
	#define  VGA_PARAM_POP_SIZE			"population size"
	#define  VGA_PARAM_INFECTED_POP_SIZE	"infected pop size"
	#define  VGA_PARAM_PROB_CROSS		"crossing"
	#define  VGA_PARAM_STATIC_CROSS		"static crossing"
	#define  VGA_PARAM_CROSS_TYPE		"crossing type//0-tournament size 2; 1-tournament size 2 + chance for tournament size 3 with difference-fitness"
	#define  VGA_PARAM_CHANCE_FOR_3_PARENT_DIFFR_TOURNAMENT		"chance for size 3 diffrence fitness tournament//important ONLY for tournament type 1"
	#define  VGA_PARAM_GLUE_INFECTIONS	"glue infections"
	#define  VGA_PARAM_TEMPL_FITNESS_CHECK	"template fitness check"
	#define  VGA_PARAM_PATTERN_POOL_SIZE	"pattern pool size"
	#define  VGA_PARAM_SAME_PATTERN_CHECK	"the same pattern check"
	#define  VGA_PARAM_PREFERRED_PATTERN_LENGTH	"preferred pattern length"
	#define  VGA_PARAM_MINIMAL_PATTERN_LEN	"minimal pattern length"
	#define  VGA_PARAM_LEN_OR_ENTROPHY	"length or entrophy at pattern number check"

	#define  VGA_PARAM_USE_TEMPL_AT_VIRUS_INIT		"use templates at virus init"
	#define  VGA_PARAM_VIR_INIT_DIFFERENT_TO_TEMPLATE		"init viruses genes as opposite to competetive template"
	
	#define  VGA_PARAM_VIR_GENERATIONS		"virus generations"
	#define  VGA_PARAM_VIR_POP			"virus population"
	#define  VGA_PARAM_VIR_POP_RED		"virus population reduction"
	#define  VGA_PARAM_VIR_PROB_CUT		"virus prob cut"
	#define  VGA_PARAM_VIR_PROB_SPLICE	"virus prob splice"
	#define  VGA_PARAM_VIR_PROB_MUT		"virus prob mutation"
	#define  VGA_PARAM_VIR_REM_GENE		"virus prob rem gene"
	#define  VGA_PARAM_VIR_ADD_GENE		"virus prob add gene"
	//#define  VGA_PARAM_VIR_LOW_CROSS		"virus prob low level cross"
	#define  VGA_PARAM_VIR_VIRGINITY_ROUNDS  "virus virginity rounds"
	#define  VGA_PARAM_VIR_CT_STRATEGY  "CT number strategy (positive-static number of CTs -1=classic -2=active -3=memo -4=total memo)"
	#define  VGA_PARAM_PARENT_SELECTION_STRATEGY  "Parent selection strategy (0-penalized fitness 1-fitnes and penalty divided 2-fitnes and penalty divided + incremental tournamet)"

    #define  VGA_PARAM_NEW_CT_IS_A_DISTURBED_COPY  "New subpopulation - disturbed copy (0-random init 1-disturbed copy)"
	#define  VGA_PARAM_NEW_CT_LLDSI  "LLDSI (only for disturbed copy (0-on 1-off))"
	#define  VGA_PARAM_NEW_CT_GENE_DISTURB_PROB  "Gene disturbance probability (only for disturbed copy without LLDSI"
	

	


	#define  VGA_PARAM_FMGA_POP_RED_RATE		"fmga primordial pop red rate"
	#define  VGA_PARAM_FMGA_POP_RED_PERIOD		"fmga primordial pop red period"
	#define  VGA_PARAM_FMGA_INDIV_TO_CHECK		"fmga primordial individuals to check"
	#define  VGA_PARAM_FMGA_THRESHOLD_MULTIPLE		"fmga primordial threshold multiple"



class  CHefanSystem
{

public:

	CString  sInParameters;

	CHefanSystem();
	~CHefanSystem()
	{
		if  (pl_capa  !=  NULL)  delete  []  pl_capa;
		if  (pl_pairs  !=  NULL)  delete  []  pl_pairs;
		if  (pc_finder  !=  NULL)  delete  pc_finder;
	};//~CHefanSystem()


	CError  eGetSolutionFitness
		(
		CString  sTopologyFile,  CString  sConFile,  CString  sIniFile, CString  sFOMFunc,
		double  *pdFitness, long  lPenalty
		);

	CError  eReadPairs(CString  sPairsFile);



	void  vRunAlgorithm_vmES
		(
		System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,

		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		CString  sResFile,  CString  sPopFOMTrackingFile,
		bool  bAllowCapacityOverloading,

		int  i_gen,
		bool  b_glue_infection_rows,//it glueas all infection in a row until the individual is stucked
		bool  b_fitness_change_templ_check,//if true then every template must cause any fitness change in the next population if not the template candidate is not considered
		int  i_max_infections_considered_at_crossing,
		int  i_the_same_template_check,
		int  i_preferred_template_length,
		int  i_minimal_template_length,

		bool  b_pattern_check_length_entrophy,  //pattern number check based on: true - length based pattern fitnes, false - entrophy based pattern fitnes,
		bool  b_use_templates_at_virus_pop_init,//when true the viruses are inited using one of templates
		bool  b_vir_init_different_to_template,//if this is set then all virus genes during init phase are set value opposite to competetive template gene's value

		int  i_virus_gen,
		int  i_virus_pop_size,
		double  d_pop_reduction_juxtapositional,
		double  d_vir_prob_cut,
		double  d_vir_prob_splice,
		double  d_vir_prob_mut,
		double  d_prob_mut_rem_gene,
		double  d_prob_mut_add_gene,
		double  d_prob_low_level_cross,
		double  d_prob_low_level_mut,
		double  d_prob_init_mut,
		int  i_virginity_rounds,
		int  i_no_new_ct,
		int  iParentSelection,
		int  i_new_ct_disturbed_copy,
		int  i_new_ct_disturbed_LLDSI,
		double  d_new_ct_disturbed_gene_disturbed_prob
		);


	void  vRunAlgorithm_IslandModel
		(
		System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		bool  bAllowCapacityOverloading,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,

		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		CString  sResFile,  CString  sPopFOMTrackingFile,
		
		int  iMaxTime,
		int  iMaxInfectionsConsideredAtCrossing, int i_minimal_template_length,
	
		int  iCtStrategy,
		int  i_im_linkage_gen, int  i_migration_freq,	int  i_pop_size,
		double d_high_cross,  double d_high_mut,  double d_low_cross,  double d_low_mut, double d_random_cross,

		int  i_new_ct_disturbed_copy,
		int  i_new_ct_disturbed_LLDSI,
		double  d_new_ct_disturbed_gene_disturbed_prob
		);


	void  vRunAlgorithm_3LO_alg
		(
		System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		bool  bAllowCapacityOverloading,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,

		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		CString  sResFile,  CString  sPopFOMTrackingFile,
		
		int  iMaxTime,
		int  i_pop_size,
		int  i_p3_leave_ind_at_level,
		int  iRandomLinkage, int iLinkageScrap, int  iLinkageScrapCreateEffectScrap,  int iLinkageScrapCreateEffectScrapAndConcatenatedWithProvokingScrap,
		double d_low_cross,  double d_low_mut
		);


	void  vRunAlgorithm_IC_PSO
		(
		System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		bool  bAllowCapacityOverloading,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,

		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		CString  sResFile,  CString  sPopFOMTrackingFile,
		
		int  iMaxTime,
		int  i_pop_size,
		double d_psi_1, double d_psi_2, double d_omega,
		double  d_scaling_factor,
		int  iNoImprovementsUntilReset,
		double d_low_cross,  double d_low_mut
		);


	void  vRunAlgorithmCompare
		(
		System::Windows::Forms::ListBox *  listComm,  
		CString  sReportFileName,
		CString  sTopologyFile, CString  sConFile, CString  sConName, CString  sFOMFuncMain, CString  sFOMFunc2,

		CString  sAlg1Name, CString  sAlg1File,
		CString  sAlg2Name, CString  sAlg2File,

		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		bool  bAllowCapacityOverloading
		);

	void  vRunAlgorithm_Standard_EA
		(System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,
		double  dHighCross,  double  dHighMut,
		double  dRandomCross,//influences the high level crossing shape
		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		long  lPopNum,  long  lGenNum,  double  dTimeRestriction, 
		long  lResNum,
		CString  sResFile,  CString  sPopFOMTrackingFile, FILE *pfResFile,
		long  lCapaIncr,  long  lCapaGenIncr,
		bool  bAllowCapacityOverloading,

		//brainstorming
		long  lBrainAvrLen,  double  dBrainMinInc,
		long  lBrainTimeLen,  long  lBrainFinishTime,
		long  lBrainMinBreak
		);

	void  vRunAlgorithm_HEFAN_1_0
		(System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,
		double  dHighCross,  double  dHighMut,
		double  dLowCross,  double  dLowMut,
		double  dRandomCross,//influences the high level crossing shape
		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		long  lPopNum,  long  lGenNum,  double  dTimeRestriction, 
		long  lResNum,
		CString  sResFile,  CString  sPopFOMTrackingFile, FILE *pfResFile,
		long  lCapaIncr,  long  lCapaGenIncr,
		bool  bAllowCapacityOverloading,

		//brainstorming
		long  lBrainAvrLen,  double  dBrainMinInc,
		long  lBrainTimeLen,  long  lBrainFinishTime,
		long  lBrainMinBreak
		);


	void  vRunAlgorithm_HEFAN_1_1
		(System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,
		double  dHighCross,  double  dHighMut,
		double  dLowCross,  double  dLowMut,
		double  dRandomCross,//influences the high level crossing shape
		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		long  lPopNum,  long  lGenNum,  double  dTimeRestriction, 
		long  lResNum,
		CString  sResFile,  CString  sPopFOMTrackingFile, FILE *pfResFile,
		long  lCapaIncr,  long  lCapaGenIncr,
		bool  bAllowCapacityOverloading,

		//brainstorming
		long  lBrainAvrLen,  double  dBrainMinInc,
		long  lBrainTimeLen,  long  lBrainFinishTime,
		long  lBrainMinBreak
		);


	void  vRunAlgorithm_HEFAN_2_0_or_2_1_or_2_2
		(System::Windows::Forms::ListBox *  listComm,  
		CString  sTopologyFile,  CString  sVWFile,
		CString  sIniFile,
		long lCloneRoundsNumber,  int  iShortestWaysNumber,
		CString  sFOMFunc,
		double  dHighCross,  double  dHighMut,
		double  dLowCross,  double  dLowMut,
		double  dRandomCross,//influences the high level crossing shape
		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		long  lPopNum,  long  lGenNum, double  dTimeRestriction, 
		long  lResNum,
		CString  sResFile,  CString  sPopFOMTrackingFile, FILE  *pfResFile,
		long  lCapaIncr,  long  lCapaGenIncr,
		bool  bAllowCapacityOverloading,

		//brainstorming
		long  lBrainAvrLen,  double  dBrainMinInc,
		long  lBrainTimeLen,  long  lBrainFinishTime,
		long  lBrainMinBreak,
		int  AlgorithmVersion  //0- 2.0; 1- 2.1
		);

	void  vRunAlgorithmPrevPop
		(
		System::Windows::Forms::ListBox *  listComm, 
		CString  sFOMFunc,
		double  dHighCross,  double  dHighMut,
		double  dLowCross,  double  dLowMut,
		double  dRandomCross,//influences the high level crossing shape
		long  lPenalty,//if we are allowed to exceed the capacity this is the penalty put on every single capacity unit exceeding the capacity that is allowed
					//WARNING: IT DEPENDS ON THE CHOSEN FOM FUNCTION!!!
		long  lGenNum,
		long  lResNum,
		CString  sResFile,  CString  sPopFOMTrackingFile, FILE *pfResFile,
		long  lCapaIncr,  long  lCapaGenIncr,
		bool  bAllowCapacityOverloading,

		//brainstorming
		long  lBrainAvrLen,  double  dBrainMinInc,
		long  lBrainTimeLen,  long  lBrainFinishTime,
		long  lBrainMinBreak
		);


	static  CError  eCheckHeader(CString  sSettingsFile,  int  *piHeaderType)
	{
		CError  c_err;
		CString  s_buf;

		FILE  *pf_settings;
		pf_settings  =  fopen(sSettingsFile, "r+");
		if  (pf_settings  == NULL)
		{
			s_buf.Format("Unable to open file (%s)", (LPCSTR) sSettingsFile);
			c_err.vPutError(s_buf);
			return(c_err);
		}//if  (pf_settings  == NULL)

		char  c_buf;
		fscanf(pf_settings,"%c", &c_buf);
		if  (c_buf  ==  '#')
			*piHeaderType  =  HEADER_TYPE_HEFAN_2_0;
		else
			*piHeaderType  =  HEADER_TYPE_HEFAN_1_0;

		fclose(pf_settings);
		return(c_err);
	
	}//static  CError  eCheckHeader(CString  sSettingsFile,  int  *piHeaderType)
	static  CError  eReadValue(FILE  *pfSource, CString  sValueName,  CString  *psInfo)
	{
		CError  c_err;
		CString  s_buf,  s_info,  s_comment;

		if  (sValueName  ==  "")
		{
			c_err.vPutError("No value name");
			return(c_err);		
		}//if  (sValueName  ==  "")

		while  ( (s_comment.MakeLower()  !=  sValueName.MakeLower())&&(!feof(pfSource)) )
		{
			//::Tools::vShow(s_comment + "!=" + sValueName);
			vReadLine(pfSource, &s_info,  &s_comment);
		}

		if  (feof(pfSource))
		{
			s_buf.Format("Couldnt find (%s) value",  (LPCSTR)  sValueName);
			c_err.vPutError(s_buf);
			return(c_err);
		}//if  (feof(pfSource))
		else
		{
			*psInfo  =  s_info;
			return(c_err);
		}//else  if  (feof(pfSource))
	
		return(c_err);
	}//static  CError  eReadValue(FILE  *pfSource, CString  sValueName,  CString  *psInfo)
	static  void    vReadLine(FILE  *pfSource, CString  *psInfo, CString  *psComments)
	{

		char  c_buf;
		int  i_count = 0;
		CString  s_buf_info, s_buf_comment;
		bool  b_first_slash;
		bool  b_comment;

		c_buf  =  'a';//initial step so the for loop is not finished before it is started


		b_first_slash  =  false;
		b_comment  =  false;
		s_buf_info  =  "";
		s_buf_comment  =  "";
		for  (;(c_buf  !=  '\n')&&(!feof(pfSource));)
		{
			fscanf(pfSource,"%c", &c_buf);

			if  ( (c_buf  ==  '/')&&(b_first_slash  ==  true)&&(b_comment  ==  false) )  b_comment  =  true;
			if  ( (c_buf  ==  '/')&&(b_first_slash  ==  false)&&(b_comment  ==  false) )  b_first_slash  =  true;

			//if  ( (c_buf  ==  '\\')&&(b_first_slash  ==  true)&&(b_comment  ==  false) )  b_comment  =  true;
			//if  ( (c_buf  ==  '\\')&&(b_first_slash  ==  false)&&(b_comment  ==  false) )  b_first_slash  =  true;

			if  ( (c_buf  !=  '\n')&&(b_comment  ==  false)&&(c_buf  !=  '/') )
			//if  ( (c_buf  !=  '\n')&&(b_comment  ==  false)&&(c_buf  !=  '\\') )
			{
				if  (b_first_slash  ==  true)
				{
					b_first_slash  =  false;
					s_buf_info  +=  '/';
				}//if  (b_first_slash  ==  true)

				s_buf_info  +=  c_buf;
			}//if  ( (c_buf  !=  '\n')&&(b_comment  ==  false) )  

			if  ( (c_buf  !=  '\n')&&(b_comment  ==  true) )
			{
				if  (b_first_slash  ==  true)
					b_first_slash  =  false;
				else
					s_buf_comment  +=  c_buf;		
			}//if  ( (c_buf  !=  '\n')&&(b_comment  ==  true) )

		}//for  (;pc_buf[i_count] == '\n';)

		*psInfo  =  s_buf_info;
		*psComments  =  s_buf_comment;

	}//void  vReadLine(FILE  *pfSource, CString  *psBuffer)


	

	static int  iExtractFromString(CString  sLineToSearch, int  iIndex /*= 0*/)
	{
		CString  s_result;
		int  i_result;

		char  c_buf;
		bool  b_analyzing  =  true;

		for  (int  ii = iIndex;  (ii  <  sLineToSearch.GetLength())&&(b_analyzing  ==  true);  ii++)
		{
			b_analyzing  =  false;
			c_buf  =  sLineToSearch.GetAt(ii);

			if  ( (c_buf  >=  '0')&&(c_buf  <=  '9') )
			{
				s_result  +=  c_buf;
				b_analyzing  =  true;
			}//if  ( (c_buf  >=  '0')&&(c_buf  <=  '9') )

			if  (c_buf  == ' ')  b_analyzing  =  true;
			
		}//for  (int  ii = 0;  ii  <  sLineToSearch.GetLength();  ii++)

		
		i_result =  atoi(s_result);	
		return(i_result);
	}//int  Tools::iExtractFromString(sLineToSearch, int  iIndex /*= 0*/)



	static double  dExtractFromString(CString  sLineToSearch, int  iIndex /*= 0*/)
	{
		CString  s_result;
		double  d_result;

		char  c_buf;
		bool  b_analyzing  =  true;

		for  (int  ii = iIndex;  (ii  <  sLineToSearch.GetLength())&&(b_analyzing  ==  true);  ii++)
		{
			b_analyzing  =  false;
			c_buf  =  sLineToSearch.GetAt(ii);

			if  ( ((c_buf  >=  '0')&&(c_buf  <=  '9'))||(c_buf  ==  '.') )
			{
				s_result  +=  c_buf;
				b_analyzing  =  true;
			}//if  ( (c_buf  >=  '0')&&(c_buf  <=  '9') )

			if  (c_buf  == ' ')  b_analyzing  =  true;
			
		}//for  (int  ii = 0;  ii  <  sLineToSearch.GetLength();  ii++)

		d_result =  atof(s_result);	

		return(d_result);
	}//double  Tools::dExtractFromString(CString  sLineToSearch, int  iIndex /*= 0*/)



	
	CError  eRunFile
		(
		CString  sSettingsFile, 
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);
	CError  eRunSetOfFiles(CString  sSettingsFile, vector  <CString>  *pvSetOfFiles);
	
	

private:


	CError  e_run_for_hefan_header_1_0
		(
		CString  sSettingsFile, 
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);
	CError  e_run_for_hefan_header_2_0
		(
		CString  sSettingsFile, 
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);


	CError  e_run_for_island_model_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);

	CError  e_run_for_3LO_alg_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);


	CError  e_run_for_ic_pso_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);
	

	CError  e_run_for_vmea_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);

	CError  e_run_for_result_comparison
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);

	CError  e_run_for_standard_ea_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);


	CError  e_run_for_hefan_1_0_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);

	CError  e_run_for_hefan_1_1_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm
		);

	CError  e_run_for_hefan_2_0_or_2_1_or_2_2_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		System::Windows::Forms::ListBox *  listParams,
		System::Windows::Forms::ListBox *  listComm,
		CString  sAlgorithmName
		);


	long  *pl_pairs;
	long  *pl_capa;
	long  l_pairs_num;


	CTrajectorySetsFinder  *pc_finder;


};//class  CHefanSystem




