#pragma once

//tools
#include  "atlstr.h"  //CString
#include  "atlpath.h"

//system tools
#include  "..\\CONetAdmin\\error.h"





namespace Tools
{
	CString  sGetDirectory(CString  sFilePath);

	CString  sExtractNumberAtStart(CString  sSource, int iStart);
	CError  eAnalyzeRunFile(FILE  *pfSource,  FILE*  pfDest);
	CString  sReadLine(FILE  *pfSource,   CString  *psComment  =  NULL);
	int  iReadLine(FILE  *pfSource,   CString  *psComment  =  NULL);
	double  dReadLine(FILE  *pfSource,   CString  *psComment  =  NULL);
	int  iExtractFromString(CString  sLineToSearch, int  iIndex /*= 0*/);
	double  dExtractFromString(CString  sLineToSearch, int  iIndex /*= 0*/);
	CString  sExtractFromString(CString  sLineToSearch, int  iIndex /*= 0*/, int  *piFinishIndex );

	int  iSearch(CString  sLineToSearch, CString  sTextToFind, int iIndex = 0);

	int  iGetProperFileIndex(CString  sFileNameSchema);

	void  vRepInFile(CString  sFile, CString  sText);
	void  vShow(CString  sText);
	void  vShow(double  dVal);
};//namespace Tools