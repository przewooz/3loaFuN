#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for AddEditComputer
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CAddEditComputer : public System::Windows::Forms::Form
	{
	public: 
		CAddEditComputer(void)
		{
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::Button *  butOk;

	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::Label *  label1;
	public: System::Windows::Forms::TextBox *  textCompName;
	public: System::Windows::Forms::TextBox *  textCompComm;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->butCancel = new System::Windows::Forms::Button();
			this->butOk = new System::Windows::Forms::Button();
			this->textCompName = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->label1 = new System::Windows::Forms::Label();
			this->textCompComm = new System::Windows::Forms::TextBox();
			this->SuspendLayout();
			// 
			// butCancel
			// 
			this->butCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->butCancel->Location = System::Drawing::Point(376, 248);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 38;
			this->butCancel->Text = S"Cancel";
			// 
			// butOk
			// 
			this->butOk->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->butOk->Location = System::Drawing::Point(288, 248);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 37;
			this->butOk->Text = S"OK";
			// 
			// textCompName
			// 
			this->textCompName->Location = System::Drawing::Point(40, 40);
			this->textCompName->Name = S"textCompName";
			this->textCompName->Size = System::Drawing::Size(304, 20);
			this->textCompName->TabIndex = 35;
			this->textCompName->Text = S"";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(16, 16);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(88, 16);
			this->label2->TabIndex = 34;
			this->label2->Text = S"Computer name:";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(16, 80);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(112, 16);
			this->label1->TabIndex = 33;
			this->label1->Text = S"Computer comments:";
			// 
			// textCompComm
			// 
			this->textCompComm->Location = System::Drawing::Point(40, 104);
			this->textCompComm->Multiline = true;
			this->textCompComm->Name = S"textCompComm";
			this->textCompComm->Size = System::Drawing::Size(304, 128);
			this->textCompComm->TabIndex = 36;
			this->textCompComm->Text = S"";
			// 
			// CAddEditComputer
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(464, 285);
			this->Controls->Add(this->butCancel);
			this->Controls->Add(this->butOk);
			this->Controls->Add(this->textCompName);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textCompComm);
			this->Name = S"CAddEditComputer";
			this->Text = S"AddEditComputer";
			this->ResumeLayout(false);

		}		
	};
};//namespace CONetAdmin