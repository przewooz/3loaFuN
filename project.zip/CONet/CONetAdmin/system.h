#pragma once

//tools
#include  "atlstr.h"  //CString
#include  <gcroot.h>
#include <windows.h>

//windows
#include  "info_window.h"

//system tools
#include  "Error.h"
#include  <vector>
#include  <iostream>

//system
#include  "CODb.h"

//hefan tools
#include  "..\\HEFAN\\system_hefan.h"


using  namespace  CONetDbTools;


#define  NORMALIZE_NO					0
#define  NORMALIZE_STANDARD				1
#define  NORMALIZE_WINNER_TAKES_ALL		2
#define  NORMALIZE_WINNER_TAKES_ALL_WAGED	3

class  CSystem
{
public:

	CSystem();
	~CSystem();

	bool  bSaveConnConf()  {return(c_codb.bSaveConnConf("config.txt"));};
	bool  bLoadConnConf()  {return(c_codb.bLoadConnConf("config.txt"));};

	bool  bTestDbConnection(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd);
	CError  eConnect(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd)
		{CError  c_err;  c_err = c_codb.eConnect(sNewHostName, sNewDbName, sNewUser, sNewPasswd); return(c_err);};
	CError  eConnect()  {CError  c_err;  c_codb.eConnect(); return(c_err);};
	void  vGetConnParams(CString  *psNewHostName, CString  *psNewDbName, CString  *psNewUser, CString  *psNewPasswd);
	bool  bIsConnected()  {return(c_codb.bIsConnected());};

	
	void  vSetSqlConn(CCODbComponent  *pcComp);

	CError  eFindNetworkAndConnForResult
		(
		CCOResult *pcResult, CCOFDbRoot  *pcFDbRoot,
		CCONet  *pcNet,  int  *piConnIndex
		);

	CError  eFindFDbNetworkAndConnForResult
		(
		CCOResult *pcResult, 
		CCOFDbRoot  *pcFDbRoot,	CCONet  *pcNet,  CCONetConn  *pcConn
		);
	
	CError  eSelectFDbRoot(vector <CCOFDbRoot *>  *pvFDbRoots, CString sSelectSQL);
	CError  eSelectNetworks(vector <CCONet *>  *pvCONetworks, CString sSelectSQL);
	CError  eSelectConnections(vector <CCONetConn *>  *pvCOConns, CString sSelectSQL);
	CError  eSelectAlgorithms(vector <CCOAlgorithm *>  *pvCOAlgorithms, CString sSelectSQL);
	CError  eSelectFitFuncs(vector <CCOFitFunc *>  *pvCOFitFuncs, CString sSelectSQL);
	CError  eSelectComputers(vector <CCOComputer *>  *pvCOComputers, CString sSelectSQL);
	CError  eSelectResultsSets(vector <CCOResultSet *>  *pvCORSets, CString sSelectSQL);
	CError  eSelectResults(vector <CCOResult *>  *pvCOResults, CString sSelectSQL);

	CError  eLoadResultParamsFromFile
		(
		CString  sSettingsFile,
		CCOFDbRoot  *pcFdbRoot,
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		);

	CError  eLoadResultFromSolutionFile
		(
		CString  sSolutionFile,
		CCOFDbRoot  *pcFdbRoot,
		CString  sFFName,
		CCOResult  *pcResult,
		CCONet  *pcNet,  CCONetConn  *pcNetConn,
		long  lPenalty
		);

	
	CError  eGenerateReportForResults
		(
		CString  sResultFile,
		vector  <CCOResult *>  *pvResults,
		int  iNormalize = NORMALIZE_NO,
		bool  b_1IsMax  =  true
		);

	CError  CSystem::eGenerateComputationSet_Comparison
		(
		CCOFDbRoot  *pcFDBRoot,
		CString  sIniFilesDir, CString  sIniFileExt,
		CString  sMainDir,
		vector  <CCOResult  *>  *pvResults0, vector  <CCOResult  *> *pvResults1	
		);

	CError  eGenerateComputationSet_2_0
		(
		CCOFDbRoot  *pcFDBRoot,
		CString  sMainFile,
		CString  sIniFilesDir,  CString  sIniFileExt,  
		CString  sCreationDir,
		vector  <CCONetConn *>  *pvNetConns,
		vector  <CCOAlgorithm *>  *pvConfigurations,
		CString  sFitFuncName
		);

	
	CError  eSetParameter(CCOAlgorithm  *pcAlgorithm,  CString  sParamName, double  dParamVal);
	CError  eGetParameter(CCOAlgorithm  *pcAlgorithm,  CString  sParamName, double  *pdParamVal);

	CError  eGetAlgorithm(CString  sAlgorithmName,  CCOAlgorithm *pcAlgorithm,  int  iAlgorithmId = -1);
	CError  eGetNet(CCOFDbRoot  *pcFdbRoot, CCONet *pcNet,  CString  sNetName,  int iNetId  =  -1);
	CError  eGetCon(CCONet *pcNet, CString  sConName, CCONetConn  *pcNetConn);
	CError  eGetFitFunc(CString  sFitFuncName,  CCOFitFunc *pcFitFunc, int  iFFId = -1);

private:

	void  v_normalize(double  *pdRowResults,  int  *piCellResultsNumber, int  iSize, int  iNormalize, bool  b_1IsMax);
	CError  e_generate_report_file
		(
		CString  sResultFile,  
		vector  <CCOResult *>  *pvResults,  vector  <CCOAlgorithm *>  *pvAlgorithmsParams, 
		vector  <CCONetConn *>  *pvNetConns,  vector  <int>  *pvResultsColumns,
		int  iCellTextLenght  =  22,  bool  bExcelVersion  =  true,  bool  bShowNumberOfResults  =  true,
		int  iNormalize  =  NORMALIZE_NO,  bool  b_1IsMax  =  true
		);

		
	CError  e_load_result_params_from_file_header_1_0
		(
		CString  sSettingsFile,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		);

	CError  e_load_result_params_from_file_header_2_0
		(
		CString  sSettingsFile,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		);


	CError  e_load_result_params_hefan_1_0_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		);

	CError  e_load_result_params_hefan_1_1_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		);

	CError  e_load_result_params_hefan_2_0_header_2_0_and_2_1_and_2_2
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult,
		CString  sAlgorithmName  =  HEFAN_2_0_NAME
		);

	CError  e_load_result_params_standard_ea_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		);


	CError  e_load_result_params_vmea_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		);




	CCODb  c_codb;

};//class  CSystem

