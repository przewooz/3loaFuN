#include "stdafx.h"
#include "ConnectionOptions.h"
#include <windows.h>

using namespace CONetAdmin;




System::Void CConnOpt::butConnTest_Click(System::Object *  sender, System::EventArgs *  e)
{
	
	if  (
			pc_system->bTestDbConnection
			(
			editHost->Text, editDatabase->Text, 
			editUser->Text, editPasswd->Text
			)  
			==  true
		)
		::MessageBox(NULL, "Connection test successfull",  "Info", MB_OK);
	else
		::MessageBox(NULL, "Connection test failed",  "Info", MB_OK);


};//System::Void CConnOpt::butConnTest_Click(System::Object *  sender, System::EventArgs *  e)





System::Void CConnOpt::butOk_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	c_err  =  pc_system->eConnect
		(
		editHost->Text, editDatabase->Text, 
		editUser->Text, editPasswd->Text
		);
	
	if  (c_err  ==  false)
		::MessageBox(NULL, "Connection successfull",  "Info", MB_OK);
	else
	{
		c_err.vShowWindow();
		::MessageBox(NULL, "Connection failed",  "Info", MB_OK);
	}//else  


};//System::Void CConnOpt::butOk_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CConnOpt::CConnOpt_Paint(System::Object *  sender, System::Windows::Forms::PaintEventArgs *  e)
{
	CString  s_host_name,  s_db,  s_user, s_passwd;

	pc_system->vGetConnParams(&s_host_name,  &s_db,  &s_user, &s_passwd);

	editHost->Text  =  s_host_name;
	editDatabase->Text  =  s_db;
	editUser->Text  =  s_user;
	editPasswd->Text  =  s_passwd;
}//System::Void CConnOpt::CConnOpt_Paint(System::Object *  sender, System::Windows::Forms::PaintEventArgs *  e)





