#include "StdAfx.h"
#include "massive_add_info.h"


using namespace CONetAdmin;



void  CMassiveAddInfo::v_load_data()
{
	CError  c_err;
	CString  s_select_sql;


	//result sets
	for  (int ii = 0; ii < (int) pv_rsets->size(); ii++)
		delete  pv_rsets->at(ii);
	pv_rsets->clear();

	comboRSets->Items->Clear();

	s_select_sql  =  "Select * from results_sets";
	c_err  =  pc_system->eSelectResultsSets(pv_rsets, s_select_sql);

	if  (c_err)
	{
		c_err.vShowWindow();
        Close();
		return;
	}//if  (c_err)

	int  i_rset_id;
	CString  s_rset_name;
	CString  s_rset_comments;

	comboRSets->Items->Add((String *) NO_RESULTS_SET_SELECTED);	
	for  (int ii = 0; ii < (int) pv_rsets->size(); ii++)
	{
		pv_rsets->at(ii)->vGetData
			(
			&i_rset_id,
			&s_rset_name,
			&s_rset_comments
			);

		comboRSets->Items->Add((String *) s_rset_name);	
	}//for  (int ii = 0; ii < (int) ppv_computers->size(); ii++)


	
	//computers
	for  (int ii = 0; ii < (int) pv_computers->size(); ii++)
		delete  pv_computers->at(ii);
	pv_computers->clear();

	comboComput->Items->Clear();

	s_select_sql  =  "Select * from computers";
	c_err  =  pc_system->eSelectComputers(pv_computers, s_select_sql);

	if  (c_err)
	{
		c_err.vShowWindow();
        Close();
		return;
	}//if  (c_err)

	int  i_comp_id;
	CString  s_comp_name;
	CString  s_comp_comments;

	for  (int ii = 0; ii < (int) pv_computers->size(); ii++)
	{
		pv_computers->at(ii)->vGetData
			(
			&i_comp_id,
			&s_comp_name,
			&s_comp_comments
			);

		comboComput->Items->Add((String *) s_comp_name);	
	}//for  (int ii = 0; ii < (int) ppv_computers->size(); ii++)




	//algorithms
	for  (int ii = 0; ii < (int) pv_algs->size(); ii++)
		delete  pv_algs->at(ii);
	pv_algs->clear();

	comboAlg->Items->Clear();

	s_select_sql  =  "Select * from algorithms";
	c_err  =  pc_system->eSelectAlgorithms(pv_algs, s_select_sql);

	if  (c_err)
	{
		c_err.vShowWindow();
        Close();
		return;
	}//if  (c_err)

	for  (int ii = 0; ii < (int) pv_algs->size(); ii++)
	{
		comboAlg->Items->Add( (String *)  pv_algs->at(ii)->sGetAlgorithmName());	
	}//for  (int ii = 0; ii < (int) ppv_algs->size(); ii++)


	//fit_funcs
	for  (int ii = 0; ii < (int) pv_ffs->size(); ii++)
		delete  pv_ffs->at(ii);
	pv_ffs->clear();

	comboFF->Items->Clear();

	s_select_sql  =  "Select * from fit_func";
	c_err  =  pc_system->eSelectFitFuncs(pv_ffs, s_select_sql);

	if  (c_err)
	{
		c_err.vShowWindow();
        Close();
		return;
	}//if  (c_err)

	for  (int ii = 0; ii < (int) pv_ffs->size(); ii++)
	{
		comboFF->Items->Add( (String *)  pv_ffs->at(ii)->sGetName());	
	}//for  (int ii = 0; ii < (int) ppv_ffs->size(); ii++)

	
}//void  CMassiveAddInfo::v_load_data()



System::Void CMassiveAddInfo::butCancel_Click(System::Object *  sender, System::EventArgs *  e)
{
	DialogResult  =  DialogResult::Cancel;
}//System::Void CMassiveAddInfo::butCancel_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CMassiveAddInfo::butOk_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  ( (comboComput->SelectedIndex  >=  (int)  pv_computers->size())||(comboComput->SelectedIndex < 0) )
	{
		c_err.vPutError("Wrong computer selection index or no computer selected");
		c_err.vShowWindow();
		return;	
	}//if  ( (comboComput->SelectedIndex  >=  (int)  pv_computers->size())||(comboComput->SelectedIndex < 0) )

	if  (comboAlg->Visible  ==  true)
	{
		if  ( (comboAlg->SelectedIndex  >=  (int)  pv_algs->size())||(comboAlg->SelectedIndex < 0) )
		{
			c_err.vPutError("Wrong algorithm selection index or no algorithm selected");
			c_err.vShowWindow();
			return;	
		}//if  ( (comboComput->SelectedIndex  >=  (int)  pv_computers->size())||(comboComput->SelectedIndex < 0) )
	}//if  (comboAlg->Visible  ==  true)

	
	if  ( (comboRSets->SelectedIndex - 1 >=  (int)  pv_rsets->size())||(comboRSets->SelectedIndex < 0) )
	{
		c_err.vPutError("Wrong results set selection index or no results set selected");
		c_err.vShowWindow();
		return;	
	}//if  ( (comboComput->SelectedIndex  >=  (int)  pv_computers->size())||(comboComput->SelectedIndex < 0) )

	iResultCompId  =  pv_computers->at(comboComput->SelectedIndex)->iGetId();
	if  (comboAlg->Visible  ==  true)
		iResultAlgId  =  pv_algs->at(comboAlg->SelectedIndex)->iGetId();
	
	if  (comboFF->Visible  ==  true)
		iResultFFId  =  pv_ffs->at(comboFF->SelectedIndex)->iGetId();
	
	if  (comboRSets->SelectedIndex  ==  0)
		iResultRSetId  =  -1;
	else
		iResultRSetId  =  pv_rsets->at(comboRSets->SelectedIndex - 1)->iGetId();

	DialogResult  =  DialogResult::OK;
}//System::Void CMassiveAddInfo::butOk_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CMassiveAddInfo::CMassiveAddInfo_Activated(System::Object *  sender, System::EventArgs *  e)
{

	if  (b_activated  ==  false)
	{
		v_load_data();
		b_activated  =  true;	
	}//if  (b_activated  ==  false)

}//System::Void CMassiveAddInfo::CMassiveAddInfo_Activated(System::Object *  sender, System::EventArgs *  e)