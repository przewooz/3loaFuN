#pragma once

#include  "atlstr.h"  //CString
#include  "system.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for massive_add_info
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CMassiveAddInfo : public System::Windows::Forms::Form
	{
	public: 
		CMassiveAddInfo(CSystem  *pcSystem)
		{
			b_activated  =  false;
			pc_system  =  pcSystem;
			iResultCompId  =  -1;
			iResultRSetId  =  -1;
			iResultAlgId  =  -1;
			iResultFFId  =  -1;
			pv_computers  =  new  vector <CCOComputer *>;
			pv_rsets  =  new  vector <CCOResultSet *>;
			pv_algs  =  new  vector <CCOAlgorithm *>;
			pv_ffs  =  new  vector <CCOFitFunc *>;
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			for  (int ii = 0; ii < (int) pv_computers->size(); ii++)
				delete  pv_computers->at(ii);
			delete  pv_computers;

			for  (int ii = 0; ii < (int) pv_rsets->size(); ii++)
				delete  pv_rsets->at(ii);
			delete  pv_rsets;

			for  (int ii = 0; ii < (int) pv_algs->size(); ii++)
				delete  pv_algs->at(ii);
			delete  pv_algs;

			for  (int ii = 0; ii < (int) pv_ffs->size(); ii++)
				delete  pv_ffs->at(ii);
			delete  pv_ffs;

			
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
        
	private:
		CSystem  *pc_system;
		vector <CCOComputer *>  *pv_computers;
		vector <CCOResultSet *>  *pv_rsets;
		vector <CCOAlgorithm *>  *pv_algs;
		vector <CCOFitFunc *>  *pv_ffs;
	private: System::Windows::Forms::Button *  butOk;
	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::ComboBox *  comboRSets;

	public: System::Windows::Forms::ComboBox *  comboAlg;
	public: System::Windows::Forms::Label *  lab_alg;
	public: System::Windows::Forms::Label *  lab_ff;
	public: System::Windows::Forms::ComboBox *  comboFF;
			bool  b_activated;
		void  v_load_data();


	public:  int  iResultCompId;
	public:  int  iResultRSetId;
	public:  int  iResultAlgId;
	public:  int  iResultFFId;
			 
	private: System::Windows::Forms::Label *  label8;
	private: System::Windows::Forms::ComboBox *  comboComput;
			 

		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label8 = new System::Windows::Forms::Label();
			this->comboComput = new System::Windows::Forms::ComboBox();
			this->butOk = new System::Windows::Forms::Button();
			this->butCancel = new System::Windows::Forms::Button();
			this->label1 = new System::Windows::Forms::Label();
			this->label2 = new System::Windows::Forms::Label();
			this->comboRSets = new System::Windows::Forms::ComboBox();
			this->lab_alg = new System::Windows::Forms::Label();
			this->comboAlg = new System::Windows::Forms::ComboBox();
			this->lab_ff = new System::Windows::Forms::Label();
			this->comboFF = new System::Windows::Forms::ComboBox();
			this->SuspendLayout();
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(32, 48);
			this->label8->Name = S"label8";
			this->label8->Size = System::Drawing::Size(57, 16);
			this->label8->TabIndex = 31;
			this->label8->Text = S"Computer:";
			// 
			// comboComput
			// 
			this->comboComput->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboComput->Location = System::Drawing::Point(104, 48);
			this->comboComput->Name = S"comboComput";
			this->comboComput->Size = System::Drawing::Size(248, 21);
			this->comboComput->TabIndex = 30;
			// 
			// butOk
			// 
			this->butOk->Location = System::Drawing::Point(224, 216);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 32;
			this->butOk->Text = S"OK";
			this->butOk->Click += new System::EventHandler(this, &CMassiveAddInfo::butOk_Click);
			// 
			// butCancel
			// 
			this->butCancel->Location = System::Drawing::Point(320, 216);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 33;
			this->butCancel->Text = S"Cancel";
			this->butCancel->Click += new System::EventHandler(this, &CMassiveAddInfo::butCancel_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, (System::Byte)238);
			this->label1->Location = System::Drawing::Point(32, 24);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(330, 18);
			this->label1->TabIndex = 34;
			this->label1->Text = S"Choose a general purpouses for inputted set of results:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(32, 80);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(65, 16);
			this->label2->TabIndex = 36;
			this->label2->Text = S"Results Set:";
			// 
			// comboRSets
			// 
			this->comboRSets->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboRSets->Location = System::Drawing::Point(104, 80);
			this->comboRSets->Name = S"comboRSets";
			this->comboRSets->Size = System::Drawing::Size(248, 21);
			this->comboRSets->TabIndex = 35;
			// 
			// lab_alg
			// 
			this->lab_alg->AutoSize = true;
			this->lab_alg->Location = System::Drawing::Point(32, 112);
			this->lab_alg->Name = S"lab_alg";
			this->lab_alg->Size = System::Drawing::Size(55, 16);
			this->lab_alg->TabIndex = 38;
			this->lab_alg->Text = S"Algorithm:";
			this->lab_alg->Visible = false;
			// 
			// comboAlg
			// 
			this->comboAlg->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboAlg->Location = System::Drawing::Point(104, 112);
			this->comboAlg->Name = S"comboAlg";
			this->comboAlg->Size = System::Drawing::Size(248, 21);
			this->comboAlg->TabIndex = 37;
			this->comboAlg->Visible = false;
			// 
			// lab_ff
			// 
			this->lab_ff->AutoSize = true;
			this->lab_ff->Location = System::Drawing::Point(32, 144);
			this->lab_ff->Name = S"lab_ff";
			this->lab_ff->Size = System::Drawing::Size(44, 16);
			this->lab_ff->TabIndex = 40;
			this->lab_ff->Text = S"Fit func:";
			this->lab_ff->Visible = false;
			// 
			// comboFF
			// 
			this->comboFF->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboFF->Location = System::Drawing::Point(104, 144);
			this->comboFF->Name = S"comboFF";
			this->comboFF->Size = System::Drawing::Size(248, 21);
			this->comboFF->TabIndex = 39;
			this->comboFF->Visible = false;
			// 
			// CMassiveAddInfo
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(416, 261);
			this->Controls->Add(this->lab_ff);
			this->Controls->Add(this->comboFF);
			this->Controls->Add(this->lab_alg);
			this->Controls->Add(this->comboAlg);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->comboRSets);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->butCancel);
			this->Controls->Add(this->butOk);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->comboComput);
			this->Name = S"CMassiveAddInfo";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = S"massive_add_info";
			this->Activated += new System::EventHandler(this, &CMassiveAddInfo::CMassiveAddInfo_Activated);
			this->ResumeLayout(false);

		}		
	private: System::Void butCancel_Click(System::Object *  sender, System::EventArgs *  e);
	private: System::Void butOk_Click(System::Object *  sender, System::EventArgs *  e);
	private: System::Void CMassiveAddInfo_Activated(System::Object *  sender, System::EventArgs *  e);

	
};
};//namespace CONetAdmin