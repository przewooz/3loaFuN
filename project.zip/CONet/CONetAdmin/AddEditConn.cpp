#include "StdAfx.h"
#include "AddEditConn.h"



using namespace CONetAdmin;
using namespace TopologyTranslator;
using namespace TrajectorySetsFinder;
using namespace System::IO;



System::Void CAddEditConn::CAddEditConn_Activated(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (pc_system  ==  NULL)
	{
		c_err.vPutError("No system object!");
		c_err.vShowWindow();
		Close();
		return;
	}//if  (pc_fdb_root  ==  NULL)

	if  (b_activated  ==  false)
	{
		if  (pc_fdb_root  ==  NULL)
		{
			c_err.vPutError("No fdb root given!");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		if  (i_net_index  <  0)
		{
			c_err.vPutError("No net index given!");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		if  ( (i_net_index  >=  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  <  0) )
		{
			c_err.vPutError("Wrong net index");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		int  i_fdb_id;
		CString  s_root_dir, s_fdb_name;

		pc_fdb_root->vGetData
			(
			&i_fdb_id,
			&s_root_dir, &s_fdb_name
			);

		textFDbName->Text  =  (String *)  s_fdb_name;
		textFDbDir->Text  =  (String *)  s_root_dir;

		int  i_net_id;
		int  i_net_root_id;
		int  i_num_nodes,  i_num_edges;
		CString  s_net_name,  s_net_file,  s_net_dir;
		CString  s_net_comments;
		__int64  dt_added;

		pc_fdb_root->pvGetNets()->at(i_net_index)->vGetData
			(
			&i_net_id,
			&i_net_root_id,
			&i_num_nodes,  &i_num_edges,
			&s_net_name,  &s_net_file,  &s_net_dir,
			&s_net_comments,
			&dt_added		
			);

		textNetName->Text  =  (String *)  s_net_name;
		textNetDir->Text  =  (String *)  s_net_dir;


		if  (i_conn_index  >=  0)
		{
			if  ( (i_conn_index  <  (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->size())&&(i_conn_index  >=  0) )
			{
				int  i_conn_id;
				int  i_conn_net_id;
				CString  s_conn_name;
				CString  s_conn_file,  s_conn_dir;

				pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->vGetData
					(
					&i_conn_id,
					&i_conn_net_id,
					&s_conn_name,
					&s_conn_file,  &s_conn_dir
					);

				textConnName->Text  =  (String *)  s_conn_name;
				textConnDir->Text  =  (String *)  s_conn_dir;

				//if we edit the file can not be changed!
				text_chosen_file->Visible  =  false;
				but_find_dir->Visible  =  false;
			
			}//if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
			else
			{
				c_err.vPutError("Wrong connection configuration index!");
				c_err.vShowWindow();
				Close();
				return;
			}//else  if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
		
		}//if  (i_net_index  >=  0)
		

		v_refresh_results();
		b_activated  =  true;
	}//if  (b_activated  ==  false)

}//System::Void CAddEditConn::CAddEditConn_Activated(System::Object *  sender, System::EventArgs *  e)


System::Void CAddEditConn::but_find_dir_Click(System::Object *  sender, System::EventArgs *  e)
{
	OpenFileDialog* openFileDialog1 = new OpenFileDialog();
 
    //openFileDialog1->InitialDirectory = S"D:\\praca dyplomowa - nowy interfejs\\publikacja\\FD_init" ;
	openFileDialog1->Filter = "con files (*.con)|*.con|All files (*.*)|*.*";
    openFileDialog1->FilterIndex = 0;
    openFileDialog1->RestoreDirectory = true;
	openFileDialog1->Multiselect  =  true;

    if(openFileDialog1->ShowDialog() == DialogResult::OK)
    {
		CString  s_buf;

		if  (openFileDialog1->FileNames->Count  >  1)
		{
			for  (int  ii = 0;  ii < openFileDialog1->FileNames->Count; ii++)
			{
				s_buf.Format("%s | %s", s_buf, openFileDialog1->FileNames[ii]);
			}//for  (int  ii = 0;  ii < openFileDialog1->FileNames->Count; ii++)
		}//if  (openFileDialog1->FileNames->Count  >  1)
		else
		{
			FileInfo  *fi  =  new  FileInfo(openFileDialog1->FileName);
			s_buf  =  fi->Name;
			
			int  i_dot_pos  =  0;
			if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
			if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
			if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
			if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;


			CString  s_name;

			if  (i_dot_pos  >  0)
				for  (int  ii = 0; ii < i_dot_pos; ii++)
					s_name  +=  s_buf.GetAt(ii);
			else
				s_name  =  s_buf;
			
			textConnName->Text  =  s_name;

			text_chosen_file->Text  =  openFileDialog1->FileName;
					
		}//else  if  (openFileDialog1->FileNames->Count  >  1)

    }//if(openFileDialog1->ShowDialog() == DialogResult::OK)


};//System::Void CAddEditConn::but_find_dir_Click(System::Object *  sender, System::EventArgs *  e)



void  CAddEditConn::v_refresh_results()
{
	i_selected_result_index  =  -1;

	CError  c_err;

	if  (i_conn_index  <  0)
	{
		but_add_result->Enabled  =  false;
		but_edit_result->Enabled  =  false;
		but_rem_result->Enabled  =  false;

		list_results->Enabled  =  false;
	}//if  (i_conn_index  <  0)
	else
	{
		if  ( (i_net_index  >=  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  <  0) )
		{
			c_err.vPutError("Wrong net index");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)


		if  ( (i_conn_index  >=  (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->size())&&(i_conn_index  <  0) )
		{
			c_err.vPutError("Wrong conn index");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->eRefreshResults();

		if  (c_err)
		{
			c_err.vShowWindow();
			return;		
		}//if  (c_err)



		vector <CCOComputer *>  v_computers;
		vector <CCOAlgorithm *>  v_algorithms;
		vector <CCOFitFunc *>  v_ffuncs;

		c_err  =  pc_system->eSelectAlgorithms(&v_algorithms, "Select * from algorithms");
		if  (c_err)
		{
			for  (int ii=0; ii < (int) v_algorithms.size(); ii++)
				delete  (CCOAlgorithm *) v_algorithms.at(ii);

			c_err.vShowWindow();
			return;		
		}//if  (c_err)

		c_err  =  pc_system->eSelectFitFuncs(&v_ffuncs, "Select * from fit_func");
		if  (c_err)
		{
			for  (int ii=0; ii < (int) v_algorithms.size(); ii++)
				delete  (CCOAlgorithm *) v_algorithms.at(ii);

			for  (int ii=0; ii < (int) v_ffuncs.size(); ii++)
				delete  (CCOFitFunc *) v_ffuncs.at(ii);

			c_err.vShowWindow();
			return;		
		}//if  (c_err)

		c_err  =  pc_system->eSelectComputers(&v_computers, "Select * from computers");
		if  (c_err)
		{
			for  (int ii=0; ii < (int) v_algorithms.size(); ii++)
				delete  (CCOAlgorithm *) v_algorithms.at(ii);

			for  (int ii=0; ii < (int) v_ffuncs.size(); ii++)
				delete  (CCOFitFunc *) v_ffuncs.at(ii);

			for  (int ii=0; ii < (int) v_computers.size(); ii++)
				delete  (CCOFitFunc *) v_computers.at(ii);

			c_err.vShowWindow();
			return;		
		}//if  (c_err)


		int  i_id;
		int i_con_id, i_fit_id, i_alg_id, i_comp_id, i_rset_id;
		CString  s_res_dir, s_res_comments;
		double  d_fit_value;
		double  d_time;
		__int64  dt_generated;


		int  i_ff_ff_id;
		CString  s_ff_name;
		CString  s_ff_comments;

		int  i_alg_alg_id;
		CString  s_alg_name;
		CString  s_alg_comments;

		int  i_comp_comp_id;
		CString  s_comp_name;
		CString  s_comp_comments;

		CString  s_buf;
		bool  b_found;


		list_results->Items->Clear();
		for  (int  ii = 0; ii < (int) pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->size(); ii++)
		{

			pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(ii)->vGetData
			(
			&i_id,
			&i_con_id, &i_fit_id, &i_alg_id, &i_comp_id, &i_rset_id,
			&s_res_dir, &s_res_comments,
			&d_fit_value,
			&d_time,
			&dt_generated
			);

			s_buf.Format("%.16lf", d_fit_value);
			ListViewItem* item_buf  =  new ListViewItem((String *) s_buf);

			b_found  =  false;
			s_buf  =  "Unknown";
			for  (int ij = 0; (ij < (int)  v_ffuncs.size())&&(b_found ==  false); ij++)
			{
				v_ffuncs.at(ij)->vGetData
					(
					&i_ff_ff_id, &s_ff_name, &s_ff_comments
					);

				if  (i_ff_ff_id  ==  i_fit_id)
				{
					b_found  =  true;
					s_buf  =  s_ff_name;
				}//if  (i_ff_id  ==  i_fit_id)
			}//for  (int ij = 0; (ij < (int)  v_ffuncs.size())&&(b_found ==  false); ij++)
			item_buf->SubItems->Add((String *) s_buf);


			b_found  =  false;
			s_buf  =  "Unknown";
			for  (int ij = 0; (ij < (int)  v_algorithms.size())&&(b_found ==  false); ij++)
			{
				v_algorithms.at(ij)->vGetData
					(
					&i_alg_alg_id, &s_alg_name, &s_alg_comments
					);

				if  (i_alg_alg_id  ==  i_alg_id)
				{
					b_found  =  true;
					s_buf  =  s_alg_name;
				}//if  (i_ff_id  ==  i_fit_id)
			}//for  (int ij = 0; (ij < (int)  v_algorithms.size())&&(b_found ==  false); ij++)
			item_buf->SubItems->Add((String *) s_buf);

			s_buf.Format("%lf", d_time);
			item_buf->SubItems->Add((String *) s_buf);


			b_found  =  false;
			s_buf  =  "Unknown";
			for  (int ij = 0; (ij < (int)  v_computers.size())&&(b_found ==  false); ij++)
			{
				v_computers.at(ij)->vGetData
					(
					&i_comp_comp_id, &s_comp_name, &s_comp_comments
					);

				if  (i_comp_comp_id  ==  i_comp_id)
				{
					b_found  =  true;
					s_buf  =  s_comp_name;
				}//if  (i_ff_id  ==  i_fit_id)
			}//for  (int ij = 0; (ij < (int)  v_computers.size())&&(b_found ==  false); ij++)
			item_buf->SubItems->Add((String *) s_buf);


			System::DateTime  dt_buf;
			dt_buf  =  System::DateTime::FromFileTime(dt_generated);

			s_buf  =  dt_buf.ToString();
			item_buf->SubItems->Add((String *) s_buf);
			

						
			s_buf.Format("%d", ii);
			item_buf->SubItems->Add(s_buf);

			list_results->Items->Add(item_buf);
		
		}//for  (int  ii = 0; ii < (int) pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->size(); ii++)


		for  (int ii=0; ii < (int) v_algorithms.size(); ii++)
				delete  (CCOAlgorithm *) v_algorithms.at(ii);

		for  (int ii=0; ii < (int) v_ffuncs.size(); ii++)
			delete  (CCOFitFunc *) v_ffuncs.at(ii);

		for  (int ii=0; ii < (int) v_computers.size(); ii++)
			delete  (CCOFitFunc *) v_computers.at(ii);

	
	}//else  if  (i_conn_index  <  0)

}//void  CAddEditConn::v_refresh_results()




System::Void CAddEditConn::but_edit_result_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (pc_fdb_root  ==  NULL)||(i_net_index < 0)||(i_conn_index < 0) )
	{
		::MessageBox(NULL,"You must choose fdb root, net and conn to add a new result","Info",MB_OK);
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)

	if  ( (i_selected_result_index  <  (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->size())&&(i_selected_result_index  >=  0) )
	{
		
		CAddEditResult  *pc_edit_window;

		pc_edit_window  =  new  CAddEditResult(pc_system);
		pc_edit_window->vSetFDbRootNetIndConnInd(pc_fdb_root, i_net_index, i_conn_index);

		pc_edit_window->vSetResultIndex(i_selected_result_index);

		
		if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
		{
			v_refresh_results();
		}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)	

		
	}//if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	else
	{
		::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
	}//else  if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	
}//System::Void but_edit_result_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CAddEditConn::but_rem_result_Click(System::Object *  sender, System::EventArgs *  e)
{	
	if  ( (pc_fdb_root  ==  NULL)||(i_net_index < 0)||(i_conn_index < 0) )
	{
		::MessageBox(NULL,"You must choose fdb root, net and conn to add a new result","Info",MB_OK);
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)

	if  ( (i_selected_result_index  <  (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->size())&&(i_selected_result_index  >=  0) )
	{
		CError  c_err;

		int  i_id;
		int i_con_id, i_fit_id, i_alg_id, i_comp_id, i_rset_id;
		CString  s_res_dir, s_res_comments;
		double  d_fit_value;
		double  d_time;
		__int64  dt_generated;

		pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->at(i_selected_result_index)->vGetData
			(
			&i_id,
			&i_con_id, &i_fit_id, &i_alg_id, &i_comp_id, &i_rset_id,
			&s_res_dir, &s_res_comments,
			&d_fit_value,
			&d_time,
			&dt_generated
			);

	
		CString  s_buf;
		s_buf.Format("Are You sure You want to delete this result?: \n'%s'?", (LPCSTR) s_res_comments);
		if  (::MessageBox(NULL,  s_buf, "Delete?", MB_YESNO)  ==  IDYES)  
		{
			c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->eRemoveResult
				(pc_fdb_root->sGetRootDir(), pc_fdb_root->pvGetNets()->at(i_net_index)->sGetNetDir(), i_selected_result_index);
			if  (c_err)  c_err.vShowWindow();
            v_refresh_results();
		}//if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  

	}//if  (i_selected_index  <  i_fdb_len)
	else
	{
        ::MessageBox(NULL,"Unexpected error caused by wrong selection index."	, "Error", MB_OK);
	}//else  if  (i_selected_index  <  i_fdb_len)

}//System::Void CAddEditConn::but_rem_result_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CAddEditConn::but_add_result_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (pc_fdb_root  ==  NULL)
	{
		c_err.vPutError("You must choose fdb root to add a new network");
		c_err.vShowWindow();
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)

	if  ( (i_net_index  >=  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  <  0) )
	{
		c_err.vPutError("Wrong net index");
		c_err.vShowWindow();
		return;				
	}//if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )


	if  ( (i_conn_index  >=  (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->size())&&(i_conn_index  <  0) )
	{
		c_err.vPutError("Wrong connection configuration index index");
		c_err.vShowWindow();
		return;				
	}//if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )


	CAddEditResult  *pc_edit_window;

	pc_edit_window  =  new  CAddEditResult(pc_system);
	pc_edit_window->vSetFDbRootNetIndConnInd(pc_fdb_root, i_net_index, i_conn_index);

	
	if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
	{
		v_refresh_results();
	}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)

}//System::Void CAddEditConn::but_add_result_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CAddEditConn::list_results_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_results->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_results->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_results->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_results->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_results->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_results->ListViewItemSorter  !=  NULL)
	else
		list_results->ListViewItemSorter = new list_item_comparer(e->Column);

}//System::Void CAddEditConn::list_results_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)


System::Void CAddEditConn::list_results_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	but_edit_result_Click(sender, e);
}//System::Void CAddEditConn::list_results_DoubleClick(System::Object *  sender, System::EventArgs *  e)


System::Void CAddEditConn::list_results_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	ListViewItem *pc_selected = list_results->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_result_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);

		if  ( (i_selected_result_index  <  (int) pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->pvGetResults()->size())&&(i_selected_result_index  >=  0) )
		{
			
		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_result_index  =  -1;
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)
}//System::Void CAddEditConn::list_results_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)


System::Void CAddEditConn::butOk_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (pc_fdb_root  ==  NULL)
	{
		c_err.vPutError("No fdb root assigned");
		c_err.vShowWindow();        	
	}//if  (pc_fdb_root  ==  NULL)


	if  (i_net_index  <  0)
	{
		c_err.vPutError("No net index given!");
		c_err.vShowWindow();
		Close();
		return;
	}//if  (pc_fdb_root  ==  NULL)

	if  ( (i_net_index  >=  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  <  0) )
	{
		c_err.vPutError("Wrong net index");
		c_err.vShowWindow();
		Close();
		return;
	}//if  (pc_fdb_root  ==  NULL)

	
	if  (i_conn_index  <  0)
	{
		//ADDING NEW CON

		c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->eRefreshNetConns();
		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)
		
		c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->eAddNetConn
			(
			pc_fdb_root->sGetRootDir(),
			text_chosen_file->Text,
			textConnName->Text
			);
	}//if  (i_conn_index  <  0)
	else
	{
		if  ( (i_conn_index  <  (int)  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->size())&&(i_conn_index  >=  0) )
		{
			
			c_err  =  pc_fdb_root->pvGetNets()->at(i_net_index)->pvGetNetConns()->at(i_conn_index)->eUpdate
				(
				textConnName->Text
				);

		}//if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
		else
		{
			c_err.vPutError("Wrong net index!");
			c_err.vShowWindow();
			Close();
			return;
		}//else  if  ( (i_net_index  <  (int)  pc_fdb_root->pvGetNets()->size())&&(i_net_index  >=  0) )
	
			
	}//else  if  (i_net_index  <  0)

	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)

	DialogResult  =  DialogResult::OK;
};//System::Void CAddEditConn::butOk_Click(System::Object *  sender, System::EventArgs *  e)



