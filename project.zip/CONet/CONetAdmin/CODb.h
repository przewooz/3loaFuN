#pragma once


//tools
#include  "atlstr.h"  //CString
#include <windows.h>
#undef CreateDirectory
#using <mscorlib.dll>


//system tools
#include  "Error.h"
#include  "MySqlController.h"
#include  "..\\HEFAN\\TopologyTranslator.h"
#include  <vector>
#include  <iostream>

//system
class  CSystem;//predefintion for friend operator

using namespace std;
using namespace System::IO;



namespace  CONetDbTools
{

	//pre-definitions
	class  CCODbComponent;
	class  CCOFDbRoot;
	class  CCONet;
	class  CCONetConn;
	class  CCOAlgorithm;
	class  CCOFitFunc;
	class  CCOComputer;
	class  CCOAlgorithmParam;
	class  CCOResult;
	class  CCOAlgorithmParamValue;
	class  CCOResultSet;


	class  CCODb
	{
	public:

		CCODb();
		~CCODb();


		//db connect methods
		bool  bIsConnected()  {return(c_sql_conn.bIsConnected());};

		bool  bSaveConnConf(CString  sConfigFile);
		bool  bLoadConnConf(CString  sConfigFile);

		void  vGetConnParams(CString  *psNewHostName, CString  *psNewDbName, CString  *psNewUser, CString  *psNewPasswd);
		bool  bTestDbConnection(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd);
		CError  eConnect(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd);
		CError  eConnect();

		void  vDisconnect()  {c_sql_conn.vDisconnect();};

		CString  sGetHost()  {return(c_sql_conn.sGetHost());};
		CString  sGetDbName()  {return(c_sql_conn.sGetDbName());};
		CString  sGetUser()  {return(c_sql_conn.sGetUser());};
		CString  sGetPasswd()  {return(c_sql_conn.sGetPasswd());};

		void  vSetSqlConn(CCODbComponent  *pcComp);
		//db data retrieve methods

		CError  eSelectFDbRoot(vector <CCOFDbRoot *>  *pvFDbRoots, CString sSelectSQL);
		CError  eSelectCONets(vector <CCONet *>  *pvCONets, CString sSelectSQL);
		CError  eSelectConnections(vector <CCONetConn *>  *pvCOConns, CString sSelectSQL);
		CError  eSelectAlgorithms(vector <CCOAlgorithm *>  *pvCOAlgorithms, CString sSelectSQL);
		CError  eSelectFitFuncs(vector <CCOFitFunc *>  *pvCOFitFuncs, CString sSelectSQL);
		CError  eSelectComputers(vector <CCOComputer *>  *pvCOComputers, CString sSelectSQL);
		CError  eSelectResultsSets(vector <CCOResultSet *>  *pvCORSets, CString sSelectSQL);
		CError  eSelectResults(vector <CCOResult *>  *pvCOResults, CString sSelectSQL);
		

	private:

		bool  b_load_conn_conf(FILE  *pfSource);
		CString  s_read_line(FILE  *pfSource);


		//data handler
		CMySqlControl  c_sql_conn;
	
	};//class  CCODb



	//CDbComponent Object statuses:
	#define  DB_COMP_STATUS_NOT_LOADED		0
	#define  DB_COMP_STATUS_NOT_VALID		-1
	#define  DB_COMP_STATUS_VALID			1

	//CDbComponent Object types:
	#define  DB_COMP_TYPE_MAIN		0
	#define  DB_COMP_TYPE_ROOT		1



	#define  CODB_COMP_TYPE_MAIN		0
	class  CCODbComponent
	{
	public:

		CCODbComponent(CMySqlControl  *pcNewConn)  {pc_conn = pcNewConn;};
		CCODbComponent()  {};
		virtual  ~CCODbComponent()  {};

		void  vSetConnetcion(CMySqlControl  *pcNewConn)  {pc_conn = pcNewConn;};

		virtual  int  iGetType()  {return(CODB_COMP_TYPE_MAIN);};//returns particular object type
		virtual  int  iGetId()  =  0;

		//virtual  CError  eLoad(gcroot<MySqlDataReader *> pcReader)  {CError c_err; return(c_err);};
		virtual  CError  eRefresh()  =  0;
		virtual  bool  operator==(CCODbComponent &cOtherComponent) = 0;

	protected:

		CMySqlControl  *pc_conn;
	};//class  CADbComponent

	


	#define  CODB_COMP_TYPE_FDB_ROOT	1
    class  CCOFDbRoot  :  public  CCODbComponent
	{
	public:
		CCOFDbRoot(CMySqlControl  *pcNewConn);
		~CCOFDbRoot();

		int  iGetType()  {return(CODB_COMP_TYPE_FDB_ROOT);};//returns particular object type
		int  iGetId()  {return(i_id);};


		CString  sGetControlString();

		CError  eLoad(gcroot<MySqlDataReader *> pcReader);
		CError  eRemove();
		CError  eRefresh();

		void  vGetData
			(
			int  *pi_id,
			CString  *ps_root_dir, CString  *ps_fdb_name
			);

		CString  sGetRootDir()  {return(s_root_dir);};

		CError  eUpdate
			(
			CString  s_new_fdb_root_dir,	CString  s_new_fdb_name
			);

		
		bool  operator==(CCODbComponent &cOtherComponent);
		void  operator=(CCOFDbRoot &cOtherFdb);



		CError  eRefreshNets();
		CError  eAddNetwork
			(
			CString  sFileName,
			int  iControlNumNodes,  int  iControlNumEdges,
			CString  sNetName,	CString  sNetComments
			);

		CError  eRemoveNetwork(int  iNetIndex);

		vector <CCONet *>*  pvGetNets()  {return(&v_nets);};

	private:
		//object data
		int  i_id;
		CString  s_root_dir;
		CString  s_fdb_name;

		vector <CCONet *>  v_nets;
	
	};//class  CCOFDbRoot




	#define  CODB_COMP_TYPE_NETOWRK		2
    class  CCONet  :  public  CCODbComponent
	{
	public:
		CCONet(CMySqlControl  *pcNewConn);
		~CCONet();

		int  iGetType()  {return(CODB_COMP_TYPE_NETOWRK);};//returns particular object type
		int  iGetId()  {return(i_id);};


		CString  sGetControlString();

		CError  eLoad(gcroot<MySqlDataReader *> pcReader);
		CError  eRemove();
		CError  eRemove(CString  sRootDir);
		CError  eRefresh();

		void  vGetData
			(
			int  *pi_id,
			int  *pi_root_id,
			int  *pi_num_nodes,  int  *pi_num_edges,
			CString  *ps_net_name,  CString  *ps_net_file,  CString  *ps_net_dir,
			CString  *ps_net_comments,
			__int64  *pdt_added
			);

		CString  sGetNetDir()  {return(s_net_dir);};
		CString  sGetName()  {return(s_net_name);};

		CError  eUpdate
			(
			int  i_new_root_id,
			int  i_new_num_nodes,  int  i_new_num_edges,
			CString  s_new_net_name,  CString  s_new_net_file,  CString  s_new_net_dir,
			CString  s_new_net_comments
			);

		CError  eUpdate
			(
			int  i_new_num_nodes,  int  i_new_num_edges,
			CString  s_new_net_name,  CString  s_new_net_file,  CString  s_new_net_dir,
			CString  s_new_net_comments
			);


		bool  operator==(CCODbComponent &cOtherComponent);
		void  operator=(CCONet &cOtherNet);

		
		CError  eRefreshNetConns();
		CError  eAddNetConn
			(
			CString  sRootDir,
			CString  sConnFile,
			CString  sConnName
			);
		CError  eRemoveNetConn(CString  sRootDir,  int  iNetConnIndex);

		vector <CCONetConn *>*  pvGetNetConns()  {return(&v_net_conns);};

	private:
		//object data
		int  i_id;
		int  i_root_id;
		int  i_num_nodes,  i_num_edges;
		CString  s_net_name,  s_net_file,  s_net_dir;
		CString  s_net_comments;
		__int64  dt_added;
		

		vector <CCONetConn *>  v_net_conns;

	};//class  CCONet



	#define  CODB_COMP_TYPE_NETOWRK_CONN		3
    class  CCONetConn  :  public  CCODbComponent
	{
	public:
		CCONetConn(CMySqlControl  *pcNewConn);
		~CCONetConn();

		int  iGetType()  {return(CODB_COMP_TYPE_NETOWRK_CONN);};//returns particular object type
		int  iGetId()  {return(i_id);};
		int  iGetNetId()  {return(i_net_id);};


		CString  sGetControlString();
		CString  sGetConnDir()  {return(s_conn_dir);};
		CString  sGetName()  {return(s_conn_name);};

		CError  eLoad(gcroot<MySqlDataReader *> pcReader);

		CError  eRemove();
		CError  eRemove(CString  sNetDir);

		void    vRemove
			(
			vector  <CString>  *pvsControlSql,  
			vector  <CString>  *pvsRemoveSql
			);


		CError  eRefresh();

		void  vGetData
			(
			int  *pi_id,
			int  *pi_net_id,
			CString  *ps_conn_name,
			CString  *ps_conn_file,  CString  *ps_conn_dir				
			);

		CError  eUpdate
			(
			int  i_new_net_id,
			CString  s_new_conn_name,
			CString  s_new_conn_file,  CString  s_new_conn_dir
			);

		CError  eUpdate
			(
			CString  s_new_name
			);


		bool  operator==(CCODbComponent &cOtherComponent);
		void  operator=(CCONetConn &cOtherConn);

		CError  eRefreshResults();
		CError  eAddResult
			(
			CString  sRootDir,
			CString  sNetDir,
			int  iFitId, int iCompId,  int iRSetId,
			CString  sResComments,  
			double  dFitValue,
			double  dTime, __int64  dtGenerated,
			vector <CString>  *pvFiles, CCOAlgorithm  *pcAlgorithm
			);
		CError  eRemoveResult(CString  sRootDir,  CString  sNetDir, int iResultIndex);

		vector <CCOResult *>*  pvGetResults()  {return(&v_results);};

	private:
		//object data
		int  i_id;
		int  i_net_id;
		CString  s_conn_name;
		CString  s_conn_file,  s_conn_dir;


		vector <CCOResult *>  v_results;
				
	};//class  CCONetConn


	#define  CODB_COMP_TYPE_ALGORITHM		4
    class  CCOAlgorithm  :  public  CCODbComponent
	{
	public:
		CCOAlgorithm(CMySqlControl  *pcNewConn);
		~CCOAlgorithm();

		int  iGetType()  {return(CODB_COMP_TYPE_ALGORITHM);};//returns particular object type
		int  iGetId()  {return(i_id);};
		CString  sGetAlgorithmName()  {return(s_alg_name);};
		

		CString  sGetControlString();

		CError  eLoad(gcroot<MySqlDataReader *> pcReader);

		CError  eRemove();
		CError  eRefresh();

		CError  eRefreshParams();
		
		CError  eRefreshParamsForResult(int  iResultId);
		CError  eUpdateParamsForResult(int  iResultId);


		CError  eRemoveParam(int  iParamIndex);
		CError  eAddParam(CString  sParamName, double dDefaultValue);
		vector <CCOAlgorithmParam *>*  pvGetParams()  {return(&v_alg_params);};
		int  iCompareParams(CCOAlgorithm  *pcOtherAlgorithm);//0 equal  1-not equal




		void  vGetData
			(
			int  *pi_id,
			CString  *ps_alg_name,
			CString  *ps_alg_comments
			);

		CError  eUpdate
			(
			CString  s_new_alg_name,
			CString  s_new_alg_comments
			);

		bool  operator==(CCODbComponent &cOtherComponent);
		void  operator=(CCOAlgorithm &cOtherAlgorithm);

	private:
		//object data
		int  i_id;
		CString  s_alg_name;
		CString  s_alg_comments;

		vector <CCOAlgorithmParam *>  v_alg_params;

				
	};//class  CCOAlgorithm


	#define  CODB_COMP_TYPE_ALGORITHM_PARAMETER		5
    class  CCOAlgorithmParam  :  public  CCODbComponent
	{
	friend class  CCOAlgorithm;
	public:
		CCOAlgorithmParam(CMySqlControl  *pcNewConn);
		~CCOAlgorithmParam();

		int  iGetType()  {return(CODB_COMP_TYPE_ALGORITHM_PARAMETER);};//returns particular object type
		int  iGetId()  {return(i_id);};


		CString  sGetControlString();
		CString  sGetParamName()  {return(s_param_name);};

		CError  eLoad(gcroot<MySqlDataReader *> pcReader);

		CError  eRemove();
		CError  eRefresh();

		double  dGetParamValue();
		CError  eUpdateParamValue
			(
			double  d_new_param_value, int iResultId
			);

		//does the same thing that eUpdateParamValue, but it does not write to db
		CError  eSetParamValue
			(
			double  d_new_param_value, int iResultId
			);
		

		void  vGetData
			(
			int  *pi_id,
			int  *pi_alg_id,
			CString  *ps_param_name,
			double  *pd_param_default
			);

		CError  eUpdate
			(
			int  i_new_alg_id,
			CString  s_new_param_name,
			double  d_new_param_default
			);

		bool  operator==(CCODbComponent &cOtherComponent);

	private:
		//object data
		int  i_id;
		int  i_alg_id;
		CString  s_param_name;
		double  d_param_default;

		CCOAlgorithmParamValue  *pc_alg_par_val;

				
	};//class  CCOAlgorithmParam



	#define  CODB_COMP_TYPE_FIT_FUNC		6
    class  CCOFitFunc  :  public  CCODbComponent
	{
	public:
		CCOFitFunc(CMySqlControl  *pcNewConn);
		~CCOFitFunc();

		int  iGetType()  {return(CODB_COMP_TYPE_FIT_FUNC);};//returns particular object type
		int  iGetId()  {return(i_id);};


		CString  sGetControlString();
		CString  sGetName()  {return(s_ff_name);};

		CError  eLoad(gcroot<MySqlDataReader *> pcReader);

		CError  eRemove();
		CError  eRefresh();

		void  vGetData
			(
			int  *pi_id,
			CString  *ps_ff_name,
			CString  *ps_ff_comments
			);

		CError  eUpdate
			(
			CString  s_new_ff_name,
			CString  s_new_ff_comments
			);

		bool  operator==(CCODbComponent &cOtherComponent);
		void  operator=(CCOFitFunc &cOtherFitFunc);

	private:
		//object data
		int  i_id;
		CString  s_ff_name;
		CString  s_ff_comments;

				
	};//class  CCOFitFunc


	#define  CODB_COMP_TYPE_COMPUTER		7
    class  CCOComputer  :  public  CCODbComponent
	{
	public:
		CCOComputer(CMySqlControl  *pcNewConn);
		~CCOComputer();

		int  iGetType()  {return(CODB_COMP_TYPE_COMPUTER);};//returns particular object type
		int  iGetId()  {return(i_id);};


		CString  sGetControlString();

		CError  eLoad(gcroot<MySqlDataReader *> pcReader);

		CError  eRemove();
		CError  eRefresh();

		void  vGetData
			(
			int  *pi_id,
			CString  *ps_comp_name,
			CString  *ps_comp_comments
			);

		CError  eUpdate
			(
			CString  s_new_comp_name,
			CString  s_new_comp_comments
			);

		bool  operator==(CCODbComponent &cOtherComponent);

	private:
		//object data
		int  i_id;
		CString  s_comp_name;
		CString  s_comp_comments;

				
	};//class  CCOComputer



	#define  CODB_COMP_TYPE_RESULT		8
    class  CCOResult  :  public  CCODbComponent
	{
	//for file information loading
	friend  class  CSystem;

	public:
		CCOResult(CMySqlControl  *pcNewConn);
		~CCOResult();

		int  iGetType()  {return(CODB_COMP_TYPE_RESULT);};//returns particular object type
		int  iGetId()  {return(i_id);};
		int  iGetAlgorithmId()  {return(i_alg_id);};
		int  iGetConnId()  {return(i_con_id);}
		int  iGetFitFuncId()  {return(i_fit_id);}
		double  dGetFitVal()  {return(d_fit_value);};


		CString  sGetControlString();
		CString  sGetResultDir()  {return(s_res_dir);};

		CError  eLoad(gcroot<MySqlDataReader *> pcReader);

		CError  eRemove();
		CError  eRemove(CString  sConnDir);
		CError  eRefresh();

		void  vGetData
			(
			int  *pi_id,
			int *pi_con_id, int *pi_fit_id, int *pi_alg_id, int *pi_comp_id, int *pi_rset_id,
			CString  *ps_res_dir, CString  *ps_res_comments,
			double  *pd_fit_value,
			double  *pd_time,
			__int64  *pdt_generated
			);


		CError  eUpdate
			(
			
			CString  s_new_res_dir,  CString  s_new_res_comments,
			double  d_new_fit_value,
			double  d_new_time
			);

		CError  eUpdate
			(
			int i_new_con_id, int i_new_fit_id, int i_new_alg_id, int i_new_comp_id,  int  i_new_rset_id,
			CString  s_new_res_dir, CString  s_new_res_comments,
			double  d_new_fit_value,
			double  d_new_time,
			__int64  dt_new_generated
			);

		CError  eAddFile(CString  sRootDir,  CString  sNetDir, CString   sConnDir, CString  sFileToAdd, bool  bOverwrite = true);
		CError  eRemoveFile(CString  sRootDir,  CString  sNetDir, CString   sConnDir, CString  sFileToRemove);
		CError  eGetFiles(CString  sRootDir,  CString  sNetDir, CString   sConnDir, vector <CString>  *pvFiles);

		bool  operator==(CCODbComponent &cOtherComponent);

	private:
		//object data
		int  i_id;
		int i_con_id, i_fit_id, i_alg_id, i_comp_id, i_rset_id;
		CString  s_res_dir, s_res_comments;
		double  d_fit_value;
		double  d_time;
		__int64  dt_generated;

	};//class  CCOResult  :  public  CCODbComponent



	#define  CODB_COMP_TYPE_ALGORITHM_PARAMETER_VALUE		9
    class  CCOAlgorithmParamValue  :  public  CCODbComponent
	{
	friend class  CCOAlgorithm;
	public:
		CCOAlgorithmParamValue(CMySqlControl  *pcNewConn);
		~CCOAlgorithmParamValue();

		int  iGetType()  {return(CODB_COMP_TYPE_ALGORITHM_PARAMETER_VALUE);};//returns particular object type
		int  iGetId()  {return(i_id);};


		CString  sGetControlString();

		CError  eLoad(gcroot<MySqlDataReader *> pcReader);

		CError  eRemove();
		CError  eRefresh();

		double  dGetParamValue()  {return(d_param_value);};

		void  vGetData
			(
			int  *pi_id,
			int  *pi_alg_param_id,  int  *pi_result_id,
			double  *pd_param_value
			);

		CError  eUpdate
			(
            double  d_new_param_value,
			int  iAlgParamId, int iResult
			);

		//does the same thing that eUpdateParamValue, but it does not write to db
		CError  eSetParamValue
			(
			double  d_new_param_value,
			int  iAlgParamId, int iResultId
			);

		bool  operator==(CCODbComponent &cOtherComponent);

	private:
		int  i_id;
		int  i_alg_param_id,  i_result_id;
		double  d_param_value;

	};//class  CCOAlgorithmParamValue  :  public  CCODbComponent


	#define  NO_RESULTS_SET_SELECTED  "<No results set selected>"
	#define  CODB_COMP_TYPE_RESULT_SET		10
    class  CCOResultSet  :  public  CCODbComponent
	{
	public:
		CCOResultSet(CMySqlControl  *pcNewConn);
		~CCOResultSet();

		int  iGetType()  {return(CODB_COMP_TYPE_RESULT_SET);};//returns particular object type
		int  iGetId()  {return(i_id);};


		CString  sGetControlString();

		CError  eLoad(gcroot<MySqlDataReader *> pcReader);

		CError  eRemove();
		CError  eRemoveWithResults(CSystem  *pcSystem);
		CError  eRefresh();

		void  vGetData
			(
			int  *pi_id,
			CString  *ps_rset_name,
			CString  *ps_rset_comments
			);

		CError  eUpdate
			(
			CString  s_new_rset_name,
			CString  s_new_rset_comments
			);

		bool  operator==(CCODbComponent &cOtherComponent);

	private:
		//object data
		int  i_id;
		CString  s_rset_name;
		CString  s_rset_comments;

				
	};//class  CCOComputer


};//namespace  CONetDbTools









