#include "stdafx.h"
#include "Form1.h"
#include <windows.h>

using namespace CONetAdmin;
using namespace System::IO;



int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	System::Threading::Thread::CurrentThread->ApartmentState = System::Threading::ApartmentState::STA;
	Application::Run(new CCONetmainForm());
	return 0;
}


CCONetmainForm ::CCONetmainForm (void)
{
	pc_system  =  new  CSystem;//IT HAS TO BE DONE BEFORE INITILIZATION OF CONNECTION OPTIONS WINDOW

	pcConnOpt  =  new  CConnOpt(pc_system);


	b_activated  =  false;

	pv_fdb_roots  =  new  vector  <CCOFDbRoot  *>;
	i_selected_fdb_index  =  -1;
	pc_chosen_fdb  =  NULL;

	i_selected_net_index  =  -1;
	i_selected_net_conn_index  =  -1;

	pv_algorithms =  new  vector  <CCOAlgorithm  *>;
	i_selected_alg_index =  -1;

	pv_fit_funcs  =  new  vector  <CCOFitFunc  *>;
	i_selected_ff_index =  -1;

	pv_computers  =  new  vector  <CCOComputer  *>;
	i_selected_comp_index =  -1;

	pv_rsets  =  new  vector  <CCOResultSet  *>;
	i_selected_rset_index  =  -1;

	i_selected_choose_net_index  =  -1;
	i_selected_choose_set_index  =  -1;
	
	InitializeComponent();
}//cCONetmainForm::cCONetmainForm(void)



void CCONetmainForm ::InitializeComponent(void)
{
	this->components = (new System::ComponentModel::Container());
	this->tabControl_main = (new System::Windows::Forms::TabControl());
	this->tabpgAdmin = (new System::Windows::Forms::TabPage());
	this->tabControl_admin = (new System::Windows::Forms::TabControl());
	this->tabpg_db_roots = (new System::Windows::Forms::TabPage());
	this->groupFDbListAndFilters = (new System::Windows::Forms::GroupBox());
	this->groupFDbList = (new System::Windows::Forms::GroupBox());
	this->list_fdb_roots = (new System::Windows::Forms::ListView());
	this->col_root_name = (new System::Windows::Forms::ColumnHeader());
	this->col_root_dir = (new System::Windows::Forms::ColumnHeader());
	this->groupChosenFDb = (new System::Windows::Forms::GroupBox());
	this->textChosenFDbName = (new System::Windows::Forms::TextBox());
	this->butFDbDeselect = (new System::Windows::Forms::Button());
	this->groupFDbControls = (new System::Windows::Forms::GroupBox());
	this->textFDbName = (new System::Windows::Forms::TextBox());
	this->label2 = (new System::Windows::Forms::Label());
	this->label1 = (new System::Windows::Forms::Label());
	this->textFDbDir = (new System::Windows::Forms::TextBox());
	this->butRemoveFDb = (new System::Windows::Forms::Button());
	this->butAddFDb = (new System::Windows::Forms::Button());
	this->butEditFDb = (new System::Windows::Forms::Button());
	this->tabpg_netowrks = (new System::Windows::Forms::TabPage());
	this->groupBox1 = (new System::Windows::Forms::GroupBox());
	this->tabControl_net_list_tree = (new System::Windows::Forms::TabControl());
	this->tabPage_net_list = (new System::Windows::Forms::TabPage());
	this->list_nets = (new System::Windows::Forms::ListView());
	this->columnHeader1 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader2 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader3 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader4 = (new System::Windows::Forms::ColumnHeader());
	this->tabPage_net_tree = (new System::Windows::Forms::TabPage());
	this->groupBox2 = (new System::Windows::Forms::GroupBox());
	this->check_config = (new System::Windows::Forms::CheckBox());
	this->check_filter_by_fdb_root = (new System::Windows::Forms::CheckBox());
	this->textChosenFDbNameForNets = (new System::Windows::Forms::TextBox());
	this->butFDbDeselectNets = (new System::Windows::Forms::Button());
	this->groupBox6 = (new System::Windows::Forms::GroupBox());
	this->but_massive_add_results = (new System::Windows::Forms::Button());
	this->but_massive_add_results_walk = (new System::Windows::Forms::Button());
	this->but_massive_add_results_old = (new System::Windows::Forms::Button());
	this->but_massive_add_conns = (new System::Windows::Forms::Button());
	this->textAddedBy = (new System::Windows::Forms::TextBox());
	this->label8 = (new System::Windows::Forms::Label());
	this->textNetComments = (new System::Windows::Forms::TextBox());
	this->textNetLinksNum = (new System::Windows::Forms::TextBox());
	this->label7 = (new System::Windows::Forms::Label());
	this->textNetNodesNum = (new System::Windows::Forms::TextBox());
	this->label5 = (new System::Windows::Forms::Label());
	this->textNetDir = (new System::Windows::Forms::TextBox());
	this->label3 = (new System::Windows::Forms::Label());
	this->label4 = (new System::Windows::Forms::Label());
	this->textNetName = (new System::Windows::Forms::TextBox());
	this->label6 = (new System::Windows::Forms::Label());
	this->butRemoveNet = (new System::Windows::Forms::Button());
	this->butAddNet = (new System::Windows::Forms::Button());
	this->butEditNet = (new System::Windows::Forms::Button());
	this->tabpg_algorithms = (new System::Windows::Forms::TabPage());
	this->groupBox3 = (new System::Windows::Forms::GroupBox());
	this->tabControl1 = (new System::Windows::Forms::TabControl());
	this->tabPage1 = (new System::Windows::Forms::TabPage());
	this->list_algorithms = (new System::Windows::Forms::ListView());
	this->columnHeader13 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader14 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader15 = (new System::Windows::Forms::ColumnHeader());
	this->tabPage4 = (new System::Windows::Forms::TabPage());
	this->groupBox4 = (new System::Windows::Forms::GroupBox());
	this->textAlgName = (new System::Windows::Forms::TextBox());
	this->label9 = (new System::Windows::Forms::Label());
	this->label10 = (new System::Windows::Forms::Label());
	this->textAlgComments = (new System::Windows::Forms::TextBox());
	this->but_rem_alg = (new System::Windows::Forms::Button());
	this->but_add_alg = (new System::Windows::Forms::Button());
	this->but_edit_alg = (new System::Windows::Forms::Button());
	this->tabpg_computers = (new System::Windows::Forms::TabPage());
	this->groupBox5 = (new System::Windows::Forms::GroupBox());
	this->tabControl3 = (new System::Windows::Forms::TabControl());
	this->tabPage7 = (new System::Windows::Forms::TabPage());
	this->list_computers = (new System::Windows::Forms::ListView());
	this->columnHeader6 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader7 = (new System::Windows::Forms::ColumnHeader());
	this->tabPage8 = (new System::Windows::Forms::TabPage());
	this->groupBox8 = (new System::Windows::Forms::GroupBox());
	this->textCompName = (new System::Windows::Forms::TextBox());
	this->label13 = (new System::Windows::Forms::Label());
	this->label14 = (new System::Windows::Forms::Label());
	this->textCompComm = (new System::Windows::Forms::TextBox());
	this->butRemoveComp = (new System::Windows::Forms::Button());
	this->butAddComp = (new System::Windows::Forms::Button());
	this->butEditComp = (new System::Windows::Forms::Button());
	this->tabpg_fitt_funcs = (new System::Windows::Forms::TabPage());
	this->groupBox7 = (new System::Windows::Forms::GroupBox());
	this->tabControl2 = (new System::Windows::Forms::TabControl());
	this->tabPage5 = (new System::Windows::Forms::TabPage());
	this->list_ff = (new System::Windows::Forms::ListView());
	this->columnHeader9 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader5 = (new System::Windows::Forms::ColumnHeader());
	this->tabPage6 = (new System::Windows::Forms::TabPage());
	this->groupBox10 = (new System::Windows::Forms::GroupBox());
	this->textFFuncName = (new System::Windows::Forms::TextBox());
	this->label11 = (new System::Windows::Forms::Label());
	this->label12 = (new System::Windows::Forms::Label());
	this->textFFuncComm = (new System::Windows::Forms::TextBox());
	this->butRemoveFF = (new System::Windows::Forms::Button());
	this->butAddFF = (new System::Windows::Forms::Button());
	this->butEditFF = (new System::Windows::Forms::Button());
	this->tabpg_results_sets = (new System::Windows::Forms::TabPage());
	this->groupBox13 = (new System::Windows::Forms::GroupBox());
	this->tabControl5 = (new System::Windows::Forms::TabControl());
	this->tabPage11 = (new System::Windows::Forms::TabPage());
	this->list_results_sets = (new System::Windows::Forms::ListView());
	this->columnHeader21 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader22 = (new System::Windows::Forms::ColumnHeader());
	this->tabPage12 = (new System::Windows::Forms::TabPage());
	this->groupBox14 = (new System::Windows::Forms::GroupBox());
	this->textRSetName = (new System::Windows::Forms::TextBox());
	this->label21 = (new System::Windows::Forms::Label());
	this->label22 = (new System::Windows::Forms::Label());
	this->textRSetComm = (new System::Windows::Forms::TextBox());
	this->butRemRSet = (new System::Windows::Forms::Button());
	this->butAddRSet = (new System::Windows::Forms::Button());
	this->butEditRSet = (new System::Windows::Forms::Button());
	this->tabpg_results = (new System::Windows::Forms::TabPage());
	this->groupBox9 = (new System::Windows::Forms::GroupBox());
	this->tabControl4 = (new System::Windows::Forms::TabControl());
	this->tabPage9 = (new System::Windows::Forms::TabPage());
	this->list_results = (new System::Windows::Forms::ListView());
	this->columnHeader8 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader10 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader11 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader12 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader16 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader17 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader18 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader19 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader20 = (new System::Windows::Forms::ColumnHeader());
	this->tabPage10 = (new System::Windows::Forms::TabPage());
	this->groupBox11 = (new System::Windows::Forms::GroupBox());
	this->checkBox2 = (new System::Windows::Forms::CheckBox());
	this->textChosenFDbNameForResults = (new System::Windows::Forms::TextBox());
	this->butFDbDeselectResults = (new System::Windows::Forms::Button());
	this->groupBox12 = (new System::Windows::Forms::GroupBox());
	this->textBox2 = (new System::Windows::Forms::TextBox());
	this->label15 = (new System::Windows::Forms::Label());
	this->textBox3 = (new System::Windows::Forms::TextBox());
	this->textBox4 = (new System::Windows::Forms::TextBox());
	this->label16 = (new System::Windows::Forms::Label());
	this->textBox5 = (new System::Windows::Forms::TextBox());
	this->label17 = (new System::Windows::Forms::Label());
	this->textBox6 = (new System::Windows::Forms::TextBox());
	this->label18 = (new System::Windows::Forms::Label());
	this->label19 = (new System::Windows::Forms::Label());
	this->textBox7 = (new System::Windows::Forms::TextBox());
	this->label20 = (new System::Windows::Forms::Label());
	this->button2 = (new System::Windows::Forms::Button());
	this->button3 = (new System::Windows::Forms::Button());
	this->button4 = (new System::Windows::Forms::Button());
	this->tabPgResults = (new System::Windows::Forms::TabPage());
	this->tabControlStats = (new System::Windows::Forms::TabControl());
	this->tabpg_stats_general = (new System::Windows::Forms::TabPage());
	this->groupBox15 = (new System::Windows::Forms::GroupBox());
	this->tabControl6 = (new System::Windows::Forms::TabControl());
	this->tabPage2 = (new System::Windows::Forms::TabPage());
	this->list_choose_nets = (new System::Windows::Forms::ListView());
	this->columnHeader23 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader24 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader25 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader26 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader29 = (new System::Windows::Forms::ColumnHeader());
	this->tabPage14 = (new System::Windows::Forms::TabPage());
	this->groupBox16 = (new System::Windows::Forms::GroupBox());
	this->but_choose_nets_invert = (new System::Windows::Forms::Button());
	this->but_choose_nets_deselect_all = (new System::Windows::Forms::Button());
	this->but_choose_nets_select_all = (new System::Windows::Forms::Button());
	this->groupBox17 = (new System::Windows::Forms::GroupBox());
	this->tabControl7 = (new System::Windows::Forms::TabControl());
	this->tabPage15 = (new System::Windows::Forms::TabPage());
	this->list_choose_set = (new System::Windows::Forms::ListView());
	this->columnHeader27 = (new System::Windows::Forms::ColumnHeader());
	this->columnHeader28 = (new System::Windows::Forms::ColumnHeader());
	this->tabPage16 = (new System::Windows::Forms::TabPage());
	this->groupBox18 = (new System::Windows::Forms::GroupBox());
	this->combo_ext = (new System::Windows::Forms::ComboBox());
	this->but_compare_set = (new System::Windows::Forms::Button());
	this->chk_report_max = (new System::Windows::Forms::CheckBox());
	this->combo_normalize = (new System::Windows::Forms::ComboBox());
	this->but_report_general = (new System::Windows::Forms::Button());
	this->but_choose_set_invert = (new System::Windows::Forms::Button());
	this->but_choose_set_deselect_all = (new System::Windows::Forms::Button());
	this->but_choose_set_select_all = (new System::Windows::Forms::Button());
	this->tabPage13 = (new System::Windows::Forms::TabPage());
	this->but_results_test = (new System::Windows::Forms::Button());
	this->tabPage3 = (new System::Windows::Forms::TabPage());
	this->menu_main = (new System::Windows::Forms::MainMenu(this->components));
	this->menu_main_exit = (new System::Windows::Forms::MenuItem());
	this->menu_main_connect_opt = (new System::Windows::Forms::MenuItem());
	this->menu_main_help = (new System::Windows::Forms::MenuItem());
	this->statusMain = (new System::Windows::Forms::StatusBar());
	this->openFileDialog1 = (new System::Windows::Forms::OpenFileDialog());
	this->saveFileDialog1 = (new System::Windows::Forms::SaveFileDialog());
	this->folderBrowserDialog1 = (new System::Windows::Forms::FolderBrowserDialog());
	this->but_choose_nets_select_a = (new System::Windows::Forms::Button());
	this->but_choose_nets_select_b = (new System::Windows::Forms::Button());
	this->but_choose_nets_select_c = (new System::Windows::Forms::Button());
	this->tabControl_main->SuspendLayout();
	this->tabpgAdmin->SuspendLayout();
	this->tabControl_admin->SuspendLayout();
	this->tabpg_db_roots->SuspendLayout();
	this->groupFDbListAndFilters->SuspendLayout();
	this->groupFDbList->SuspendLayout();
	this->groupChosenFDb->SuspendLayout();
	this->groupFDbControls->SuspendLayout();
	this->tabpg_netowrks->SuspendLayout();
	this->groupBox1->SuspendLayout();
	this->tabControl_net_list_tree->SuspendLayout();
	this->tabPage_net_list->SuspendLayout();
	this->groupBox2->SuspendLayout();
	this->groupBox6->SuspendLayout();
	this->tabpg_algorithms->SuspendLayout();
	this->groupBox3->SuspendLayout();
	this->tabControl1->SuspendLayout();
	this->tabPage1->SuspendLayout();
	this->groupBox4->SuspendLayout();
	this->tabpg_computers->SuspendLayout();
	this->groupBox5->SuspendLayout();
	this->tabControl3->SuspendLayout();
	this->tabPage7->SuspendLayout();
	this->groupBox8->SuspendLayout();
	this->tabpg_fitt_funcs->SuspendLayout();
	this->groupBox7->SuspendLayout();
	this->tabControl2->SuspendLayout();
	this->tabPage5->SuspendLayout();
	this->groupBox10->SuspendLayout();
	this->tabpg_results_sets->SuspendLayout();
	this->groupBox13->SuspendLayout();
	this->tabControl5->SuspendLayout();
	this->tabPage11->SuspendLayout();
	this->groupBox14->SuspendLayout();
	this->tabpg_results->SuspendLayout();
	this->groupBox9->SuspendLayout();
	this->tabControl4->SuspendLayout();
	this->tabPage9->SuspendLayout();
	this->groupBox11->SuspendLayout();
	this->groupBox12->SuspendLayout();
	this->tabPgResults->SuspendLayout();
	this->tabControlStats->SuspendLayout();
	this->tabpg_stats_general->SuspendLayout();
	this->groupBox15->SuspendLayout();
	this->tabControl6->SuspendLayout();
	this->tabPage2->SuspendLayout();
	this->groupBox16->SuspendLayout();
	this->groupBox17->SuspendLayout();
	this->tabControl7->SuspendLayout();
	this->tabPage15->SuspendLayout();
	this->groupBox18->SuspendLayout();
	this->tabPage13->SuspendLayout();
	this->SuspendLayout();
	// 
	// tabControl_main
	// 
	this->tabControl_main->Controls->Add(this->tabpgAdmin);
	this->tabControl_main->Controls->Add(this->tabPgResults);
	this->tabControl_main->Controls->Add(this->tabPage3);
	this->tabControl_main->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControl_main->Location = System::Drawing::Point(0, 0);
	this->tabControl_main->Name = S"tabControl_main";
	this->tabControl_main->SelectedIndex = 0;
	this->tabControl_main->Size = System::Drawing::Size(848, 617);
	this->tabControl_main->TabIndex = 0;
	this->tabControl_main->VisibleChanged += new System::EventHandler(this, &CCONetmainForm::tabControl_main_VisibleChanged);
	this->tabControl_main->SelectedIndexChanged += new System::EventHandler(this, &CCONetmainForm::tabControl_main_SelectedIndexChanged);
	// 
	// tabpgAdmin
	// 
	this->tabpgAdmin->Controls->Add(this->tabControl_admin);
	this->tabpgAdmin->Location = System::Drawing::Point(4, 22);
	this->tabpgAdmin->Name = S"tabpgAdmin";
	this->tabpgAdmin->Size = System::Drawing::Size(840, 591);
	this->tabpgAdmin->TabIndex = 0;
	this->tabpgAdmin->Text = S"Database administration";
	// 
	// tabControl_admin
	// 
	this->tabControl_admin->Controls->Add(this->tabpg_db_roots);
	this->tabControl_admin->Controls->Add(this->tabpg_netowrks);
	this->tabControl_admin->Controls->Add(this->tabpg_algorithms);
	this->tabControl_admin->Controls->Add(this->tabpg_computers);
	this->tabControl_admin->Controls->Add(this->tabpg_fitt_funcs);
	this->tabControl_admin->Controls->Add(this->tabpg_results_sets);
	this->tabControl_admin->Controls->Add(this->tabpg_results);
	this->tabControl_admin->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControl_admin->Location = System::Drawing::Point(0, 0);
	this->tabControl_admin->Name = S"tabControl_admin";
	this->tabControl_admin->SelectedIndex = 0;
	this->tabControl_admin->Size = System::Drawing::Size(840, 591);
	this->tabControl_admin->TabIndex = 0;
	this->tabControl_admin->VisibleChanged += new System::EventHandler(this, &CCONetmainForm::tabControl_admin_VisibleChanged);
	this->tabControl_admin->SelectedIndexChanged += new System::EventHandler(this, &CCONetmainForm::tabControl_admin_SelectedIndexChanged);
	// 
	// tabpg_db_roots
	// 
	this->tabpg_db_roots->Controls->Add(this->groupFDbListAndFilters);
	this->tabpg_db_roots->Controls->Add(this->groupFDbControls);
	this->tabpg_db_roots->Location = System::Drawing::Point(4, 22);
	this->tabpg_db_roots->Name = S"tabpg_db_roots";
	this->tabpg_db_roots->Size = System::Drawing::Size(832, 565);
	this->tabpg_db_roots->TabIndex = 0;
	this->tabpg_db_roots->Text = S"Database roots";
	// 
	// groupFDbListAndFilters
	// 
	this->groupFDbListAndFilters->Controls->Add(this->groupFDbList);
	this->groupFDbListAndFilters->Controls->Add(this->groupChosenFDb);
	this->groupFDbListAndFilters->Dock = System::Windows::Forms::DockStyle::Fill;
	this->groupFDbListAndFilters->Location = System::Drawing::Point(0, 0);
	this->groupFDbListAndFilters->Name = S"groupFDbListAndFilters";
	this->groupFDbListAndFilters->Size = System::Drawing::Size(480, 565);
	this->groupFDbListAndFilters->TabIndex = 5;
	this->groupFDbListAndFilters->TabStop = false;
	// 
	// groupFDbList
	// 
	this->groupFDbList->Controls->Add(this->list_fdb_roots);
	this->groupFDbList->Dock = System::Windows::Forms::DockStyle::Fill;
	this->groupFDbList->Location = System::Drawing::Point(3, 56);
	this->groupFDbList->Name = S"groupFDbList";
	this->groupFDbList->Size = System::Drawing::Size(474, 506);
	this->groupFDbList->TabIndex = 8;
	this->groupFDbList->TabStop = false;
	this->groupFDbList->Text = S"File database roots list";
	// 
	// list_fdb_roots
	// 
	this->list_fdb_roots->AllowColumnReorder = true;
	System::Windows::Forms::ColumnHeader* __mcTemp__1[] = new System::Windows::Forms::ColumnHeader*[2];
	__mcTemp__1[0] = this->col_root_name;
	__mcTemp__1[1] = this->col_root_dir;
	this->list_fdb_roots->Columns->AddRange(__mcTemp__1);
	this->list_fdb_roots->Dock = System::Windows::Forms::DockStyle::Fill;
	this->list_fdb_roots->ForeColor = System::Drawing::SystemColors::WindowText;
	this->list_fdb_roots->FullRowSelect = true;
	this->list_fdb_roots->GridLines = true;
	this->list_fdb_roots->Location = System::Drawing::Point(3, 16);
	this->list_fdb_roots->Name = S"list_fdb_roots";
	this->list_fdb_roots->Size = System::Drawing::Size(468, 487);
	this->list_fdb_roots->TabIndex = 3;
	this->list_fdb_roots->UseCompatibleStateImageBehavior = false;
	this->list_fdb_roots->View = System::Windows::Forms::View::Details;
	this->list_fdb_roots->DoubleClick += new System::EventHandler(this, &CCONetmainForm::list_fdb_roots_DoubleClick);
	this->list_fdb_roots->MouseUp += new System::Windows::Forms::MouseEventHandler(this, &CCONetmainForm::list_fdb_roots_MouseUp);
	this->list_fdb_roots->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CCONetmainForm::list_fdb_roots_ColumnClick);
	this->list_fdb_roots->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CCONetmainForm::list_fdb_roots_MouseDown);
	// 
	// col_root_name
	// 
	this->col_root_name->Text = S"Name";
	this->col_root_name->Width = 100;
	// 
	// col_root_dir
	// 
	this->col_root_dir->Text = S"Db root dir";
	this->col_root_dir->Width = 180;
	// 
	// groupChosenFDb
	// 
	this->groupChosenFDb->Controls->Add(this->textChosenFDbName);
	this->groupChosenFDb->Controls->Add(this->butFDbDeselect);
	this->groupChosenFDb->Dock = System::Windows::Forms::DockStyle::Top;
	this->groupChosenFDb->Location = System::Drawing::Point(3, 16);
	this->groupChosenFDb->Name = S"groupChosenFDb";
	this->groupChosenFDb->Size = System::Drawing::Size(474, 40);
	this->groupChosenFDb->TabIndex = 7;
	this->groupChosenFDb->TabStop = false;
	this->groupChosenFDb->Text = S"Chosen FDb root";
	// 
	// textChosenFDbName
	// 
	this->textChosenFDbName->Dock = System::Windows::Forms::DockStyle::Fill;
	this->textChosenFDbName->Location = System::Drawing::Point(3, 16);
	this->textChosenFDbName->Name = S"textChosenFDbName";
	this->textChosenFDbName->ReadOnly = true;
	this->textChosenFDbName->Size = System::Drawing::Size(393, 20);
	this->textChosenFDbName->TabIndex = 2;
	// 
	// butFDbDeselect
	// 
	this->butFDbDeselect->Dock = System::Windows::Forms::DockStyle::Right;
	this->butFDbDeselect->Location = System::Drawing::Point(396, 16);
	this->butFDbDeselect->Name = S"butFDbDeselect";
	this->butFDbDeselect->Size = System::Drawing::Size(75, 21);
	this->butFDbDeselect->TabIndex = 1;
	this->butFDbDeselect->Text = S"Deselect";
	this->butFDbDeselect->Click += new System::EventHandler(this, &CCONetmainForm::butFDbDeselect_Click);
	// 
	// groupFDbControls
	// 
	this->groupFDbControls->Controls->Add(this->textFDbName);
	this->groupFDbControls->Controls->Add(this->label2);
	this->groupFDbControls->Controls->Add(this->label1);
	this->groupFDbControls->Controls->Add(this->textFDbDir);
	this->groupFDbControls->Controls->Add(this->butRemoveFDb);
	this->groupFDbControls->Controls->Add(this->butAddFDb);
	this->groupFDbControls->Controls->Add(this->butEditFDb);
	this->groupFDbControls->Dock = System::Windows::Forms::DockStyle::Right;
	this->groupFDbControls->Location = System::Drawing::Point(480, 0);
	this->groupFDbControls->Name = S"groupFDbControls";
	this->groupFDbControls->Size = System::Drawing::Size(352, 565);
	this->groupFDbControls->TabIndex = 4;
	this->groupFDbControls->TabStop = false;
	// 
	// textFDbName
	// 
	this->textFDbName->Location = System::Drawing::Point(32, 160);
	this->textFDbName->Name = S"textFDbName";
	this->textFDbName->ReadOnly = true;
	this->textFDbName->Size = System::Drawing::Size(304, 20);
	this->textFDbName->TabIndex = 12;
	// 
	// label2
	// 
	this->label2->AutoSize = true;
	this->label2->Location = System::Drawing::Point(16, 136);
	this->label2->Name = S"label2";
	this->label2->Size = System::Drawing::Size(102, 13);
	this->label2->TabIndex = 11;
	this->label2->Text = S"File database name:";
	// 
	// label1
	// 
	this->label1->AutoSize = true;
	this->label1->Location = System::Drawing::Point(16, 208);
	this->label1->Name = S"label1";
	this->label1->Size = System::Drawing::Size(88, 13);
	this->label1->TabIndex = 10;
	this->label1->Text = S"File databse root:";
	// 
	// textFDbDir
	// 
	this->textFDbDir->Location = System::Drawing::Point(32, 232);
	this->textFDbDir->Multiline = true;
	this->textFDbDir->Name = S"textFDbDir";
	this->textFDbDir->ReadOnly = true;
	this->textFDbDir->Size = System::Drawing::Size(304, 56);
	this->textFDbDir->TabIndex = 9;
	// 
	// butRemoveFDb
	// 
	this->butRemoveFDb->Location = System::Drawing::Point(16, 88);
	this->butRemoveFDb->Name = S"butRemoveFDb";
	this->butRemoveFDb->Size = System::Drawing::Size(75, 23);
	this->butRemoveFDb->TabIndex = 6;
	this->butRemoveFDb->Text = S"Remove";
	this->butRemoveFDb->Click += new System::EventHandler(this, &CCONetmainForm::butRemoveFDb_Click);
	// 
	// butAddFDb
	// 
	this->butAddFDb->Location = System::Drawing::Point(16, 56);
	this->butAddFDb->Name = S"butAddFDb";
	this->butAddFDb->Size = System::Drawing::Size(75, 23);
	this->butAddFDb->TabIndex = 5;
	this->butAddFDb->Text = S"Add";
	this->butAddFDb->Click += new System::EventHandler(this, &CCONetmainForm::butAddFDb_Click);
	// 
	// butEditFDb
	// 
	this->butEditFDb->Location = System::Drawing::Point(16, 24);
	this->butEditFDb->Name = S"butEditFDb";
	this->butEditFDb->Size = System::Drawing::Size(75, 23);
	this->butEditFDb->TabIndex = 4;
	this->butEditFDb->Text = S"Edit";
	this->butEditFDb->Click += new System::EventHandler(this, &CCONetmainForm::butEditFDb_Click);
	// 
	// tabpg_netowrks
	// 
	this->tabpg_netowrks->Controls->Add(this->groupBox1);
	this->tabpg_netowrks->Controls->Add(this->groupBox6);
	this->tabpg_netowrks->Location = System::Drawing::Point(4, 22);
	this->tabpg_netowrks->Name = S"tabpg_netowrks";
	this->tabpg_netowrks->Size = System::Drawing::Size(832, 565);
	this->tabpg_netowrks->TabIndex = 1;
	this->tabpg_netowrks->Text = S"Networks";
	// 
	// groupBox1
	// 
	this->groupBox1->Controls->Add(this->tabControl_net_list_tree);
	this->groupBox1->Controls->Add(this->groupBox2);
	this->groupBox1->Dock = System::Windows::Forms::DockStyle::Fill;
	this->groupBox1->Location = System::Drawing::Point(0, 0);
	this->groupBox1->Name = S"groupBox1";
	this->groupBox1->Size = System::Drawing::Size(480, 565);
	this->groupBox1->TabIndex = 7;
	this->groupBox1->TabStop = false;
	// 
	// tabControl_net_list_tree
	// 
	this->tabControl_net_list_tree->Controls->Add(this->tabPage_net_list);
	this->tabControl_net_list_tree->Controls->Add(this->tabPage_net_tree);
	this->tabControl_net_list_tree->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControl_net_list_tree->Location = System::Drawing::Point(3, 112);
	this->tabControl_net_list_tree->Name = S"tabControl_net_list_tree";
	this->tabControl_net_list_tree->SelectedIndex = 0;
	this->tabControl_net_list_tree->Size = System::Drawing::Size(474, 450);
	this->tabControl_net_list_tree->TabIndex = 9;
	// 
	// tabPage_net_list
	// 
	this->tabPage_net_list->Controls->Add(this->list_nets);
	this->tabPage_net_list->Location = System::Drawing::Point(4, 22);
	this->tabPage_net_list->Name = S"tabPage_net_list";
	this->tabPage_net_list->Size = System::Drawing::Size(466, 424);
	this->tabPage_net_list->TabIndex = 0;
	this->tabPage_net_list->Text = S"List";
	// 
	// list_nets
	// 
	this->list_nets->AllowColumnReorder = true;
	System::Windows::Forms::ColumnHeader* __mcTemp__2[] = new System::Windows::Forms::ColumnHeader*[4];
	__mcTemp__2[0] = this->columnHeader1;
	__mcTemp__2[1] = this->columnHeader2;
	__mcTemp__2[2] = this->columnHeader3;
	__mcTemp__2[3] = this->columnHeader4;
	this->list_nets->Columns->AddRange(__mcTemp__2);
	this->list_nets->Dock = System::Windows::Forms::DockStyle::Fill;
	this->list_nets->ForeColor = System::Drawing::SystemColors::WindowText;
	this->list_nets->FullRowSelect = true;
	this->list_nets->GridLines = true;
	this->list_nets->Location = System::Drawing::Point(0, 0);
	this->list_nets->Name = S"list_nets";
	this->list_nets->Size = System::Drawing::Size(466, 424);
	this->list_nets->TabIndex = 4;
	this->list_nets->UseCompatibleStateImageBehavior = false;
	this->list_nets->View = System::Windows::Forms::View::Details;
	this->list_nets->DoubleClick += new System::EventHandler(this, &CCONetmainForm::list_nets_DoubleClick);
	this->list_nets->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CCONetmainForm::list_nets_ColumnClick);
	this->list_nets->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CCONetmainForm::list_nets_MouseDown);
	// 
	// columnHeader1
	// 
	this->columnHeader1->Text = S"Name";
	this->columnHeader1->Width = 105;
	// 
	// columnHeader2
	// 
	this->columnHeader2->Text = S"nodes";
	this->columnHeader2->Width = 45;
	// 
	// columnHeader3
	// 
	this->columnHeader3->Text = S"links";
	this->columnHeader3->Width = 45;
	// 
	// columnHeader4
	// 
	this->columnHeader4->Text = S"Added";
	this->columnHeader4->Width = 120;
	// 
	// tabPage_net_tree
	// 
	this->tabPage_net_tree->Location = System::Drawing::Point(4, 22);
	this->tabPage_net_tree->Name = S"tabPage_net_tree";
	this->tabPage_net_tree->Size = System::Drawing::Size(466, 424);
	this->tabPage_net_tree->TabIndex = 1;
	this->tabPage_net_tree->Text = S"Tree";
	// 
	// groupBox2
	// 
	this->groupBox2->Controls->Add(this->check_config);
	this->groupBox2->Controls->Add(this->check_filter_by_fdb_root);
	this->groupBox2->Controls->Add(this->textChosenFDbNameForNets);
	this->groupBox2->Controls->Add(this->butFDbDeselectNets);
	this->groupBox2->Dock = System::Windows::Forms::DockStyle::Top;
	this->groupBox2->Location = System::Drawing::Point(3, 16);
	this->groupBox2->Name = S"groupBox2";
	this->groupBox2->Size = System::Drawing::Size(474, 96);
	this->groupBox2->TabIndex = 8;
	this->groupBox2->TabStop = false;
	this->groupBox2->Text = S"Chosen FDb root";
	// 
	// check_config
	// 
	this->check_config->Location = System::Drawing::Point(8, 64);
	this->check_config->Name = S"check_config";
	this->check_config->Size = System::Drawing::Size(160, 24);
	this->check_config->TabIndex = 4;
	this->check_config->Text = S"Show with configurations";
	this->check_config->CheckedChanged += new System::EventHandler(this, &CCONetmainForm::check_config_CheckedChanged);
	// 
	// check_filter_by_fdb_root
	// 
	this->check_filter_by_fdb_root->Location = System::Drawing::Point(8, 40);
	this->check_filter_by_fdb_root->Name = S"check_filter_by_fdb_root";
	this->check_filter_by_fdb_root->Size = System::Drawing::Size(160, 24);
	this->check_filter_by_fdb_root->TabIndex = 3;
	this->check_filter_by_fdb_root->Text = S"Filter by chosen FDb root";
	// 
	// textChosenFDbNameForNets
	// 
	this->textChosenFDbNameForNets->Location = System::Drawing::Point(3, 16);
	this->textChosenFDbNameForNets->Name = S"textChosenFDbNameForNets";
	this->textChosenFDbNameForNets->ReadOnly = true;
	this->textChosenFDbNameForNets->Size = System::Drawing::Size(179, 20);
	this->textChosenFDbNameForNets->TabIndex = 2;
	// 
	// butFDbDeselectNets
	// 
	this->butFDbDeselectNets->Location = System::Drawing::Point(182, 16);
	this->butFDbDeselectNets->Name = S"butFDbDeselectNets";
	this->butFDbDeselectNets->Size = System::Drawing::Size(75, 21);
	this->butFDbDeselectNets->TabIndex = 1;
	this->butFDbDeselectNets->Text = S"Deselect";
	this->butFDbDeselectNets->Click += new System::EventHandler(this, &CCONetmainForm::butFDbDeselectNets_Click);
	// 
	// groupBox6
	// 
	this->groupBox6->Controls->Add(this->but_massive_add_results);
	this->groupBox6->Controls->Add(this->but_massive_add_results_walk);
	this->groupBox6->Controls->Add(this->but_massive_add_results_old);
	this->groupBox6->Controls->Add(this->but_massive_add_conns);
	this->groupBox6->Controls->Add(this->textAddedBy);
	this->groupBox6->Controls->Add(this->label8);
	this->groupBox6->Controls->Add(this->textNetComments);
	this->groupBox6->Controls->Add(this->textNetLinksNum);
	this->groupBox6->Controls->Add(this->label7);
	this->groupBox6->Controls->Add(this->textNetNodesNum);
	this->groupBox6->Controls->Add(this->label5);
	this->groupBox6->Controls->Add(this->textNetDir);
	this->groupBox6->Controls->Add(this->label3);
	this->groupBox6->Controls->Add(this->label4);
	this->groupBox6->Controls->Add(this->textNetName);
	this->groupBox6->Controls->Add(this->label6);
	this->groupBox6->Controls->Add(this->butRemoveNet);
	this->groupBox6->Controls->Add(this->butAddNet);
	this->groupBox6->Controls->Add(this->butEditNet);
	this->groupBox6->Dock = System::Windows::Forms::DockStyle::Right;
	this->groupBox6->Location = System::Drawing::Point(480, 0);
	this->groupBox6->Name = S"groupBox6";
	this->groupBox6->Size = System::Drawing::Size(352, 565);
	this->groupBox6->TabIndex = 6;
	this->groupBox6->TabStop = false;
	// 
	// but_massive_add_results
	// 
	this->but_massive_add_results->Location = System::Drawing::Point(248, 72);
	this->but_massive_add_results->Name = S"but_massive_add_results";
	this->but_massive_add_results->Size = System::Drawing::Size(96, 40);
	this->but_massive_add_results->TabIndex = 55;
	this->but_massive_add_results->Text = S"Add hefan results";
	this->but_massive_add_results->Click += new System::EventHandler(this, &CCONetmainForm::but_massive_add_results_Click);
	// 
	// but_massive_add_results_walk
	// 
	this->but_massive_add_results_walk->Location = System::Drawing::Point(248, 24);
	this->but_massive_add_results_walk->Name = S"but_massive_add_results_walk";
	this->but_massive_add_results_walk->Size = System::Drawing::Size(96, 40);
	this->but_massive_add_results_walk->TabIndex = 54;
	this->but_massive_add_results_walk->Text = S"Add Walkowiak results";
	this->but_massive_add_results_walk->Click += new System::EventHandler(this, &CCONetmainForm::but_massive_add_results_walk_Click);
	// 
	// but_massive_add_results_old
	// 
	this->but_massive_add_results_old->Location = System::Drawing::Point(144, 72);
	this->but_massive_add_results_old->Name = S"but_massive_add_results_old";
	this->but_massive_add_results_old->Size = System::Drawing::Size(96, 40);
	this->but_massive_add_results_old->TabIndex = 53;
	this->but_massive_add_results_old->Text = S"Add old hefan results";
	this->but_massive_add_results_old->Click += new System::EventHandler(this, &CCONetmainForm::but_massive_add_results_old_Click);
	// 
	// but_massive_add_conns
	// 
	this->but_massive_add_conns->Location = System::Drawing::Point(144, 24);
	this->but_massive_add_conns->Name = S"but_massive_add_conns";
	this->but_massive_add_conns->Size = System::Drawing::Size(96, 40);
	this->but_massive_add_conns->TabIndex = 52;
	this->but_massive_add_conns->Text = S"Add connections by name";
	this->but_massive_add_conns->Click += new System::EventHandler(this, &CCONetmainForm::but_massive_add_conns_Click);
	// 
	// textAddedBy
	// 
	this->textAddedBy->Location = System::Drawing::Point(72, 496);
	this->textAddedBy->Name = S"textAddedBy";
	this->textAddedBy->ReadOnly = true;
	this->textAddedBy->Size = System::Drawing::Size(264, 20);
	this->textAddedBy->TabIndex = 51;
	// 
	// label8
	// 
	this->label8->AutoSize = true;
	this->label8->Location = System::Drawing::Point(24, 504);
	this->label8->Name = S"label8";
	this->label8->Size = System::Drawing::Size(38, 13);
	this->label8->TabIndex = 50;
	this->label8->Text = S"Added";
	// 
	// textNetComments
	// 
	this->textNetComments->Location = System::Drawing::Point(32, 312);
	this->textNetComments->Multiline = true;
	this->textNetComments->Name = S"textNetComments";
	this->textNetComments->ReadOnly = true;
	this->textNetComments->Size = System::Drawing::Size(304, 160);
	this->textNetComments->TabIndex = 49;
	// 
	// textNetLinksNum
	// 
	this->textNetLinksNum->Location = System::Drawing::Point(136, 256);
	this->textNetLinksNum->Name = S"textNetLinksNum";
	this->textNetLinksNum->ReadOnly = true;
	this->textNetLinksNum->Size = System::Drawing::Size(64, 20);
	this->textNetLinksNum->TabIndex = 48;
	// 
	// label7
	// 
	this->label7->AutoSize = true;
	this->label7->Location = System::Drawing::Point(120, 240);
	this->label7->Name = S"label7";
	this->label7->Size = System::Drawing::Size(58, 13);
	this->label7->TabIndex = 47;
	this->label7->Text = S"Links num:";
	// 
	// textNetNodesNum
	// 
	this->textNetNodesNum->Location = System::Drawing::Point(32, 256);
	this->textNetNodesNum->Name = S"textNetNodesNum";
	this->textNetNodesNum->ReadOnly = true;
	this->textNetNodesNum->Size = System::Drawing::Size(64, 20);
	this->textNetNodesNum->TabIndex = 46;
	// 
	// label5
	// 
	this->label5->AutoSize = true;
	this->label5->Location = System::Drawing::Point(16, 240);
	this->label5->Name = S"label5";
	this->label5->Size = System::Drawing::Size(64, 13);
	this->label5->TabIndex = 45;
	this->label5->Text = S"Nodes num:";
	// 
	// textNetDir
	// 
	this->textNetDir->Location = System::Drawing::Point(32, 208);
	this->textNetDir->Name = S"textNetDir";
	this->textNetDir->ReadOnly = true;
	this->textNetDir->Size = System::Drawing::Size(304, 20);
	this->textNetDir->TabIndex = 44;
	// 
	// label3
	// 
	this->label3->AutoSize = true;
	this->label3->Location = System::Drawing::Point(16, 192);
	this->label3->Name = S"label3";
	this->label3->Size = System::Drawing::Size(41, 13);
	this->label3->TabIndex = 43;
	this->label3->Text = S"Net dir:";
	// 
	// label4
	// 
	this->label4->AutoSize = true;
	this->label4->Location = System::Drawing::Point(16, 288);
	this->label4->Name = S"label4";
	this->label4->Size = System::Drawing::Size(59, 13);
	this->label4->TabIndex = 42;
	this->label4->Text = S"Comments:";
	// 
	// textNetName
	// 
	this->textNetName->Location = System::Drawing::Point(32, 160);
	this->textNetName->Name = S"textNetName";
	this->textNetName->ReadOnly = true;
	this->textNetName->Size = System::Drawing::Size(304, 20);
	this->textNetName->TabIndex = 41;
	// 
	// label6
	// 
	this->label6->AutoSize = true;
	this->label6->Location = System::Drawing::Point(16, 144);
	this->label6->Name = S"label6";
	this->label6->Size = System::Drawing::Size(56, 13);
	this->label6->TabIndex = 40;
	this->label6->Text = S"Net name:";
	// 
	// butRemoveNet
	// 
	this->butRemoveNet->Location = System::Drawing::Point(16, 88);
	this->butRemoveNet->Name = S"butRemoveNet";
	this->butRemoveNet->Size = System::Drawing::Size(75, 23);
	this->butRemoveNet->TabIndex = 6;
	this->butRemoveNet->Text = S"Remove";
	this->butRemoveNet->Click += new System::EventHandler(this, &CCONetmainForm::butRemoveNet_Click);
	// 
	// butAddNet
	// 
	this->butAddNet->Location = System::Drawing::Point(16, 56);
	this->butAddNet->Name = S"butAddNet";
	this->butAddNet->Size = System::Drawing::Size(75, 23);
	this->butAddNet->TabIndex = 5;
	this->butAddNet->Text = S"Add";
	this->butAddNet->Click += new System::EventHandler(this, &CCONetmainForm::butAddNet_Click);
	// 
	// butEditNet
	// 
	this->butEditNet->Location = System::Drawing::Point(16, 24);
	this->butEditNet->Name = S"butEditNet";
	this->butEditNet->Size = System::Drawing::Size(75, 23);
	this->butEditNet->TabIndex = 4;
	this->butEditNet->Text = S"Edit";
	this->butEditNet->Click += new System::EventHandler(this, &CCONetmainForm::butEditNet_Click);
	// 
	// tabpg_algorithms
	// 
	this->tabpg_algorithms->Controls->Add(this->groupBox3);
	this->tabpg_algorithms->Controls->Add(this->groupBox4);
	this->tabpg_algorithms->Location = System::Drawing::Point(4, 22);
	this->tabpg_algorithms->Name = S"tabpg_algorithms";
	this->tabpg_algorithms->Size = System::Drawing::Size(832, 565);
	this->tabpg_algorithms->TabIndex = 3;
	this->tabpg_algorithms->Text = S"Algorithms";
	// 
	// groupBox3
	// 
	this->groupBox3->Controls->Add(this->tabControl1);
	this->groupBox3->Dock = System::Windows::Forms::DockStyle::Fill;
	this->groupBox3->Location = System::Drawing::Point(0, 0);
	this->groupBox3->Name = S"groupBox3";
	this->groupBox3->Size = System::Drawing::Size(488, 565);
	this->groupBox3->TabIndex = 2;
	this->groupBox3->TabStop = false;
	// 
	// tabControl1
	// 
	this->tabControl1->Controls->Add(this->tabPage1);
	this->tabControl1->Controls->Add(this->tabPage4);
	this->tabControl1->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControl1->Location = System::Drawing::Point(3, 16);
	this->tabControl1->Name = S"tabControl1";
	this->tabControl1->SelectedIndex = 0;
	this->tabControl1->Size = System::Drawing::Size(482, 546);
	this->tabControl1->TabIndex = 10;
	// 
	// tabPage1
	// 
	this->tabPage1->Controls->Add(this->list_algorithms);
	this->tabPage1->Location = System::Drawing::Point(4, 22);
	this->tabPage1->Name = S"tabPage1";
	this->tabPage1->Size = System::Drawing::Size(474, 520);
	this->tabPage1->TabIndex = 0;
	this->tabPage1->Text = S"List";
	// 
	// list_algorithms
	// 
	this->list_algorithms->AllowColumnReorder = true;
	System::Windows::Forms::ColumnHeader* __mcTemp__3[] = new System::Windows::Forms::ColumnHeader*[3];
	__mcTemp__3[0] = this->columnHeader13;
	__mcTemp__3[1] = this->columnHeader14;
	__mcTemp__3[2] = this->columnHeader15;
	this->list_algorithms->Columns->AddRange(__mcTemp__3);
	this->list_algorithms->Dock = System::Windows::Forms::DockStyle::Fill;
	this->list_algorithms->ForeColor = System::Drawing::SystemColors::WindowText;
	this->list_algorithms->FullRowSelect = true;
	this->list_algorithms->GridLines = true;
	this->list_algorithms->Location = System::Drawing::Point(0, 0);
	this->list_algorithms->Name = S"list_algorithms";
	this->list_algorithms->Size = System::Drawing::Size(474, 520);
	this->list_algorithms->TabIndex = 4;
	this->list_algorithms->UseCompatibleStateImageBehavior = false;
	this->list_algorithms->View = System::Windows::Forms::View::Details;
	this->list_algorithms->DoubleClick += new System::EventHandler(this, &CCONetmainForm::list_algorithms_DoubleClick);
	this->list_algorithms->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CCONetmainForm::list_algorithms_ColumnClick);
	this->list_algorithms->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CCONetmainForm::list_algorithms_MouseDown);
	// 
	// columnHeader13
	// 
	this->columnHeader13->Text = S"Name";
	this->columnHeader13->Width = 100;
	// 
	// columnHeader14
	// 
	this->columnHeader14->Text = S"Par. number";
	this->columnHeader14->Width = 80;
	// 
	// columnHeader15
	// 
	this->columnHeader15->Text = S"Comments";
	this->columnHeader15->Width = 200;
	// 
	// tabPage4
	// 
	this->tabPage4->Location = System::Drawing::Point(4, 22);
	this->tabPage4->Name = S"tabPage4";
	this->tabPage4->Size = System::Drawing::Size(474, 520);
	this->tabPage4->TabIndex = 1;
	this->tabPage4->Text = S"Tree";
	this->tabPage4->Visible = false;
	// 
	// groupBox4
	// 
	this->groupBox4->Controls->Add(this->textAlgName);
	this->groupBox4->Controls->Add(this->label9);
	this->groupBox4->Controls->Add(this->label10);
	this->groupBox4->Controls->Add(this->textAlgComments);
	this->groupBox4->Controls->Add(this->but_rem_alg);
	this->groupBox4->Controls->Add(this->but_add_alg);
	this->groupBox4->Controls->Add(this->but_edit_alg);
	this->groupBox4->Dock = System::Windows::Forms::DockStyle::Right;
	this->groupBox4->Location = System::Drawing::Point(488, 0);
	this->groupBox4->Name = S"groupBox4";
	this->groupBox4->Size = System::Drawing::Size(344, 565);
	this->groupBox4->TabIndex = 1;
	this->groupBox4->TabStop = false;
	// 
	// textAlgName
	// 
	this->textAlgName->Location = System::Drawing::Point(32, 168);
	this->textAlgName->Name = S"textAlgName";
	this->textAlgName->ReadOnly = true;
	this->textAlgName->Size = System::Drawing::Size(304, 20);
	this->textAlgName->TabIndex = 19;
	// 
	// label9
	// 
	this->label9->AutoSize = true;
	this->label9->Location = System::Drawing::Point(16, 144);
	this->label9->Name = S"label9";
	this->label9->Size = System::Drawing::Size(82, 13);
	this->label9->TabIndex = 18;
	this->label9->Text = S"Algorithm name:";
	// 
	// label10
	// 
	this->label10->AutoSize = true;
	this->label10->Location = System::Drawing::Point(16, 216);
	this->label10->Name = S"label10";
	this->label10->Size = System::Drawing::Size(104, 13);
	this->label10->TabIndex = 17;
	this->label10->Text = S"Algorithm comments:";
	// 
	// textAlgComments
	// 
	this->textAlgComments->Location = System::Drawing::Point(32, 240);
	this->textAlgComments->Multiline = true;
	this->textAlgComments->Name = S"textAlgComments";
	this->textAlgComments->ReadOnly = true;
	this->textAlgComments->Size = System::Drawing::Size(304, 56);
	this->textAlgComments->TabIndex = 16;
	// 
	// but_rem_alg
	// 
	this->but_rem_alg->Location = System::Drawing::Point(16, 96);
	this->but_rem_alg->Name = S"but_rem_alg";
	this->but_rem_alg->Size = System::Drawing::Size(75, 23);
	this->but_rem_alg->TabIndex = 15;
	this->but_rem_alg->Text = S"Remove";
	this->but_rem_alg->Click += new System::EventHandler(this, &CCONetmainForm::but_rem_alg_Click);
	// 
	// but_add_alg
	// 
	this->but_add_alg->Location = System::Drawing::Point(16, 64);
	this->but_add_alg->Name = S"but_add_alg";
	this->but_add_alg->Size = System::Drawing::Size(75, 23);
	this->but_add_alg->TabIndex = 14;
	this->but_add_alg->Text = S"Add";
	this->but_add_alg->Click += new System::EventHandler(this, &CCONetmainForm::but_add_alg_Click);
	// 
	// but_edit_alg
	// 
	this->but_edit_alg->Location = System::Drawing::Point(16, 32);
	this->but_edit_alg->Name = S"but_edit_alg";
	this->but_edit_alg->Size = System::Drawing::Size(75, 23);
	this->but_edit_alg->TabIndex = 13;
	this->but_edit_alg->Text = S"Edit";
	this->but_edit_alg->Click += new System::EventHandler(this, &CCONetmainForm::but_edit_alg_Click);
	// 
	// tabpg_computers
	// 
	this->tabpg_computers->Controls->Add(this->groupBox5);
	this->tabpg_computers->Controls->Add(this->groupBox8);
	this->tabpg_computers->Location = System::Drawing::Point(4, 22);
	this->tabpg_computers->Name = S"tabpg_computers";
	this->tabpg_computers->Size = System::Drawing::Size(832, 565);
	this->tabpg_computers->TabIndex = 6;
	this->tabpg_computers->Text = S"Computers";
	// 
	// groupBox5
	// 
	this->groupBox5->Controls->Add(this->tabControl3);
	this->groupBox5->Dock = System::Windows::Forms::DockStyle::Fill;
	this->groupBox5->Location = System::Drawing::Point(0, 0);
	this->groupBox5->Name = S"groupBox5";
	this->groupBox5->Size = System::Drawing::Size(488, 565);
	this->groupBox5->TabIndex = 10;
	this->groupBox5->TabStop = false;
	// 
	// tabControl3
	// 
	this->tabControl3->Controls->Add(this->tabPage7);
	this->tabControl3->Controls->Add(this->tabPage8);
	this->tabControl3->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControl3->Location = System::Drawing::Point(3, 16);
	this->tabControl3->Name = S"tabControl3";
	this->tabControl3->SelectedIndex = 0;
	this->tabControl3->Size = System::Drawing::Size(482, 546);
	this->tabControl3->TabIndex = 10;
	// 
	// tabPage7
	// 
	this->tabPage7->Controls->Add(this->list_computers);
	this->tabPage7->Location = System::Drawing::Point(4, 22);
	this->tabPage7->Name = S"tabPage7";
	this->tabPage7->Size = System::Drawing::Size(474, 520);
	this->tabPage7->TabIndex = 0;
	this->tabPage7->Text = S"List";
	// 
	// list_computers
	// 
	this->list_computers->AllowColumnReorder = true;
	System::Windows::Forms::ColumnHeader* __mcTemp__4[] = new System::Windows::Forms::ColumnHeader*[2];
	__mcTemp__4[0] = this->columnHeader6;
	__mcTemp__4[1] = this->columnHeader7;
	this->list_computers->Columns->AddRange(__mcTemp__4);
	this->list_computers->Dock = System::Windows::Forms::DockStyle::Fill;
	this->list_computers->ForeColor = System::Drawing::SystemColors::WindowText;
	this->list_computers->FullRowSelect = true;
	this->list_computers->GridLines = true;
	this->list_computers->Location = System::Drawing::Point(0, 0);
	this->list_computers->Name = S"list_computers";
	this->list_computers->Size = System::Drawing::Size(474, 520);
	this->list_computers->TabIndex = 4;
	this->list_computers->UseCompatibleStateImageBehavior = false;
	this->list_computers->View = System::Windows::Forms::View::Details;
	this->list_computers->DoubleClick += new System::EventHandler(this, &CCONetmainForm::list_computers_DoubleClick);
	this->list_computers->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CCONetmainForm::list_computers_ColumnClick);
	this->list_computers->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CCONetmainForm::list_computers_MouseDown);
	// 
	// columnHeader6
	// 
	this->columnHeader6->Text = S"Name";
	this->columnHeader6->Width = 105;
	// 
	// columnHeader7
	// 
	this->columnHeader7->Text = S"Comments";
	this->columnHeader7->Width = 280;
	// 
	// tabPage8
	// 
	this->tabPage8->Location = System::Drawing::Point(4, 22);
	this->tabPage8->Name = S"tabPage8";
	this->tabPage8->Size = System::Drawing::Size(474, 520);
	this->tabPage8->TabIndex = 1;
	this->tabPage8->Text = S"Tree";
	this->tabPage8->Visible = false;
	// 
	// groupBox8
	// 
	this->groupBox8->Controls->Add(this->textCompName);
	this->groupBox8->Controls->Add(this->label13);
	this->groupBox8->Controls->Add(this->label14);
	this->groupBox8->Controls->Add(this->textCompComm);
	this->groupBox8->Controls->Add(this->butRemoveComp);
	this->groupBox8->Controls->Add(this->butAddComp);
	this->groupBox8->Controls->Add(this->butEditComp);
	this->groupBox8->Dock = System::Windows::Forms::DockStyle::Right;
	this->groupBox8->Location = System::Drawing::Point(488, 0);
	this->groupBox8->Name = S"groupBox8";
	this->groupBox8->Size = System::Drawing::Size(344, 565);
	this->groupBox8->TabIndex = 9;
	this->groupBox8->TabStop = false;
	// 
	// textCompName
	// 
	this->textCompName->Location = System::Drawing::Point(32, 168);
	this->textCompName->Name = S"textCompName";
	this->textCompName->ReadOnly = true;
	this->textCompName->Size = System::Drawing::Size(304, 20);
	this->textCompName->TabIndex = 26;
	// 
	// label13
	// 
	this->label13->AutoSize = true;
	this->label13->Location = System::Drawing::Point(16, 144);
	this->label13->Name = S"label13";
	this->label13->Size = System::Drawing::Size(80, 13);
	this->label13->TabIndex = 25;
	this->label13->Text = S"Function name:";
	// 
	// label14
	// 
	this->label14->AutoSize = true;
	this->label14->Location = System::Drawing::Point(16, 216);
	this->label14->Name = S"label14";
	this->label14->Size = System::Drawing::Size(102, 13);
	this->label14->TabIndex = 24;
	this->label14->Text = S"Function comments:";
	// 
	// textCompComm
	// 
	this->textCompComm->Location = System::Drawing::Point(32, 240);
	this->textCompComm->Multiline = true;
	this->textCompComm->Name = S"textCompComm";
	this->textCompComm->ReadOnly = true;
	this->textCompComm->Size = System::Drawing::Size(304, 56);
	this->textCompComm->TabIndex = 23;
	// 
	// butRemoveComp
	// 
	this->butRemoveComp->Location = System::Drawing::Point(16, 96);
	this->butRemoveComp->Name = S"butRemoveComp";
	this->butRemoveComp->Size = System::Drawing::Size(75, 23);
	this->butRemoveComp->TabIndex = 22;
	this->butRemoveComp->Text = S"Remove";
	this->butRemoveComp->Click += new System::EventHandler(this, &CCONetmainForm::butRemoveComp_Click);
	// 
	// butAddComp
	// 
	this->butAddComp->Location = System::Drawing::Point(16, 64);
	this->butAddComp->Name = S"butAddComp";
	this->butAddComp->Size = System::Drawing::Size(75, 23);
	this->butAddComp->TabIndex = 21;
	this->butAddComp->Text = S"Add";
	this->butAddComp->Click += new System::EventHandler(this, &CCONetmainForm::butAddComp_Click);
	// 
	// butEditComp
	// 
	this->butEditComp->Location = System::Drawing::Point(16, 32);
	this->butEditComp->Name = S"butEditComp";
	this->butEditComp->Size = System::Drawing::Size(75, 23);
	this->butEditComp->TabIndex = 20;
	this->butEditComp->Text = S"Edit";
	this->butEditComp->Click += new System::EventHandler(this, &CCONetmainForm::butEditComp_Click);
	// 
	// tabpg_fitt_funcs
	// 
	this->tabpg_fitt_funcs->Controls->Add(this->groupBox7);
	this->tabpg_fitt_funcs->Controls->Add(this->groupBox10);
	this->tabpg_fitt_funcs->Location = System::Drawing::Point(4, 22);
	this->tabpg_fitt_funcs->Name = S"tabpg_fitt_funcs";
	this->tabpg_fitt_funcs->Size = System::Drawing::Size(832, 565);
	this->tabpg_fitt_funcs->TabIndex = 5;
	this->tabpg_fitt_funcs->Text = S"Fitness functions";
	// 
	// groupBox7
	// 
	this->groupBox7->Controls->Add(this->tabControl2);
	this->groupBox7->Dock = System::Windows::Forms::DockStyle::Fill;
	this->groupBox7->Location = System::Drawing::Point(0, 0);
	this->groupBox7->Name = S"groupBox7";
	this->groupBox7->Size = System::Drawing::Size(488, 565);
	this->groupBox7->TabIndex = 8;
	this->groupBox7->TabStop = false;
	// 
	// tabControl2
	// 
	this->tabControl2->Controls->Add(this->tabPage5);
	this->tabControl2->Controls->Add(this->tabPage6);
	this->tabControl2->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControl2->Location = System::Drawing::Point(3, 16);
	this->tabControl2->Name = S"tabControl2";
	this->tabControl2->SelectedIndex = 0;
	this->tabControl2->Size = System::Drawing::Size(482, 546);
	this->tabControl2->TabIndex = 10;
	// 
	// tabPage5
	// 
	this->tabPage5->Controls->Add(this->list_ff);
	this->tabPage5->Location = System::Drawing::Point(4, 22);
	this->tabPage5->Name = S"tabPage5";
	this->tabPage5->Size = System::Drawing::Size(474, 520);
	this->tabPage5->TabIndex = 0;
	this->tabPage5->Text = S"List";
	// 
	// list_ff
	// 
	this->list_ff->AllowColumnReorder = true;
	System::Windows::Forms::ColumnHeader* __mcTemp__5[] = new System::Windows::Forms::ColumnHeader*[2];
	__mcTemp__5[0] = this->columnHeader9;
	__mcTemp__5[1] = this->columnHeader5;
	this->list_ff->Columns->AddRange(__mcTemp__5);
	this->list_ff->Dock = System::Windows::Forms::DockStyle::Fill;
	this->list_ff->ForeColor = System::Drawing::SystemColors::WindowText;
	this->list_ff->FullRowSelect = true;
	this->list_ff->GridLines = true;
	this->list_ff->Location = System::Drawing::Point(0, 0);
	this->list_ff->Name = S"list_ff";
	this->list_ff->Size = System::Drawing::Size(474, 520);
	this->list_ff->TabIndex = 4;
	this->list_ff->UseCompatibleStateImageBehavior = false;
	this->list_ff->View = System::Windows::Forms::View::Details;
	this->list_ff->DoubleClick += new System::EventHandler(this, &CCONetmainForm::list_ff_DoubleClick);
	this->list_ff->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CCONetmainForm::list_ff_ColumnClick);
	this->list_ff->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CCONetmainForm::list_ff_MouseDown);
	// 
	// columnHeader9
	// 
	this->columnHeader9->Text = S"Name";
	this->columnHeader9->Width = 105;
	// 
	// columnHeader5
	// 
	this->columnHeader5->Text = S"Comments";
	this->columnHeader5->Width = 280;
	// 
	// tabPage6
	// 
	this->tabPage6->Location = System::Drawing::Point(4, 22);
	this->tabPage6->Name = S"tabPage6";
	this->tabPage6->Size = System::Drawing::Size(474, 520);
	this->tabPage6->TabIndex = 1;
	this->tabPage6->Text = S"Tree";
	this->tabPage6->Visible = false;
	// 
	// groupBox10
	// 
	this->groupBox10->Controls->Add(this->textFFuncName);
	this->groupBox10->Controls->Add(this->label11);
	this->groupBox10->Controls->Add(this->label12);
	this->groupBox10->Controls->Add(this->textFFuncComm);
	this->groupBox10->Controls->Add(this->butRemoveFF);
	this->groupBox10->Controls->Add(this->butAddFF);
	this->groupBox10->Controls->Add(this->butEditFF);
	this->groupBox10->Dock = System::Windows::Forms::DockStyle::Right;
	this->groupBox10->Location = System::Drawing::Point(488, 0);
	this->groupBox10->Name = S"groupBox10";
	this->groupBox10->Size = System::Drawing::Size(344, 565);
	this->groupBox10->TabIndex = 7;
	this->groupBox10->TabStop = false;
	// 
	// textFFuncName
	// 
	this->textFFuncName->Location = System::Drawing::Point(32, 168);
	this->textFFuncName->Name = S"textFFuncName";
	this->textFFuncName->ReadOnly = true;
	this->textFFuncName->Size = System::Drawing::Size(304, 20);
	this->textFFuncName->TabIndex = 26;
	// 
	// label11
	// 
	this->label11->AutoSize = true;
	this->label11->Location = System::Drawing::Point(16, 144);
	this->label11->Name = S"label11";
	this->label11->Size = System::Drawing::Size(80, 13);
	this->label11->TabIndex = 25;
	this->label11->Text = S"Function name:";
	// 
	// label12
	// 
	this->label12->AutoSize = true;
	this->label12->Location = System::Drawing::Point(16, 216);
	this->label12->Name = S"label12";
	this->label12->Size = System::Drawing::Size(102, 13);
	this->label12->TabIndex = 24;
	this->label12->Text = S"Function comments:";
	// 
	// textFFuncComm
	// 
	this->textFFuncComm->Location = System::Drawing::Point(32, 240);
	this->textFFuncComm->Multiline = true;
	this->textFFuncComm->Name = S"textFFuncComm";
	this->textFFuncComm->ReadOnly = true;
	this->textFFuncComm->Size = System::Drawing::Size(304, 56);
	this->textFFuncComm->TabIndex = 23;
	// 
	// butRemoveFF
	// 
	this->butRemoveFF->Location = System::Drawing::Point(16, 96);
	this->butRemoveFF->Name = S"butRemoveFF";
	this->butRemoveFF->Size = System::Drawing::Size(75, 23);
	this->butRemoveFF->TabIndex = 22;
	this->butRemoveFF->Text = S"Remove";
	this->butRemoveFF->Click += new System::EventHandler(this, &CCONetmainForm::butRemoveFF_Click);
	// 
	// butAddFF
	// 
	this->butAddFF->Location = System::Drawing::Point(16, 64);
	this->butAddFF->Name = S"butAddFF";
	this->butAddFF->Size = System::Drawing::Size(75, 23);
	this->butAddFF->TabIndex = 21;
	this->butAddFF->Text = S"Add";
	this->butAddFF->Click += new System::EventHandler(this, &CCONetmainForm::butAddFF_Click);
	// 
	// butEditFF
	// 
	this->butEditFF->Location = System::Drawing::Point(16, 32);
	this->butEditFF->Name = S"butEditFF";
	this->butEditFF->Size = System::Drawing::Size(75, 23);
	this->butEditFF->TabIndex = 20;
	this->butEditFF->Text = S"Edit";
	this->butEditFF->Click += new System::EventHandler(this, &CCONetmainForm::butEditFF_Click);
	// 
	// tabpg_results_sets
	// 
	this->tabpg_results_sets->Controls->Add(this->groupBox13);
	this->tabpg_results_sets->Controls->Add(this->groupBox14);
	this->tabpg_results_sets->Location = System::Drawing::Point(4, 22);
	this->tabpg_results_sets->Name = S"tabpg_results_sets";
	this->tabpg_results_sets->Size = System::Drawing::Size(832, 565);
	this->tabpg_results_sets->TabIndex = 7;
	this->tabpg_results_sets->Text = S"Results sets";
	// 
	// groupBox13
	// 
	this->groupBox13->Controls->Add(this->tabControl5);
	this->groupBox13->Dock = System::Windows::Forms::DockStyle::Fill;
	this->groupBox13->Location = System::Drawing::Point(0, 0);
	this->groupBox13->Name = S"groupBox13";
	this->groupBox13->Size = System::Drawing::Size(488, 565);
	this->groupBox13->TabIndex = 12;
	this->groupBox13->TabStop = false;
	// 
	// tabControl5
	// 
	this->tabControl5->Controls->Add(this->tabPage11);
	this->tabControl5->Controls->Add(this->tabPage12);
	this->tabControl5->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControl5->Location = System::Drawing::Point(3, 16);
	this->tabControl5->Name = S"tabControl5";
	this->tabControl5->SelectedIndex = 0;
	this->tabControl5->Size = System::Drawing::Size(482, 546);
	this->tabControl5->TabIndex = 10;
	// 
	// tabPage11
	// 
	this->tabPage11->Controls->Add(this->list_results_sets);
	this->tabPage11->Location = System::Drawing::Point(4, 22);
	this->tabPage11->Name = S"tabPage11";
	this->tabPage11->Size = System::Drawing::Size(474, 520);
	this->tabPage11->TabIndex = 0;
	this->tabPage11->Text = S"List";
	// 
	// list_results_sets
	// 
	this->list_results_sets->AllowColumnReorder = true;
	System::Windows::Forms::ColumnHeader* __mcTemp__6[] = new System::Windows::Forms::ColumnHeader*[2];
	__mcTemp__6[0] = this->columnHeader21;
	__mcTemp__6[1] = this->columnHeader22;
	this->list_results_sets->Columns->AddRange(__mcTemp__6);
	this->list_results_sets->Dock = System::Windows::Forms::DockStyle::Fill;
	this->list_results_sets->ForeColor = System::Drawing::SystemColors::WindowText;
	this->list_results_sets->FullRowSelect = true;
	this->list_results_sets->GridLines = true;
	this->list_results_sets->Location = System::Drawing::Point(0, 0);
	this->list_results_sets->Name = S"list_results_sets";
	this->list_results_sets->Size = System::Drawing::Size(474, 520);
	this->list_results_sets->TabIndex = 4;
	this->list_results_sets->UseCompatibleStateImageBehavior = false;
	this->list_results_sets->View = System::Windows::Forms::View::Details;
	this->list_results_sets->DoubleClick += new System::EventHandler(this, &CCONetmainForm::list_results_sets_DoubleClick);
	this->list_results_sets->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CCONetmainForm::list_results_sets_ColumnClick);
	this->list_results_sets->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CCONetmainForm::list_results_sets_MouseDown);
	// 
	// columnHeader21
	// 
	this->columnHeader21->Text = S"Name";
	this->columnHeader21->Width = 105;
	// 
	// columnHeader22
	// 
	this->columnHeader22->Text = S"Comments";
	this->columnHeader22->Width = 280;
	// 
	// tabPage12
	// 
	this->tabPage12->Location = System::Drawing::Point(4, 22);
	this->tabPage12->Name = S"tabPage12";
	this->tabPage12->Size = System::Drawing::Size(474, 520);
	this->tabPage12->TabIndex = 1;
	this->tabPage12->Text = S"Tree";
	this->tabPage12->Visible = false;
	// 
	// groupBox14
	// 
	this->groupBox14->Controls->Add(this->textRSetName);
	this->groupBox14->Controls->Add(this->label21);
	this->groupBox14->Controls->Add(this->label22);
	this->groupBox14->Controls->Add(this->textRSetComm);
	this->groupBox14->Controls->Add(this->butRemRSet);
	this->groupBox14->Controls->Add(this->butAddRSet);
	this->groupBox14->Controls->Add(this->butEditRSet);
	this->groupBox14->Dock = System::Windows::Forms::DockStyle::Right;
	this->groupBox14->Location = System::Drawing::Point(488, 0);
	this->groupBox14->Name = S"groupBox14";
	this->groupBox14->Size = System::Drawing::Size(344, 565);
	this->groupBox14->TabIndex = 11;
	this->groupBox14->TabStop = false;
	// 
	// textRSetName
	// 
	this->textRSetName->Location = System::Drawing::Point(32, 168);
	this->textRSetName->Name = S"textRSetName";
	this->textRSetName->ReadOnly = true;
	this->textRSetName->Size = System::Drawing::Size(304, 20);
	this->textRSetName->TabIndex = 26;
	// 
	// label21
	// 
	this->label21->AutoSize = true;
	this->label21->Location = System::Drawing::Point(16, 144);
	this->label21->Name = S"label21";
	this->label21->Size = System::Drawing::Size(86, 13);
	this->label21->TabIndex = 25;
	this->label21->Text = S"Result set name:";
	// 
	// label22
	// 
	this->label22->AutoSize = true;
	this->label22->Location = System::Drawing::Point(16, 216);
	this->label22->Name = S"label22";
	this->label22->Size = System::Drawing::Size(108, 13);
	this->label22->TabIndex = 24;
	this->label22->Text = S"Result set comments:";
	// 
	// textRSetComm
	// 
	this->textRSetComm->Location = System::Drawing::Point(32, 240);
	this->textRSetComm->Multiline = true;
	this->textRSetComm->Name = S"textRSetComm";
	this->textRSetComm->ReadOnly = true;
	this->textRSetComm->Size = System::Drawing::Size(304, 56);
	this->textRSetComm->TabIndex = 23;
	// 
	// butRemRSet
	// 
	this->butRemRSet->Location = System::Drawing::Point(16, 96);
	this->butRemRSet->Name = S"butRemRSet";
	this->butRemRSet->Size = System::Drawing::Size(75, 23);
	this->butRemRSet->TabIndex = 22;
	this->butRemRSet->Text = S"Remove";
	this->butRemRSet->Click += new System::EventHandler(this, &CCONetmainForm::butRemRSet_Click);
	// 
	// butAddRSet
	// 
	this->butAddRSet->Location = System::Drawing::Point(16, 64);
	this->butAddRSet->Name = S"butAddRSet";
	this->butAddRSet->Size = System::Drawing::Size(75, 23);
	this->butAddRSet->TabIndex = 21;
	this->butAddRSet->Text = S"Add";
	this->butAddRSet->Click += new System::EventHandler(this, &CCONetmainForm::butAddRSet_Click);
	// 
	// butEditRSet
	// 
	this->butEditRSet->Location = System::Drawing::Point(16, 32);
	this->butEditRSet->Name = S"butEditRSet";
	this->butEditRSet->Size = System::Drawing::Size(75, 23);
	this->butEditRSet->TabIndex = 20;
	this->butEditRSet->Text = S"Edit";
	this->butEditRSet->Click += new System::EventHandler(this, &CCONetmainForm::butEditRSet_Click);
	// 
	// tabpg_results
	// 
	this->tabpg_results->Controls->Add(this->groupBox9);
	this->tabpg_results->Controls->Add(this->groupBox12);
	this->tabpg_results->Location = System::Drawing::Point(4, 22);
	this->tabpg_results->Name = S"tabpg_results";
	this->tabpg_results->Size = System::Drawing::Size(832, 565);
	this->tabpg_results->TabIndex = 4;
	this->tabpg_results->Text = S"Results";
	// 
	// groupBox9
	// 
	this->groupBox9->Controls->Add(this->tabControl4);
	this->groupBox9->Controls->Add(this->groupBox11);
	this->groupBox9->Dock = System::Windows::Forms::DockStyle::Fill;
	this->groupBox9->Location = System::Drawing::Point(0, 0);
	this->groupBox9->Name = S"groupBox9";
	this->groupBox9->Size = System::Drawing::Size(528, 565);
	this->groupBox9->TabIndex = 9;
	this->groupBox9->TabStop = false;
	// 
	// tabControl4
	// 
	this->tabControl4->Controls->Add(this->tabPage9);
	this->tabControl4->Controls->Add(this->tabPage10);
	this->tabControl4->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControl4->Location = System::Drawing::Point(3, 88);
	this->tabControl4->Name = S"tabControl4";
	this->tabControl4->SelectedIndex = 0;
	this->tabControl4->Size = System::Drawing::Size(522, 474);
	this->tabControl4->TabIndex = 9;
	// 
	// tabPage9
	// 
	this->tabPage9->Controls->Add(this->list_results);
	this->tabPage9->Location = System::Drawing::Point(4, 22);
	this->tabPage9->Name = S"tabPage9";
	this->tabPage9->Size = System::Drawing::Size(514, 448);
	this->tabPage9->TabIndex = 0;
	this->tabPage9->Text = S"List";
	// 
	// list_results
	// 
	this->list_results->AllowColumnReorder = true;
	System::Windows::Forms::ColumnHeader* __mcTemp__7[] = new System::Windows::Forms::ColumnHeader*[9];
	__mcTemp__7[0] = this->columnHeader8;
	__mcTemp__7[1] = this->columnHeader10;
	__mcTemp__7[2] = this->columnHeader11;
	__mcTemp__7[3] = this->columnHeader12;
	__mcTemp__7[4] = this->columnHeader16;
	__mcTemp__7[5] = this->columnHeader17;
	__mcTemp__7[6] = this->columnHeader18;
	__mcTemp__7[7] = this->columnHeader19;
	__mcTemp__7[8] = this->columnHeader20;
	this->list_results->Columns->AddRange(__mcTemp__7);
	this->list_results->Dock = System::Windows::Forms::DockStyle::Fill;
	this->list_results->ForeColor = System::Drawing::SystemColors::WindowText;
	this->list_results->FullRowSelect = true;
	this->list_results->GridLines = true;
	this->list_results->Location = System::Drawing::Point(0, 0);
	this->list_results->Name = S"list_results";
	this->list_results->Size = System::Drawing::Size(514, 448);
	this->list_results->TabIndex = 4;
	this->list_results->UseCompatibleStateImageBehavior = false;
	this->list_results->View = System::Windows::Forms::View::Details;
	// 
	// columnHeader8
	// 
	this->columnHeader8->Text = S"Name";
	this->columnHeader8->Width = 80;
	// 
	// columnHeader10
	// 
	this->columnHeader10->Text = S"Fdb";
	this->columnHeader10->Width = 80;
	// 
	// columnHeader11
	// 
	this->columnHeader11->Text = S"network";
	this->columnHeader11->Width = 80;
	// 
	// columnHeader12
	// 
	this->columnHeader12->Text = S"Conn. config.";
	this->columnHeader12->Width = 80;
	// 
	// columnHeader16
	// 
	this->columnHeader16->Text = S"Algorithm";
	this->columnHeader16->Width = 80;
	// 
	// columnHeader17
	// 
	this->columnHeader17->Text = S"Fitt. func.";
	this->columnHeader17->Width = 80;
	// 
	// columnHeader18
	// 
	this->columnHeader18->Text = S"Fitt. value";
	// 
	// columnHeader19
	// 
	this->columnHeader19->Text = S"Time";
	// 
	// columnHeader20
	// 
	this->columnHeader20->Text = S"Date";
	this->columnHeader20->Width = 80;
	// 
	// tabPage10
	// 
	this->tabPage10->Location = System::Drawing::Point(4, 22);
	this->tabPage10->Name = S"tabPage10";
	this->tabPage10->Size = System::Drawing::Size(514, 448);
	this->tabPage10->TabIndex = 1;
	this->tabPage10->Text = S"Tree";
	this->tabPage10->Visible = false;
	// 
	// groupBox11
	// 
	this->groupBox11->Controls->Add(this->checkBox2);
	this->groupBox11->Controls->Add(this->textChosenFDbNameForResults);
	this->groupBox11->Controls->Add(this->butFDbDeselectResults);
	this->groupBox11->Dock = System::Windows::Forms::DockStyle::Top;
	this->groupBox11->Location = System::Drawing::Point(3, 16);
	this->groupBox11->Name = S"groupBox11";
	this->groupBox11->Size = System::Drawing::Size(522, 72);
	this->groupBox11->TabIndex = 8;
	this->groupBox11->TabStop = false;
	this->groupBox11->Text = S"Chosen FDb root";
	// 
	// checkBox2
	// 
	this->checkBox2->Location = System::Drawing::Point(8, 40);
	this->checkBox2->Name = S"checkBox2";
	this->checkBox2->Size = System::Drawing::Size(160, 24);
	this->checkBox2->TabIndex = 3;
	this->checkBox2->Text = S"Filter by chosen FDb root";
	// 
	// textChosenFDbNameForResults
	// 
	this->textChosenFDbNameForResults->Location = System::Drawing::Point(3, 16);
	this->textChosenFDbNameForResults->Name = S"textChosenFDbNameForResults";
	this->textChosenFDbNameForResults->ReadOnly = true;
	this->textChosenFDbNameForResults->Size = System::Drawing::Size(179, 20);
	this->textChosenFDbNameForResults->TabIndex = 2;
	// 
	// butFDbDeselectResults
	// 
	this->butFDbDeselectResults->Location = System::Drawing::Point(182, 16);
	this->butFDbDeselectResults->Name = S"butFDbDeselectResults";
	this->butFDbDeselectResults->Size = System::Drawing::Size(75, 21);
	this->butFDbDeselectResults->TabIndex = 1;
	this->butFDbDeselectResults->Text = S"Deselect";
	// 
	// groupBox12
	// 
	this->groupBox12->Controls->Add(this->textBox2);
	this->groupBox12->Controls->Add(this->label15);
	this->groupBox12->Controls->Add(this->textBox3);
	this->groupBox12->Controls->Add(this->textBox4);
	this->groupBox12->Controls->Add(this->label16);
	this->groupBox12->Controls->Add(this->textBox5);
	this->groupBox12->Controls->Add(this->label17);
	this->groupBox12->Controls->Add(this->textBox6);
	this->groupBox12->Controls->Add(this->label18);
	this->groupBox12->Controls->Add(this->label19);
	this->groupBox12->Controls->Add(this->textBox7);
	this->groupBox12->Controls->Add(this->label20);
	this->groupBox12->Controls->Add(this->button2);
	this->groupBox12->Controls->Add(this->button3);
	this->groupBox12->Controls->Add(this->button4);
	this->groupBox12->Dock = System::Windows::Forms::DockStyle::Right;
	this->groupBox12->Location = System::Drawing::Point(528, 0);
	this->groupBox12->Name = S"groupBox12";
	this->groupBox12->Size = System::Drawing::Size(304, 565);
	this->groupBox12->TabIndex = 8;
	this->groupBox12->TabStop = false;
	// 
	// textBox2
	// 
	this->textBox2->Location = System::Drawing::Point(72, 496);
	this->textBox2->Name = S"textBox2";
	this->textBox2->ReadOnly = true;
	this->textBox2->Size = System::Drawing::Size(264, 20);
	this->textBox2->TabIndex = 51;
	// 
	// label15
	// 
	this->label15->AutoSize = true;
	this->label15->Location = System::Drawing::Point(24, 504);
	this->label15->Name = S"label15";
	this->label15->Size = System::Drawing::Size(38, 13);
	this->label15->TabIndex = 50;
	this->label15->Text = S"Added";
	// 
	// textBox3
	// 
	this->textBox3->Location = System::Drawing::Point(32, 312);
	this->textBox3->Multiline = true;
	this->textBox3->Name = S"textBox3";
	this->textBox3->ReadOnly = true;
	this->textBox3->Size = System::Drawing::Size(304, 160);
	this->textBox3->TabIndex = 49;
	// 
	// textBox4
	// 
	this->textBox4->Location = System::Drawing::Point(136, 256);
	this->textBox4->Name = S"textBox4";
	this->textBox4->ReadOnly = true;
	this->textBox4->Size = System::Drawing::Size(64, 20);
	this->textBox4->TabIndex = 48;
	// 
	// label16
	// 
	this->label16->AutoSize = true;
	this->label16->Location = System::Drawing::Point(120, 240);
	this->label16->Name = S"label16";
	this->label16->Size = System::Drawing::Size(58, 13);
	this->label16->TabIndex = 47;
	this->label16->Text = S"Links num:";
	// 
	// textBox5
	// 
	this->textBox5->Location = System::Drawing::Point(32, 256);
	this->textBox5->Name = S"textBox5";
	this->textBox5->ReadOnly = true;
	this->textBox5->Size = System::Drawing::Size(64, 20);
	this->textBox5->TabIndex = 46;
	// 
	// label17
	// 
	this->label17->AutoSize = true;
	this->label17->Location = System::Drawing::Point(16, 240);
	this->label17->Name = S"label17";
	this->label17->Size = System::Drawing::Size(64, 13);
	this->label17->TabIndex = 45;
	this->label17->Text = S"Nodes num:";
	// 
	// textBox6
	// 
	this->textBox6->Location = System::Drawing::Point(32, 208);
	this->textBox6->Name = S"textBox6";
	this->textBox6->ReadOnly = true;
	this->textBox6->Size = System::Drawing::Size(304, 20);
	this->textBox6->TabIndex = 44;
	// 
	// label18
	// 
	this->label18->AutoSize = true;
	this->label18->Location = System::Drawing::Point(16, 192);
	this->label18->Name = S"label18";
	this->label18->Size = System::Drawing::Size(41, 13);
	this->label18->TabIndex = 43;
	this->label18->Text = S"Net dir:";
	// 
	// label19
	// 
	this->label19->AutoSize = true;
	this->label19->Location = System::Drawing::Point(16, 288);
	this->label19->Name = S"label19";
	this->label19->Size = System::Drawing::Size(59, 13);
	this->label19->TabIndex = 42;
	this->label19->Text = S"Comments:";
	// 
	// textBox7
	// 
	this->textBox7->Location = System::Drawing::Point(32, 160);
	this->textBox7->Name = S"textBox7";
	this->textBox7->ReadOnly = true;
	this->textBox7->Size = System::Drawing::Size(304, 20);
	this->textBox7->TabIndex = 41;
	// 
	// label20
	// 
	this->label20->AutoSize = true;
	this->label20->Location = System::Drawing::Point(16, 144);
	this->label20->Name = S"label20";
	this->label20->Size = System::Drawing::Size(56, 13);
	this->label20->TabIndex = 40;
	this->label20->Text = S"Net name:";
	// 
	// button2
	// 
	this->button2->Location = System::Drawing::Point(16, 88);
	this->button2->Name = S"button2";
	this->button2->Size = System::Drawing::Size(75, 23);
	this->button2->TabIndex = 6;
	this->button2->Text = S"Remove";
	// 
	// button3
	// 
	this->button3->Location = System::Drawing::Point(16, 56);
	this->button3->Name = S"button3";
	this->button3->Size = System::Drawing::Size(75, 23);
	this->button3->TabIndex = 5;
	this->button3->Text = S"Add";
	// 
	// button4
	// 
	this->button4->Location = System::Drawing::Point(16, 24);
	this->button4->Name = S"button4";
	this->button4->Size = System::Drawing::Size(75, 23);
	this->button4->TabIndex = 4;
	this->button4->Text = S"Edit";
	// 
	// tabPgResults
	// 
	this->tabPgResults->Controls->Add(this->tabControlStats);
	this->tabPgResults->Location = System::Drawing::Point(4, 22);
	this->tabPgResults->Name = S"tabPgResults";
	this->tabPgResults->Size = System::Drawing::Size(840, 591);
	this->tabPgResults->TabIndex = 1;
	this->tabPgResults->Text = S"Results and Stats";
	// 
	// tabControlStats
	// 
	this->tabControlStats->Controls->Add(this->tabpg_stats_general);
	this->tabControlStats->Controls->Add(this->tabPage13);
	this->tabControlStats->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControlStats->Location = System::Drawing::Point(0, 0);
	this->tabControlStats->Name = S"tabControlStats";
	this->tabControlStats->SelectedIndex = 0;
	this->tabControlStats->Size = System::Drawing::Size(840, 591);
	this->tabControlStats->TabIndex = 2;
	this->tabControlStats->VisibleChanged += new System::EventHandler(this, &CCONetmainForm::tabControlStats_VisibleChanged);
	this->tabControlStats->SelectedIndexChanged += new System::EventHandler(this, &CCONetmainForm::tabControlStats_SelectedIndexChanged);
	// 
	// tabpg_stats_general
	// 
	this->tabpg_stats_general->Controls->Add(this->groupBox15);
	this->tabpg_stats_general->Controls->Add(this->groupBox17);
	this->tabpg_stats_general->Location = System::Drawing::Point(4, 22);
	this->tabpg_stats_general->Name = S"tabpg_stats_general";
	this->tabpg_stats_general->Size = System::Drawing::Size(832, 565);
	this->tabpg_stats_general->TabIndex = 0;
	this->tabpg_stats_general->Text = S"General stats";
	// 
	// groupBox15
	// 
	this->groupBox15->Controls->Add(this->tabControl6);
	this->groupBox15->Controls->Add(this->groupBox16);
	this->groupBox15->Dock = System::Windows::Forms::DockStyle::Fill;
	this->groupBox15->Location = System::Drawing::Point(0, 0);
	this->groupBox15->Name = S"groupBox15";
	this->groupBox15->Size = System::Drawing::Size(288, 565);
	this->groupBox15->TabIndex = 9;
	this->groupBox15->TabStop = false;
	// 
	// tabControl6
	// 
	this->tabControl6->Controls->Add(this->tabPage2);
	this->tabControl6->Controls->Add(this->tabPage14);
	this->tabControl6->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControl6->Location = System::Drawing::Point(3, 95);
	this->tabControl6->Name = S"tabControl6";
	this->tabControl6->SelectedIndex = 0;
	this->tabControl6->Size = System::Drawing::Size(282, 467);
	this->tabControl6->TabIndex = 10;
	// 
	// tabPage2
	// 
	this->tabPage2->Controls->Add(this->list_choose_nets);
	this->tabPage2->Location = System::Drawing::Point(4, 22);
	this->tabPage2->Name = S"tabPage2";
	this->tabPage2->Size = System::Drawing::Size(274, 441);
	this->tabPage2->TabIndex = 0;
	this->tabPage2->Text = S"List";
	// 
	// list_choose_nets
	// 
	this->list_choose_nets->AllowColumnReorder = true;
	System::Windows::Forms::ColumnHeader* __mcTemp__8[] = new System::Windows::Forms::ColumnHeader*[5];
	__mcTemp__8[0] = this->columnHeader23;
	__mcTemp__8[1] = this->columnHeader24;
	__mcTemp__8[2] = this->columnHeader25;
	__mcTemp__8[3] = this->columnHeader26;
	__mcTemp__8[4] = this->columnHeader29;
	this->list_choose_nets->Columns->AddRange(__mcTemp__8);
	this->list_choose_nets->Dock = System::Windows::Forms::DockStyle::Fill;
	this->list_choose_nets->ForeColor = System::Drawing::SystemColors::WindowText;
	this->list_choose_nets->FullRowSelect = true;
	this->list_choose_nets->GridLines = true;
	this->list_choose_nets->Location = System::Drawing::Point(0, 0);
	this->list_choose_nets->Name = S"list_choose_nets";
	this->list_choose_nets->Size = System::Drawing::Size(274, 441);
	this->list_choose_nets->TabIndex = 4;
	this->list_choose_nets->UseCompatibleStateImageBehavior = false;
	this->list_choose_nets->View = System::Windows::Forms::View::Details;
	this->list_choose_nets->DoubleClick += new System::EventHandler(this, &CCONetmainForm::list_choose_nets_DoubleClick);
	this->list_choose_nets->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CCONetmainForm::list_choose_nets_ColumnClick);
	this->list_choose_nets->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CCONetmainForm::list_choose_nets_MouseDown);
	// 
	// columnHeader23
	// 
	this->columnHeader23->Text = S"Name";
	this->columnHeader23->Width = 105;
	// 
	// columnHeader24
	// 
	this->columnHeader24->Text = S"nodes";
	this->columnHeader24->Width = 45;
	// 
	// columnHeader25
	// 
	this->columnHeader25->Text = S"links";
	this->columnHeader25->Width = 45;
	// 
	// columnHeader26
	// 
	this->columnHeader26->Text = S"Added";
	this->columnHeader26->Width = 120;
	// 
	// columnHeader29
	// 
	this->columnHeader29->Text = S"Connection name";
	this->columnHeader29->Width = 120;
	// 
	// tabPage14
	// 
	this->tabPage14->Location = System::Drawing::Point(4, 22);
	this->tabPage14->Name = S"tabPage14";
	this->tabPage14->Size = System::Drawing::Size(274, 456);
	this->tabPage14->TabIndex = 1;
	this->tabPage14->Text = S"Tree";
	this->tabPage14->Visible = false;
	// 
	// groupBox16
	// 
	this->groupBox16->Controls->Add(this->but_choose_nets_select_c);
	this->groupBox16->Controls->Add(this->but_choose_nets_select_b);
	this->groupBox16->Controls->Add(this->but_choose_nets_select_a);
	this->groupBox16->Controls->Add(this->but_choose_nets_invert);
	this->groupBox16->Controls->Add(this->but_choose_nets_deselect_all);
	this->groupBox16->Controls->Add(this->but_choose_nets_select_all);
	this->groupBox16->Dock = System::Windows::Forms::DockStyle::Top;
	this->groupBox16->Location = System::Drawing::Point(3, 16);
	this->groupBox16->Name = S"groupBox16";
	this->groupBox16->Size = System::Drawing::Size(282, 79);
	this->groupBox16->TabIndex = 8;
	this->groupBox16->TabStop = false;
	// 
	// but_choose_nets_invert
	// 
	this->but_choose_nets_invert->Location = System::Drawing::Point(188, 12);
	this->but_choose_nets_invert->Name = S"but_choose_nets_invert";
	this->but_choose_nets_invert->Size = System::Drawing::Size(88, 23);
	this->but_choose_nets_invert->TabIndex = 2;
	this->but_choose_nets_invert->Text = S"Invert selection";
	this->but_choose_nets_invert->Click += new System::EventHandler(this, &CCONetmainForm::but_choose_nets_invert_Click);
	// 
	// but_choose_nets_deselect_all
	// 
	this->but_choose_nets_deselect_all->Location = System::Drawing::Point(89, 12);
	this->but_choose_nets_deselect_all->Name = S"but_choose_nets_deselect_all";
	this->but_choose_nets_deselect_all->Size = System::Drawing::Size(75, 23);
	this->but_choose_nets_deselect_all->TabIndex = 1;
	this->but_choose_nets_deselect_all->Text = S"Deselect all";
	this->but_choose_nets_deselect_all->Click += new System::EventHandler(this, &CCONetmainForm::but_choose_nets_deselect_all_Click);
	// 
	// but_choose_nets_select_all
	// 
	this->but_choose_nets_select_all->Location = System::Drawing::Point(8, 12);
	this->but_choose_nets_select_all->Name = S"but_choose_nets_select_all";
	this->but_choose_nets_select_all->Size = System::Drawing::Size(75, 23);
	this->but_choose_nets_select_all->TabIndex = 0;
	this->but_choose_nets_select_all->Text = S"Select all";
	this->but_choose_nets_select_all->Click += new System::EventHandler(this, &CCONetmainForm::but_choose_nets_select_all_Click);
	// 
	// groupBox17
	// 
	this->groupBox17->Controls->Add(this->tabControl7);
	this->groupBox17->Controls->Add(this->groupBox18);
	this->groupBox17->Dock = System::Windows::Forms::DockStyle::Right;
	this->groupBox17->Location = System::Drawing::Point(288, 0);
	this->groupBox17->Name = S"groupBox17";
	this->groupBox17->Size = System::Drawing::Size(544, 565);
	this->groupBox17->TabIndex = 8;
	this->groupBox17->TabStop = false;
	// 
	// tabControl7
	// 
	this->tabControl7->Controls->Add(this->tabPage15);
	this->tabControl7->Controls->Add(this->tabPage16);
	this->tabControl7->Dock = System::Windows::Forms::DockStyle::Fill;
	this->tabControl7->Location = System::Drawing::Point(3, 104);
	this->tabControl7->Name = S"tabControl7";
	this->tabControl7->SelectedIndex = 0;
	this->tabControl7->Size = System::Drawing::Size(538, 458);
	this->tabControl7->TabIndex = 12;
	// 
	// tabPage15
	// 
	this->tabPage15->Controls->Add(this->list_choose_set);
	this->tabPage15->Location = System::Drawing::Point(4, 22);
	this->tabPage15->Name = S"tabPage15";
	this->tabPage15->Size = System::Drawing::Size(530, 432);
	this->tabPage15->TabIndex = 0;
	this->tabPage15->Text = S"List";
	// 
	// list_choose_set
	// 
	this->list_choose_set->AllowColumnReorder = true;
	System::Windows::Forms::ColumnHeader* __mcTemp__9[] = new System::Windows::Forms::ColumnHeader*[2];
	__mcTemp__9[0] = this->columnHeader27;
	__mcTemp__9[1] = this->columnHeader28;
	this->list_choose_set->Columns->AddRange(__mcTemp__9);
	this->list_choose_set->Dock = System::Windows::Forms::DockStyle::Fill;
	this->list_choose_set->ForeColor = System::Drawing::SystemColors::WindowText;
	this->list_choose_set->FullRowSelect = true;
	this->list_choose_set->GridLines = true;
	this->list_choose_set->Location = System::Drawing::Point(0, 0);
	this->list_choose_set->Name = S"list_choose_set";
	this->list_choose_set->Size = System::Drawing::Size(530, 432);
	this->list_choose_set->TabIndex = 5;
	this->list_choose_set->UseCompatibleStateImageBehavior = false;
	this->list_choose_set->View = System::Windows::Forms::View::Details;
	this->list_choose_set->DoubleClick += new System::EventHandler(this, &CCONetmainForm::list_choose_set_DoubleClick);
	this->list_choose_set->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CCONetmainForm::list_choose_set_ColumnClick);
	this->list_choose_set->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CCONetmainForm::list_choose_set_MouseDown);
	// 
	// columnHeader27
	// 
	this->columnHeader27->Text = S"Name";
	this->columnHeader27->Width = 200;
	// 
	// columnHeader28
	// 
	this->columnHeader28->Text = S"Comments";
	this->columnHeader28->Width = 200;
	// 
	// tabPage16
	// 
	this->tabPage16->Location = System::Drawing::Point(4, 22);
	this->tabPage16->Name = S"tabPage16";
	this->tabPage16->Size = System::Drawing::Size(530, 432);
	this->tabPage16->TabIndex = 1;
	this->tabPage16->Text = S"Tree";
	this->tabPage16->Visible = false;
	// 
	// groupBox18
	// 
	this->groupBox18->Controls->Add(this->combo_ext);
	this->groupBox18->Controls->Add(this->but_compare_set);
	this->groupBox18->Controls->Add(this->chk_report_max);
	this->groupBox18->Controls->Add(this->combo_normalize);
	this->groupBox18->Controls->Add(this->but_report_general);
	this->groupBox18->Controls->Add(this->but_choose_set_invert);
	this->groupBox18->Controls->Add(this->but_choose_set_deselect_all);
	this->groupBox18->Controls->Add(this->but_choose_set_select_all);
	this->groupBox18->Dock = System::Windows::Forms::DockStyle::Top;
	this->groupBox18->Location = System::Drawing::Point(3, 16);
	this->groupBox18->Name = S"groupBox18";
	this->groupBox18->Size = System::Drawing::Size(538, 88);
	this->groupBox18->TabIndex = 11;
	this->groupBox18->TabStop = false;
	// 
	// combo_ext
	// 
	this->combo_ext->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
	this->combo_ext->Location = System::Drawing::Point(279, 58);
	this->combo_ext->Name = S"combo_ext";
	this->combo_ext->Size = System::Drawing::Size(121, 21);
	this->combo_ext->TabIndex = 10;
	// 
	// but_compare_set
	// 
	this->but_compare_set->Location = System::Drawing::Point(128, 57);
	this->but_compare_set->Name = S"but_compare_set";
	this->but_compare_set->Size = System::Drawing::Size(128, 23);
	this->but_compare_set->TabIndex = 9;
	this->but_compare_set->Text = S"Create comparison set";
	this->but_compare_set->Click += new System::EventHandler(this, &CCONetmainForm::but_compare_set_Click);
	// 
	// chk_report_max
	// 
	this->chk_report_max->Location = System::Drawing::Point(425, 56);
	this->chk_report_max->Name = S"chk_report_max";
	this->chk_report_max->Size = System::Drawing::Size(104, 24);
	this->chk_report_max->TabIndex = 8;
	this->chk_report_max->Text = S"1 is best";
	// 
	// combo_normalize
	// 
	this->combo_normalize->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
	this->combo_normalize->Location = System::Drawing::Point(408, 24);
	this->combo_normalize->Name = S"combo_normalize";
	this->combo_normalize->Size = System::Drawing::Size(121, 21);
	this->combo_normalize->TabIndex = 7;
	// 
	// but_report_general
	// 
	this->but_report_general->Location = System::Drawing::Point(280, 24);
	this->but_report_general->Name = S"but_report_general";
	this->but_report_general->Size = System::Drawing::Size(120, 23);
	this->but_report_general->TabIndex = 6;
	this->but_report_general->Text = S"Generate report";
	this->but_report_general->Click += new System::EventHandler(this, &CCONetmainForm::but_report_general_Click);
	// 
	// but_choose_set_invert
	// 
	this->but_choose_set_invert->Location = System::Drawing::Point(168, 24);
	this->but_choose_set_invert->Name = S"but_choose_set_invert";
	this->but_choose_set_invert->Size = System::Drawing::Size(88, 23);
	this->but_choose_set_invert->TabIndex = 2;
	this->but_choose_set_invert->Text = S"Invert selection";
	this->but_choose_set_invert->Click += new System::EventHandler(this, &CCONetmainForm::but_choose_set_invert_Click);
	// 
	// but_choose_set_deselect_all
	// 
	this->but_choose_set_deselect_all->Location = System::Drawing::Point(88, 24);
	this->but_choose_set_deselect_all->Name = S"but_choose_set_deselect_all";
	this->but_choose_set_deselect_all->Size = System::Drawing::Size(75, 23);
	this->but_choose_set_deselect_all->TabIndex = 1;
	this->but_choose_set_deselect_all->Text = S"Deselect all";
	this->but_choose_set_deselect_all->Click += new System::EventHandler(this, &CCONetmainForm::but_choose_set_deselect_all_Click);
	// 
	// but_choose_set_select_all
	// 
	this->but_choose_set_select_all->Location = System::Drawing::Point(8, 24);
	this->but_choose_set_select_all->Name = S"but_choose_set_select_all";
	this->but_choose_set_select_all->Size = System::Drawing::Size(75, 23);
	this->but_choose_set_select_all->TabIndex = 0;
	this->but_choose_set_select_all->Text = S"Select all";
	this->but_choose_set_select_all->Click += new System::EventHandler(this, &CCONetmainForm::but_choose_set_select_all_Click);
	// 
	// tabPage13
	// 
	this->tabPage13->Controls->Add(this->but_results_test);
	this->tabPage13->Location = System::Drawing::Point(4, 22);
	this->tabPage13->Name = S"tabPage13";
	this->tabPage13->Size = System::Drawing::Size(832, 565);
	this->tabPage13->TabIndex = 1;
	this->tabPage13->Text = S"tabPage13";
	// 
	// but_results_test
	// 
	this->but_results_test->Location = System::Drawing::Point(304, 271);
	this->but_results_test->Name = S"but_results_test";
	this->but_results_test->Size = System::Drawing::Size(176, 23);
	this->but_results_test->TabIndex = 4;
	this->but_results_test->Text = S"Generate results set";
	this->but_results_test->Click += new System::EventHandler(this, &CCONetmainForm::but_results_test_Click);
	// 
	// tabPage3
	// 
	this->tabPage3->Location = System::Drawing::Point(4, 22);
	this->tabPage3->Name = S"tabPage3";
	this->tabPage3->Size = System::Drawing::Size(840, 591);
	this->tabPage3->TabIndex = 2;
	this->tabPage3->Text = S"tabPage3";
	// 
	// menu_main
	// 
	System::Windows::Forms::MenuItem* __mcTemp__10[] = new System::Windows::Forms::MenuItem*[3];
	__mcTemp__10[0] = this->menu_main_exit;
	__mcTemp__10[1] = this->menu_main_connect_opt;
	__mcTemp__10[2] = this->menu_main_help;
	this->menu_main->MenuItems->AddRange(__mcTemp__10);
	// 
	// menu_main_exit
	// 
	this->menu_main_exit->Index = 0;
	this->menu_main_exit->Text = S"&Exit";
	this->menu_main_exit->Click += new System::EventHandler(this, &CCONetmainForm::menu_main_exit_Click);
	// 
	// menu_main_connect_opt
	// 
	this->menu_main_connect_opt->Index = 1;
	this->menu_main_connect_opt->Text = S"&Connect options";
	this->menu_main_connect_opt->Click += new System::EventHandler(this, &CCONetmainForm::menu_main_connect_opt_Click);
	// 
	// menu_main_help
	// 
	this->menu_main_help->Index = 2;
	this->menu_main_help->Text = S"&Help";
	// 
	// statusMain
	// 
	this->statusMain->Location = System::Drawing::Point(0, 595);
	this->statusMain->Name = S"statusMain";
	this->statusMain->Size = System::Drawing::Size(848, 22);
	this->statusMain->TabIndex = 1;
	// 
	// but_choose_nets_select_a
	// 
	this->but_choose_nets_select_a->Location = System::Drawing::Point(8, 48);
	this->but_choose_nets_select_a->Name = S"but_choose_nets_select_a";
	this->but_choose_nets_select_a->Size = System::Drawing::Size(75, 23);
	this->but_choose_nets_select_a->TabIndex = 3;
	this->but_choose_nets_select_a->Text = S"Select A";
	this->but_choose_nets_select_a->Click += new System::EventHandler(this, &CCONetmainForm::but_choose_nets_select_a_Click);
	// 
	// but_choose_nets_select_b
	// 
	this->but_choose_nets_select_b->Location = System::Drawing::Point(89, 48);
	this->but_choose_nets_select_b->Name = S"but_choose_nets_select_b";
	this->but_choose_nets_select_b->Size = System::Drawing::Size(75, 23);
	this->but_choose_nets_select_b->TabIndex = 4;
	this->but_choose_nets_select_b->Text = S"Select B";
	this->but_choose_nets_select_b->Click += new System::EventHandler(this, &CCONetmainForm::but_choose_nets_select_b_Click);
	// 
	// but_choose_nets_select_c
	// 
	this->but_choose_nets_select_c->Location = System::Drawing::Point(170, 48);
	this->but_choose_nets_select_c->Name = S"but_choose_nets_select_c";
	this->but_choose_nets_select_c->Size = System::Drawing::Size(75, 23);
	this->but_choose_nets_select_c->TabIndex = 5;
	this->but_choose_nets_select_c->Text = S"Select C";
	this->but_choose_nets_select_c->Click += new System::EventHandler(this, &CCONetmainForm::but_choose_nets_select_c_Click);
	// 
	// CCONetmainForm
	// 
	this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
	this->ClientSize = System::Drawing::Size(848, 617);
	this->Controls->Add(this->statusMain);
	this->Controls->Add(this->tabControl_main);
	this->Menu = this->menu_main;
	this->Name = S"CCONetmainForm";
	this->Text = S"CO Networks Administrator";
	this->WindowState = System::Windows::Forms::FormWindowState::Maximized;
	this->Activated += new System::EventHandler(this, &CCONetmainForm::cCONetmainForm_Activated);
	this->Closing += new System::ComponentModel::CancelEventHandler(this, &CCONetmainForm::cCONetmainForm_Closing);
	this->tabControl_main->ResumeLayout(false);
	this->tabpgAdmin->ResumeLayout(false);
	this->tabControl_admin->ResumeLayout(false);
	this->tabpg_db_roots->ResumeLayout(false);
	this->groupFDbListAndFilters->ResumeLayout(false);
	this->groupFDbList->ResumeLayout(false);
	this->groupChosenFDb->ResumeLayout(false);
	this->groupChosenFDb->PerformLayout();
	this->groupFDbControls->ResumeLayout(false);
	this->groupFDbControls->PerformLayout();
	this->tabpg_netowrks->ResumeLayout(false);
	this->groupBox1->ResumeLayout(false);
	this->tabControl_net_list_tree->ResumeLayout(false);
	this->tabPage_net_list->ResumeLayout(false);
	this->groupBox2->ResumeLayout(false);
	this->groupBox2->PerformLayout();
	this->groupBox6->ResumeLayout(false);
	this->groupBox6->PerformLayout();
	this->tabpg_algorithms->ResumeLayout(false);
	this->groupBox3->ResumeLayout(false);
	this->tabControl1->ResumeLayout(false);
	this->tabPage1->ResumeLayout(false);
	this->groupBox4->ResumeLayout(false);
	this->groupBox4->PerformLayout();
	this->tabpg_computers->ResumeLayout(false);
	this->groupBox5->ResumeLayout(false);
	this->tabControl3->ResumeLayout(false);
	this->tabPage7->ResumeLayout(false);
	this->groupBox8->ResumeLayout(false);
	this->groupBox8->PerformLayout();
	this->tabpg_fitt_funcs->ResumeLayout(false);
	this->groupBox7->ResumeLayout(false);
	this->tabControl2->ResumeLayout(false);
	this->tabPage5->ResumeLayout(false);
	this->groupBox10->ResumeLayout(false);
	this->groupBox10->PerformLayout();
	this->tabpg_results_sets->ResumeLayout(false);
	this->groupBox13->ResumeLayout(false);
	this->tabControl5->ResumeLayout(false);
	this->tabPage11->ResumeLayout(false);
	this->groupBox14->ResumeLayout(false);
	this->groupBox14->PerformLayout();
	this->tabpg_results->ResumeLayout(false);
	this->groupBox9->ResumeLayout(false);
	this->tabControl4->ResumeLayout(false);
	this->tabPage9->ResumeLayout(false);
	this->groupBox11->ResumeLayout(false);
	this->groupBox11->PerformLayout();
	this->groupBox12->ResumeLayout(false);
	this->groupBox12->PerformLayout();
	this->tabPgResults->ResumeLayout(false);
	this->tabControlStats->ResumeLayout(false);
	this->tabpg_stats_general->ResumeLayout(false);
	this->groupBox15->ResumeLayout(false);
	this->tabControl6->ResumeLayout(false);
	this->tabPage2->ResumeLayout(false);
	this->groupBox16->ResumeLayout(false);
	this->groupBox17->ResumeLayout(false);
	this->tabControl7->ResumeLayout(false);
	this->tabPage15->ResumeLayout(false);
	this->groupBox18->ResumeLayout(false);
	this->tabPage13->ResumeLayout(false);
	this->ResumeLayout(false);

}//void CCONetmainForm ::InitializeComponent(void)


System::Void CCONetmainForm ::menu_main_exit_Click(System::Object *  sender, System::EventArgs *  e)
{
	Close();
}//System::Void CCONetmainForm ::menu_main_exit_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm ::menu_main_connect_opt_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  (pcConnOpt->ShowDialog()  ==  DialogResult::OK)
	{
		if  (pc_system->bIsConnected())
		{
			CString  s_buf;
			CString  s_host_name,  s_db,  s_user, s_passwd;

			pc_system->vGetConnParams(&s_host_name,  &s_db,  &s_user, &s_passwd);

			s_buf.Format
				(
				"Status: Connected to database '%s' on '%s' server as '%s' user",
				s_db, s_host_name, s_user
				);

			statusMain->Text  =  s_buf;
		}//if  (pc_system->bIsConnected())
		else
		{
			statusMain->Text  =  "Status: NOT connected";		
		}//else  if  (pc_system->bIsConnected())
	
	}//if  (pcConnOpt->ShowDialog()  ==  DialogResult::OK)
}//System::Void CCONetmainForm::menu_main_connect_opt_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::cCONetmainForm_Closing(System::Object *  sender, System::ComponentModel::CancelEventArgs *  e)
{
	if  (pc_system->bSaveConnConf()  ==  false)
		::MessageBox(NULL, "Unable to save connection params","Info",  MB_OK);

}//System::Void CCONetmainForm ::cCONetmainForm_Closing(System::Object *  sender, System::ComponentModel::CancelEventArgs *  e)


System::Void CCONetmainForm::cCONetmainForm_Activated(System::Object *  sender, System::EventArgs *  e)
{

	if  (b_activated  ==  false)
	{
		CError  c_err;

		list_fdb_roots->ListViewItemSorter = new list_item_comparer();

		statusMain->Text  =  "Loading connection parameters...";
		if  (pc_system->bLoadConnConf()  ==  false)
		{
			::MessageBox(NULL, "Unable to load previous connection parameters","Info",  MB_OK);
			statusMain->Text  =  "Status: NOT connected";
		}//if  (pc_system->bLoadConnConf()  ==  false)
		else
		{
			statusMain->Text  =  "Connecting to database...";
			c_err  =  pc_system->eConnect();
			if  (c_err)
			{
				c_err.vShowWindow();
				statusMain->Text  =  "Status: NOT connected";
			}//if  (pc_system->bConnect()  ==  false)
			else
			{
				CString  s_buf;
				CString  s_host_name,  s_db,  s_user, s_passwd;

				pc_system->vGetConnParams(&s_host_name,  &s_db,  &s_user, &s_passwd);

				s_buf.Format
					(
					"Status: Connected to database '%s' on '%s' server as '%s' user",
					s_db, s_host_name, s_user
					);

				statusMain->Text  =  s_buf;
			}//else  if  (pc_system->bConnect()  ==  false)
			
		}//else  if  (pc_system->bLoadConnConf()  ==  false)


		b_activated  =  true;
	}//if  (b_activated  ==  false)

}//System::Void CCONetmainForm ::cCONetmainForm_Activated(System::Object *  sender, System::EventArgs *  e)



System::Void CCONetmainForm::check_config_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
{
	if  (check_config->Checked  ==  true)
	{
		list_nets->Columns->Add(S"Config", 80, HorizontalAlignment::Left);
	}//if  (check_config->Checked  ==  true)
	else
	{
		list_nets->Columns->RemoveAt(list_nets->Columns->Count-1);
	}//else  if  (check_config->Checked  ==  true)

	v_refresh_nets();

}//System::Void CCONetmainForm::check_config_CheckedChanged(System::Object *  sender, System::EventArgs *  e)




void  CCONetmainForm::v_refresh_nets_only()
{
	vector  <CCONet *>  *pv_nets;
	pv_nets  =  pc_chosen_fdb->pvGetNets();

	//now getting nets data
	int  i_id;
	int  i_net_root_id;
	int  i_num_nodes,  i_num_edges;
	CString  s_net_name,  s_net_file,  s_net_dir;
	CString  s_net_comments;
	__int64  dt_added;

	System::DateTime  dt_buf;
	

	list_nets->Items->Clear();
	for  (int  ii = 0; ii < (int)  pv_nets->size(); ii++)
	{
		pv_nets->at(ii)->vGetData
			(
			&i_id,
			&i_net_root_id,
			&i_num_nodes,  &i_num_edges,
			&s_net_name,  &s_net_file,  &s_net_dir,
			&s_net_comments,
			&dt_added
			);

		ListViewItem* item_buf  =  new ListViewItem((String *) s_net_name);
		CString  s_buf;
		s_buf.Format("%d", i_num_nodes);
		item_buf->SubItems->Add((String *) s_buf);
		s_buf.Format("%d", i_num_edges);
		item_buf->SubItems->Add((String *) s_buf);
		dt_buf  =  System::DateTime::FromFileTime(dt_added);
		item_buf->SubItems->Add(dt_buf.ToString());

		s_buf.Format("%d", ii);
		item_buf->SubItems->Add(s_buf);

		list_nets->Items->Add(item_buf);
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)
}//void  CCONetmainForm::v_refresh_nets_only()



void  CCONetmainForm::v_refresh_nets_with_conns()
{
	vector  <CCONet *>  *pv_nets;
	pv_nets  =  pc_chosen_fdb->pvGetNets();

	//for getting nets data
	int  i_net_id;
	int  i_net_root_id;
	int  i_num_nodes,  i_num_edges;
	CString  s_net_name,  s_net_file,  s_net_dir;
	CString  s_net_comments;
	__int64  dt_added;

	System::DateTime  dt_buf;

	//for getting conns data
	int  i_conn_id;
	int  i_conn_net_id;
	CString  s_conn_name;
	CString  s_conn_file,  s_conn_dir;
	

	list_nets->Items->Clear();
	for  (int  ii = 0; ii < (int)  pv_nets->size(); ii++)
	{
		pv_nets->at(ii)->vGetData
			(
			&i_net_id,
			&i_net_root_id,
			&i_num_nodes,  &i_num_edges,
			&s_net_name,  &s_net_file,  &s_net_dir,
			&s_net_comments,
			&dt_added
			);

		for  (int  ij = 0; ij < (int)  pv_nets->at(ii)->pvGetNetConns()->size(); ij++)
		{
			pv_nets->at(ii)->pvGetNetConns()->at(ij)->vGetData
				(
				&i_conn_id,
				&i_conn_net_id,
				&s_conn_name,
				&s_conn_file,  &s_conn_dir				
				);


			ListViewItem* item_buf  =  new ListViewItem((String *) s_net_name);
			CString  s_buf;
			s_buf.Format("%d", i_num_nodes);
			item_buf->SubItems->Add((String *) s_buf);
			s_buf.Format("%d", i_num_edges);
			item_buf->SubItems->Add((String *) s_buf);
			dt_buf  =  System::DateTime::FromFileTime(dt_added);
			item_buf->SubItems->Add(dt_buf.ToString());
			item_buf->SubItems->Add((String *) s_conn_name);

			s_buf.Format("%d", ij);
			item_buf->SubItems->Add(s_buf);

			s_buf.Format("%d", ii);
			item_buf->SubItems->Add(s_buf);

			list_nets->Items->Add(item_buf);

		}//for  (int  ij = 0; ij < (int)  pv_nets->at(ii)->pvGetNetConns()->size(); ij++)

		
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)
}//void  CCONetmainForm::v_refresh_nets_with_conns()



void  CCONetmainForm::v_refresh_choose()
{
	combo_normalize->Items->Add(S"No normalization");
	combo_normalize->Items->Add(S"Standard");
	combo_normalize->Items->Add(S"Winner takes all");
	combo_normalize->Items->Add(S"Winner takes all waged");

	combo_ext->Items->Add(S"ini");
	combo_ext->Items->Add(S"lfl");
	combo_ext->SelectedIndex = 0;


	v_refresh_choose_sets();
	v_refresh_choose_nets();
}//void  CCONetmainForm::v_refresh_choose()



void  CCONetmainForm::v_refresh_choose_sets()
{
	CError  c_err;

	v_refresh_rsets();

	i_selected_choose_set_index  =  -1;
	list_choose_set->Items->Clear();


	
	if  ((int)  pv_rsets->size()  >  0)
	{

		CString  s_buf;

		//set data
		int  i_id;
		CString  s_rset_name;
		CString  s_rset_comments;

		for  (int  ii = 0; ii < (int)  pv_rsets->size(); ii++)
		{
			pv_rsets->at(ii)->vGetData
				(
				&i_id,
				&s_rset_name,
				&s_rset_comments
				);

			ListViewItem* item_buf  =  new ListViewItem((String *) s_rset_name);
			item_buf->SubItems->Add((String *) s_rset_comments);
			s_buf.Format("%d", ii);
			item_buf->SubItems->Add(s_buf);

			//chosen/not chosen information
			s_buf.Format("0");
			item_buf->SubItems->Add(s_buf);

			list_choose_set->Items->Add(item_buf);
		}//for  (int  ii = 0; ii < i_fdb_size; ii++)

		
	}//if  (pc_chosen_fdb  !=  NULL)

}//void  CCONetmainForm::v_refresh_choose_sets()



void  CCONetmainForm::v_refresh_choose_nets()
{
	CError  c_err;

	i_selected_choose_net_index  =  -1;
	list_choose_nets->Items->Clear();

	if  (pc_chosen_fdb  !=  NULL)
	{
		//now refreshing nets
		c_err  =  pc_chosen_fdb->eRefreshNets();
		if  (c_err)
		{
			c_err.vShowWindow();
			return;		
		}//if  (c_err)


		CString  s_buf;
		System::DateTime  dt_buf;

		//nets data
		int  i_id;
		int  i_net_root_id;
		int  i_num_nodes,  i_num_edges;
		CString  s_net_name,  s_net_file,  s_net_dir;
		CString  s_net_comments;
		__int64  dt_added;

		//for getting conns data
		int  i_conn_id;
		int  i_conn_net_id;
		CString  s_conn_name;
		CString  s_conn_file,  s_conn_dir;

		CError  c_ref_err;
		for  (int  ii = 0; ii < (int)  pc_chosen_fdb->pvGetNets()->size(); ii++)
		{
			c_ref_err  =  pc_chosen_fdb->pvGetNets()->at(ii)->eRefreshNetConns();
			if  (c_ref_err)
			{
				c_ref_err.vShowWindow();
				return;			
			}//if  (c_ref_err)		
		}//for  (int  ii = 0; ii < (int)  pc_chosen_fdb->pvGetNets()->size(); ii++)


		for  (int  ii = 0; ii < (int)  pc_chosen_fdb->pvGetNets()->size(); ii++)
		{
			pc_chosen_fdb->pvGetNets()->at(ii)->vGetData
				(
				&i_id,
				&i_net_root_id,
				&i_num_nodes,  &i_num_edges,
				&s_net_name,  &s_net_file,  &s_net_dir,
				&s_net_comments,
				&dt_added
				);

			for  (int  ij = 0; ij < (int)  pc_chosen_fdb->pvGetNets()->at(ii)->pvGetNetConns()->size(); ij++)
			{
				pc_chosen_fdb->pvGetNets()->at(ii)->pvGetNetConns()->at(ij)->vGetData
					(
					&i_conn_id,
					&i_conn_net_id,
					&s_conn_name,
					&s_conn_file,  &s_conn_dir				
					);


				ListViewItem* item_buf  =  new ListViewItem((String *) s_net_name);
				CString  s_buf;
				s_buf.Format("%d", i_num_nodes);
				item_buf->SubItems->Add((String *) s_buf);
				s_buf.Format("%d", i_num_edges);
				item_buf->SubItems->Add((String *) s_buf);
				dt_buf  =  System::DateTime::FromFileTime(dt_added);
				item_buf->SubItems->Add(dt_buf.ToString());
				item_buf->SubItems->Add((String *) s_conn_name);

				s_buf.Format("%d", ij);
				item_buf->SubItems->Add(s_buf);

				s_buf.Format("%d", ii);
				item_buf->SubItems->Add(s_buf);

				//chosen/not chosen information
				s_buf.Format("0");
				item_buf->SubItems->Add(s_buf);

				list_choose_nets->Items->Add(item_buf);

			}//for  (int  ij = 0; ij < (int)  pv_nets->at(ii)->pvGetNetConns()->size(); ij++)

		}//for  (int  ii = 0; ii < i_fdb_size; ii++)

		
	}//if  (pc_chosen_fdb  !=  NULL)

}//void  CCONetmainForm::v_refresh_choose_nets()




void  CCONetmainForm::v_refresh_nets()
{
	CError  c_err;

	list_nets->Items->Clear();

	textNetName->Text  =  S"";
	textNetDir->Text  =  S"";
	textNetComments->Text  =  S"";
	textNetNodesNum->Text  =  S"";
	textNetLinksNum->Text  =  S"";
	textAddedBy->Text  =  S"";
	textChosenFDbNameForNets->Text  =  S"";

	i_selected_net_index  =  -1;
	i_selected_net_conn_index  =  -1;

	if  (pc_chosen_fdb  !=  NULL)
	{
		int  i_root_id;
		CString  s_root_dir, s_fdb_name;

		pc_chosen_fdb->vGetData
			(
			&i_root_id,
			&s_root_dir, &s_fdb_name
			);

		textChosenFDbNameForNets->Text  =  s_fdb_name;

		//now refreshing nets
		c_err  =  pc_chosen_fdb->eRefreshNets();
		if  (c_err)
		{
			c_err.vShowWindow();
			return;		
		}//if  (c_err)

		if  (check_config->Checked  ==  false)
		{
			v_refresh_nets_only();
		}//if  (check_config->Checked  ==  false)
		else
		{
			for  (int  ii = 0; ii < (int)  pc_chosen_fdb->pvGetNets()->size(); ii++)
			{
				c_err  = pc_chosen_fdb->pvGetNets()->at(ii)->eRefreshNetConns();
				if  (c_err)
				{
					c_err.vShowWindow();
					return;		
				}//if  (c_err)
			
			}//for  (int  ii = 0; ii < (int)  pv_nets->size(); ii++)

			v_refresh_nets_with_conns();
		}//else  if  (check_config->Checked  ==  false)

	}//if  (pc_chosen_fdb  !=  NULL)

}//void  CCONetmainForm::v_refresh_nets()




void  CCONetmainForm::v_refresh_roots()
{

	int  i_root_id;
	CString  s_root_dir, s_fdb_name;

	for  (int  ii = 0; ii < (int) pv_fdb_roots->size(); ii++)
		delete  pv_fdb_roots->at(ii);
	pv_fdb_roots->clear();
	

	pc_system->eSelectFDbRoot(pv_fdb_roots,  "Select * from fdb_root");

	list_fdb_roots->Items->Clear();
	for  (int  ii = 0; ii < (int)  pv_fdb_roots->size(); ii++)
	{
		pv_fdb_roots->at(ii)->vGetData(&i_root_id, &s_root_dir, &s_fdb_name);

		ListViewItem* item_buf  =  new ListViewItem((String *) s_fdb_name);
		item_buf->SubItems->Add((String *) s_root_dir);
		list_fdb_roots->Items->Add(item_buf);
		CString  s_buf;
		s_buf.Format("%d", ii);
		item_buf->SubItems->Add(s_buf);
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)

	textFDbDir->Text =  "";
	textFDbName->Text =  "";

	if  (pc_chosen_fdb  !=  NULL)
	{
		int  i_root_id;
		CString  s_root_dir, s_fdb_name;

		pc_chosen_fdb->vGetData
			(
			&i_root_id,
			&s_root_dir, &s_fdb_name
			);

		textChosenFDbName->Text  =  s_fdb_name;
	}//if  (pc_chosen_fdb  !=  NULL)
	else
	{
		textChosenFDbName->Text  =  S"";	
	}//else  if  (pc_chosen_fdb  !=  NULL)


	i_selected_fdb_index  =  -1;

	list_fdb_roots_MouseUp(NULL, NULL);
	list_fdb_roots->Refresh();
	
}//void  CCONetmainForm::v_refresh_roots()


void  CCONetmainForm::v_refresh_results()
{

}//void  CCONetmainForm::v_refresh_results()


void  CCONetmainForm::v_refresh_algs()
{
	CError  c_err;

	int  i_id;
	CString  s_alg_name;
	CString  s_alg_comments;

	for  (int  ii = 0; ii < (int) pv_algorithms->size(); ii++)
		delete  pv_algorithms->at(ii);
	pv_algorithms->clear();
	

	c_err  =  pc_system->eSelectAlgorithms(pv_algorithms,  "Select * from algorithms");
	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)

	list_algorithms->Items->Clear();
	for  (int  ii = 0; ii < (int)  pv_algorithms->size(); ii++)
	{
		pv_algorithms->at(ii)->vGetData(&i_id,  &s_alg_name,  &s_alg_comments);

		ListViewItem* item_buf  =  new ListViewItem((String *) s_alg_name);
		
		CString  s_buf;

		c_err  =  pv_algorithms->at(ii)->eRefreshParams();
		if  (c_err)  c_err.vShowWindow();

		s_buf.Format("%d", (int) pv_algorithms->at(ii)->pvGetParams()->size());
		item_buf->SubItems->Add(s_buf);

		item_buf->SubItems->Add((String *) s_alg_comments);

		s_buf.Format("%d", ii);
		item_buf->SubItems->Add(s_buf);
		list_algorithms->Items->Add(item_buf);
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)

	textAlgName->Text =  "";
	textAlgComments->Text =  "";

	i_selected_alg_index  =  -1;

	list_algorithms->Refresh();
}//void  CCONetmainForm::v_refresh_algs()



void  CCONetmainForm::v_refresh_computers()
{
	int  i_id;
	CString  s_comp_name;
	CString  s_comp_comments;

	for  (int  ii = 0; ii < (int) pv_computers->size(); ii++)
		delete  pv_computers->at(ii);
	pv_computers->clear();
	

	pc_system->eSelectComputers(pv_computers,  "Select * from computers");

	list_computers->Items->Clear();
	for  (int  ii = 0; ii < (int)  pv_computers->size(); ii++)
	{
		pv_computers->at(ii)->vGetData(&i_id,  &s_comp_name,  &s_comp_comments);

		ListViewItem* item_buf  =  new ListViewItem((String *) s_comp_name);
		
		item_buf->SubItems->Add((String *) s_comp_comments);

		CString  s_buf;
		s_buf.Format("%d", ii);
		item_buf->SubItems->Add(s_buf);
		list_computers->Items->Add(item_buf);
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)

	textCompName->Text =  "";
	textCompComm->Text =  "";

	i_selected_comp_index  =  -1;

	list_computers->Refresh();
}//void  CCONetmainForm::v_refresh_computers()




void  CCONetmainForm::v_refresh_rsets()
{
	int  i_id;
	CString  s_rset_name;
	CString  s_rset_comments;

	for  (int  ii = 0; ii < (int) pv_rsets->size(); ii++)
		delete  pv_rsets->at(ii);
	pv_rsets->clear();
	

	pc_system->eSelectResultsSets(pv_rsets,  "Select * from results_sets");

	list_results_sets->Items->Clear();
	for  (int  ii = 0; ii < (int)  pv_rsets->size(); ii++)
	{
		pv_rsets->at(ii)->vGetData(&i_id,  &s_rset_name,  &s_rset_comments);

		ListViewItem* item_buf  =  new ListViewItem((String *) s_rset_name);
		
		item_buf->SubItems->Add((String *) s_rset_comments);

		CString  s_buf;
		s_buf.Format("%d", ii);
		item_buf->SubItems->Add(s_buf);
		list_results_sets->Items->Add(item_buf);
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)

	textRSetName->Text =  "";
	textRSetComm->Text =  "";

	i_selected_rset_index  =  -1;

	list_computers->Refresh();
}//void  CCONetmainForm::v_refresh_rsets()




void  CCONetmainForm::v_refresh_fit_funcs()
{
	int  i_id;
	CString  s_ff_name;
	CString  s_ff_comments;

	for  (int  ii = 0; ii < (int) pv_fit_funcs->size(); ii++)
		delete  pv_fit_funcs->at(ii);
	pv_fit_funcs->clear();
	

	pc_system->eSelectFitFuncs(pv_fit_funcs,  "Select * from fit_func");

	list_ff->Items->Clear();
	for  (int  ii = 0; ii < (int)  pv_fit_funcs->size(); ii++)
	{
		pv_fit_funcs->at(ii)->vGetData(&i_id,  &s_ff_name,  &s_ff_comments);

		ListViewItem* item_buf  =  new ListViewItem((String *) s_ff_name);
		
		item_buf->SubItems->Add((String *) s_ff_comments);

		CString  s_buf;
		s_buf.Format("%d", ii);
		item_buf->SubItems->Add(s_buf);
		list_ff->Items->Add(item_buf);
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)

	textFFuncName->Text =  "";
	textFFuncComm->Text =  "";

	i_selected_ff_index  =  -1;

	list_ff->Refresh();

}//void  CCONetmainForm::v_refresh_fitt_funcs()


System::Void CCONetmainForm::list_ff_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	int  i_id;
	CString  s_ff_name;
	CString  s_ff_comments;

	ListViewItem *pc_selected = list_ff->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_ff_index
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);


		if  ( (i_selected_ff_index  <  (int) pv_fit_funcs->size())&&(i_selected_ff_index  >=  0) )
		{
			pv_fit_funcs->at(i_selected_ff_index)->vGetData
				(
				&i_id,
				&s_ff_name,
				&s_ff_comments
				);

			textFFuncName->Text  =  (String *)  s_ff_name;
			textFFuncComm->Text  =  (String *)  s_ff_comments;

		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_ff_index  =  -1;
			
			CError  c_err;
			c_err.vPutError("Selected index exceeds list length - click again after refreshing");
			c_err.vShowWindow();

			v_refresh_fit_funcs();
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)
}//System::Void CCONetmainForm::list_ff_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)


System::Void CCONetmainForm::list_computers_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	int  i_id;
	CString  s_comp_name;
	CString  s_comp_comments;

	
	ListViewItem *pc_selected = list_computers->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_comp_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);


		if  ( (i_selected_comp_index  <  (int) pv_computers->size())&&(i_selected_comp_index  >=  0) )
		{
			pv_computers->at(i_selected_comp_index)->vGetData
				(
				&i_id,
				&s_comp_name,
				&s_comp_comments
				);

			textCompName->Text  =  (String *)  s_comp_name;
			textCompComm->Text  =  (String *)  s_comp_comments;

		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_comp_index  =  -1;
			
			CError  c_err;
			c_err.vPutError("Selected index exceeds list length - click again after refreshing");
			c_err.vShowWindow();

			v_refresh_computers();
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)

}//System::Void CCONetmainForm::list_computers_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)


System::Void CCONetmainForm::list_algorithms_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	int  i_id;
	CString  s_alg_name;
	CString  s_alg_comments;

	
	ListViewItem *pc_selected = list_algorithms->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_alg_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);


		if  ( (i_selected_alg_index  <  (int) pv_algorithms->size())&&(i_selected_alg_index  >=  0) )
		{
			pv_algorithms->at(i_selected_alg_index)->vGetData
				(
				&i_id,
				&s_alg_name,
				&s_alg_comments
				);

			textAlgName->Text  =  (String *)  s_alg_name;
			textAlgComments->Text  =  (String *)  s_alg_comments;

		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_alg_index  =  -1;
			
			CError  c_err;
			c_err.vPutError("Selected index exceeds list length - click again after refreshing");
			c_err.vShowWindow();

			v_refresh_algs();
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)
}//System::Void CCONetmainForm::list_algorithms_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)




void  CCONetmainForm::list_change_state(System::Windows::Forms::ListViewItem  *pcItem)
{
	if  (
		atoi(
		(CString)  pcItem->SubItems->Item
			[pcItem->SubItems->Count - 1]->Text
		)
		==
		0
		)
	{
		pcItem->SubItems->Item
			[pcItem->SubItems->Count - 1]->Text  =  "1";

		pcItem->BackColor  =
			System::Drawing::SystemColors::ActiveBorder;
	
	}//if  (
	else
	{
		pcItem->SubItems->Item
			[pcItem->SubItems->Count - 1]->Text  =  "0";

		pcItem->BackColor  =
			System::Drawing::SystemColors::Window;			
	}//else  if

}//void  CCONetmainForm::list_change_state(System::Windows::Forms::ListViewItem  *pcItem)




void  CCONetmainForm::list_selected_state(System::Windows::Forms::ListViewItem  *pcItem)
{
	pcItem->SubItems->Item
		[pcItem->SubItems->Count - 1]->Text  =  "1";

	pcItem->BackColor  =
		System::Drawing::SystemColors::ActiveBorder;
}//void  CCONetmainForm::list_set_state(System::Windows::Forms::ListViewItem  *pcItem)




void  CCONetmainForm::list_unselected_state(System::Windows::Forms::ListViewItem  *pcItem)
{
	pcItem->SubItems->Item
		[pcItem->SubItems->Count - 1]->Text  =  "0";

	pcItem->BackColor  =
		System::Drawing::SystemColors::Window;
}//void  CCONetmainForm::list_unselected_state(System::Windows::Forms::ListViewItem  *pcItem)




System::Void CCONetmainForm::but_choose_set_select_all_Click(System::Object *  sender, System::EventArgs *  e)
{
	for  (int ii = 0; ii < (int) list_choose_set->Items->Count; ii++)
	{
		if  (
			atoi(
				(CString)  list_choose_set->Items->Item[ii]->SubItems->Item
					[list_choose_set->Items->Item[ii]->SubItems->Count - 1]->Text
				)
			==
			0
			)
		{
			list_change_state(list_choose_set->Items->Item[ii]);
		}//if  (

	}//for  (int ii = 0; ii < i_fdb_len; ii++)

}//System::Void CCONetmainForm::but_choose_set_select_all_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CCONetmainForm::but_choose_nets_select_a_Click(System::Object*  sender, System::EventArgs*  e)
{
	CString  s_name;

	for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)
	{
		s_name = list_choose_nets->Items->Item[ii]->SubItems->Item[0]->Text;


		if  ( (s_name.Find("b") >=  0)||(s_name.Find("d") >=  0) )
		{
			list_unselected_state(list_choose_nets->Items->Item[ii]);
		}//if  (s_name.Find("a") >=  0)
		else
		{
			list_selected_state(list_choose_nets->Items->Item[ii]);		
		}//else  if  (s_name.Find("a") >=  0)
		
			
	}//for  (int ii = 0; ii < i_fdb_len; ii++)

}//System::Void CCONetmainForm::but_choose_nets_select_a_Click(System::Object*  sender, System::EventArgs*  e)



System::Void CCONetmainForm::but_choose_nets_select_b_Click(System::Object*  sender, System::EventArgs*  e)
{
	CString  s_name;

	for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)
	{
		s_name = list_choose_nets->Items->Item[ii]->SubItems->Item[0]->Text;


		if  (s_name.Find("b") >=  0)
		{
			list_selected_state(list_choose_nets->Items->Item[ii]);
		}//if  (s_name.Find("a") >=  0)
		else
		{
			list_unselected_state(list_choose_nets->Items->Item[ii]);		
		}//else  if  (s_name.Find("a") >=  0)
		
			
	}//for  (int ii = 0; ii < i_fdb_len; ii++)

}//System::Void CCONetmainForm::but_choose_nets_select_b_Click(System::Object*  sender, System::EventArgs*  e)



System::Void CCONetmainForm::but_choose_nets_select_c_Click(System::Object*  sender, System::EventArgs*  e)
{
	CString  s_name;

	for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)
	{
		s_name = list_choose_nets->Items->Item[ii]->SubItems->Item[0]->Text;


		if  (s_name.Find("d") >=  0)
		{
			list_selected_state(list_choose_nets->Items->Item[ii]);
		}//if  (s_name.Find("a") >=  0)
		else
		{
			list_unselected_state(list_choose_nets->Items->Item[ii]);		
		}//else  if  (s_name.Find("a") >=  0)
		
			
	}//for  (int ii = 0; ii < i_fdb_len; ii++)
}//System::Void CCONetmainForm::but_choose_nets_select_c_Click(System::Object*  sender, System::EventArgs*  e)




System::Void CCONetmainForm::but_choose_set_deselect_all_Click(System::Object *  sender, System::EventArgs *  e)
{
	for  (int ii = 0; ii < (int) list_choose_set->Items->Count; ii++)
	{
		if  (
			atoi(
				(CString)  list_choose_set->Items->Item[ii]->SubItems->Item
					[list_choose_set->Items->Item[ii]->SubItems->Count - 1]->Text
				)
			==
			1
			)
		{
			list_change_state(list_choose_set->Items->Item[ii]);
		}//if  (

	}//for  (int ii = 0; ii < i_fdb_len; ii++)
}//System::Void CCONetmainForm::but_choose_set_deselect_all_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::but_choose_set_invert_Click(System::Object *  sender, System::EventArgs *  e)
{
	for  (int ii = 0; ii < (int) list_choose_set->Items->Count; ii++)
	{
		list_change_state(list_choose_set->Items->Item[ii]);
	}//for  (int ii = 0; ii < i_fdb_len; ii++)
}//System::Void CCONetmainForm::but_choose_set_invert_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::but_choose_nets_select_all_Click(System::Object *  sender, System::EventArgs *  e)
{
	for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)
	{
		if  (
			atoi(
				(CString)  list_choose_nets->Items->Item[ii]->SubItems->Item
					[list_choose_nets->Items->Item[ii]->SubItems->Count - 1]->Text
				)
			==
			0
			)
		{
			list_change_state(list_choose_nets->Items->Item[ii]);
		}//if  (

	}//for  (int ii = 0; ii < i_fdb_len; ii++)
}//System::Void CCONetmainForm::but_choose_nets_select_all_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::but_choose_nets_deselect_all_Click(System::Object *  sender, System::EventArgs *  e)
{
	for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)
	{
		if  (
			atoi(
				(CString)  list_choose_nets->Items->Item[ii]->SubItems->Item
					[list_choose_nets->Items->Item[ii]->SubItems->Count - 1]->Text
				)
			==
			1
			)
		{
			list_change_state(list_choose_nets->Items->Item[ii]);
		}//if  (

	}//for  (int ii = 0; ii < i_fdb_len; ii++)
}//System::Void CCONetmainForm::but_choose_nets_deselect_all_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CCONetmainForm::but_choose_nets_invert_Click(System::Object *  sender, System::EventArgs *  e)
{
	for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)
	{
		list_change_state(list_choose_nets->Items->Item[ii]);
	}//for  (int ii = 0; ii < i_fdb_len; ii++)
}//System::Void CCONetmainForm::but_choose_nets_invert_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CCONetmainForm::list_choose_set_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	for  (int ii = 0; ii < (int) list_choose_set->Items->Count; ii++)
	{
		if  (
			atoi(
				(CString)  list_choose_set->Items->Item[ii]->SubItems->Item
					[list_choose_set->Items->Item[ii]->SubItems->Count - 2]->Text
				)
			==
			i_selected_choose_set_index
			)
		{
			list_change_state(list_choose_set->Items->Item[ii]);
		}//if  (

	}//for  (int ii = 0; ii < i_fdb_len; ii++)
}//System::Void CCONetmainForm::list_choose_set_DoubleClick(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::list_choose_nets_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	/*for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)
	{
		if  (
			atoi(
				(CString)  list_choose_nets->Items->Item[ii]->SubItems->Item
					[list_choose_nets->Items->Item[ii]->SubItems->Count - 2]->Text
				)
			==
			i_selected_choose_net_index
			)
		{
			list_change_state(list_choose_nets->Items->Item[ii]);
		}//if  (

	}//for  (int ii = 0; ii < i_fdb_len; ii++)*/

	for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)
	{
		if  (
			list_choose_nets->Items->Item[ii]->Selected
			==
			true
			)
		{
			list_change_state(list_choose_nets->Items->Item[ii]);
		}//if  (

	}//for  (int ii = 0; ii < i_fdb_len; ii++)
	

}//System::Void CCONetmainForm::list_choose_nets_DoubleClick(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::list_choose_set_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	ListViewItem *pc_selected = list_choose_set->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_choose_set_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 2]->Text);
	}//if (pc_selected != NULL)
}//System::Void CCONetmainForm::list_choose_set_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)



System::Void CCONetmainForm::list_choose_nets_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{

	ListViewItem *pc_selected = list_choose_nets->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_choose_net_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 2]->Text);
	}//if (pc_selected != NULL)

}//System::Void CCONetmainForm::list_choose_nets_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)




System::Void CCONetmainForm::list_nets_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	int  i_id;
	int  i_net_root_id;
	int  i_num_nodes,  i_num_edges;
	CString  s_net_name,  s_net_file,  s_net_dir;
	CString  s_net_comments;
	__int64  dt_added;

	
	if  (pc_chosen_fdb  ==  NULL)  return;


	ListViewItem *pc_selected = list_nets->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_net_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);

		if  (check_config->Checked  ==  true)
			i_selected_net_conn_index  
				=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 2]->Text);
		else
			i_selected_net_conn_index  =  -1;
	

		if  ( (i_selected_net_index  <  (int) pc_chosen_fdb->pvGetNets()->size())&&(i_selected_net_index  >=  0) )
		{
			pc_chosen_fdb->pvGetNets()->at(i_selected_net_index)->vGetData
				(
				&i_id,
				&i_net_root_id,
				&i_num_nodes,  &i_num_edges,
				&s_net_name,  &s_net_file,  &s_net_dir,
				&s_net_comments,
				&dt_added		
				);

			textNetName->Text  =  (String *)  s_net_name;
			textNetDir->Text  =  (String *)  s_net_dir;
			textNetComments->Text  =  (String *)  s_net_comments;

			CString  s_buf;
			s_buf.Format("%d", i_num_nodes);
			textNetNodesNum->Text  =  (String *)  s_buf;
			s_buf.Format("%d", i_num_edges);
			textNetLinksNum->Text  =  (String *)  s_buf;
			
			System::DateTime  dt_buf;
			dt_buf  =  System::DateTime::FromFileTime(dt_added);
			textAddedBy->Text  =  dt_buf.ToString();

		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_net_index  =  -1;
			
			CError  c_err;
			c_err.vPutError("Selected index exceeds list length - click again after refreshing");
			c_err.vShowWindow();

			v_refresh_nets();
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)
}//System::Void CCONetmainForm::list_nets_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)




System::Void CCONetmainForm::list_fdb_roots_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	int  i_root_id;
	CString  s_root_dir, s_fdb_name;


    ListViewItem *pc_selected = list_fdb_roots->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_fdb_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);

		if  ( (i_selected_fdb_index  <  (int) pv_fdb_roots->size())&&(i_selected_fdb_index  >=  0) )
		{
			pv_fdb_roots->at(i_selected_fdb_index)->vGetData
				(
				&i_root_id,
				&s_root_dir, &s_fdb_name
				);

			textFDbDir->Text  =  (String *)  s_root_dir;
			textFDbName->Text  =  (String *)  s_fdb_name;
		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_fdb_index  =  -1;
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)
		
}//System::Void CCONetmainForm::list_fdb_roots2_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)




System::Void CCONetmainForm::list_fdb_roots_MouseUp(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	for  (int ii = 0; ii < (int) pv_fdb_roots->size(); ii++)
	{
		if  (
			atoi(
				(CString)  list_fdb_roots->Items->Item[ii]->SubItems->Item
					[list_fdb_roots->Items->Item[ii]->SubItems->Count - 1]->Text
				)
			==
			i_selected_fdb_index
			)
			list_fdb_roots->Items->Item[ii]->Selected  =  true;

		if  (pc_chosen_fdb  !=  NULL)
		{
			if	(
				*(pv_fdb_roots->at
					(
						atoi(
							(CString)  list_fdb_roots->Items->Item[ii]->SubItems->Item
								[list_fdb_roots->Items->Item[ii]->SubItems->Count - 1]->Text
							)
					)
					)//*
				==
				*pc_chosen_fdb
				)
				list_fdb_roots->Items->Item[ii]->BackColor  =
					System::Drawing::SystemColors::ActiveBorder;
			else
				list_fdb_roots->Items->Item[ii]->BackColor  =
				System::Drawing::SystemColors::Window;
		}//if  (pc_chosen_fdb  !=  NULL)
	
	}//for  (int ii = 0; ii < i_fdb_len; ii++)
	


}//System::Void CCONetmainForm::list_fdb_roots2_MouseUp(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)


System::Void CCONetmainForm::list_computers_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	butEditComp_Click(sender, e);
}//System::Void CCONetmainForm::list_computers_DoubleClick(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::list_algorithms_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	but_edit_alg_Click(sender, e);
}//System::Void CCONetmainForm::list_algorithms_DoubleClick(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::list_ff_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	butEditFF_Click(sender, e);
}//System::Void CCONetmainForm::list_ff_DoubleClick(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::list_nets_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	butEditNet_Click(sender, e);
}//System::Void CCONetmainForm::list_nets_DoubleClick(System::Object *  sender, System::EventArgs *  e)



System::Void CCONetmainForm::list_fdb_roots_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	int  i_root_id;
	CString  s_root_dir, s_fdb_name;

	if  ( (i_selected_fdb_index  <  (int)  pv_fdb_roots->size())&&(i_selected_fdb_index  >=  0) )
	{
		if  (pc_chosen_fdb  !=  NULL)  delete  pc_chosen_fdb;
		pc_chosen_fdb  =  new  CCOFDbRoot(NULL);
		pc_system->vSetSqlConn(pc_chosen_fdb);
		*pc_chosen_fdb  =  *(pv_fdb_roots->at(i_selected_fdb_index));
		

		pc_chosen_fdb->vGetData
			(
			&i_root_id,
			&s_root_dir, &s_fdb_name
			);

		textChosenFDbName->Text  =  s_fdb_name;
	}//if  ( (i_selected_fdb_index  <  i_fdb_len)&&(i_selected_fdb_index  >=  0) )

}//System::Void CCONetmainForm::list_fdb_roots_DoubleClick(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::list_choose_set_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_choose_set->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_choose_set->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_choose_set->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_choose_set->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_choose_set->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_nets->ListViewItemSorter  !=  NULL)
	else
		list_choose_set->ListViewItemSorter = new list_item_comparer(e->Column);
}//System::Void CCONetmainForm::list_choose_set_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)



System::Void CCONetmainForm::list_choose_nets_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_choose_nets->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_choose_nets->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_choose_nets->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_choose_nets->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_choose_nets->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_nets->ListViewItemSorter  !=  NULL)
	else
		list_choose_nets->ListViewItemSorter = new list_item_comparer(e->Column);

}//System::Void CCONetmainForm::list_choose_nets_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)




System::Void CCONetmainForm::list_nets_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_nets->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_nets->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_nets->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_nets->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_nets->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_nets->ListViewItemSorter  !=  NULL)
	else
		list_nets->ListViewItemSorter = new list_item_comparer(e->Column);
}//System::Void CCONetmainForm::list_nets_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)



System::Void CCONetmainForm::list_ff_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_ff->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_ff->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_ff->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_ff->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_ff->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_fdb_roots2->ListViewItemSorter  !=  NULL)
	else
		list_ff->ListViewItemSorter = new list_item_comparer(e->Column);
}//System::Void CCONetmainForm::list_ff_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)



System::Void CCONetmainForm::list_results_sets_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_results_sets->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_results_sets->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_results_sets->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_results_sets->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_results_sets->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_fdb_roots2->ListViewItemSorter  !=  NULL)
	else
		list_results_sets->ListViewItemSorter = new list_item_comparer(e->Column);
}//System::Void CCONetmainForm::list_results_sets_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)


System::Void CCONetmainForm::list_results_sets_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
	butEditRSet_Click(sender, e);
}//System::Void CCONetmainForm::list_results_sets_DoubleClick(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::list_results_sets_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	int  i_id;
	CString  s_rset_name;
	CString  s_rset_comments;

	
	ListViewItem *pc_selected = list_results_sets->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_rset_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);


		if  ( (i_selected_rset_index  <  (int) pv_rsets->size())&&(i_selected_rset_index  >=  0) )
		{
			pv_rsets->at(i_selected_rset_index)->vGetData
				(
				&i_id,
				&s_rset_name,
				&s_rset_comments
				);

			textRSetName->Text  =  (String *)  s_rset_name;
			textRSetComm->Text  =  (String *)  s_rset_comments;

		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_rset_index  =  -1;
			
			CError  c_err;
			c_err.vPutError("Selected index exceeds list length - click again after refreshing");
			c_err.vShowWindow();

			v_refresh_rsets();
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)
}//System::Void CCONetmainForm::list_results_sets_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)



System::Void CCONetmainForm::list_computers_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_computers->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_computers->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_computers->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_computers->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_computers->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_fdb_roots2->ListViewItemSorter  !=  NULL)
	else
		list_computers->ListViewItemSorter = new list_item_comparer(e->Column);
}//System::Void CCONetmainForm::list_computers_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)


System::Void CCONetmainForm::list_algorithms_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_algorithms->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_algorithms->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_algorithms->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_algorithms->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_algorithms->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_fdb_roots2->ListViewItemSorter  !=  NULL)
	else
		list_algorithms->ListViewItemSorter = new list_item_comparer(e->Column);
}//System::Void CCONetmainForm::list_algorithms_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)




System::Void CCONetmainForm::list_fdb_roots_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_fdb_roots->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_fdb_roots->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_fdb_roots->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_fdb_roots->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_fdb_roots->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_fdb_roots2->ListViewItemSorter  !=  NULL)
	else
		list_fdb_roots->ListViewItemSorter = new list_item_comparer(e->Column);
};//System::Void CCONetmainForm::list_fdb_roots2_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)



System::Void CCONetmainForm::butEditRSet_Click(System::Object *  sender, System::EventArgs *  e)
{

	if  ( (i_selected_rset_index  <  (int)  pv_rsets->size())&&(i_selected_rset_index  >=  0) )
	{
		CAddEditResultsSet  *pc_edit_window;

		pc_edit_window  =  new  CAddEditResultsSet;

		int  i_id;
		CString  s_rset_name;
		CString  s_rset_comments;

		pv_rsets->at(i_selected_rset_index)->vGetData
			(
			&i_id,
			&s_rset_name,
			&s_rset_comments
			);

		pc_edit_window->textRSetName->Text  =  s_rset_name;
		pc_edit_window->textRSetComm->Text  =  s_rset_comments;

		if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
		{
			CError  c_err;

			s_rset_name  =  pc_edit_window->textRSetName->Text;
			s_rset_comments  =  pc_edit_window->textRSetComm->Text;

			c_err  =  pv_rsets->at(i_selected_rset_index)->eUpdate(s_rset_name, s_rset_comments);
			if  (c_err)  c_err.vShowWindow();

			v_refresh_rsets();
		}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)

		
	}//if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	else
	{
		::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
	}//else  if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )


}//System::Void CCONetmainForm::butEditRSet_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::butAddRSet_Click(System::Object *  sender, System::EventArgs *  e)
{
	CAddEditResultsSet  *pc_edit_window;

	pc_edit_window  =  new  CAddEditResultsSet;

	pc_edit_window->textRSetName->Text  =  "";
	pc_edit_window->textRSetComm->Text  =  "";

	if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
	{
		CError  c_err;

		CString  s_rset_name,  s_rset_comments;

		s_rset_name  =  pc_edit_window->textRSetName->Text;
		s_rset_comments  =  pc_edit_window->textRSetComm->Text;

		
		CCOResultSet  c_new_rset(NULL);
		pc_system->vSetSqlConn(&c_new_rset);
		c_err  =  c_new_rset.eUpdate(s_rset_name, s_rset_comments);

		if  (c_err)  c_err.vShowWindow();

		v_refresh_rsets();
	}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
}//System::Void CCONetmainForm::butAddRSet_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::butRemRSet_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (i_selected_rset_index  <  (int)  pv_rsets->size())&&(i_selected_rset_index  >=  0) )
	{
		CError  c_err;

		int  i_id;
		CString  s_rset_name;
		CString  s_rset_comments;

		pv_rsets->at(i_selected_rset_index)->vGetData
			(
			&i_id,
			&s_rset_name,
			&s_rset_comments
			);

		CString  s_buf;
		s_buf.Format("Are You sure You want to delete this results set?:'%s'?", (LPCSTR) s_rset_name);
		if  (::MessageBox(NULL,  s_buf, "Question", MB_YESNO)  ==  IDYES)  
		{
			c_err  =  pv_rsets->at(i_selected_rset_index)->eRemoveWithResults(pc_system);
			if  (c_err)  c_err.vShowWindow();
			v_refresh_rsets();
		}//if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  

	}//if  (i_selected_index  <  i_fdb_len)
	else
	{
        ::MessageBox(NULL,"Unexpected error caused by wrong selection index."	, "Error", MB_OK);
	}//else  if  (i_selected_index  <  i_fdb_len)

}//System::Void CCONetmainForm::butRemRSet_Click(System::Object *  sender, System::EventArgs *  e)





System::Void CCONetmainForm::butEditComp_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (i_selected_comp_index  <  (int)  pv_computers->size())&&(i_selected_comp_index  >=  0) )
	{
		CAddEditComputer  *pc_edit_window;

		pc_edit_window  =  new  CAddEditComputer;

		int  i_id;
		CString  s_comp_name;
		CString  s_comp_comments;

		pv_computers->at(i_selected_comp_index)->vGetData
			(
			&i_id,
			&s_comp_name,
			&s_comp_comments
			);

		pc_edit_window->textCompName->Text  =  s_comp_name;
		pc_edit_window->textCompComm->Text  =  s_comp_comments;

		if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
		{
			CError  c_err;

			s_comp_name  =  pc_edit_window->textCompName->Text;
			s_comp_comments  =  pc_edit_window->textCompComm->Text;

			c_err  =  pv_computers->at(i_selected_comp_index)->eUpdate(s_comp_name, s_comp_comments);
			if  (c_err)  c_err.vShowWindow();

			v_refresh_computers();
		}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)

		
	}//if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	else
	{
		::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
	}//else  if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )


}//System::Void CCONetmainForm::butEditComp_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CCONetmainForm::butAddComp_Click(System::Object *  sender, System::EventArgs *  e)
{
	CAddEditComputer  *pc_edit_window;

	pc_edit_window  =  new  CAddEditComputer;

	pc_edit_window->textCompName->Text  =  "";
	pc_edit_window->textCompComm->Text  =  "";

	if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
	{
		CError  c_err;

		CString  s_comp_name,  s_comp_comments;

		s_comp_name  =  pc_edit_window->textCompName->Text;
		s_comp_comments  =  pc_edit_window->textCompComm->Text;

		
		CCOComputer  c_new_comp(NULL);
		pc_system->vSetSqlConn(&c_new_comp);
		c_err  =  c_new_comp.eUpdate(s_comp_name, s_comp_comments);

		if  (c_err)  c_err.vShowWindow();

		v_refresh_computers();
	}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)


}//System::Void CCONetmainForm::butAddComp_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CCONetmainForm::butAddFF_Click(System::Object *  sender, System::EventArgs *  e)
{
	CAddEditFitFunc  *pc_edit_window;

	pc_edit_window  =  new  CAddEditFitFunc;

	pc_edit_window->textFFuncName->Text  =  "";
	pc_edit_window->textFFuncComm->Text  =  "";

	if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
	{
		CError  c_err;

		CString  s_ff_name,  s_ff_comments;

		s_ff_name  =  pc_edit_window->textFFuncName->Text;
		s_ff_comments  =  pc_edit_window->textFFuncComm->Text;

		
		CCOFitFunc  c_new_ff(NULL);
		pc_system->vSetSqlConn(&c_new_ff);
		c_err  =  c_new_ff.eUpdate(s_ff_name, s_ff_comments);

		if  (c_err)  c_err.vShowWindow();

		v_refresh_fit_funcs();
	}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)


}//System::Void CCONetmainForm::butAddFF_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::but_add_alg_Click(System::Object *  sender, System::EventArgs *  e)
{
	CAddEditAlgorithm  *pc_edit_window;

	pc_edit_window  =  new  CAddEditAlgorithm;


	CCOAlgorithm  c_new_alg(NULL);
	pc_system->vSetSqlConn(&c_new_alg);

	pc_edit_window->vSetAlgorithm(&c_new_alg);
	if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
	{
		v_refresh_algs();
	}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)

}//System::Void CCONetmainForm::but_add_alg_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::butAddFDb_Click(System::Object *  sender, System::EventArgs *  e)
{
	CAddEditFDb  *pc_edit_window;

	pc_edit_window  =  new  CAddEditFDb;

	pc_edit_window->textFDbDir->Text  =  "";
	pc_edit_window->textFDbName->Text  =  "";

	if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
	{
		CError  c_err;

		CString  s_fdb_name,  s_fdb_dir;

		s_fdb_name  =  pc_edit_window->textFDbName->Text;
		s_fdb_dir  =  pc_edit_window->textFDbDir->Text;

		
		CCOFDbRoot  c_new_root(NULL);
		pc_system->vSetSqlConn(&c_new_root);
		c_err  =  c_new_root.eUpdate(s_fdb_dir, s_fdb_name);

		if  (c_err)  c_err.vShowWindow();

		v_refresh_roots();
	}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)

}//System::Void CCONetmainForm::butAddFDb_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::butFDbDeselect_Click(System::Object *  sender, System::EventArgs *  e)
{


	for  (int ii = 0; ii < (int)  pv_fdb_roots->size(); ii++)
	{
		list_fdb_roots->Items->Item[ii]->BackColor  =
			System::Drawing::SystemColors::Window;

		if  (
			atoi(
				(CString)  list_fdb_roots->Items->Item[ii]->SubItems->Item
					[list_fdb_roots->Items->Item[ii]->SubItems->Count - 1]->Text
				)
			==
			i_selected_fdb_index
			)
			list_fdb_roots->Items->Item[ii]->Selected  =  true;

	}//for  (int ii = 0; ii < i_fdb_len; ii++)

	
	textChosenFDbName->Text  =  "";

	if  (pc_chosen_fdb  !=  NULL)  
	{
		delete  pc_chosen_fdb;
		pc_chosen_fdb  =  NULL;
	}//if  (pc_chosen_fdb  !=  NULL)  

	v_refresh_nets();

}//System::Void CCONetmainForm::butFDbDeselect_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CCONetmainForm::butEditFF_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (i_selected_ff_index  <  (int)  pv_fit_funcs->size())&&(i_selected_ff_index  >=  0) )
	{
		CAddEditFitFunc  *pc_edit_window;

		pc_edit_window  =  new  CAddEditFitFunc;

		int  i_id;
		CString  s_ff_name;
		CString  s_ff_comments;

		pv_fit_funcs->at(i_selected_ff_index)->vGetData
			(
			&i_id,
			&s_ff_name,
			&s_ff_comments
			);

		pc_edit_window->textFFuncName->Text  =  s_ff_name;
		pc_edit_window->textFFuncComm->Text  =  s_ff_comments;

		if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
		{
			CError  c_err;

			s_ff_name  =  pc_edit_window->textFFuncName->Text;
			s_ff_comments  =  pc_edit_window->textFFuncComm->Text;

			c_err  =  pv_fit_funcs->at(i_selected_ff_index)->eUpdate(s_ff_name, s_ff_comments);
			if  (c_err)  c_err.vShowWindow();

			v_refresh_fit_funcs();
		}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)

		
	}//if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	else
	{
		::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
	}//else  if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )

}//System::Void CCONetmainForm::butEditFF_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::but_edit_alg_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (i_selected_alg_index  <  (int)  pv_algorithms->size())&&(i_selected_alg_index  >=  0) )
	{
		CAddEditAlgorithm  *pc_edit_window;

		pc_edit_window  =  new  CAddEditAlgorithm;
		pc_edit_window->vSetAlgorithm(pv_algorithms->at(i_selected_alg_index));

		
		if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
		{
			v_refresh_algs();
		}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)

		
	}//if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	else
	{
		::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
	}//else  if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )

}//System::Void CCONetmainForm::but_edit_alg_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::butEditFDb_Click(System::Object *  sender, System::EventArgs *  e)
{

	if  ( (i_selected_fdb_index  <  (int)  pv_fdb_roots->size())&&(i_selected_fdb_index  >=  0) )
	{
		CAddEditFDb  *pc_edit_window;

		pc_edit_window  =  new  CAddEditFDb;

		int  i_root_id;
		CString  s_root_dir, s_fdb_name;

		pv_fdb_roots->at(i_selected_fdb_index)->vGetData
			(
			&i_root_id,
			&s_root_dir, &s_fdb_name
			);

		pc_edit_window->textFDbDir->Text  =  s_root_dir;
		pc_edit_window->textFDbName->Text  =  s_fdb_name;

		if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
		{
			CError  c_err;

			s_fdb_name  =  pc_edit_window->textFDbName->Text;
			s_root_dir  =  pc_edit_window->textFDbDir->Text;

			c_err  =  pv_fdb_roots->at(i_selected_fdb_index)->eUpdate(s_root_dir, s_fdb_name);
			if  (c_err)  c_err.vShowWindow();

			v_refresh_roots();
		}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)

		
	}//if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	else
	{
		::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
	}//else  if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )

};//System::Void CCONetmainForm::butEditFDb_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CCONetmainForm::butRemoveNet_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  (pc_chosen_fdb  ==  NULL)
	{
		::MessageBox(NULL,"You must choose fdb root to add a new network","Info",MB_OK);
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)


	if  ( (i_selected_net_index  <  (int)  pc_chosen_fdb->pvGetNets()->size())&&(i_selected_net_index  >=  0) )
	{
		CError  c_err;

		int  i_id;
		int  i_net_root_id;
		int  i_num_nodes,  i_num_edges;
		CString  s_net_name,  s_net_file,  s_net_dir;
		CString  s_net_comments;
		__int64  dt_added;

		pc_chosen_fdb->pvGetNets()->at(i_selected_net_index)->vGetData
			(
			&i_id,
			&i_net_root_id,
			&i_num_nodes,  &i_num_edges,
			&s_net_name,  &s_net_file,  &s_net_dir,
			&s_net_comments,
			&dt_added		
			);

	
		CString  s_buf;
		s_buf.Format("Are You sure You want to delete this network?:'%s'?", (LPCSTR) s_net_name);
		if  (::MessageBox(NULL,  s_buf, "Delete?", MB_YESNO)  ==  IDYES)  
		{
			c_err  =  pc_chosen_fdb->eRemoveNetwork(i_selected_net_index);
			if  (c_err)  c_err.vShowWindow();
            v_refresh_nets();
		}//if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  

	}//if  (i_selected_index  <  i_fdb_len)
	else
	{
        ::MessageBox(NULL,"Unexpected error caused by wrong selection index."	, "Error", MB_OK);
	}//else  if  (i_selected_index  <  i_fdb_len)

}//System::Void CCONetmainForm::butRemoveNet_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::butRemoveComp_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (i_selected_comp_index  <  (int)  pv_computers->size())&&(i_selected_comp_index  >=  0) )
	{
		CError  c_err;

		int  i_id;
		CString  s_comp_name;
		CString  s_comp_comments;

		pv_computers->at(i_selected_comp_index)->vGetData
			(
			&i_id,
			&s_comp_name,
			&s_comp_comments
			);

		CString  s_buf;
		s_buf.Format("Are You sure You want to delete this computer?:'%s'?", (LPCSTR) s_comp_name);
		if  (::MessageBox(NULL,  s_buf, "Question", MB_YESNO)  ==  IDYES)  
		{
			c_err  =  pv_computers->at(i_selected_comp_index)->eRemove();
			if  (c_err)  c_err.vShowWindow();
			v_refresh_computers();
		}//if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  

	}//if  (i_selected_index  <  i_fdb_len)
	else
	{
        ::MessageBox(NULL,"Unexpected error caused by wrong selection index."	, "Error", MB_OK);
	}//else  if  (i_selected_index  <  i_fdb_len)
}//System::Void CCONetmainForm::butRemoveComp_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::butRemoveFF_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (i_selected_ff_index  <  (int)  pv_fit_funcs->size())&&(i_selected_ff_index  >=  0) )
	{
		CError  c_err;

		int  i_id;
		CString  s_ff_name;
		CString  s_ff_comments;

		pv_fit_funcs->at(i_selected_ff_index)->vGetData
			(
			&i_id,
			&s_ff_name,
			&s_ff_comments
			);

		CString  s_buf;
		s_buf.Format("Are You sure You want to delete this fit function?:'%s'?", (LPCSTR) s_ff_name);
		if  (::MessageBox(NULL,  s_buf, "Question", MB_YESNO)  ==  IDYES)  
		{
			c_err  =  pv_fit_funcs->at(i_selected_ff_index)->eRemove();
			if  (c_err)  c_err.vShowWindow();
			v_refresh_fit_funcs();
		}//if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  

	}//if  (i_selected_index  <  i_fdb_len)
	else
	{
        ::MessageBox(NULL,"Unexpected error caused by wrong selection index."	, "Error", MB_OK);
	}//else  if  (i_selected_index  <  i_fdb_len)
}//System::Void CCONetmainForm::butRemoveFF_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::but_rem_alg_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (i_selected_alg_index  <  (int)  pv_algorithms->size())&&(i_selected_alg_index  >=  0) )
	{
		CError  c_err;

		int  i_id;
		CString  s_alg_name;
		CString  s_alg_comments;

		pv_algorithms->at(i_selected_alg_index)->vGetData
			(
			&i_id,
			&s_alg_name,
			&s_alg_comments
			);

		CString  s_buf;
		s_buf.Format("Are You sure You want to delete this fdb root?:'%s'?", (LPCSTR) s_alg_name);
		if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  
		{
			c_err  =  pv_algorithms->at(i_selected_alg_index)->eRemove();
			if  (c_err)  c_err.vShowWindow();
			v_refresh_algs();
		}//if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  

	}//if  (i_selected_index  <  i_fdb_len)
	else
	{
        ::MessageBox(NULL,"Unexpected error caused by wrong selection index."	, "Error", MB_OK);
	}//else  if  (i_selected_index  <  i_fdb_len)
}//System::Void CCONetmainForm::but_rem_alg_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::butRemoveFDb_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  ( (i_selected_fdb_index  <  (int)  pv_fdb_roots->size())&&(i_selected_fdb_index  >=  0) )
	{
		CError  c_err;

		int  i_root_id;
		CString  s_root_dir, s_fdb_name;

		pv_fdb_roots->at(i_selected_fdb_index)->vGetData
			(
			&i_root_id,
			&s_root_dir, &s_fdb_name
			);

		CString  s_buf;
		s_buf.Format("Are You sure You want to delete this fdb root?:'%s' ('%s')?", (LPCSTR) s_fdb_name,  (LPCSTR) s_root_dir);
		if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  
		{
			c_err  =  pv_fdb_roots->at(i_selected_fdb_index)->eRemove();
			if  (c_err)  c_err.vShowWindow();
            v_refresh_roots();
		}//if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  

	}//if  (i_selected_index  <  i_fdb_len)
	else
	{
        ::MessageBox(NULL,"Unexpected error caused by wrong selection index."	, "Error", MB_OK);
	}//else  if  (i_selected_index  <  i_fdb_len)

};//System::Void CCONetmainForm::butRemoveFDb_Click(System::Object *  sender, System::EventArgs *  e)


void CCONetmainForm::but_edit_net_only_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  (pc_chosen_fdb  ==  NULL)
	{
		::MessageBox(NULL,"You must choose fdb root to add a new network","Info",MB_OK);
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)

	if  ( (i_selected_net_index  <  (int)  pc_chosen_fdb->pvGetNets()->size())&&(i_selected_net_index  >=  0) )
	{
		
		CAddEditNet  *pc_edit_window;

		pc_edit_window  =  new  CAddEditNet(pc_system);
		pc_edit_window->vSetFDbRoot(pc_chosen_fdb);
		pc_edit_window->vSetNetIndex(i_selected_net_index);

		
		if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
		{
			v_refresh_nets();
		}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)	

		
	}//if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	else
	{
		::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
	}//else  if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	
}//void CCONetmainForm::but_edit_net_only_Click(System::Object *  sender, System::EventArgs *  e)



void CCONetmainForm::but_edit_net_with_conns_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  (pc_chosen_fdb  ==  NULL)
	{
		::MessageBox(NULL,"You must choose fdb root to add a new network","Info",MB_OK);
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)


	if  ( (i_selected_net_index  <  (int)  pc_chosen_fdb->pvGetNets()->size())&&(i_selected_net_index  >=  0) )
	{

		if  ( (i_selected_net_conn_index  <  (int)  pc_chosen_fdb->pvGetNets()->at(i_selected_net_index)->pvGetNetConns()->size())&&(i_selected_net_conn_index  >=  0) )
		{
			CAddEditConn  *pc_edit_window;

			pc_edit_window  =  new  CAddEditConn(pc_system);
			pc_edit_window->vSetFDbRootAndNetIndex(pc_chosen_fdb, i_selected_net_index);
			pc_edit_window->vSetConnIndex(i_selected_net_conn_index);

			
			if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
			{
				v_refresh_nets();
			}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)	
			
						
		}//if  ( (i_selected_net_conn_index  <  (int)  pc_chosen_fdb->pvGetNets()->at(i_selected_net_index)->pvGetNetConns()->size())&&(i_selected_net_conn_index  >=  0) )
		else
		{
			::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
		}//else  if  ( (i_selected_net_conn_index  <  (int)  pc_chosen_fdb->pvGetNets()->at(i_selected_net_index)->pvGetNetConns()->size())&&(i_selected_net_conn_index  >=  0) )
		
		
		
	}//if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	else
	{
		::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
	}//else  if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	
}//void CCONetmainForm::but_edit_net_with_conns_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CCONetmainForm::butEditNet_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  (check_config->Checked  ==  true)
	{
		but_edit_net_with_conns_Click(sender, e);
	}//if  (check_config->Checked  ==  true)
	else
	{
		but_edit_net_only_Click(sender, e);
	}//else  if  (check_config->Checked  ==  true)	
}//System::Void CCONetmainForm::butEditNet_Click(System::Object *  sender, System::EventArgs *  e)



void  CCONetmainForm::v_add_conn_by_name(CString  sConnPath)
{
	CError  c_err;
	CString  s_buf;


	//first we recognize the name
	if  (File::Exists(sConnPath)  ==  false)
	{
		s_buf.Format("The file does not exist (%s)", (LPCSTR) sConnPath);
		c_err.vPutError(s_buf);
		c_err.vShowWindow();
		return;	
	}//if  (File::Exists(sNetPath)  ==  false)

	FileInfo  *fi  =  new  FileInfo(sConnPath);
	s_buf  =  fi->Name;
	
	int  i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;


	CString  s_name;

	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_name  +=  s_buf.GetAt(ii);
	else
		s_name  =  s_buf;

	//now we need to find the same network name as the connection name
	bool  b_found  =  false;
	for  (int  ii = 0; (ii < (int) pc_chosen_fdb->pvGetNets()->size())&&(b_found  ==  false); ii++)
	{
		if  (s_name.MakeLower()  ==  pc_chosen_fdb->pvGetNets()->at(ii)->sGetName().MakeLower())
		{
			b_found  =  true;
			c_err  =  pc_chosen_fdb->pvGetNets()->at(ii)->eAddNetConn
				(
				pc_chosen_fdb->sGetRootDir(), 
				sConnPath,
				s_name
				);

			if  (c_err)
			{
				c_err.vShowWindow();
				return;			
			}//if  (c_err)
		
		}//if  (s_name  ==  pc_chosen_fdb->pvGetNets()->sGetName())	
	}//for  (int  ii = 0; ii < (int) pc_chosen_fdb->pvGetNets()->size(); ii++)
	
	if  (b_found  ==  false)
	{
		s_buf.Format("Network (%s) not found", (LPCSTR) s_name);
		c_err.vPutError(s_buf);
		c_err.vShowWindow();
		return;	
	}//if  (b_found  ==  false)
	


}//void  CCONetmainForm::v_add_conn_by_name(CString  sConnDir)





void  CCONetmainForm::v_add_result_walk(CString  sSolutionFile,  int  iCompId, int  iRSetId, int  iAlgId, int iFitFunc)
{
	CError  c_err;


	CCOAlgorithm  c_alogrithm(NULL);
	pc_system->vSetSqlConn(&c_alogrithm);

	vector <CString>  v_files;

	CCOResult  c_result(NULL);
	pc_system->vSetSqlConn(&c_result);

	CCOFitFunc  c_fit_func(NULL);
	pc_system->vSetSqlConn(&c_fit_func);

	CCONet  c_network(NULL);
	pc_system->vSetSqlConn(&c_network);

	CCONetConn  c_net_con(NULL);
	pc_system->vSetSqlConn(&c_net_con);



	CString  s_buf;

	c_err  =  pc_system->eGetAlgorithm("", &c_alogrithm, iAlgId);
	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)

	
	c_err  =  pc_system->eGetFitFunc("", &c_fit_func, iFitFunc);
	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)


	c_err  =  pc_system->eLoadResultFromSolutionFile
		(
		sSolutionFile,
		pc_chosen_fdb,
		c_fit_func.sGetName(),
		&c_result,
		&c_network, &c_net_con, 10
		);

	if  (c_err)
	{
		c_err.vShowWindow();
		return;
	}//if  (c_err)
	else
	{
		int  i_id;
		int i_con_id, i_fit_id, i_alg_id, i_comp_id, i_rset_id;
		CString  s_res_dir, s_res_comments;
		double  d_fit_value;
		double  d_time;
		__int64  dt_generated;

		c_result.vGetData
			(
			&i_id,
			&i_con_id, &i_fit_id, &i_alg_id, &i_comp_id,  &i_rset_id,
			&s_res_dir, &s_res_comments,
			&d_fit_value,
			&d_time,
			&dt_generated
			);

		d_time  =  -1;
		d_fit_value  =  1.0 / d_fit_value;
		d_fit_value  =  d_fit_value  -  1.0;
		d_fit_value  =  Math::Round(d_fit_value);

		v_files.push_back(sSolutionFile);

		c_err  =  c_net_con.eAddResult
			(
			pc_chosen_fdb->sGetRootDir(), c_network.sGetNetDir(),
			iFitFunc, iCompId, iRSetId,
			s_res_comments,
			d_fit_value, 
			d_time, dt_generated,
			&v_files, &c_alogrithm
			);

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

	}//else  if  (c_err)

}//void  v_add_result_walk(s_settings_file,  i_comp_id_for_all_results, i_rset_id_for_all_results, i_alg_id_for_all_results)



void  CCONetmainForm::v_add_result(CString  sSettingsFile, int iCompId, int iRSetId)
{

}//void  CCONetmainForm::v_add_result(CString  sSettingsFile, int iCompId, int iRSetId)



void  CCONetmainForm::v_add_result_old(CString  sSettingsFile, int iCompId, int iRSetId)
{
	CError  c_err;

	CCOAlgorithm  c_alogrithm(NULL);
	pc_system->vSetSqlConn(&c_alogrithm);
	
	vector <CString>  v_files;

	CCOResult  c_result(NULL);
	pc_system->vSetSqlConn(&c_result);

	CString  s_buf;

	c_err  =  pc_system->eLoadResultParamsFromFile
		(
		sSettingsFile,
		pc_chosen_fdb,
		&v_files,
		&c_alogrithm,
		&c_result
		);

	if  (c_err)
	{
		c_err.vShowWindow();
		return;
	}//if  (c_err)
	else
	{
		int  i_id;
		int i_con_id, i_fit_id, i_alg_id, i_comp_id, i_rset_id;
		CString  s_res_dir, s_res_comments;
		double  d_fit_value;
		double  d_time;
		__int64  dt_generated;

		c_result.vGetData
			(
			&i_id,
			&i_con_id, &i_fit_id, &i_alg_id, &i_comp_id,  &i_rset_id,
			&s_res_dir, &s_res_comments,
			&d_fit_value,
			&d_time,
			&dt_generated
			);

		CCONet  c_network(NULL);
		int  i_con_index;
		pc_system->vSetSqlConn(&c_network);
		c_err  =  pc_system->eFindNetworkAndConnForResult
			(
			&c_result, pc_chosen_fdb, 
			&c_network,  &i_con_index
			);

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)


		c_err  =  c_network.pvGetNetConns()->at(i_con_index)->eAddResult
			(
			pc_chosen_fdb->sGetRootDir(), c_network.sGetNetDir(),
			i_fit_id, iCompId, iRSetId,
			s_res_comments,
			d_fit_value, 
			d_time, dt_generated,
			&v_files, &c_alogrithm
			);

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

	}//else  if  (c_err)

}//void  CCONetmainForm::v_add_result_old(CString  sSettingsFile)



System::Void CCONetmainForm::but_massive_add_results_walk_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;
	CString  s_buf;

	CMassiveAddInfo  *pc_general_info_dialog;
	pc_general_info_dialog  =  new  CMassiveAddInfo(pc_system);
	pc_general_info_dialog->comboAlg->Visible  =  true;
	pc_general_info_dialog->lab_alg->Visible  =  true;
	pc_general_info_dialog->comboFF->Visible  =  true;
	pc_general_info_dialog->lab_ff->Visible  =  true;
	
	if  (pc_general_info_dialog->ShowDialog()  !=  DialogResult::OK)  return;
	int  i_comp_id_for_all_results;
	i_comp_id_for_all_results  =  pc_general_info_dialog->iResultCompId;
	int  i_rset_id_for_all_results;
	i_rset_id_for_all_results  =  pc_general_info_dialog->iResultRSetId;
	int  i_alg_id_for_all_results;
	i_alg_id_for_all_results  =  pc_general_info_dialog->iResultAlgId;
	int  i_ff_id_for_all_results;
	i_ff_id_for_all_results  =  pc_general_info_dialog->iResultFFId;
	pc_general_info_dialog->Hide();
	Refresh();


	OpenFileDialog* openFileDialog1 = new OpenFileDialog();
 
    //openFileDialog1->InitialDirectory = S"D:\\praca dyplomowa - nowy interfejs\\publikacja\\FD_init" ;
	openFileDialog1->Filter = "LFL files (*.lfl)|*.lfl|All files (*.*)|*.*";
    openFileDialog1->FilterIndex = 0;
    openFileDialog1->RestoreDirectory = true;
	openFileDialog1->Multiselect  =  true;

    if(openFileDialog1->ShowDialog() == DialogResult::OK)
    {
		Refresh();

		CInfoWindow  *pc_info_dialog;
		pc_info_dialog  =  new  CInfoWindow;
		pc_info_dialog->Text  =  S"Massive old Hefan results adding...";
		CString  s_settings_file;

		for  (int  ii = 0;  ii < openFileDialog1->FileNames->Count; ii++)
		{
			pc_info_dialog->pbar_progres->Minimum = 0;
			pc_info_dialog->pbar_progres->Maximum = openFileDialog1->FileNames->Count;
			pc_info_dialog->pbar_progres->Value = ii;
			s_buf.Format("%d/%d results added", ii, openFileDialog1->FileNames->Count);
			pc_info_dialog->lab_text->Text  =  s_buf;
			pc_info_dialog->Refresh();
			pc_info_dialog->Show();

			s_settings_file  =  (CString)  openFileDialog1->FileNames[ii];
			v_add_result_walk(s_settings_file,  i_comp_id_for_all_results, i_rset_id_for_all_results, i_alg_id_for_all_results, i_ff_id_for_all_results);
		}//for  (int  ii = 0;  ii < openFileDialog1->FileNames->Count)

		pc_info_dialog->pbar_progres->Minimum = 0;
		pc_info_dialog->pbar_progres->Maximum = openFileDialog1->FileNames->Count;
		pc_info_dialog->pbar_progres->Value = openFileDialog1->FileNames->Count;
		s_buf.Format("FINISHED! %d/%d results added", openFileDialog1->FileNames->Count, openFileDialog1->FileNames->Count);
		pc_info_dialog->lab_text->Text  =  s_buf;
		pc_info_dialog->Refresh();
		pc_info_dialog->Show();
		Sleep(STANDARD_INFO_SLEEP);
		pc_info_dialog->Hide();
	}//if(openFileDialog1->ShowDialog() == DialogResult::OK)


}//System::Void CCONetmainForm::but_massive_add_results_walk_Click(System::Object *  sender, System::EventArgs *  e)





System::Void CCONetmainForm::but_massive_add_results_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;
	CString  s_buf;

	CMassiveAddInfo  *pc_general_info_dialog;
	pc_general_info_dialog  =  new  CMassiveAddInfo(pc_system);
	
	if  (pc_general_info_dialog->ShowDialog()  !=  DialogResult::OK)  return;
	int  i_comp_id_for_all_results;
	i_comp_id_for_all_results  =  pc_general_info_dialog->iResultCompId;
	int  i_rset_id_for_all_results;
	i_rset_id_for_all_results  =  pc_general_info_dialog->iResultRSetId;
	pc_general_info_dialog->Hide();
	Refresh();


	OpenFileDialog* openFileDialog1 = new OpenFileDialog();
 
    //openFileDialog1->InitialDirectory = S"D:\\praca dyplomowa - nowy interfejs\\publikacja\\FD_init" ;
	openFileDialog1->Filter = "All files (*.*)|*.*";
    openFileDialog1->FilterIndex = 0;
    openFileDialog1->RestoreDirectory = true;
	openFileDialog1->Multiselect  =  false;

    if(openFileDialog1->ShowDialog() == DialogResult::OK)
    {
		Refresh();

		if  (File::Exists(openFileDialog1->FileNames[0])  ==  false)
		{
			s_buf  =  (CString) openFileDialog1->FileNames[0];
			s_buf.Format("The file does not exist (%s)", (LPCSTR) s_buf);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
			return;	
		}//if  (File::Exists(openFileDialog1->FileNames[ii])  ==  false)


		CString  s_set_of_files_name;
		int  i_header_type;
		s_set_of_files_name  =  (CString)  openFileDialog1->FileNames[0];

		c_err  =  CHefanSystem::eCheckHeader(s_set_of_files_name,  &i_header_type);
		if  (i_header_type  !=  HEADER_TYPE_HEFAN_2_0)
		{
			s_buf.Format("Script version type different from %s", SCRIPT_VER_1_0);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
			return;		
		}//if  (i_header_type  !=  HEADER_TYPE_HEFAN_2_0)


		FILE  *pf_set_of_files;
		pf_set_of_files  =  fopen((LPCSTR)  s_set_of_files_name, "r+");

		if  (pf_set_of_files  ==  NULL)
		{
			s_buf.Format("Can not open file %s", (LPCSTR) s_set_of_files_name);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
			return;
		}//if  (pf_set_of_files  ==  NULL)


		CHefanSystem::vReadLine(pf_set_of_files, &s_buf, &s_buf);//script version...

		CString  s_mother_dir;
		c_err  =  CHefanSystem::eReadValue(pf_set_of_files, "root dir", &s_mother_dir);
		if  (c_err)
		{
			fclose(pf_set_of_files);
			c_err.vShowWindow();
			return;		
		}//if  (c_err)

		
		vector  <CString>  v_settings_files_to_run;
		CString  s_settings_file;
		while  (!feof(pf_set_of_files))
		{
			CHefanSystem::vReadLine(pf_set_of_files, &s_settings_file, &s_buf);
			v_settings_files_to_run.push_back(s_settings_file);
		}//while  (!feof(pf_settings_file))

		fclose(pf_set_of_files);


		
		CInfoWindow  *pc_info_dialog;
		pc_info_dialog  =  new  CInfoWindow;
		pc_info_dialog->Text  =  S"Massive Hefan results adding...";
		for  (int  ii = 0; ii < (int) v_settings_files_to_run.size(); ii++)
		{
			pc_info_dialog->pbar_progres->Minimum = 0;
			pc_info_dialog->pbar_progres->Maximum = v_settings_files_to_run.size();
			pc_info_dialog->pbar_progres->Value = ii;
			s_buf.Format("%d/%d results added", ii, v_settings_files_to_run.size());
			pc_info_dialog->lab_text->Text  =  s_buf;
			pc_info_dialog->Refresh();
			pc_info_dialog->Show();

			v_add_result_old(s_mother_dir + "\\" + v_settings_files_to_run.at(ii),  i_comp_id_for_all_results, i_rset_id_for_all_results);
		}//for  (int  ii = 0; ii < i_number_of_setting_files; ii++)
		pc_info_dialog->pbar_progres->Minimum = 0;
		pc_info_dialog->pbar_progres->Maximum = v_settings_files_to_run.size();
		pc_info_dialog->pbar_progres->Value = v_settings_files_to_run.size();
		s_buf.Format("FINISHED! %d/%d results added", v_settings_files_to_run.size(), v_settings_files_to_run.size());
		pc_info_dialog->lab_text->Text  =  s_buf;
		pc_info_dialog->Refresh();
		pc_info_dialog->Show();
		Sleep(STANDARD_INFO_SLEEP);
		pc_info_dialog->Hide();

	}//if(openFileDialog1->ShowDialog() == DialogResult::OK)

}//System::Void CCONetmainForm::but_massive_add_results_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::but_massive_add_results_old_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;
	CString  s_buf;

	CMassiveAddInfo  *pc_general_info_dialog;
	pc_general_info_dialog  =  new  CMassiveAddInfo(pc_system);
	
	if  (pc_general_info_dialog->ShowDialog()  !=  DialogResult::OK)  return;
	int  i_comp_id_for_all_results;
	i_comp_id_for_all_results  =  pc_general_info_dialog->iResultCompId;
	int  i_rset_id_for_all_results;
	i_rset_id_for_all_results  =  pc_general_info_dialog->iResultRSetId;
	pc_general_info_dialog->Hide();
	Refresh();


	OpenFileDialog* openFileDialog1 = new OpenFileDialog();
 
    //openFileDialog1->InitialDirectory = S"D:\\praca dyplomowa - nowy interfejs\\publikacja\\FD_init" ;
	openFileDialog1->Filter = "All files (*.*)|*.*";
    openFileDialog1->FilterIndex = 0;
    openFileDialog1->RestoreDirectory = true;
	openFileDialog1->Multiselect  =  false;

    if(openFileDialog1->ShowDialog() == DialogResult::OK)
    {
		Refresh();

		if  (File::Exists(openFileDialog1->FileNames[0])  ==  false)
		{
			s_buf  =  (CString) openFileDialog1->FileNames[0];
			s_buf.Format("The file does not exist (%s)", (LPCSTR) s_buf);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
			return;	
		}//if  (File::Exists(openFileDialog1->FileNames[ii])  ==  false)


		FILE  *pf_main_file;
		s_buf  =  (CString)  openFileDialog1->FileNames[0];
		pf_main_file  =  fopen( s_buf,"r+");
		if  (pf_main_file  ==  NULL)
		{
			s_buf  =  (CString) openFileDialog1->FileNames[0];
			s_buf.Format("Can not open file (%s)", (LPCSTR) s_buf);
			c_err.vPutError(s_buf);
			c_err.vShowWindow();
			return;			
		}//if  (pf_main_file  ==  NULL)

		int  i_number_of_setting_files;
		fscanf(pf_main_file, "%d\n", &i_number_of_setting_files);

		CInfoWindow  *pc_info_dialog;
		pc_info_dialog  =  new  CInfoWindow;
		pc_info_dialog->Text  =  S"Massive old Hefan results adding...";
		CString  s_settings_file;
		for  (int  ii = 0; ii < i_number_of_setting_files; ii++)
		{
			if  (feof(pf_main_file))
			{
				s_buf  =  (CString) openFileDialog1->FileNames[0];
				s_buf.Format("Unexpected end of file (%s)", (LPCSTR) s_buf);
				c_err.vPutError(s_buf);
				c_err.vShowWindow();                			
				fclose(pf_main_file);
				return;
			}//if  (eof(pf_main_file))

			pc_info_dialog->pbar_progres->Minimum = 0;
			pc_info_dialog->pbar_progres->Maximum = i_number_of_setting_files;
			pc_info_dialog->pbar_progres->Value = ii;
			s_buf.Format("%d/%d results added", ii, i_number_of_setting_files);
			pc_info_dialog->lab_text->Text  =  s_buf;
			pc_info_dialog->Refresh();
			pc_info_dialog->Show();


			CHefanSystem::vReadLine(pf_main_file, &s_settings_file, &s_buf);
			v_add_result_old(s_settings_file,  i_comp_id_for_all_results, i_rset_id_for_all_results);
		}//for  (int  ii = 0; ii < i_number_of_setting_files; ii++)
		pc_info_dialog->pbar_progres->Minimum = 0;
		pc_info_dialog->pbar_progres->Maximum = i_number_of_setting_files;
		pc_info_dialog->pbar_progres->Value = i_number_of_setting_files;
		s_buf.Format("FINISHED! %d/%d results added", i_number_of_setting_files, i_number_of_setting_files);
		pc_info_dialog->lab_text->Text  =  s_buf;
		pc_info_dialog->Refresh();
		pc_info_dialog->Show();
		Sleep(STANDARD_INFO_SLEEP);
		pc_info_dialog->Hide();

		fclose(pf_main_file);
	}//if(openFileDialog1->ShowDialog() == DialogResult::OK)

}//System::Void CCONetmainForm::but_massive_add_results_old_Click(System::Object *  sender, System::EventArgs *  e)




System::Void CCONetmainForm::but_massive_add_conns_Click(System::Object *  sender, System::EventArgs *  e)
{
	OpenFileDialog* openFileDialog1 = new OpenFileDialog();
 
    //openFileDialog1->InitialDirectory = S"D:\\praca dyplomowa - nowy interfejs\\publikacja\\FD_init" ;
	openFileDialog1->Filter = "net files (*.con)|*.con|All files (*.*)|*.*";
    openFileDialog1->FilterIndex = 0;
    openFileDialog1->RestoreDirectory = true;
	openFileDialog1->Multiselect  =  true;

    if(openFileDialog1->ShowDialog() == DialogResult::OK)
    {
		Refresh();
		CString  s_buf;
		CError  c_err;

		c_err  =  pc_chosen_fdb->eRefreshNets();
		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

		CInfoWindow  *pc_info_dialog;
		pc_info_dialog  =  new  CInfoWindow;
		pc_info_dialog->Text  =  S"Massive connections adding by name...";
		for  (int  ii = 0;  ii < openFileDialog1->FileNames->Count; ii++)
		{
			
			pc_info_dialog->pbar_progres->Minimum = 0;
			pc_info_dialog->pbar_progres->Maximum = openFileDialog1->FileNames->Count;
			pc_info_dialog->pbar_progres->Value = ii;
			s_buf.Format("%d/%d network connections added", ii, openFileDialog1->FileNames->Count);
			pc_info_dialog->lab_text->Text  =  s_buf;
			pc_info_dialog->Refresh();
			pc_info_dialog->Show();

			v_add_conn_by_name(openFileDialog1->FileNames[ii]);

		}//for  (int  ii = 0;  ii < openFileDialog1->FileNames->Count; ii++)

		pc_info_dialog->pbar_progres->Minimum = 0;
		pc_info_dialog->pbar_progres->Maximum = openFileDialog1->FileNames->Count;
		pc_info_dialog->pbar_progres->Value = openFileDialog1->FileNames->Count;
		s_buf.Format("FINISHED! %d/%d network connections added", openFileDialog1->FileNames->Count, openFileDialog1->FileNames->Count);
		pc_info_dialog->lab_text->Text  =  s_buf;
		pc_info_dialog->Refresh();
		pc_info_dialog->Show();
		Sleep(STANDARD_INFO_SLEEP);
		pc_info_dialog->Hide();
    }//if(openFileDialog1->ShowDialog() == DialogResult::OK)
}//System::Void CCONetmainForm::but_massive_add_conns_Click(System::Object *  sender, System::EventArgs *  e)





System::Void CCONetmainForm::butAddNet_Click(System::Object *  sender, System::EventArgs *  e)
{

	if  (pc_chosen_fdb  ==  NULL)
	{
		::MessageBox(NULL,"You must choose fdb root to add a new network","Info",MB_OK);
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)


	CAddEditNet  *pc_edit_window;

	pc_edit_window  =  new  CAddEditNet(pc_system);
	pc_edit_window->vSetFDbRoot(pc_chosen_fdb);

	
	if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
	{
		v_refresh_nets();
	}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)

};//System::Void CCONetmainForm::butAddNet_Click(System::Object *  sender, System::EventArgs *  e)



void  CCONetmainForm::v_create_chosen_result_for_hefan_2_1_1_root(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{

	//Config 20  HEFAN 2.1  'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=1.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.300000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.200000   'High level crossing unordered'=0.500000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//High level crossing'=0.300000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.200000   'High level crossing unordered'=0.500000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	pc_system->eSetParameter(pvConfigs->at(0), "High level crossing", 0.3);
	pc_system->eSetParameter(pvConfigs->at(0), "High level crossing unordered", 0.5);
	pc_system->eSetParameter(pvConfigs->at(0), "High level mutation", 0.1);
	pc_system->eSetParameter(pvConfigs->at(0), "Low level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(0), "Low level mutation", 0.2);
	pc_system->eSetParameter(pvConfigs->at(0), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(0), "init shortest ways", 1);
						
	pc_system->eSetParameter(pvConfigs->at(0), "Init solution", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "exceed link capacity penalty", 10);
	pc_system->eSetParameter(pvConfigs->at(0), "flow increase", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "flow increase every x generations", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Population size", 200);
	pc_system->eSetParameter(pvConfigs->at(0), "Generation number", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Time restriction", 600);

	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm radius", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm turn on %", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm duration", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm turning off", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm min break", 5000);

	

}//void  CCONetmainForm::v_create_chosen_result_for_hefan_2_0(&c_err, &v_algorithms)




void  CCONetmainForm::v_create_chosen_result_for_hefan_2_0(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{

	//Config 56  HEFAN 2.0  'Init solution'=0.000000   'Clone repetations'=2.000000   'Init shortest ways'=1.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.500000   'High level mutation'=0.200000   'Low level crossing'=0.300000   'Low level mutation'=0.200000   'High level crossing unordered'=0.500000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//'High level crossing'=0.500000   'High level mutation'=0.200000   'Low level crossing'=0.300000   'Low level mutation'=0.200000   'High level crossing unordered'=0.500000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   

	//Config 15  HEFAN 2.2  'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=4.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.300000   'High level mutation'=0.200000   'Low level crossing'=0.500000   'Low level mutation'=0.400000   'High level crossing unordered'=0.300000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//'High level crossing'=0.300000   'High level mutation'=0.200000   'Low level crossing'=0.500000   'Low level mutation'=0.400000   'High level crossing unordered'=0.300000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   

	//Config 31  HEFAN 2.2  'Init solution'=0.000000   'Clone repetations'=2.000000   'Init shortest ways'=4.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.500000   'High level mutation'=0.200000   'Low level crossing'=0.500000   'Low level mutation'=0.400000   'High level crossing unordered'=0.500000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//'High level crossing'=0.500000   'High level mutation'=0.200000   'Low level crossing'=0.500000   'Low level mutation'=0.400000   'High level crossing unordered'=0.500000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   

	pc_system->eSetParameter(pvConfigs->at(0), "High level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(0), "High level crossing unordered", 0.5);
	pc_system->eSetParameter(pvConfigs->at(0), "High level mutation", 0.2);
	pc_system->eSetParameter(pvConfigs->at(0), "Low level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(0), "Low level mutation", 0.4);
	pc_system->eSetParameter(pvConfigs->at(0), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(0), "init shortest ways", 4);
						
	pc_system->eSetParameter(pvConfigs->at(0), "Init solution", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "exceed link capacity penalty", 10);
	pc_system->eSetParameter(pvConfigs->at(0), "flow increase", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "flow increase every x generations", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Population size", 200);
	pc_system->eSetParameter(pvConfigs->at(0), "Generation number", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Time restriction", 2400);

	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm radius", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm turn on %", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm duration", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm turning off", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm min break", 5000);

	

}//void  CCONetmainForm::v_create_chosen_result_for_hefan_2_0(&c_err, &v_algorithms)


void  CCONetmainForm::v_create_chosen_result_for_standard_ea(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{
	//Config 7  Standard EA  'init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=4.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.300000   'High level mutation'=0.200000   'High level crossing unordered'=0.500000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=40.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//'High level crossing'=0.300000   'High level mutation'=0.200000   'High level crossing unordered'=0.500000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=40.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//'High level crossing'=0.500000   'High level mutation'=0.200000   'High level crossing unordered'=0.500000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   

	pc_system->eSetParameter(pvConfigs->at(0), "High level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(0), "High level crossing unordered", 0.5);
	pc_system->eSetParameter(pvConfigs->at(0), "High level mutation", 0.2);
	pc_system->eSetParameter(pvConfigs->at(0), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(0), "init shortest ways", 4);
						
	pc_system->eSetParameter(pvConfigs->at(0), "Init solution", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "exceed link capacity penalty", 10);
	pc_system->eSetParameter(pvConfigs->at(0), "flow increase", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "flow increase every x generations", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Population size", 200);
	pc_system->eSetParameter(pvConfigs->at(0), "Generation number", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Time restriction", 720);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm radius", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm turn on %", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm duration", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm turning off", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm min break", 5000);

}//CCONetmainForm::v_create_chosen_result_for_standard_ea(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)



void  CCONetmainForm::v_create_chosen_result_for_hefan_1_0(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{

	//Config 100  HEFAN 1.0  'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=1.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.300000   'High level mutation'=0.200000   'Low level crossing'=0.300000   'Low level mutation'=0.400000   'High level crossing unordered'=0.000000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//High level crossing'=0.300000   'High level mutation'=0.200000   'Low level crossing'=0.300000   'Low level mutation'=0.400000   'High level crossing unordered'=0.000000

	//Config 27  HEFAN 1.0  'Init solution'=0.000000   'Clone repetations'=2.000000   'Init shortest ways'=4.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.500000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.400000   'High level crossing unordered'=0.500000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//High level crossing'=0.500000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.400000   'High level crossing unordered'=0.500000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   

	//Config 3  HEFAN 1.0  'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=4.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.300000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.400000   'High level crossing unordered'=0.300000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//High level crossing'=0.300000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.400000   'High level crossing unordered'=0.300000   'Population size'=200.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	pc_system->eSetParameter(pvConfigs->at(0), "High level crossing", 0.3);
	pc_system->eSetParameter(pvConfigs->at(0), "High level crossing unordered", 0.3);
	pc_system->eSetParameter(pvConfigs->at(0), "High level mutation", 0.1);
	pc_system->eSetParameter(pvConfigs->at(0), "Low level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(0), "Low level mutation", 0.4);
	pc_system->eSetParameter(pvConfigs->at(0), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(0), "init shortest ways", 4);
						
	pc_system->eSetParameter(pvConfigs->at(0), "Init solution", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "exceed link capacity penalty", 10);
	pc_system->eSetParameter(pvConfigs->at(0), "flow increase", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "flow increase every x generations", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Population size", 200);
	pc_system->eSetParameter(pvConfigs->at(0), "Generation number", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Time restriction", 360);

	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm radius", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm turn on %", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm duration", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm turning off", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "Brainstorm min break", 5000);

	

}//void  CCONetmainForm::v_create_chosen_result_for_hefan_2_0(&c_err, &v_algorithms)




void  CCONetmainForm::v_create_chosen_results_set_for_tuning_lfl(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{
	CError  c_err;

	int  i_number_of_configs  =  6;
	CCOAlgorithm  *pc_alg;

	//first creating configs by copying the first 1
	for  (int  ii = 1;  ii < i_number_of_configs; ii++)
	{
		pc_alg  =  new  CCOAlgorithm(NULL);
		pc_system->vSetSqlConn(pc_alg);

		*pc_alg  =  *(pvConfigs->at(0));
		c_err  =  pc_alg->eRefreshParams();

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

		pvConfigs->push_back(pc_alg);
	}//for  (int  ii = 1;  ii < i_number_of_configs; ii++)

	int  i_main_config_counter  =  0;


	//Config 101  HEFAN 1.1  'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=4.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.300000   'High level mutation'=0.200000   'Low level crossing'=0.300000   'Low level mutation'=0.400000   'High level crossing unordered'=0.000000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//High level crossing'=0.300000   'High level mutation'=0.200000   'Low level crossing'=0.300000   'Low level mutation'=0.400000   'High level crossing unordered'=0.000000
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.3);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level crossing", 0.3);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level mutation", 0.4);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 4);
						
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase every x generations", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Population size", 200);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Generation number", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Time restriction", 600);

	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm radius", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turn on %", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm duration", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turning off", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm min break", 5000);

	i_main_config_counter++;


	//Config 194  HEFAN 1.1  'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=1.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.300000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.200000   'High level crossing unordered'=0.500000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//High level crossing'=0.300000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.200000   'High level crossing unordered'=0.500000   
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.3);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level mutation", 0.2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 1);
						
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase every x generations", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Population size", 200);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Generation number", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Time restriction", 600);

	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm radius", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turn on %", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm duration", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turning off", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm min break", 5000);

	i_main_config_counter++;


	//Config 195  HEFAN 1.1  'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=4.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.300000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.200000   'High level crossing unordered'=0.500000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//High level crossing'=0.300000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.200000   'High level crossing unordered'=0.500000   
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.3);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level mutation", 0.2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 4);
						
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase every x generations", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Population size", 200);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Generation number", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Time restriction", 600);

	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm radius", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turn on %", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm duration", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turning off", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm min break", 5000);

	i_main_config_counter++;




	//Config 214  HEFAN 1.1  'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=1.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.300000   'High level mutation'=0.200000   'Low level crossing'=0.500000   'Low level mutation'=0.400000   'High level crossing unordered'=0.500000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//High level crossing'=0.300000   'High level mutation'=0.200000   'Low level crossing'=0.500000   'Low level mutation'=0.400000   'High level crossing unordered'=0.500000
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.3);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level mutation", 0.4);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 1);
						
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase every x generations", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Population size", 200);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Generation number", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Time restriction", 600);

	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm radius", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turn on %", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm duration", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turning off", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm min break", 5000);

	i_main_config_counter++;





	//Config 321  HEFAN 1.1  'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=4.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.500000   'High level mutation'=0.200000   'Low level crossing'=0.500000   'Low level mutation'=0.200000   'High level crossing unordered'=0.300000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//High level crossing'=0.500000   'High level mutation'=0.200000   'Low level crossing'=0.500000   'Low level mutation'=0.200000   'High level crossing unordered'=0.300000
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.3);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level mutation", 0.2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 4);
						
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase every x generations", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Population size", 200);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Generation number", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Time restriction", 600);

	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm radius", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turn on %", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm duration", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turning off", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm min break", 5000);

	i_main_config_counter++;



	//Config 354  HEFAN 1.1  'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=1.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   'Flow increase'=0.000000   'Flow increase every x generations'=0.000000   'High level crossing'=0.500000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.000000   'High level crossing unordered'=0.500000   'Population size'=0.000000   'Generation number'=0.000000   'Time restriction'=60.000000   'Brainstorm radius'=0.000000   'Brainstorm turn on %'=0.000000   'Brainstorm duration'=0.000000   'Brainstorm turning off'=0.000000   'Brainstorm min break'=5000.000000   
	//High level crossing'=0.500000   'High level mutation'=0.100000   'Low level crossing'=0.500000   'Low level mutation'=0.000000   'High level crossing unordered'=0.500000
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level crossing", 0.5);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level mutation", 0.0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 1);
						
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase every x generations", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Population size", 200);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Generation number", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Time restriction", 600);

	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm radius", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turn on %", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm duration", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turning off", 0);
	pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm min break", 5000);

	i_main_config_counter++;

};//void  CCONetmainForm::v_create_chosen_results_set_for_tuning_lfl(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)



void  CCONetmainForm::v_create_results_set_for_tuning_standard_ea(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{
	CError  c_err;

	int  i_number_of_configs  =  16;
	CCOAlgorithm  *pc_alg;

	//first creating configs by copying the first 1
	for  (int  ii = 1;  ii < i_number_of_configs; ii++)
	{
		pc_alg  =  new  CCOAlgorithm(NULL);
		pc_system->vSetSqlConn(pc_alg);

		*pc_alg  =  *(pvConfigs->at(0));
		c_err  =  pc_alg->eRefreshParams();

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

		pvConfigs->push_back(pc_alg);
	}//for  (int  ii = 1;  ii < i_number_of_configs; ii++)


	int  i_main_config_counter  =  0;

	for  (int  ii = 0;  ii < 4; ii++)
	{
		for  (int  ij = 0;  ij < 2; ij++)
		{
			
					//for  (int  in = 0;  in < 2; in++)
					//{
						if  (ii == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.3);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.3);
						}//if  (ii == 0)

						if  (ii == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.3);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.5);
						}//if  (ii == 1)

						if  (ii == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.5);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.3);
						}//if  (ii == 2)

						if  (ii == 3)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.5);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.5);
						}//if  (ii == 3)

						

						if  (ij == 0)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.1);

						if  (ij == 1)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.2);





						/*if  (in == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 1);
						}//if  (in == 0)

						if  (in == 1)
						{*/
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 4);
						//}//if  (in == 1)

												
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase every x generations", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Population size", 200);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Generation number", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Time restriction", 60);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm radius", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turn on %", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm duration", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turning off", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm min break", 5000);

						i_main_config_counter++;						
					
					//}//for  (int  in = 0;  in < 3; in++)
				
		}//for  (int  ij = 0;  ij < 3; ij++)
	
	}//for  (int  ii = 1;  ii < 7; ii++)

}//void  CCONetmainForm::v_create_results_set_for_tuning_standard_ea(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)


void  CCONetmainForm::v_create_results_set_for_tuning_lfl(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{
	CError  c_err;

	int  i_number_of_configs  =  32;
	CCOAlgorithm  *pc_alg;

	//first creating configs by copying the first 1
	for  (int  ii = 1;  ii < i_number_of_configs; ii++)
	{
		pc_alg  =  new  CCOAlgorithm(NULL);
		pc_system->vSetSqlConn(pc_alg);

		*pc_alg  =  *(pvConfigs->at(0));
		c_err  =  pc_alg->eRefreshParams();

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

		pvConfigs->push_back(pc_alg);
	}//for  (int  ii = 1;  ii < i_number_of_configs; ii++)


	int  i_main_config_counter  =  0;

	for  (int  ii = 0;  ii < 4; ii++)
	{
		for  (int  ij = 0;  ij < 2; ij++)
		{
			for  (int  ik = 0;  ik < 2; ik++)
			{
			
				for  (int  im = 0;  im < 2; im++)
				{
					
					//for  (int  in = 0;  in < 2; in++)
					//{
						if  (ii == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.3);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.3);
						}//if  (ii == 0)

						if  (ii == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.3);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.5);
						}//if  (ii == 1)

						if  (ii == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.5);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.3);
						}//if  (ii == 2)

						if  (ii == 3)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.5);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.5);
						}//if  (ii == 3)

						/*if  (ii == 4)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.5);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0);
						}//if  (ii == 4)

						if  (ii == 5)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.5);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.3);
						}//if  (ii == 5)

						if  (ii == 6)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing", 0.5);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level crossing unordered", 0.5);
						}//if  (ii == 6)*/


						if  (ij == 0)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.1);

						if  (ij == 1)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.2);

						/*if  (ij == 2)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "High level mutation", 0.2);*/


						if  (ik == 0)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level crossing", 0.3);
						if  (ik == 1)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level crossing", 0.5);
						/*if  (ik == 2)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level crossing", 0.5);*/



						if  (im == 0)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level mutation", 0.2);
						if  (im == 1)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level mutation", 0.4);
						/*if  (im == 2)
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Low level mutation", 0.4);*/




						/*if  (in == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 1);
						}//if  (in == 0)*/

						//if  (in == 1)
						//{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 4);
						//}//if  (in == 1)

												
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "flow increase every x generations", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Population size", 200);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Generation number", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Time restriction", 60);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm radius", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turn on %", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm duration", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm turning off", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Brainstorm min break", 5000);

						i_main_config_counter++;						
					
					//}//for  (int  in = 0;  in < 3; in++)
				
				}//for  (int  im = 0;  im < 3; im++)


			}//for  (int  ij = 0;  ij < 3; ij++)

		}//for  (int  ij = 0;  ij < 3; ij++)
	
	}//for  (int  ii = 1;  ii < 7; ii++)


}//void  CCONetmainForm::v_create_results_set_for_tuning_lfl(CError  *pcErr,  vector  <CCOAlgorithm>  *pvConfigs)




/*
Config 13  vmEA HEFAN  'init solution'=0.000000   'Clone repetations'=2.000000   
'Init shortest ways'=4.000000   'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   
'Exceed link capacity penalty'=10.000000   
'max time'=600.000000   'glue infections'=1.000000   'template fitness check'=1.000000   
'pattern pool size'=500.000000   'the same pattern check'=0.000000   'preferred pattern length'=0.000000   
'minimal pattern length'=3.000000   'length or entrophy at pattern number check'=0.000000   
'use templates at virus init'=1.000000   
'virus generations'=30.000000   'virus population'=30.000000   
'virus population reduction'=0.970000   
'virus prob cut'=0.090000   'virus prob splice'=0.150000   
'virus prob mutation'=0.100000   
'virus prob rem gene'=0.100000   'virus prob add gene'=0.100000   
'virus prob low cross'=0.500000   'virus prob low mut'=0.400000   
'virus prob init mut'=1.000000   'virus virginity rounds'=10.000000   
'no new ct'=0.000000   
*/
void  CCONetmainForm::v_create_chosen_result_for_vmea(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{

	pc_system->eSetParameter(pvConfigs->at(0), "clone repetations", 2);
	pc_system->eSetParameter(pvConfigs->at(0), "init shortest ways", 4);
													
	pc_system->eSetParameter(pvConfigs->at(0), "Init solution", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "top individuals", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "allow exceed link capacity", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "exceed link capacity penalty", 10);

	pc_system->eSetParameter(pvConfigs->at(0), "max time", 2400);
	pc_system->eSetParameter(pvConfigs->at(0), "glue infections", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "template fitness check", 1);
	pc_system->eSetParameter(pvConfigs->at(0), "pattern pool size", 500);
	pc_system->eSetParameter(pvConfigs->at(0), "the same pattern check", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "preferred pattern length", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "minimal pattern length", 3);
	pc_system->eSetParameter(pvConfigs->at(0), "length or entrophy at pattern number check", 0);
	pc_system->eSetParameter(pvConfigs->at(0), "use templates at virus init", 1);

	pc_system->eSetParameter(pvConfigs->at(0), "virus generations", 30);
	pc_system->eSetParameter(pvConfigs->at(0), "virus population", 30);
	pc_system->eSetParameter(pvConfigs->at(0), "virus population reduction", 0.97);
	pc_system->eSetParameter(pvConfigs->at(0), "virus prob cut", 0.09);
	pc_system->eSetParameter(pvConfigs->at(0), "virus prob splice", 0.15);

	pc_system->eSetParameter(pvConfigs->at(0), "virus prob mutation", 0.1);
	pc_system->eSetParameter(pvConfigs->at(0), "virus prob rem gene", 0.1);
	pc_system->eSetParameter(pvConfigs->at(0), "virus prob add gene", 0.1);

	pc_system->eSetParameter(pvConfigs->at(0), "virus prob low cross", 0.5);
	pc_system->eSetParameter(pvConfigs->at(0), "virus prob low mut", 0.4);
	pc_system->eSetParameter(pvConfigs->at(0), "virus prob init mut", 1);

	pc_system->eSetParameter(pvConfigs->at(0), "virus virginity rounds", 10);

	pc_system->eSetParameter(pvConfigs->at(0), "no new ct", -1);

}//void  CCONetmainForm::v_create_chosen_result_for_hefan_2_0(&c_err, &v_algorithms)






void  CCONetmainForm::v_create_results_set_for_tuning_vmea_init_mut_tuning(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{
	CError  c_err;

	int  i_number_of_configs  =  9;
	CCOAlgorithm  *pc_alg;

	//first creating configs by copying the first 1
	for  (int  ii = 1;  ii < i_number_of_configs; ii++)
	{
		pc_alg  =  new  CCOAlgorithm(NULL);
		pc_system->vSetSqlConn(pc_alg);

		*pc_alg  =  *(pvConfigs->at(0));
		c_err  =  pc_alg->eRefreshParams();

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

		pvConfigs->push_back(pc_alg);
	}//for  (int  ii = 1;  ii < i_number_of_configs; ii++)


	int  i_main_config_counter  =  0;

	for  (int  ii = 0;  ii < 3; ii++)
	{
		//for  (int  ij = 0;  ij < 3; ij++)
		{
			//for  (int  ik = 0;  ik < 3; ik++)
			{
			
				//for  (int  im = 0;  im < 2; im++)
				{
					
					
						if  (ii == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob init mut", 0);
						}//if  (ii == 0)
						if  (ii == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob init mut", 0.2);
						}//if  (ii == 0)
						if  (ii == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob init mut", 0.4);
						}//if  (ii == 0)


		


						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 4);
																		
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "max time", 1500);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "glue infections", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "template fitness check", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "pattern pool size", 500);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "the same pattern check", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "preferred pattern length", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "minimal pattern length", 3);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "length or entrophy at pattern number check", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "use templates at virus init", 1);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 10);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 50);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population reduction", 0.97);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob cut", 0.05);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob splice", 0.3);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob mutation", 0.3);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob rem gene", 0.3);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob add gene", 0.1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob low cross", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob low mut", 0.3);
						//pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob init mut", 0);



						i_main_config_counter++;						
					
					
				
				}//for  (int  im = 0;  im < 3; im++)


			}//for  (int  ij = 0;  ij < 3; ij++)

		}//for  (int  ij = 0;  ij < 3; ij++)
	
	}//for  (int  ii = 1;  ii < 7; ii++)


}//void  CCONetmainForm::v_create_results_set_for_tuning_lfl(CError  *pcErr,  vector  <CCOAlgorithm>  *pvConfigs)



/*
Config 5  vmEA HEFAN  'init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=4.000000   
'Top individuals'=1.000000   
'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   
'max time'=600.000000   
'glue infections'=1.000000   'template fitness check'=1.000000   
'pattern pool size'=500.000000   'the same pattern check'=0.000000   
'preferred pattern length'=0.000000   'minimal pattern length'=3.000000   
'length or entrophy at pattern number check'=0.000000   
'use templates at virus init'=1.000000   
'virus generations'=20.000000   'virus population'=130.000000   'virus population reduction'=0.970000   
'virus prob cut'=0.050000   'virus prob splice'=0.300000   
'virus prob mutation'=0.300000   'virus prob rem gene'=0.300000   'virus prob add gene'=0.100000   
'virus prob low cross'=0.000000   'virus prob low mut'=0.300000   'virus prob init mut'=1.000000   
'virus virginity rounds'=10.000000   'no new ct'=0.000000   
*/


void  CCONetmainForm::v_create_results_set_for_tuning_vmea_final(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{
	CError  c_err;

	int  i_number_of_configs  =  9;
	CCOAlgorithm  *pc_alg;

	//first creating configs by copying the first 1
	for  (int  ii = 1;  ii < i_number_of_configs; ii++)
	{
		pc_alg  =  new  CCOAlgorithm(NULL);
		pc_system->vSetSqlConn(pc_alg);

		*pc_alg  =  *(pvConfigs->at(0));
		c_err  =  pc_alg->eRefreshParams();

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

		pvConfigs->push_back(pc_alg);
	}//for  (int  ii = 1;  ii < i_number_of_configs; ii++)


	int  i_main_config_counter  =  0;

	for  (int  ii = 0;  ii < 3; ii++)
	{
		for  (int  ij = 0;  ij < 3; ij++)
		{
			//for  (int  ik = 0;  ik < 3; ik++)
			{
			
				//for  (int  im = 0;  im < 2; im++)
				{

						if  (ii == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 10);
						}//if  (ii == 0)
						if  (ii == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 20);
						}//if  (ii == 0)
						if  (ii == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 30);
						}//if  (ii == 0)


						if  (ij == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 50);
						}//if  (ij == 0)
						if  (ij == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 90);
						}//if  (ij == 0)
						if  (ij == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 130);
						}//if  (ij == 0)
						
					


						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 4);
																		
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "max time", 600);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "glue infections", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "template fitness check", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "pattern pool size", 500);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "the same pattern check", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "preferred pattern length", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "minimal pattern length", 3);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "length or entrophy at pattern number check", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "use templates at virus init", 1);

						/*pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 10);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 50);*/
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population reduction", 0.97);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob cut", 0.05);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob splice", 0.3);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob mutation", 0.3);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob rem gene", 0.3);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob add gene", 0.1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob low cross", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob low mut", 0.3);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob init mut", 1.0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus virginity rounds", 10);


						i_main_config_counter++;						
					
					
				
				}//for  (int  im = 0;  im < 3; im++)


			}//for  (int  ij = 0;  ij < 3; ij++)

		}//for  (int  ij = 0;  ij < 3; ij++)
	
	}//for  (int  ii = 1;  ii < 7; ii++)

}//void  v_create_results_set_for_tuning_vmea_final(&c_err, &v_algorithms)




/*
Config 2  VMEA HEFAN  
'Init solution'=1.000000   'Clone repetations'=2.000000   'Init shortest ways'=4.000000   
'Top individuals'=1.000000   'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   

'max time'=600.000000   
'glue infections'=1.000000   'template fitness check'=1.000000   
'pattern pool size'=500.000000   'the same pattern check'=0.000000   
'preferred pattern length'=0.000000   'minimal pattern length'=3.000000   
'length or entrophy at pattern number check'=0.000000   'use templates at virus init'=1.000000   

'virus generations'=10.000000   
'virus population'=50.000000   
'virus population reduction'=0.970000   
'virus prob cut'=0.050000   'virus prob splice'=0.300000   
'virus prob mutation'=0.300000   'virus prob rem gene'=0.300000   'virus prob add gene'=0.100000   
'virus prob low cross'=0.000000   'virus prob low mut'=0.300000   
'virus prob init mut'=0.000000   
*/


void  CCONetmainForm::v_create_results_set_for_tuning_vmea_cut_splice_tuning(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{
	CError  c_err;

	int  i_number_of_configs  =  9;
	CCOAlgorithm  *pc_alg;

	//first creating configs by copying the first 1
	for  (int  ii = 1;  ii < i_number_of_configs; ii++)
	{
		pc_alg  =  new  CCOAlgorithm(NULL);
		pc_system->vSetSqlConn(pc_alg);

		*pc_alg  =  *(pvConfigs->at(0));
		c_err  =  pc_alg->eRefreshParams();

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

		pvConfigs->push_back(pc_alg);
	}//for  (int  ii = 1;  ii < i_number_of_configs; ii++)


	int  i_main_config_counter  =  0;

	for  (int  ii = 0;  ii < 3; ii++)
	{
		for  (int  ij = 0;  ij < 3; ij++)
		{
			//for  (int  ik = 0;  ik < 3; ik++)
			{
			
				//for  (int  im = 0;  im < 2; im++)
				{
					
					
						if  (ii == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob cut", 0.07);
						}//if  (ii == 0)
						if  (ii == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob cut", 0.09);
						}//if  (ii == 0)
						if  (ii == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob cut", 0.11);
						}//if  (ii == 0)


						if  (ij == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob splice", 0.15);
						}//if  (ij == 0)
						if  (ij == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob splice", 0.10);
						}//if  (ij == 0)
						if  (ij == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob splice", 0.05);
						}//if  (ij == 0)


					


						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 4);
																		
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "max time", 600);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "glue infections", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "template fitness check", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "pattern pool size", 500);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "the same pattern check", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "preferred pattern length", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "minimal pattern length", 3);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "length or entrophy at pattern number check", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "use templates at virus init", 1);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 20);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 130);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population reduction", 0.97);
						/*pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob cut", 0.05);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob splice", 0.3);*/

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob mutation", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob rem gene", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob add gene", 0);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob low cross", 0.5);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob low mut", 0.4);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob init mut", 1);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus virginity rounds", 10);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "no new ct", 1);



						i_main_config_counter++;						
					
					
				
				}//for  (int  im = 0;  im < 3; im++)


			}//for  (int  ij = 0;  ij < 3; ij++)

		}//for  (int  ij = 0;  ij < 3; ij++)
	
	}//for  (int  ii = 1;  ii < 7; ii++)


}//void  CCONetmainForm::v_create_results_set_for_tuning_lfl(CError  *pcErr,  vector  <CCOAlgorithm>  *pvConfigs)






/*
Config 3  vmEA HEFAN  'init solution'=0.000000   
'Clone repetations'=2.000000   'Init shortest ways'=4.000000   'Top individuals'=1.000000   
'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   
'max time'=600.000000   'glue infections'=1.000000   'template fitness check'=1.000000   
'pattern pool size'=500.000000   'the same pattern check'=0.000000   'preferred pattern length'=0.000000   
'minimal pattern length'=3.000000   'length or entrophy at pattern number check'=0.000000   
'use templates at virus init'=1.000000   'virus generations'=20.000000   'virus population'=130.000000   
'virus population reduction'=0.970000   
'virus prob cut'=0.090000   'virus prob splice'=0.150000   'virus prob mutation'=0.000000   'virus prob rem gene'=0.000000   'virus prob add gene'=0.000000   'virus prob low cross'=0.500000   'virus prob low mut'=0.400000   'virus prob init mut'=1.000000   'virus virginity rounds'=10.000000   'no new ct'=1.000000   

TO SAMO: :)
Config 11  vmEA HEFAN  'init solution'=0.000000   
'Clone repetations'=2.000000   'Init shortest ways'=4.000000   'Top individuals'=1.000000   
'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   
'max time'=600.000000   'glue infections'=1.000000   'template fitness check'=1.000000   
'pattern pool size'=500.000000   'the same pattern check'=0.000000   'preferred pattern length'=0.000000   
'minimal pattern length'=3.000000   'length or entrophy at pattern number check'=0.000000   
'use templates at virus init'=1.000000   'virus generations'=20.000000   'virus population'=130.000000   
'virus population reduction'=0.970000   
'virus prob cut'=0.090000   'virus prob splice'=0.150000   'virus prob mutation'=0.000000   'virus prob rem gene'=0.000000   'virus prob add gene'=0.000000   'virus prob low cross'=0.500000   'virus prob low mut'=0.400000   'virus prob init mut'=1.000000   'virus virginity rounds'=10.000000   'no new ct'=1.000000   
*/


void  CCONetmainForm::v_create_results_set_for_tuning_vmea_mut_tuning(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{
	CError  c_err;

	int  i_number_of_configs  =  9;
	CCOAlgorithm  *pc_alg;

	//first creating configs by copying the first 1
	for  (int  ii = 1;  ii < i_number_of_configs; ii++)
	{
		pc_alg  =  new  CCOAlgorithm(NULL);
		pc_system->vSetSqlConn(pc_alg);

		*pc_alg  =  *(pvConfigs->at(0));
		c_err  =  pc_alg->eRefreshParams();

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

		pvConfigs->push_back(pc_alg);
	}//for  (int  ii = 1;  ii < i_number_of_configs; ii++)


	int  i_main_config_counter  =  0;

	for  (int  ii = 0;  ii < 3; ii++)
	{
		for  (int  ij = 0;  ij < 3; ij++)
		{
			//for  (int  ik = 0;  ik < 3; ik++)
			{
			
				//for  (int  im = 0;  im < 2; im++)
				{
					
					
						if  (ii == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob mutation", 0);
						}//if  (ii == 0)
						if  (ii == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob mutation", 0.1);
						}//if  (ii == 0)
						if  (ii == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob mutation", 0.2);
						}//if  (ii == 0)


						if  (ij == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob rem gene", 0);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob add gene", 0);
						}//if  (ij == 0)
						if  (ij == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob rem gene", 0.1);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob add gene", 0.1);
						}//if  (ij == 0)
						if  (ij == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob rem gene", 0.2);
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob add gene", 0.2);
						}//if  (ij == 0)


						


						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 4);
																		
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "max time", 600);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "glue infections", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "template fitness check", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "pattern pool size", 500);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "the same pattern check", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "preferred pattern length", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "minimal pattern length", 3);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "length or entrophy at pattern number check", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "use templates at virus init", 1);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 20);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 130);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population reduction", 0.97);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob cut", 0.09);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob splice", 0.15);

						/*pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob mutation", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob rem gene", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob add gene", 0);*/

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob low cross", 0.5);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob low mut", 0.4);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob init mut", 1);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus virginity rounds", 10);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "no new ct", 1);



						i_main_config_counter++;						
					
					
				
				}//for  (int  im = 0;  im < 3; im++)


			}//for  (int  ij = 0;  ij < 3; ij++)

		}//for  (int  ij = 0;  ij < 3; ij++)
	
	}//for  (int  ii = 1;  ii < 7; ii++)


}//void  CCONetmainForm::v_create_results_set_for_tuning_lfl(CError  *pcErr,  vector  <CCOAlgorithm>  *pvConfigs)





/*
vmEA HEFAN  'init solution'=0.000000   'Clone repetations'=2.000000   
'Init shortest ways'=4.000000   'Top individuals'=1.000000   
'Allow exceed link capacity'=1.000000   'Exceed link capacity penalty'=10.000000   
'max time'=600.000000   'glue infections'=1.000000   'template fitness check'=1.000000   
'pattern pool size'=500.000000   'the same pattern check'=0.000000   'preferred pattern length'=0.000000   
'minimal pattern length'=3.000000   'length or entrophy at pattern number check'=0.000000   
'use templates at virus init'=1.000000   
'virus generations'=20.000000   'virus population'=130.000000   
'virus population reduction'=0.970000   'virus prob cut'=0.090000   
'virus prob splice'=0.150000   'virus prob mutation'=0.100000   
'virus prob rem gene'=0.100000   'virus prob add gene'=0.100000   
'virus prob low cross'=0.500000   'virus prob low mut'=0.400000   
'virus prob init mut'=1.000000   'virus virginity rounds'=10.000000   
'no new ct'=1.000000      */



void  CCONetmainForm::v_create_results_set_for_tuning_vmea(CError  *pcErr,  vector  <CCOAlgorithm  *>  *pvConfigs)
{
	CError  c_err;

	int  i_number_of_configs  =  9;
	CCOAlgorithm  *pc_alg;

	//first creating configs by copying the first 1
	for  (int  ii = 1;  ii < i_number_of_configs; ii++)
	{
		pc_alg  =  new  CCOAlgorithm(NULL);
		pc_system->vSetSqlConn(pc_alg);

		*pc_alg  =  *(pvConfigs->at(0));
		c_err  =  pc_alg->eRefreshParams();

		if  (c_err)
		{
			c_err.vShowWindow();
			return;
		}//if  (c_err)

		pvConfigs->push_back(pc_alg);
	}//for  (int  ii = 1;  ii < i_number_of_configs; ii++)


	int  i_main_config_counter  =  0;

	for  (int  ii = 0;  ii < 3; ii++)
	{
		for  (int  ij = 0;  ij < 3; ij++)
		{
			//for  (int  ik = 0;  ik < 2; ik++)
			{
					
						if  (ii == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 20);
						}//if  (ii == 0)
						if  (ii == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 30);
						}//if  (ii == 0)
						if  (ii == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 40);
						}//if  (ii == 0)





						if  (ij == 0)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 15);
						}//if  (ij == 0)
						if  (ij == 1)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 30);
						}//if  (ij == 0)
						if  (ij == 2)
						{
							pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 60);
						}//if  (ij == 0)


						


						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "clone repetations", 2);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "init shortest ways", 4);
																		
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "Init solution", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "top individuals", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "allow exceed link capacity", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "exceed link capacity penalty", 10);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "max time", 600);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "glue infections", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "template fitness check", 1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "pattern pool size", 500);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "the same pattern check", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "preferred pattern length", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "minimal pattern length", 3);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "length or entrophy at pattern number check", 0);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "use templates at virus init", 1);

						/*pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus generations", 20);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population", 130);*/
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus population reduction", 0.97);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob cut", 0.09);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob splice", 0.15);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob mutation", 0.1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob rem gene", 0.1);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob add gene", 0.1);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob low cross", 0.5);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob low mut", 0.4);
						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus prob init mut", 1);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "virus virginity rounds", 10);

						pc_system->eSetParameter(pvConfigs->at(i_main_config_counter), "no new ct", 0);


						i_main_config_counter++;						
					
					
				//}//for  (int  im = 0;  im < 3; im++)


			}//for  (int  ij = 0;  ij < 3; ij++)

		}//for  (int  ij = 0;  ij < 3; ij++)
	
	}//for  (int  ii = 1;  ii < 7; ii++)


}//void  CCONetmainForm::v_create_results_set_for_tuning_lfl(CError  *pcErr,  vector  <CCOAlgorithm>  *pvConfigs)







System::Void CCONetmainForm::but_results_test_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;
	vector  <CCONetConn  *>  v_conns;

	//c_err  =  pc_system->eSelectConnections(&v_conns, "Select * from connections where con_name = '104059' OR con_name = '114d07' OR con_name = '128080' OR con_name = '144088' OR con_name = '162b03' OR con_name = 'g120077' ");
	//c_err  =  pc_system->eSelectConnections(&v_conns, "Select * from connections where net_id = ANY  (select net_id from networks where root_id = '3' and net_name like '104%%' order by net_name) ");
	c_err  =  pc_system->eSelectConnections(&v_conns, "Select * from connections where net_id = ANY  (select net_id from networks where root_id = '6' order by net_name) ");
	//c_err  =  pc_system->eSelectConnections(&v_conns, "Select * from connections where con_name like '1040%' OR con_name like '1140%' OR con_name like '1280%' OR con_name like '1440%' OR con_name like '1620%' OR con_name like '1621%'");
	//c_err  =  pc_system->eSelectConnections(&v_conns, "Select * from connections where con_name = 'g120083' OR con_name = '104b02' OR con_name = '114d00' OR con_name = '128b09' ");
	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)



	vector  <CCOAlgorithm  *>  v_algorithms;
	//c_err  =  pc_system->eSelectAlgorithms(&v_algorithms,  "Select * from algorithms where alg_name='HEFAN 2.2'");
	c_err  =  pc_system->eSelectAlgorithms(&v_algorithms,  "Select * from algorithms where alg_name='VMEA HEFAN'");

	if  (c_err)
	{
		for  (int  ii = 0; ii < (int) v_conns.size(); ii++)
			delete  v_conns.at(ii);
		for  (int  ii = 0; ii < (int) v_algorithms.size(); ii++)
			delete  v_algorithms.at(ii);
		c_err.vShowWindow();
		return;	
	}//if  (c_err)

	for  (int  ii = 0; ii < (int) v_algorithms.size(); ii++)
	{
		c_err  =  v_algorithms.at(ii)->eRefreshParams();
		if  (c_err)
		{
			for  (int  ii = 0; ii < (int) v_conns.size(); ii++)
				delete  v_conns.at(ii);
			for  (int  ii = 0; ii < (int) v_algorithms.size(); ii++)
				delete  v_algorithms.at(ii);
			c_err.vShowWindow();
			return;	
		}//if  (c_err)
	}//for  (int  ii = 0; ii < v_algorithms.size(); ii++)

	
	//v_create_chosen_result_for_hefan_2_0(&c_err, &v_algorithms);
	//v_create_results_set_for_tuning_lfl(&c_err, &v_algorithms);
	//v_create_chosen_results_set_for_tuning_lfl(&c_err, &v_algorithms);
	//v_create_results_set_for_tuning_lfl(&c_err, &v_algorithms);
	//v_create_chosen_result_for_standard_ea(&c_err, &v_algorithms);
	//v_create_results_set_for_tuning_standard_ea(&c_err, &v_algorithms);
	//v_create_chosen_result_for_standard_ea(&c_err, &v_algorithms);
	//v_create_chosen_result_for_hefan_1_0(&c_err, &v_algorithms);
	//v_create_results_set_for_tuning_vmea(&c_err, &v_algorithms);
	//v_create_results_set_for_tuning_vmea_mut_tuning(&c_err, &v_algorithms);
	//v_create_results_set_for_tuning_vmea_cut_splice_tuning(&c_err, &v_algorithms);
	//v_create_results_set_for_tuning_vmea_final(&c_err, &v_algorithms);
	//v_create_results_set_for_tuning_vmea_init_mut_tuning(&c_err, &v_algorithms);
	v_create_chosen_result_for_vmea(&c_err, &v_algorithms);

	
	if  (c_err)
	{
		for  (int  ii = 0; ii < (int) v_conns.size(); ii++)
			delete  v_conns.at(ii);
		for  (int  ii = 0; ii < (int) v_algorithms.size(); ii++)
			delete  v_algorithms.at(ii);
		c_err.vShowWindow();
		return;	
	}//if  (c_err)
		
	
	c_err  =  pc_system->eGenerateComputationSet_2_0
		(
		pc_chosen_fdb,
		"co ACTIVE vmea no start 4 init 2400.txt",  "D:\\COnetREsults", "LFL",
		"D:\\co ACTIVE vmea no start 4 init 2400", &v_conns,  &v_algorithms,
		"LFL"
		);
	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)


}//System::Void CCONetmainForm::but_results_test_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CCONetmainForm::but_compare_set_Click(System::Object*  sender, System::EventArgs*  e)
{
	//generate report
	CError  c_err;
	CString  s_result_select_0, s_result_select_1, s_buf;
	
	s_result_select_0  =  "Select * from results where ";
	s_result_select_1  =  "Select * from results where ";

	//s_buf.Format("%d", list_choose_set->Items->Count);
	//::MessageBox(NULL, s_buf,s_buf, MB_OK);


	int  i_rset_id;
	int  i_chosen_number = 0;
	for  (int ii = 0; ii < (int) list_choose_set->Items->Count; ii++)
	{
		if  (
			atoi(
				(CString)  list_choose_set->Items->Item[ii]->SubItems->Item
					[list_choose_set->Items->Item[ii]->SubItems->Count - 1]->Text
				)
			==
			1
			)
		{
			i_rset_id  =
				pv_rsets->at
					(
					atoi(
						(CString)  list_choose_set->Items->Item[ii]->SubItems->Item
						[list_choose_set->Items->Item[ii]->SubItems->Count - 2]->Text
						)
					)->iGetId();

			
			s_buf.Format(" (results_set_id='%d') ", i_rset_id);
			
			if  (i_chosen_number  ==  0)
				s_result_select_0  +=  s_buf;
			else
				s_result_select_1  +=  s_buf;

			i_chosen_number++;
		}//if  (
	
	}//for  (int ii = 0; ii < (int) list_choose_set->Items->Count; ii++)

	
	if  ( (i_chosen_number  !=  1)&&(i_chosen_number  !=  2) )
	{
		::MessageBox(NULL, "Wybierz 1, lub 2 serie danych", "info",  MB_OK);
		return;	
	}//if  (list_choose_set->Items->Count == 0)



	bool  b_net_chosen  =  false;
	int  i_con_id;
	for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)
	{
		if  (
			atoi(
				(CString)  list_choose_nets->Items->Item[ii]->SubItems->Item
					[list_choose_nets->Items->Item[ii]->SubItems->Count - 1]->Text
				)
			==
			1
			)
		{
			i_con_id  =  pc_chosen_fdb->pvGetNets()->at
				(
				atoi(
					(CString)  list_choose_nets->Items->Item[ii]->SubItems->Item
					[list_choose_nets->Items->Item[ii]->SubItems->Count - 2]->Text
					)
				)->pvGetNetConns()->at
					(
					atoi(
						(CString)  list_choose_nets->Items->Item[ii]->SubItems->Item
						[list_choose_nets->Items->Item[ii]->SubItems->Count - 3]->Text
						)
					)->iGetId();

			if  ( b_net_chosen  ==  false )
			{
				s_result_select_0  +=  " AND ";
				s_result_select_1  +=  " AND ";
			}//if  ( (b_set_chosen  ==  true)&&(b_net_chosen  ==  false) )

			if  (b_net_chosen  ==  false)
				s_buf.Format(" (con_id='%d' ", i_con_id);
			else
				s_buf.Format(" or con_id='%d' ", i_con_id);


			b_net_chosen  =  true;

			s_result_select_0  +=  s_buf;
			s_result_select_1  +=  s_buf;

		}//if  (

	}//for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)

	if  (b_net_chosen  ==  true)  
	{
		s_result_select_0  +=  ") ";
		s_result_select_1  +=  ") ";
	}//if  (b_net_chosen  ==  true)  
	

	vector  <CCOResult  *>  v_results_0, v_results_1;

	c_err  =  pc_system->eSelectResults
		(
		&v_results_0, 
		s_result_select_0
		);
	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)

	
	if  (i_chosen_number == 2)
	{
		c_err  =  pc_system->eSelectResults
		(
		&v_results_1, 
		s_result_select_1
		);
		if  (c_err)
		{
			c_err.vShowWindow();
			return;	
		}//if  (c_err)	
	}//if  (list_choose_set->Items->Count > 2)



	CString  s_result_file;
	
    saveFileDialog1->Filter = "folder files (*)|*";
    saveFileDialog1->FilterIndex = 1;
    saveFileDialog1->RestoreDirectory = true;

	if(saveFileDialog1->ShowDialog() == DialogResult::OK)
	{
        s_result_file  =  (CString)  saveFileDialog1->FileNames[0];
	
		if  (i_chosen_number  ==  2)
			c_err = pc_system->eGenerateComputationSet_Comparison
				(
				pc_chosen_fdb,
				"D:\\COnetREsults", combo_ext->Text,
				s_result_file,
				&v_results_0,
				&v_results_1
				);
		else
			c_err = pc_system->eGenerateComputationSet_Comparison
				(
				pc_chosen_fdb,
				"D:\\COnetREsults", combo_ext->Text,
				s_result_file,
				&v_results_0,
				NULL
				);


		if  (c_err)
		{
			c_err.vShowWindow();
			return;	
		}//if  (c_err)

	}//if(saveFileDialog1->ShowDialog() == DialogResult::OK)	

}//System::Void CCONetmainForm::but_compare_set_Click(System::Object*  sender, System::EventArgs*  e)




System::Void CCONetmainForm::but_report_general_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;
	CString  s_result_select, s_buf;
	bool  b_set_chosen  =  false;

	s_result_select  =  "Select * from results where ";

	int  i_rset_id;
	for  (int ii = 0; ii < (int) list_choose_set->Items->Count; ii++)
	{
		if  (
			atoi(
				(CString)  list_choose_set->Items->Item[ii]->SubItems->Item
					[list_choose_set->Items->Item[ii]->SubItems->Count - 1]->Text
				)
			==
			1
			)
		{
			i_rset_id  =
				pv_rsets->at
					(
					atoi(
						(CString)  list_choose_set->Items->Item[ii]->SubItems->Item
						[list_choose_set->Items->Item[ii]->SubItems->Count - 2]->Text
						)
					)->iGetId();

			if  (b_set_chosen  ==  false)
				s_buf.Format(" (results_set_id='%d' ", i_rset_id);
			else
				s_buf.Format(" or results_set_id='%d' ", i_rset_id);


			b_set_chosen  =  true;

			s_result_select  +=  s_buf;
		}//if  (
	
	}//for  (int ii = 0; ii < (int) list_choose_set->Items->Count; ii++)

	if  (b_set_chosen  ==  true)  s_result_select  +=  ") ";

	bool  b_net_chosen  =  false;
	int  i_con_id;
	for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)
	{
		if  (
			atoi(
				(CString)  list_choose_nets->Items->Item[ii]->SubItems->Item
					[list_choose_nets->Items->Item[ii]->SubItems->Count - 1]->Text
				)
			==
			1
			)
		{
			i_con_id  =  pc_chosen_fdb->pvGetNets()->at
				(
				atoi(
					(CString)  list_choose_nets->Items->Item[ii]->SubItems->Item
					[list_choose_nets->Items->Item[ii]->SubItems->Count - 2]->Text
					)
				)->pvGetNetConns()->at
					(
					atoi(
						(CString)  list_choose_nets->Items->Item[ii]->SubItems->Item
						[list_choose_nets->Items->Item[ii]->SubItems->Count - 3]->Text
						)
					)->iGetId();

			if  ( (b_set_chosen  ==  true)&&(b_net_chosen  ==  false) )
				s_result_select  +=  " AND ";

			if  (b_net_chosen  ==  false)
				s_buf.Format(" (con_id='%d' ", i_con_id);
			else
				s_buf.Format(" or con_id='%d' ", i_con_id);


			b_net_chosen  =  true;

			s_result_select  +=  s_buf;

		}//if  (

	}//for  (int ii = 0; ii < (int) list_choose_nets->Items->Count; ii++)

	if  (b_net_chosen  ==  true)  s_result_select  +=  ") ";

	//"Select * from results where (results_set_id='2' OR results_set_id='8' OR results_set_id='9' OR results_set_id='10') and \
	//con_id = ANY (Select con_id from connections where net_id = ANY (Select net_id from networks where root_id = '3' and net_name like 'g%%' order by net_name) )"



	vector  <CCOResult  *>  v_results;

	c_err  =  pc_system->eSelectResults
		(
		&v_results, 
		s_result_select
		);
	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)

	bool  b_1_is_max;
	if  (chk_report_max->Checked  ==  true)
		b_1_is_max  =  true;
	else
		b_1_is_max  =  false;


	CString  s_result_file;
	
    saveFileDialog1->Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
    saveFileDialog1->FilterIndex = 1;
    saveFileDialog1->RestoreDirectory = true;

	if(saveFileDialog1->ShowDialog() == DialogResult::OK)
	{
        s_result_file  =  (CString)  saveFileDialog1->FileNames[0];
	
		c_err  =  pc_system->eGenerateReportForResults(s_result_file,&v_results, combo_normalize->SelectedIndex, b_1_is_max);
		if  (c_err)
		{
			c_err.vShowWindow();
			return;	
		}//if  (c_err)
	}//if(saveFileDialog1->ShowDialog() == DialogResult::OK)

}//System::Void CCONetmainForm::but_report_general_Click(System::Object *  sender, System::EventArgs *  e)




















