#include "StdAfx.h"
#include "AddEditAlgorithm.h"

using namespace CONetAdmin;

System::Void CAddEditAlgorithm::CAddEditAlgorithm_Activated(System::Object *  sender, System::EventArgs *  e)
{
	if  (b_activated  ==  false)
	{
		CError  c_err;

		if  (pc_alg  ==  NULL)
		{
			c_err.vPutError("No algorithm given!");
			c_err.vShowWindow();
			Close();
			return;
		}//if  (pc_fdb_root  ==  NULL)

		
		int  i_id;
		CString  s_alg_name;
		CString  s_alg_comments;

		pc_alg->vGetData
			(
			&i_id,
			&s_alg_name,  &s_alg_comments
			);

		textAlgName->Text  =  (String *)  s_alg_name;
		textAlgComments->Text  =  (String *)  s_alg_comments;

		v_refresh_params();
		
		b_activated  =  true;
	}//if  (b_activated  ==  false)

};//System::Void CAddEditAlgorithm::CAddEditAlgorithm_Activated(System::Object *  sender, System::EventArgs *  e)



System::Void CAddEditAlgorithm::butOk_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (pc_alg  ==  NULL)
	{
		c_err.vPutError("No algorithm assigned");
		c_err.vShowWindow();
		return;
	}//if  (pc_fdb_root  ==  NULL)

	
	//now loading data from window
	CString  s_new_alg_name;
	CString  s_new_alg_comments;

	s_new_alg_name  =  textAlgName->Text;
	s_new_alg_comments  =  textAlgComments->Text;

	c_err  =  pc_alg->eUpdate(s_new_alg_name, s_new_alg_comments);
	

	if  (c_err)
	{
		c_err.vShowWindow();
		return;	
	}//if  (c_err)

	DialogResult  =  DialogResult::OK;
};//System::Void CAddEditAlgorithm::butOk_Click(System::Object *  sender, System::EventArgs *  e)



void  CAddEditAlgorithm::v_refresh_params()
{
	CError  c_err;

	if  (pc_alg  ==  NULL)
	{
		c_err.vPutError("No algorithm given!");
		c_err.vShowWindow();
		Close();
		return;
	}//if  (pc_fdb_root  ==  NULL)

	c_err  =  pc_alg->eRefreshParams();

	if  (c_err)
	{
		c_err.vShowWindow();
		return;
	}//if  (c_err)

	int  i_id;
	int  i_alg_id;
	CString  s_param_name;
	double  d_param_default;

	list_params->Items->Clear();
	for  (int  ii = 0; ii < (int)  pc_alg->pvGetParams()->size(); ii++)
	{
		pc_alg->pvGetParams()->at(ii)->vGetData
			(
			&i_id,
			&i_alg_id,
			&s_param_name,
			&d_param_default
			);

		ListViewItem* item_buf  =  new ListViewItem((String *) s_param_name);
		CString  s_buf;
		s_buf.Format("%lf", d_param_default);
		item_buf->SubItems->Add(s_buf);

		s_buf.Format("%d", ii);
		item_buf->SubItems->Add(s_buf);

		list_params->Items->Add(item_buf);
		
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)

	i_selected_param_index  =  -1;

	//list_fdb_roots_MouseUp(NULL, NULL);
	list_params->Refresh();
}//void  CAddEditAlgorithm::v_refresh_params()


System::Void CAddEditAlgorithm::but_add_param_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;

	if  (pc_alg  ==  NULL)
	{
		c_err.vPutError("No algorithm specified!");
		c_err.vShowWindow();
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)

	CAddEditAlgParam  *pc_edit_window;

	pc_edit_window  =  new  CAddEditAlgParam;
	pc_edit_window->textAlgParamName->Text  =  "";
	pc_edit_window->textAlgParamDefault->Text  =  "";

	
	if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
	{
		CString  s_default;
		double  d_default;
		s_default  =  pc_edit_window->textAlgParamDefault->Text;
		d_default  =  atof((LPCSTR) s_default);

        c_err  =  pc_alg->eAddParam(pc_edit_window->textAlgParamName->Text, d_default);

		if  (c_err)
		{
			c_err.vShowWindow();
			return;		
		}//if  (c_err)
		else
			v_refresh_params();
	}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)

}//System::Void CAddEditAlgorithm::but_add_param_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CAddEditAlgorithm::but_edit_param_Click(System::Object *  sender, System::EventArgs *  e)
{
	CError  c_err;


	if  (pc_alg  ==  NULL)
	{
		::MessageBox(NULL,"No algorithm selected!","Info",MB_OK);
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)

	if  ( (i_selected_param_index  <  (int)  pc_alg->pvGetParams()->size())&&(i_selected_param_index  >=  0) )
	{
		
		CAddEditAlgParam  *pc_edit_window;

		pc_edit_window  =  new  CAddEditAlgParam;

		int  i_id;
		int  i_alg_id;
		CString  s_param_name;
		double  d_param_default;

		pc_alg->pvGetParams()->at(i_selected_param_index)->vGetData
			(
			&i_id,
			&i_alg_id,
			&s_param_name,
			&d_param_default
			);

        pc_edit_window->textAlgParamName->Text  =  (String *) s_param_name;

		CString  s_buf;
		s_buf.Format("%lf", d_param_default);
		pc_edit_window->textAlgParamDefault->Text  =  (String *)  s_buf;
		
		
		if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)
		{
			double  d_default;
			s_buf  =  pc_edit_window->textAlgParamDefault->Text;
			d_default  =  atof((LPCSTR) s_buf);

			c_err  =  pc_alg->pvGetParams()->at(i_selected_param_index)->eUpdate
				(
				i_alg_id,
				pc_edit_window->textAlgParamName->Text,
				d_default
				);

			if  (c_err)  c_err.vShowWindow();

			v_refresh_params();
		}//if  (pc_edit_window->ShowDialog()  ==  DialogResult::OK)	

		
	}//if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	else
	{
		::MessageBox(NULL,"No item marked or not connected to the database", "Info", MB_OK);	
	}//else  if  ( (list_fdb_roots->SelectedIndex  >=  0)&&(pc_system->bIsConnected()  ==  true) )
	
}//System::Void CAddEditAlgorithm::but_edit_param_Click(System::Object *  sender, System::EventArgs *  e)


System::Void CAddEditAlgorithm::but_rem_param_Click(System::Object *  sender, System::EventArgs *  e)
{
	if  (pc_alg  ==  NULL)
	{
		::MessageBox(NULL,"No algorithm selected!","Info",MB_OK);
		return;	
	}//if  (pc_chosen_fdb  ==  NULL)

	if  ( (i_selected_param_index  <  (int)  pc_alg->pvGetParams()->size())&&(i_selected_param_index  >=  0) )
	{
		CError  c_err;

		int  i_id;
		int  i_alg_id;
		CString  s_param_name;
		double  d_param_default;

		pc_alg->pvGetParams()->at(i_selected_param_index)->vGetData
			(
			&i_id,
			&i_alg_id,
			&s_param_name,
			&d_param_default
			);

		CString  s_buf;
		s_buf.Format("Are You sure You want to delete this algorithm parameter?:'%s'?", (LPCSTR) s_param_name);
		if  (::MessageBox(NULL,  s_buf, "Delete?", MB_YESNO)  ==  IDYES)  
		{
			c_err  =  pc_alg->eRemoveParam(i_selected_param_index);
			if  (c_err)  c_err.vShowWindow();
			v_refresh_params();
		}//if  (::MessageBox(NULL,  s_buf, "Pytanie", MB_YESNO)  ==  IDYES)  

	}//if  (i_selected_index  <  i_fdb_len)
	else
	{
        ::MessageBox(NULL,"Unexpected error caused by wrong selection index."	, "Error", MB_OK);
	}//else  if  (i_selected_index  <  i_fdb_len)

};//System::Void CAddEditAlgorithm::but_rem_param_Click(System::Object *  sender, System::EventArgs *  e)



System::Void CAddEditAlgorithm::list_params_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
	ListViewItem *pc_selected = list_params->GetItemAt(e->X, e->Y);

    if (pc_selected != NULL)
    {
		i_selected_param_index  
			=  atoi((CString) pc_selected->SubItems->Item[pc_selected->SubItems->Count - 1]->Text);

		if  ( (i_selected_param_index  <  (int) pc_alg->pvGetParams()->size())&&(i_selected_param_index  >=  0) )
		{
			
		}//if  (list_fdb_roots->SelectedIndex  <  i_fdb_len)
		else
		{
			i_selected_param_index  =  -1;
		}//else  if  (i_selected_index  <  i_fdb_len)
    }//if (pc_selected != NULL)
}//System::Void CAddEditAlgorithm::list_params_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)



System::Void CAddEditAlgorithm::list_params_DoubleClick(System::Object *  sender, System::EventArgs *  e)
{
    but_edit_param_Click(sender, e);
}//System::Void CAddEditAlgorithm::list_params_DoubleClick(System::Object *  sender, System::EventArgs *  e)



System::Void CAddEditAlgorithm::list_params_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)
{
	if  (list_params->ListViewItemSorter  !=  NULL)
	{
		list_item_comparer  *pc_buf;

		bool  b_casted  =  true;
		try{pc_buf = __try_cast<list_item_comparer*>(list_params->ListViewItemSorter);}
		catch(System::InvalidCastException  *pce)
		{b_casted  =  false;}

		if  (b_casted)
		{
			if  (pc_buf->iGetColumn()  ==  e->Column)
				list_params->ListViewItemSorter = new list_item_comparer(e->Column, !(pc_buf->bGetDirection()) );
			else
				list_params->ListViewItemSorter = new list_item_comparer(e->Column);
		
		}//if  (b_casted)
		else
			list_params->ListViewItemSorter = new list_item_comparer(e->Column);
	
	}//if  (list_params->ListViewItemSorter  !=  NULL)
	else
		list_params->ListViewItemSorter = new list_item_comparer(e->Column);

};//System::Void CAddEditAlgorithm::list_params_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e)















