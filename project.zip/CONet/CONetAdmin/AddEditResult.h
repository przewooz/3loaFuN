#pragma once

#include  "atlstr.h"  //CString
#include  "system.h"


//list item comparer
#include  "list_comparer.h"


using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


using namespace CONetDbTools;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for AddEditResult
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CAddEditResult : public System::Windows::Forms::Form
	{
	public: 
		CAddEditResult(CSystem  *pcSystem)
		{
			ps_init_dir  =  new  CString;
			*ps_init_dir  =  "C:\\";
			pc_system  =  pcSystem;

			pv_rsets  =  new  vector <CCOResultSet *>;
			pv_computers  =  new  vector <CCOComputer *>;
			pv_algorithms  =  new  vector <CCOAlgorithm *>;
			pv_ffuncs  =  new  vector <CCOFitFunc *>;

			pv_files  =  new  vector <CString>;

			pc_fdb_root  =  NULL;
			i_net_index  =  -1;
			i_conn_index  =  -1;
			i_selected_param_index  =  -1;
			i_selected_file_index  =  -1;
			b_activated  =  false;

			i_result_index  =  -1;
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			for  (int ii = 0; ii < (int) pv_rsets->size(); ii++)
				delete  pv_rsets->at(ii);
			pv_rsets->clear();
			delete  pv_rsets;
			
			for  (int ii = 0; ii < (int) pv_computers->size(); ii++)
				delete  pv_computers->at(ii);
			pv_computers->clear();
			delete  pv_computers;

			for  (int ii = 0; ii < (int) pv_algorithms->size(); ii++)
				delete  pv_algorithms->at(ii);
			pv_algorithms->clear();
			delete  pv_algorithms;

			for  (int ii = 0; ii < (int) pv_ffuncs->size(); ii++)
				delete  pv_ffuncs->at(ii);
			pv_ffuncs->clear();
			delete  pv_ffuncs;


			pv_files->clear();
			delete  pv_files;

		
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}

	public:  void  vSetFDbRootNetIndConnInd(CCOFDbRoot  *pcFDbRoot, int iNetIndex, int iConnIndex)  
			 {pc_fdb_root = pcFDbRoot;  i_net_index = iNetIndex;  i_conn_index = iConnIndex;};
	public:  void  vSetResultIndex(int iResultIndex)  {i_result_index = iResultIndex;};
        
	private:

		CSystem  *pc_system;

		bool  b_activated;
		CCOFDbRoot  *pc_fdb_root;
		int  i_net_index;
		int  i_conn_index;
		int  i_selected_param_index;
		int  i_selected_file_index;








	private: System::Windows::Forms::OpenFileDialog *  openFileDialog1;
	private: System::Windows::Forms::ListView *  list_files;
	private: System::Windows::Forms::ColumnHeader *  columnHeader4;
	private: System::Windows::Forms::Button *  but_rem_file;
	public: System::Windows::Forms::TextBox *  text_comments;

	private: System::Windows::Forms::Label *  label13;
	public: System::Windows::Forms::TextBox *  text_ff_val;
	private: System::Windows::Forms::DateTimePicker *  dtpTime;
	private: System::Windows::Forms::DateTimePicker *  dtpDate;
	private: System::Windows::Forms::Button *  but_generate;
	private: System::Windows::Forms::GroupBox *  groupBox12;
	private: System::Windows::Forms::Button *  but_param_value;
	public: System::Windows::Forms::TextBox *  text_param_value;
	private: System::Windows::Forms::GroupBox *  groupBox13;
	private: System::Windows::Forms::ListView *  list_params;
	private: System::Windows::Forms::ColumnHeader *  columnHeader1;
	private: System::Windows::Forms::ColumnHeader *  columnHeader2;
	private: System::Windows::Forms::ColumnHeader *  columnHeader3;
	private: System::Windows::Forms::Label *  label14;
	private: System::Windows::Forms::ComboBox *  comboRSets;



		int  i_result_index;

		void  v_refresh_parameters();
		void  v_refresh_dropdowns();
		void  v_refresh_files();

		vector <CCOResultSet *>  *pv_rsets;
		vector <CCOComputer *>  *pv_computers;
		vector <CCOAlgorithm *>  *pv_algorithms;
		vector <CCOFitFunc *>  *pv_ffuncs;

		vector <CString>  *pv_files;

		CString  *ps_init_dir;//just for open files dialog
				 

	private: System::Windows::Forms::GroupBox *  groupBox6;
	private: System::Windows::Forms::GroupBox *  groupBox3;

	public: System::Windows::Forms::TextBox *  textConnDir;
	private: System::Windows::Forms::Label *  label3;

	public: System::Windows::Forms::TextBox *  textConnName;
	private: System::Windows::Forms::Label *  label10;
	private: System::Windows::Forms::GroupBox *  groupBox2;
	public: System::Windows::Forms::TextBox *  textNetName;
	private: System::Windows::Forms::Label *  label1;
	public: System::Windows::Forms::TextBox *  textNetDir;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::GroupBox *  groupBox1;
	public: System::Windows::Forms::TextBox *  textFDbName;
	private: System::Windows::Forms::Label *  label6;
	public: System::Windows::Forms::TextBox *  textFDbDir;
	private: System::Windows::Forms::Label *  label4;
	private: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::GroupBox *  groupBox5;

	private: System::Windows::Forms::Label *  label5;
	private: System::Windows::Forms::ComboBox *  comboAlgorithm;
	private: System::Windows::Forms::Label *  label7;
	private: System::Windows::Forms::ComboBox *  comboFFunc;
	private: System::Windows::Forms::Label *  label8;
	private: System::Windows::Forms::ComboBox *  comboComput;

	private: System::Windows::Forms::Label *  label9;

	private: System::Windows::Forms::Label *  label11;
	public: System::Windows::Forms::TextBox *  textTime;

	private: System::Windows::Forms::Label *  label12;
	private: System::Windows::Forms::GroupBox *  groupBox7;
	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::Button *  butOk;


	private: System::Windows::Forms::GroupBox *  groupBox8;
	private: System::Windows::Forms::GroupBox *  groupBox9;
	private: System::Windows::Forms::GroupBox *  groupBox10;
	private: System::Windows::Forms::Button *  but_add_file;
	public: System::Windows::Forms::TextBox *  text_chosen_file;
	private: System::Windows::Forms::Button *  but_find_file;
	private: System::Windows::Forms::GroupBox *  groupBox11;









		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox6 = new System::Windows::Forms::GroupBox();
			this->groupBox5 = new System::Windows::Forms::GroupBox();
			this->label14 = new System::Windows::Forms::Label();
			this->comboRSets = new System::Windows::Forms::ComboBox();
			this->dtpTime = new System::Windows::Forms::DateTimePicker();
			this->dtpDate = new System::Windows::Forms::DateTimePicker();
			this->text_ff_val = new System::Windows::Forms::TextBox();
			this->label13 = new System::Windows::Forms::Label();
			this->label12 = new System::Windows::Forms::Label();
			this->text_comments = new System::Windows::Forms::TextBox();
			this->label11 = new System::Windows::Forms::Label();
			this->textTime = new System::Windows::Forms::TextBox();
			this->label9 = new System::Windows::Forms::Label();
			this->label8 = new System::Windows::Forms::Label();
			this->comboComput = new System::Windows::Forms::ComboBox();
			this->label7 = new System::Windows::Forms::Label();
			this->comboFFunc = new System::Windows::Forms::ComboBox();
			this->label5 = new System::Windows::Forms::Label();
			this->comboAlgorithm = new System::Windows::Forms::ComboBox();
			this->groupBox3 = new System::Windows::Forms::GroupBox();
			this->textConnDir = new System::Windows::Forms::TextBox();
			this->label3 = new System::Windows::Forms::Label();
			this->textConnName = new System::Windows::Forms::TextBox();
			this->label10 = new System::Windows::Forms::Label();
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->textNetName = new System::Windows::Forms::TextBox();
			this->label1 = new System::Windows::Forms::Label();
			this->textNetDir = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->textFDbName = new System::Windows::Forms::TextBox();
			this->label6 = new System::Windows::Forms::Label();
			this->textFDbDir = new System::Windows::Forms::TextBox();
			this->label4 = new System::Windows::Forms::Label();
			this->groupBox4 = new System::Windows::Forms::GroupBox();
			this->groupBox9 = new System::Windows::Forms::GroupBox();
			this->groupBox13 = new System::Windows::Forms::GroupBox();
			this->list_params = new System::Windows::Forms::ListView();
			this->columnHeader1 = new System::Windows::Forms::ColumnHeader();
			this->columnHeader2 = new System::Windows::Forms::ColumnHeader();
			this->columnHeader3 = new System::Windows::Forms::ColumnHeader();
			this->groupBox12 = new System::Windows::Forms::GroupBox();
			this->text_param_value = new System::Windows::Forms::TextBox();
			this->but_param_value = new System::Windows::Forms::Button();
			this->groupBox8 = new System::Windows::Forms::GroupBox();
			this->groupBox11 = new System::Windows::Forms::GroupBox();
			this->list_files = new System::Windows::Forms::ListView();
			this->columnHeader4 = new System::Windows::Forms::ColumnHeader();
			this->but_generate = new System::Windows::Forms::Button();
			this->groupBox10 = new System::Windows::Forms::GroupBox();
			this->but_rem_file = new System::Windows::Forms::Button();
			this->but_add_file = new System::Windows::Forms::Button();
			this->text_chosen_file = new System::Windows::Forms::TextBox();
			this->but_find_file = new System::Windows::Forms::Button();
			this->groupBox7 = new System::Windows::Forms::GroupBox();
			this->butCancel = new System::Windows::Forms::Button();
			this->butOk = new System::Windows::Forms::Button();
			this->openFileDialog1 = new System::Windows::Forms::OpenFileDialog();
			this->groupBox6->SuspendLayout();
			this->groupBox5->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox9->SuspendLayout();
			this->groupBox13->SuspendLayout();
			this->groupBox12->SuspendLayout();
			this->groupBox8->SuspendLayout();
			this->groupBox11->SuspendLayout();
			this->groupBox10->SuspendLayout();
			this->groupBox7->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox6
			// 
			this->groupBox6->Controls->Add(this->groupBox5);
			this->groupBox6->Controls->Add(this->groupBox3);
			this->groupBox6->Controls->Add(this->groupBox2);
			this->groupBox6->Controls->Add(this->groupBox1);
			this->groupBox6->Dock = System::Windows::Forms::DockStyle::Left;
			this->groupBox6->Location = System::Drawing::Point(0, 0);
			this->groupBox6->Name = S"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(464, 557);
			this->groupBox6->TabIndex = 40;
			this->groupBox6->TabStop = false;
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->label14);
			this->groupBox5->Controls->Add(this->comboRSets);
			this->groupBox5->Controls->Add(this->dtpTime);
			this->groupBox5->Controls->Add(this->dtpDate);
			this->groupBox5->Controls->Add(this->text_ff_val);
			this->groupBox5->Controls->Add(this->label13);
			this->groupBox5->Controls->Add(this->label12);
			this->groupBox5->Controls->Add(this->text_comments);
			this->groupBox5->Controls->Add(this->label11);
			this->groupBox5->Controls->Add(this->textTime);
			this->groupBox5->Controls->Add(this->label9);
			this->groupBox5->Controls->Add(this->label8);
			this->groupBox5->Controls->Add(this->comboComput);
			this->groupBox5->Controls->Add(this->label7);
			this->groupBox5->Controls->Add(this->comboFFunc);
			this->groupBox5->Controls->Add(this->label5);
			this->groupBox5->Controls->Add(this->comboAlgorithm);
			this->groupBox5->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox5->Location = System::Drawing::Point(3, 376);
			this->groupBox5->Name = S"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(458, 178);
			this->groupBox5->TabIndex = 39;
			this->groupBox5->TabStop = false;
			this->groupBox5->Text = S"Result info";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(240, 24);
			this->label14->Name = S"label14";
			this->label14->Size = System::Drawing::Size(65, 16);
			this->label14->TabIndex = 43;
			this->label14->Text = S"Results Set:";
			// 
			// comboRSets
			// 
			this->comboRSets->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboRSets->Location = System::Drawing::Point(304, 24);
			this->comboRSets->Name = S"comboRSets";
			this->comboRSets->Size = System::Drawing::Size(144, 21);
			this->comboRSets->TabIndex = 42;
			// 
			// dtpTime
			// 
			this->dtpTime->Format = System::Windows::Forms::DateTimePickerFormat::Time;
			this->dtpTime->Location = System::Drawing::Point(152, 152);
			this->dtpTime->Name = S"dtpTime";
			this->dtpTime->Size = System::Drawing::Size(72, 20);
			this->dtpTime->TabIndex = 41;
			// 
			// dtpDate
			// 
			this->dtpDate->Format = System::Windows::Forms::DateTimePickerFormat::Short;
			this->dtpDate->Location = System::Drawing::Point(72, 152);
			this->dtpDate->Name = S"dtpDate";
			this->dtpDate->Size = System::Drawing::Size(80, 20);
			this->dtpDate->TabIndex = 40;
			// 
			// text_ff_val
			// 
			this->text_ff_val->Location = System::Drawing::Point(104, 104);
			this->text_ff_val->Name = S"text_ff_val";
			this->text_ff_val->Size = System::Drawing::Size(120, 20);
			this->text_ff_val->TabIndex = 39;
			this->text_ff_val->Text = S"";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(8, 104);
			this->label13->Name = S"label13";
			this->label13->Size = System::Drawing::Size(55, 16);
			this->label13->TabIndex = 38;
			this->label13->Text = S"Fitt Value:";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(240, 56);
			this->label12->Name = S"label12";
			this->label12->Size = System::Drawing::Size(62, 16);
			this->label12->TabIndex = 35;
			this->label12->Text = S"Comments:";
			// 
			// text_comments
			// 
			this->text_comments->Location = System::Drawing::Point(240, 72);
			this->text_comments->Multiline = true;
			this->text_comments->Name = S"text_comments";
			this->text_comments->Size = System::Drawing::Size(208, 96);
			this->text_comments->TabIndex = 34;
			this->text_comments->Text = S"";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(8, 152);
			this->label11->Name = S"label11";
			this->label11->Size = System::Drawing::Size(61, 16);
			this->label11->TabIndex = 33;
			this->label11->Text = S"Generated:";
			// 
			// textTime
			// 
			this->textTime->Location = System::Drawing::Point(104, 128);
			this->textTime->Name = S"textTime";
			this->textTime->Size = System::Drawing::Size(120, 20);
			this->textTime->TabIndex = 32;
			this->textTime->Text = S"";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(8, 128);
			this->label9->Name = S"label9";
			this->label9->Size = System::Drawing::Size(33, 16);
			this->label9->TabIndex = 31;
			this->label9->Text = S"Time:";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(8, 72);
			this->label8->Name = S"label8";
			this->label8->Size = System::Drawing::Size(57, 16);
			this->label8->TabIndex = 29;
			this->label8->Text = S"Computer:";
			// 
			// comboComput
			// 
			this->comboComput->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboComput->Location = System::Drawing::Point(104, 72);
			this->comboComput->Name = S"comboComput";
			this->comboComput->Size = System::Drawing::Size(121, 21);
			this->comboComput->TabIndex = 28;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(8, 48);
			this->label7->Name = S"label7";
			this->label7->Size = System::Drawing::Size(75, 16);
			this->label7->TabIndex = 27;
			this->label7->Text = S"Fittness func.:";
			// 
			// comboFFunc
			// 
			this->comboFFunc->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboFFunc->Location = System::Drawing::Point(104, 48);
			this->comboFFunc->Name = S"comboFFunc";
			this->comboFFunc->Size = System::Drawing::Size(121, 21);
			this->comboFFunc->TabIndex = 26;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(8, 24);
			this->label5->Name = S"label5";
			this->label5->Size = System::Drawing::Size(55, 16);
			this->label5->TabIndex = 25;
			this->label5->Text = S"Algorithm:";
			// 
			// comboAlgorithm
			// 
			this->comboAlgorithm->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboAlgorithm->Location = System::Drawing::Point(104, 24);
			this->comboAlgorithm->Name = S"comboAlgorithm";
			this->comboAlgorithm->Size = System::Drawing::Size(121, 21);
			this->comboAlgorithm->TabIndex = 0;
			this->comboAlgorithm->SelectedIndexChanged += new System::EventHandler(this, &CAddEditResult::comboAlgorithm_SelectedIndexChanged);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->textConnDir);
			this->groupBox3->Controls->Add(this->label3);
			this->groupBox3->Controls->Add(this->textConnName);
			this->groupBox3->Controls->Add(this->label10);
			this->groupBox3->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox3->Location = System::Drawing::Point(3, 264);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(458, 112);
			this->groupBox3->TabIndex = 38;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = S"Connections config info";
			// 
			// textConnDir
			// 
			this->textConnDir->Location = System::Drawing::Point(40, 80);
			this->textConnDir->Name = S"textConnDir";
			this->textConnDir->ReadOnly = true;
			this->textConnDir->Size = System::Drawing::Size(304, 20);
			this->textConnDir->TabIndex = 35;
			this->textConnDir->Text = S"";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(24, 64);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(90, 16);
			this->label3->TabIndex = 34;
			this->label3->Text = S"Configuration dir:";
			// 
			// textConnName
			// 
			this->textConnName->Location = System::Drawing::Point(40, 32);
			this->textConnName->Name = S"textConnName";
			this->textConnName->ReadOnly = true;
			this->textConnName->Size = System::Drawing::Size(304, 20);
			this->textConnName->TabIndex = 25;
			this->textConnName->Text = S"";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(24, 16);
			this->label10->Name = S"label10";
			this->label10->Size = System::Drawing::Size(106, 16);
			this->label10->TabIndex = 24;
			this->label10->Text = S"Configuration name:";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->textNetName);
			this->groupBox2->Controls->Add(this->label1);
			this->groupBox2->Controls->Add(this->textNetDir);
			this->groupBox2->Controls->Add(this->label2);
			this->groupBox2->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox2->Location = System::Drawing::Point(3, 152);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(458, 112);
			this->groupBox2->TabIndex = 37;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Net info";
			// 
			// textNetName
			// 
			this->textNetName->Location = System::Drawing::Point(40, 32);
			this->textNetName->Name = S"textNetName";
			this->textNetName->ReadOnly = true;
			this->textNetName->Size = System::Drawing::Size(304, 20);
			this->textNetName->TabIndex = 37;
			this->textNetName->Text = S"";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(16, 16);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(56, 16);
			this->label1->TabIndex = 36;
			this->label1->Text = S"Net name:";
			// 
			// textNetDir
			// 
			this->textNetDir->Location = System::Drawing::Point(40, 80);
			this->textNetDir->Name = S"textNetDir";
			this->textNetDir->ReadOnly = true;
			this->textNetDir->Size = System::Drawing::Size(304, 20);
			this->textNetDir->TabIndex = 35;
			this->textNetDir->Text = S"";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(16, 64);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(41, 16);
			this->label2->TabIndex = 34;
			this->label2->Text = S"Net dir:";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->textFDbName);
			this->groupBox1->Controls->Add(this->label6);
			this->groupBox1->Controls->Add(this->textFDbDir);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox1->Location = System::Drawing::Point(3, 16);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(458, 136);
			this->groupBox1->TabIndex = 36;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"FDb info";
			// 
			// textFDbName
			// 
			this->textFDbName->Location = System::Drawing::Point(40, 32);
			this->textFDbName->Name = S"textFDbName";
			this->textFDbName->ReadOnly = true;
			this->textFDbName->Size = System::Drawing::Size(304, 20);
			this->textFDbName->TabIndex = 37;
			this->textFDbName->Text = S"";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(16, 16);
			this->label6->Name = S"label6";
			this->label6->Size = System::Drawing::Size(60, 16);
			this->label6->TabIndex = 36;
			this->label6->Text = S"FDb name:";
			// 
			// textFDbDir
			// 
			this->textFDbDir->Location = System::Drawing::Point(40, 80);
			this->textFDbDir->Multiline = true;
			this->textFDbDir->Name = S"textFDbDir";
			this->textFDbDir->ReadOnly = true;
			this->textFDbDir->Size = System::Drawing::Size(304, 48);
			this->textFDbDir->TabIndex = 35;
			this->textFDbDir->Text = S"";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(16, 64);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(67, 16);
			this->label4->TabIndex = 34;
			this->label4->Text = S"FDb root dir:";
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->groupBox9);
			this->groupBox4->Controls->Add(this->groupBox8);
			this->groupBox4->Controls->Add(this->groupBox7);
			this->groupBox4->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox4->Location = System::Drawing::Point(464, 0);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(384, 557);
			this->groupBox4->TabIndex = 41;
			this->groupBox4->TabStop = false;
			// 
			// groupBox9
			// 
			this->groupBox9->Controls->Add(this->groupBox13);
			this->groupBox9->Controls->Add(this->groupBox12);
			this->groupBox9->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox9->Location = System::Drawing::Point(3, 336);
			this->groupBox9->Name = S"groupBox9";
			this->groupBox9->Size = System::Drawing::Size(378, 170);
			this->groupBox9->TabIndex = 48;
			this->groupBox9->TabStop = false;
			this->groupBox9->Text = S"Parameters";
			// 
			// groupBox13
			// 
			this->groupBox13->Controls->Add(this->list_params);
			this->groupBox13->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox13->Location = System::Drawing::Point(3, 16);
			this->groupBox13->Name = S"groupBox13";
			this->groupBox13->Size = System::Drawing::Size(372, 103);
			this->groupBox13->TabIndex = 56;
			this->groupBox13->TabStop = false;
			// 
			// list_params
			// 
			System::Windows::Forms::ColumnHeader* __mcTemp__1[] = new System::Windows::Forms::ColumnHeader*[3];
			__mcTemp__1[0] = this->columnHeader1;
			__mcTemp__1[1] = this->columnHeader2;
			__mcTemp__1[2] = this->columnHeader3;
			this->list_params->Columns->AddRange(__mcTemp__1);
			this->list_params->Dock = System::Windows::Forms::DockStyle::Fill;
			this->list_params->FullRowSelect = true;
			this->list_params->GridLines = true;
			this->list_params->Location = System::Drawing::Point(3, 16);
			this->list_params->Name = S"list_params";
			this->list_params->Size = System::Drawing::Size(366, 84);
			this->list_params->TabIndex = 2;
			this->list_params->View = System::Windows::Forms::View::Details;
			this->list_params->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CAddEditResult::list_params_MouseDown);
			this->list_params->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CAddEditResult::list_params_ColumnClick);
			// 
			// columnHeader1
			// 
			this->columnHeader1->Text = S"Name";
			this->columnHeader1->Width = 154;
			// 
			// columnHeader2
			// 
			this->columnHeader2->Text = S"Value";
			this->columnHeader2->Width = 90;
			// 
			// columnHeader3
			// 
			this->columnHeader3->Text = S"Default";
			this->columnHeader3->Width = 90;
			// 
			// groupBox12
			// 
			this->groupBox12->Controls->Add(this->text_param_value);
			this->groupBox12->Controls->Add(this->but_param_value);
			this->groupBox12->Dock = System::Windows::Forms::DockStyle::Bottom;
			this->groupBox12->Location = System::Drawing::Point(3, 119);
			this->groupBox12->Name = S"groupBox12";
			this->groupBox12->Size = System::Drawing::Size(372, 48);
			this->groupBox12->TabIndex = 55;
			this->groupBox12->TabStop = false;
			// 
			// text_param_value
			// 
			this->text_param_value->Location = System::Drawing::Point(8, 16);
			this->text_param_value->Name = S"text_param_value";
			this->text_param_value->Size = System::Drawing::Size(96, 20);
			this->text_param_value->TabIndex = 56;
			this->text_param_value->Text = S"";
			// 
			// but_param_value
			// 
			this->but_param_value->Location = System::Drawing::Point(128, 16);
			this->but_param_value->Name = S"but_param_value";
			this->but_param_value->Size = System::Drawing::Size(96, 23);
			this->but_param_value->TabIndex = 55;
			this->but_param_value->Text = S"Reset value";
			this->but_param_value->Click += new System::EventHandler(this, &CAddEditResult::but_param_value_Click);
			// 
			// groupBox8
			// 
			this->groupBox8->Controls->Add(this->groupBox11);
			this->groupBox8->Controls->Add(this->groupBox10);
			this->groupBox8->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox8->Location = System::Drawing::Point(3, 16);
			this->groupBox8->Name = S"groupBox8";
			this->groupBox8->Size = System::Drawing::Size(378, 320);
			this->groupBox8->TabIndex = 47;
			this->groupBox8->TabStop = false;
			this->groupBox8->Text = S"Files";
			// 
			// groupBox11
			// 
			this->groupBox11->Controls->Add(this->list_files);
			this->groupBox11->Controls->Add(this->but_generate);
			this->groupBox11->Dock = System::Windows::Forms::DockStyle::Fill;
			this->groupBox11->Location = System::Drawing::Point(3, 144);
			this->groupBox11->Name = S"groupBox11";
			this->groupBox11->Size = System::Drawing::Size(372, 173);
			this->groupBox11->TabIndex = 52;
			this->groupBox11->TabStop = false;
			this->groupBox11->Text = S"Currently added files";
			// 
			// list_files
			// 
			System::Windows::Forms::ColumnHeader* __mcTemp__2[] = new System::Windows::Forms::ColumnHeader*[1];
			__mcTemp__2[0] = this->columnHeader4;
			this->list_files->Columns->AddRange(__mcTemp__2);
			this->list_files->Dock = System::Windows::Forms::DockStyle::Fill;
			this->list_files->FullRowSelect = true;
			this->list_files->Location = System::Drawing::Point(3, 39);
			this->list_files->Name = S"list_files";
			this->list_files->Size = System::Drawing::Size(366, 131);
			this->list_files->TabIndex = 57;
			this->list_files->View = System::Windows::Forms::View::Details;
			this->list_files->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &CAddEditResult::list_files_MouseDown);
			this->list_files->DoubleClick += new System::EventHandler(this, &CAddEditResult::list_files_DoubleClick);
			this->list_files->ColumnClick += new System::Windows::Forms::ColumnClickEventHandler(this, &CAddEditResult::list_files_ColumnClick);
			// 
			// columnHeader4
			// 
			this->columnHeader4->Text = S"File name";
			this->columnHeader4->Width = 240;
			// 
			// but_generate
			// 
			this->but_generate->Dock = System::Windows::Forms::DockStyle::Top;
			this->but_generate->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, (System::Byte)238);
			this->but_generate->Location = System::Drawing::Point(3, 16);
			this->but_generate->Name = S"but_generate";
			this->but_generate->Size = System::Drawing::Size(366, 23);
			this->but_generate->TabIndex = 54;
			this->but_generate->Text = S"GENERATE FROM FILES";
			this->but_generate->Click += new System::EventHandler(this, &CAddEditResult::but_generate_Click);
			// 
			// groupBox10
			// 
			this->groupBox10->Controls->Add(this->but_rem_file);
			this->groupBox10->Controls->Add(this->but_add_file);
			this->groupBox10->Controls->Add(this->text_chosen_file);
			this->groupBox10->Controls->Add(this->but_find_file);
			this->groupBox10->Dock = System::Windows::Forms::DockStyle::Top;
			this->groupBox10->Location = System::Drawing::Point(3, 16);
			this->groupBox10->Name = S"groupBox10";
			this->groupBox10->Size = System::Drawing::Size(372, 128);
			this->groupBox10->TabIndex = 51;
			this->groupBox10->TabStop = false;
			// 
			// but_rem_file
			// 
			this->but_rem_file->Location = System::Drawing::Point(200, 72);
			this->but_rem_file->Name = S"but_rem_file";
			this->but_rem_file->Size = System::Drawing::Size(128, 23);
			this->but_rem_file->TabIndex = 54;
			this->but_rem_file->Text = S"Remove file";
			this->but_rem_file->Click += new System::EventHandler(this, &CAddEditResult::but_rem_file_Click);
			// 
			// but_add_file
			// 
			this->but_add_file->Location = System::Drawing::Point(8, 72);
			this->but_add_file->Name = S"but_add_file";
			this->but_add_file->Size = System::Drawing::Size(128, 23);
			this->but_add_file->TabIndex = 53;
			this->but_add_file->Text = S"Add file";
			this->but_add_file->Click += new System::EventHandler(this, &CAddEditResult::but_add_file_Click);
			// 
			// text_chosen_file
			// 
			this->text_chosen_file->Dock = System::Windows::Forms::DockStyle::Top;
			this->text_chosen_file->Location = System::Drawing::Point(3, 16);
			this->text_chosen_file->Name = S"text_chosen_file";
			this->text_chosen_file->Size = System::Drawing::Size(366, 20);
			this->text_chosen_file->TabIndex = 52;
			this->text_chosen_file->Text = S"";
			// 
			// but_find_file
			// 
			this->but_find_file->Location = System::Drawing::Point(8, 40);
			this->but_find_file->Name = S"but_find_file";
			this->but_find_file->Size = System::Drawing::Size(128, 23);
			this->but_find_file->TabIndex = 51;
			this->but_find_file->Text = S"Search for file";
			this->but_find_file->Click += new System::EventHandler(this, &CAddEditResult::but_find_file_Click);
			// 
			// groupBox7
			// 
			this->groupBox7->Controls->Add(this->butCancel);
			this->groupBox7->Controls->Add(this->butOk);
			this->groupBox7->Dock = System::Windows::Forms::DockStyle::Bottom;
			this->groupBox7->Location = System::Drawing::Point(3, 506);
			this->groupBox7->Name = S"groupBox7";
			this->groupBox7->Size = System::Drawing::Size(378, 48);
			this->groupBox7->TabIndex = 0;
			this->groupBox7->TabStop = false;
			// 
			// butCancel
			// 
			this->butCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->butCancel->Location = System::Drawing::Point(136, 16);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 32;
			this->butCancel->Text = S"Cancel";
			// 
			// butOk
			// 
			this->butOk->Location = System::Drawing::Point(48, 16);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 31;
			this->butOk->Text = S"OK";
			this->butOk->Click += new System::EventHandler(this, &CAddEditResult::butOk_Click);
			// 
			// CAddEditResult
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(848, 557);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox6);
			this->Name = S"CAddEditResult";
			this->Text = S"AddEditResult";
			this->WindowState = System::Windows::Forms::FormWindowState::Maximized;
			this->Activated += new System::EventHandler(this, &CAddEditResult::CAddEditResult_Activated);
			this->groupBox6->ResumeLayout(false);
			this->groupBox5->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			this->groupBox1->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox9->ResumeLayout(false);
			this->groupBox13->ResumeLayout(false);
			this->groupBox12->ResumeLayout(false);
			this->groupBox8->ResumeLayout(false);
			this->groupBox11->ResumeLayout(false);
			this->groupBox10->ResumeLayout(false);
			this->groupBox7->ResumeLayout(false);
			this->ResumeLayout(false);

		}		

private: System::Void CAddEditResult_Activated(System::Object *  sender, System::EventArgs *  e);
private: System::Void comboAlgorithm_SelectedIndexChanged(System::Object *  sender, System::EventArgs *  e);


private: System::Void list_params_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_params_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

private: System::Void but_param_value_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void but_find_file_Click(System::Object *  sender, System::EventArgs *  e);
private: System::Void but_add_file_Click(System::Object *  sender, System::EventArgs *  e);

private: System::Void but_rem_file_Click(System::Object *  sender, System::EventArgs *  e);


private: System::Void list_files_ColumnClick(System::Object *  sender, System::Windows::Forms::ColumnClickEventArgs *  e);
private: System::Void list_files_DoubleClick(System::Object *  sender, System::EventArgs *  e);
private: System::Void list_files_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e);

private: System::Void butOk_Click(System::Object *  sender, System::EventArgs *  e);



private: System::Void but_generate_Click(System::Object *  sender, System::EventArgs *  e);

};
};