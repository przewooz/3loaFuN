#include "stdafx.h"
#include "system.h"


using  namespace CONetAdmin;



#pragma warning(disable:4996)



CSystem::CSystem()
{

};//CSystem::CSystem()



CSystem::~CSystem()
{
	if  (c_codb.bIsConnected())  c_codb.vDisconnect();
};//~CSystem::CSystem()



bool  CSystem::bTestDbConnection(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd)
{
	CError  c_err;

	CMySqlControl  c_sql_temp;

	
	c_sql_temp.vSetAll(sNewHostName, sNewDbName, sNewUser, sNewPasswd);
	c_err  =  c_sql_temp.eConnect();

	if  (c_err)
	{
		c_err.vShowWindow();
		return(false);
	}//if  (c_err)
	else
	{
		c_sql_temp.vDisconnect();	
		return(true);
	}//else  if  (c_err)
}//bool  CSystem::bCheckDbConnection



void  CSystem::vGetConnParams(CString  *psNewHostName, CString  *psNewDbName, CString  *psNewUser, CString  *psNewPasswd)
{
	*psNewHostName  =  c_codb.sGetHost();
	*psNewDbName  =  c_codb.sGetDbName();
	*psNewUser  =  c_codb.sGetUser();
	*psNewPasswd  =  c_codb.sGetPasswd();
}//void  CSystem::vGetConnParams(CString  *psNewHostName, CString  *psNewDbName, CString  *psNewUser, CString  *psNewPasswd)



void  CSystem::vSetSqlConn(CCODbComponent  *pcComp)
{
	c_codb.vSetSqlConn(pcComp);
};//void  CSystem::vSetSqlConn(CKDbComponent  *pcComp)



CError  CSystem::eFindFDbNetworkAndConnForResult
	(
	CCOResult *pcResult, 
	CCOFDbRoot  *pcFDbRoot,	CCONet  *pcNet,  CCONetConn  *pcConn
	)
{
	CError  c_err;
	CString  s_buf;


	int  i_id;
	int i_con_id, i_fit_id, i_alg_id, i_comp_id, i_rset_id;
	CString  s_res_dir, s_res_comments;
	double  d_fit_value;
	double  d_time;
	__int64  dt_generated;

	pcResult->vGetData
		(
		&i_id,
		&i_con_id, &i_fit_id, &i_alg_id, &i_comp_id,  &i_rset_id,
		&s_res_dir, &s_res_comments,
		&d_fit_value,
		&d_time,
		&dt_generated
		);

	//fdb search
	vector <CCOFDbRoot *>  v_root;
	s_buf.Format("Select * from fdb_root where root_id = ANY (Select root_id from networks where net_id = ANY (Select net_id from connections where con_id = '%d') )", i_con_id);
	
	c_err  =  eSelectFDbRoot(&v_root, s_buf);
	if  (c_err)
	{
		for  (int  ii = 0;  ii < (int) v_root.size(); ii++)
			delete  v_root.at(ii);
		return(c_err);
	}//if  (c_err)

	if  ( (int) v_root.size()  <  1)
	{
		s_buf.Format("No fdb roots for con_id = '%d' found", i_con_id);
		c_err.vPutError(s_buf);
		return(c_err);
	}//if  (v_network.szie()  <  1)

	if  ( (int) v_root.size()  >  1)
	{
		s_buf.Format("%d fdb roots for con_id = '%d' found", (int) v_root.size(), i_con_id);
		c_err.vPutError(s_buf);
		for  (int  ii = 0;  ii < (int) v_root.size(); ii++)
			delete  v_root.at(ii);
		return(c_err);
	}//if  (v_network.szie()  >  1)



	//net search
	vector <CCONet *>  v_net;
	s_buf.Format("Select * from networks where net_id = ANY (Select net_id from connections where con_id = '%d')", i_con_id);
	
	c_err  =  eSelectNetworks(&v_net, s_buf);
	if  (c_err)
	{
		for  (int  ii = 0;  ii < (int) v_root.size(); ii++)
			delete  v_root.at(ii);
		for  (int  ii = 0;  ii < (int) v_net.size(); ii++)
			delete  v_net.at(ii);

		return(c_err);
	}//if  (c_err)

	if  ((int) v_net.size()  <  1)
	{
		s_buf.Format("No networks for con_id = '%d' found", i_con_id);
		c_err.vPutError(s_buf);

		for  (int  ii = 0;  ii < (int) v_root.size(); ii++)
			delete  v_root.at(ii);

		return(c_err);
	}//if  (v_network.szie()  <  1)

	if  ( (int) v_net.size()  >  1)
	{
		s_buf.Format("%d fdb nets for con_id = '%d' found", (int) v_net.size(), i_con_id);
		c_err.vPutError(s_buf);
		for  (int  ii = 0;  ii < (int) v_root.size(); ii++)
			delete  v_root.at(ii);
		for  (int  ii = 0;  ii < (int) v_net.size(); ii++)
			delete  v_net.at(ii);

		return(c_err);
	}//if  (v_network.szie()  >  1)




	//con search
	vector <CCONetConn *>  v_conn;
	s_buf.Format("Select * from connections where con_id = '%d'", i_con_id);
	
	c_err  =  eSelectConnections(&v_conn, s_buf);
	if  (c_err)
	{
		for  (int  ii = 0;  ii < (int) v_root.size(); ii++)
			delete  v_root.at(ii);
		for  (int  ii = 0;  ii < (int) v_net.size(); ii++)
			delete  v_net.at(ii);
		for  (int  ii = 0;  ii < (int) v_conn.size(); ii++)
			delete  v_conn.at(ii);

		return(c_err);
	}//if  (c_err)

	if  ((int) v_conn.size()  <  1)
	{
		s_buf.Format("No connections for con_id = '%d' found", i_con_id);
		c_err.vPutError(s_buf);

		for  (int  ii = 0;  ii < (int) v_root.size(); ii++)
			delete  v_root.at(ii);
		for  (int  ii = 0;  ii < (int) v_net.size(); ii++)
			delete  v_net.at(ii);

		return(c_err);
	}//if  (v_network.szie()  <  1)

	if  ( (int) v_conn.size()  >  1)
	{
		s_buf.Format("%d connections for con_id = '%d' found", (int) v_conn.size(), i_con_id);
		c_err.vPutError(s_buf);
		for  (int  ii = 0;  ii < (int) v_root.size(); ii++)
			delete  v_root.at(ii);
		for  (int  ii = 0;  ii < (int) v_net.size(); ii++)
			delete  v_net.at(ii);
		for  (int  ii = 0;  ii < (int) v_conn.size(); ii++)
			delete  v_conn.at(ii);

		return(c_err);
	}//if  (v_network.szie()  >  1)


	

    //if we have found network and connection we return it
	*pcFDbRoot  =  *(v_root.at(0));
	*pcNet  =  *(v_net.at(0));
	*pcConn  =  *(v_conn.at(0));
	

	for  (int  ii = 0;  ii < (int) v_root.size(); ii++)
		delete  v_root.at(ii);
	for  (int  ii = 0;  ii < (int) v_net.size(); ii++)
		delete  v_net.at(ii);
	for  (int  ii = 0;  ii < (int) v_conn.size(); ii++)
		delete  v_conn.at(ii);
	return(c_err);
}//CError  CSystem::eFindFDbNetworkAndConnForResult



CError  CSystem::eFindNetworkAndConnForResult
	(
	CCOResult *pcResult, CCOFDbRoot  *pcFDbRoot,
	CCONet  *pcNet,  int  *piConnIndex
	)
{
	CError  c_err;
	CString  s_buf;


	int  i_id;
	int i_con_id, i_fit_id, i_alg_id, i_comp_id, i_rset_id;
	CString  s_res_dir, s_res_comments;
	double  d_fit_value;
	double  d_time;
	__int64  dt_generated;

	pcResult->vGetData
		(
		&i_id,
		&i_con_id, &i_fit_id, &i_alg_id, &i_comp_id,  &i_rset_id,
		&s_res_dir, &s_res_comments,
		&d_fit_value,
		&d_time,
		&dt_generated
		);

	vector <CCONet *>  v_network;
	s_buf.Format("Select * from networks where root_id = '%d' and net_id = ANY (Select net_id from connections where con_id = '%d')", pcFDbRoot->iGetId(), i_con_id);
	
	eSelectNetworks(&v_network, s_buf);
	if  (v_network.size()  <  1)
	{
		s_buf.Format("No networks for root_id = '%d' and con_id = '%d' found", pcFDbRoot->iGetId(), i_con_id);
		c_err.vPutError(s_buf);
		return(c_err);
	}//if  (v_network.szie()  <  1)

	if  (v_network.size()  >  1)
	{
		s_buf.Format("%d networks for root_id = '%d' con_id = '%d' found", v_network.size(), pcFDbRoot->iGetId(), i_con_id);
		c_err.vPutError(s_buf);
		for  (int  ii = 0; ii < (int) v_network.size(); ii++)
			delete  v_network.at(ii);
		return(c_err);
	}//if  (v_network.szie()  >  1)

	//if there is EXACTLY 1 network...
	//now we need to find proper connection
	*pcNet  =  *v_network.at(0);
	c_err  =  pcNet->eRefreshNetConns();

	if  (c_err)
	{
		s_buf.Format("Couldnt refresh connections for network (%d)", v_network.at(0)->iGetId());
		c_err.vPutError(s_buf);
		c_err.vShowWindow();
		for  (int  ii = 0; ii < (int) v_network.size(); ii++)
			delete  v_network.at(ii);
		return(c_err);
	}//if  (c_err)


	int  i_found_con_index  =  -1;
	for  (int  ii = 0; (ii < (int) pcNet->pvGetNetConns()->size())&&(i_found_con_index  ==  -1); ii++)
	{
		if  (pcNet->pvGetNetConns()->at(ii)->iGetId()  ==  i_con_id)
			i_found_con_index  =  ii;		
	}//for  (int  ii = 0; ii < (int) v_network.at(0)->pvGetNetConns()->size(); ii++)

	if  (i_found_con_index  ==  -1)
	{
		s_buf.Format("Couldnt find proper connection (%d) for network (%d)", i_con_id, v_network.at(0)->iGetId());
		c_err.vPutError(s_buf);
		c_err.vShowWindow();
		for  (int  ii = 0; ii < (int) v_network.size(); ii++)
			delete  v_network.at(ii);
		return(c_err);
	}//if  (i_found_index  ==  -1)


    //if we have found network and connection we return it
	*piConnIndex  =  i_found_con_index;

	for  (int  ii = 0; ii < (int) v_network.size(); ii++)
		delete  v_network.at(ii);
	return(c_err);

}//CError  CSystem::eFindNetworkAndConnForResult



CError  CSystem::eGetAlgorithm(CString  sAlgorithmName,  CCOAlgorithm *pcAlgorithm, int  iAlgorithmId)
{
	CError  c_err;
	
	vector <CCOAlgorithm *>  v_algorithms;
	CString  s_select_sql;

	if  (iAlgorithmId  ==  -1)
		s_select_sql.Format("Select * from algorithms where alg_name = '%s'", CMySqlControl::sFormatForSQL(sAlgorithmName));
	else
		s_select_sql.Format("Select * from algorithms where alg_id = '%d'", iAlgorithmId);
	c_err  =  eSelectAlgorithms(&v_algorithms, s_select_sql);

	if  ((int) v_algorithms.size()  ==  1)
	{
		*pcAlgorithm  =  *(v_algorithms.at(0));
	}//if  ((int) v_algorithms.size()  ==  1)
	else
	{
		CString  s_buf;
		s_buf.Format("%d algorithms types found", (int) v_algorithms.size());

		c_err.vPutError(s_buf);

		for  (int ii = 0;  ii < (int) v_algorithms.size(); ii++)
			delete  (CCOAlgorithm *)  v_algorithms.at(ii);

		return(c_err);		
	}//else  if  ((int) v_algorithms.size()  ==  1)

	for  (int ii = 0;  ii < (int) v_algorithms.size(); ii++)
		delete  (CCOAlgorithm *)  v_algorithms.at(ii);

	return(c_err);
}//CError  CSystem::e_get_algorithm(CString  sAlgorithmName,  CCOAlgorithm *pcAlgorithm)



CError  CSystem::eGetNet(CCOFDbRoot  *pcFdbRoot, CCONet *pcNet,  CString  sNetName,  int iNetId)
{
	CError  c_err;

	if  (pcFdbRoot  ==  NULL)
	{
		c_err.vPutError("No file database given!");
		return(c_err);	
	}//if  (pcFdbRoot  ==  NULL)

	//c_err  =  pcFdbRoot->eRefreshNets();
	//if  (c_err)  return(c_err);

	bool  b_found  =  false;
	for  (int  ii = 0; (ii < (int) pcFdbRoot->pvGetNets()->size())&&(b_found  ==  false);  ii++)
	{
		if  (iNetId  ==  -1)
		{
			if  (sNetName.MakeLower()  ==  pcFdbRoot->pvGetNets()->at(ii)->sGetName().MakeLower())
			{
				b_found  =  true;
				*pcNet  =  *(pcFdbRoot->pvGetNets()->at(ii));		
			}//if  (sNetName  ==  pcFdbRoot->pvGetNets()->at(ii)->sGetName())
		}//if  (iNetId  ==  -1)
		else
		{
			if  (iNetId  ==  pcFdbRoot->pvGetNets()->at(ii)->iGetId())
			{
				b_found  =  true;
				*pcNet  =  *(pcFdbRoot->pvGetNets()->at(ii));		
			}//if  (sNetName  ==  pcFdbRoot->pvGetNets()->at(ii)->sGetName())		
		}//else  if  (iNetId  ==  -1)
	}//for  (int  ii = 0; ii < pcFdbRoot->pvGetNets()->size();  ii++)

	if  (b_found  ==  false)
	{
		CString  s_buf;
		if  (iNetId  ==  -1)
			s_buf.Format("Network with the name:'%s' not found", sNetName);
		else
			s_buf.Format("Network with id:'%d' not found", iNetId);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (b_found  ==  false)

	
	return(c_err);
}//CError  CSystem::e_get_net(CString  sNetName,  CCONet *pcNet)



CError  CSystem::eGetCon(CCONet *pcNet, CString  sConName, CCONetConn  *pcNetConn)
{
	CError  c_err;

	if  (pcNet  ==  NULL)
	{
		c_err.vPutError("No network given!");
		return(c_err);	
	}//if  (pcFdbRoot  ==  NULL)

	c_err  =  pcNet->eRefreshNetConns();
	if  (c_err)  return(c_err);

	bool  b_found  =  false;
	for  (int  ii = 0; (ii < (int) pcNet->pvGetNetConns()->size())&&(b_found  ==  false);  ii++)
	{
		if  (sConName.MakeLower()  ==  pcNet->pvGetNetConns()->at(ii)->sGetName().MakeLower())
		{
			b_found  =  true;
			*pcNetConn  =  *(pcNet->pvGetNetConns()->at(ii));		
		}//if  (sNetName  ==  pcFdbRoot->pvGetNets()->at(ii)->sGetName())
	}//for  (int  ii = 0; ii < pcFdbRoot->pvGetNets()->size();  ii++)

	if  (b_found  ==  false)
	{
		CString  s_buf;
		s_buf.Format("Connection set with the name:'%s' not found", sConName);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (b_found  ==  false)

	return(c_err);
}//CError  CSystem::e_get_con(CCONet *pcNet, CString  sConName, CCONetConn  *pcNetConn)


CError  CSystem::eGetFitFunc(CString  sFitFuncName,  CCOFitFunc *pcFitFunc, int  iFFId)
{
	CError  c_err;
	
	vector <CCOFitFunc *>  v_fit_funcs;
	CString  s_select_sql;

	if  (iFFId  ==  -1)
		s_select_sql.Format("Select * from fit_func where fit_name = '%s'", CMySqlControl::sFormatForSQL(sFitFuncName));
	else
		s_select_sql.Format("Select * from fit_func where fit_id = '%d'", iFFId);

	c_err  =  eSelectFitFuncs(&v_fit_funcs, s_select_sql);

	if  ((int) v_fit_funcs.size()  ==  1)
	{
		*pcFitFunc  =  *(v_fit_funcs.at(0));
	}//if  ((int) v_algorithms.size()  ==  1)
	else
	{
		CString  s_buf;
		s_buf.Format("%d fitness functions found", (int) v_fit_funcs.size());

		c_err.vPutError(s_buf);

		for  (int ii = 0;  ii < (int) v_fit_funcs.size(); ii++)
			delete  (CCOFitFunc *)  v_fit_funcs.at(ii);

		return(c_err);		
	}//else  if  ((int) v_fit_funcs.size()  ==  1)

	for  (int ii = 0;  ii < (int) v_fit_funcs.size(); ii++)
		delete  (CCOFitFunc *)  v_fit_funcs.at(ii);

	return(c_err);

}//CError  CSystem::e_get_fit_func(CString  sFitFuncName,  CCOFitFunc *pcFitFunc)



CError  CSystem::eGetParameter(CCOAlgorithm  *pcAlgorithm,  CString  sParamName, double  *pdParamVal)
{
	CError  c_err;

	bool  b_found  =  false;
	for  (int ii = 0;  (ii < (int)  pcAlgorithm->pvGetParams()->size())&&(b_found  ==  false);  ii++)
	{
		if  (pcAlgorithm->pvGetParams()->at(ii)->sGetParamName().MakeLower()  ==  sParamName.MakeLower())
		{
			b_found  =  true;
			*pdParamVal  =  pcAlgorithm->pvGetParams()->at(ii)->dGetParamValue();
			return(c_err);
		}//if  (pcAlgorithm->pvGetParams()->at(ii)->sGetParamName()  ==  sParamName)
	
	}//for  (int ii = 0;  ii < (int)  pcAlgorithm->pvGetParams()->size();  ii++)

	if  (b_found  ==  false)
	{
		CString  s_buf;

		s_buf.Format("The requested parameter not found (%s)", sParamName);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (b_found  ==  false)

	return(c_err);
}//CError  CSystem::eGetParameter(CCOAlgorithm  *pcAlgorithm,  CString  sParamName, double  *pdParamVal)



CError  CSystem::eSetParameter(CCOAlgorithm  *pcAlgorithm,  CString  sParamName, double  dParamVal)
{
	CError  c_err;

	bool  b_found  =  false;
	for  (int ii = 0;  (ii < (int)  pcAlgorithm->pvGetParams()->size())&&(b_found  ==  false);  ii++)
	{
		if  (pcAlgorithm->pvGetParams()->at(ii)->sGetParamName().MakeLower()  ==  sParamName.MakeLower())
		{
			b_found  =  true;
			c_err  =  pcAlgorithm->pvGetParams()->at(ii)->eSetParamValue(dParamVal, -1);		
		}//if  (pcAlgorithm->pvGetParams()->at(ii)->sGetParamName()  ==  sParamName)
	
	}//for  (int ii = 0;  ii < (int)  pcAlgorithm->pvGetParams()->size();  ii++)

	if  (b_found  ==  false)
	{
		CString  s_buf;

		s_buf.Format("The requested parameter not found (%s)", sParamName);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (b_found  ==  false)

	return(c_err);
}//CError  CSystem::eSetParameter(CCOAlgorithm  *pcAlgorithm,  CString  sParamName, double  dParamVal)






CError  CSystem::e_load_result_params_hefan_2_0_header_2_0_and_2_1_and_2_2
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult,
		CString  sAlgorithmName
		)
{
	CError  c_err;

	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;
	long  l_capa_incr, l_capa_gen_incr;
	double  d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross;
	long  l_pop_num,  l_gen_num;
	double  d_time_restriction;

	long  l_brain_avr_len;
	double  d_brain_min_inc;
	long  l_brain_time_len,  l_brain_finish_time,  l_brain_min_break;


	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "flow increase", &s_info);
	if  (c_err)  return(c_err);
	l_capa_incr  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "flow increase every x generations", &s_info);
	if  (c_err)  return(c_err);
	l_capa_gen_incr  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_high_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_high_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Low level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_low_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Low level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_low_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level crossing unordered", &s_info);
	if  (c_err)  return(c_err);
	d_random_cross  =  atof( (LPCSTR)  s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Population size", &s_info);
	if  (c_err)  return(c_err);
	l_pop_num  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Generation number", &s_info);
	if  (c_err)  return(c_err);
	l_gen_num  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Time restriction", &s_info);
	if  (c_err)  return(c_err);
	d_time_restriction  =  atof( (LPCSTR)  s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm radius", &s_info);
	if  (c_err)  return(c_err);
	l_brain_avr_len  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm turn on perc", &s_info);
	if  (c_err)  return(c_err);
	d_brain_min_inc  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm duration", &s_info);
	if  (c_err)  return(c_err);
	l_brain_time_len  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm turning off", &s_info);
	if  (c_err)  return(c_err);
	l_brain_finish_time  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm min break", &s_info);
	if  (c_err)  return(c_err);
	l_brain_min_break  =  atol( (LPCSTR)  s_info );

	fclose(pfSettingsFile);
				
	//the population size nedds to be divided by 4 first
	l_pop_num  =  l_pop_num / 4;

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch;

	//now inserting params into the params window

	CString  s_buf;
	//general data

	//algorithm loading
	c_err  =  eGetAlgorithm(sAlgorithmName, pcAlgorithm);
	if  (c_err)  return(c_err);


	c_codb.vSetSqlConn(pcAlgorithm);
    c_err  =  pcAlgorithm->eRefreshParams();
	if  (c_err)  return(c_err);


	//fit function
	CCOFitFunc  c_fit_func(NULL);
	c_err  =  eGetFitFunc(s_fom_func, &c_fit_func);
	if  (c_err)  return(c_err);
	pcResult->i_fit_id  =  c_fit_func.iGetId();



	//net loading
	CCONet  c_net(NULL);
	FileInfo  *fi_net  =  new  FileInfo(s_topology);
	s_buf  =  fi_net->Name;

	int  i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_net_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_net_name  +=  s_buf.GetAt(ii);
	else
		s_net_name  =  s_buf;

	c_err  =  eGetNet(pcFdbRoot, &c_net, s_net_name);
	if  (c_err)  return(c_err);



	//con loading
	CCONetConn  c_net_conn(NULL);
	FileInfo  *fi_con  =  new  FileInfo(s_con_file);
	s_buf  =  fi_con->Name;

	i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_con_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_con_name  +=  s_buf.GetAt(ii);
	else
		s_con_name  =  s_buf;

	c_codb.vSetSqlConn(&c_net);
	c_err  =  eGetCon(&c_net, s_con_name, &c_net_conn);
	if  (c_err)  return(c_err);

	pcResult->i_con_id  =  c_net_conn.iGetId();



	//initial solution
	if  (s_ini_file  !=  "")
	{
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 1.0);
		pvFiles->push_back(s_ini_file);
	}//if  (s_ini_file  !=  "")
	else
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 0);
	
	if  (c_err)  return(c_err);
	

	if  (s_res_file  !=  "")
	{
		pvFiles->push_back(s_res_file  +  ".rep");
		pvFiles->push_back(s_res_file  +  ".ful");
		pvFiles->push_back(s_res_file  +  ".vwd");
		pvFiles->push_back(s_res_file  +  ".vws");
	}//if  (s_info  !=  "")


	//population tracj file
	if  (s_pop_fom_watch  !=  "")
	{
		pvFiles->push_back(s_pop_fom_watch);
	}//if  (s_info  !=  "")



	//cloner repetations
	c_err  =  eSetParameter(pcAlgorithm, "Clone repetations", l_clo_rep);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "init shortest ways", l_shortest_ways_number);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "top individuals", l_res_num);
	if  (c_err)  return(c_err);


	//allow to exceed link capacity
	if  (b_allow_capacity_overloading)
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 1.0);
	else
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 0);
	if  (c_err)  return(c_err);


	//capa penalty
	c_err  =  eSetParameter(pcAlgorithm, "Exceed link capacity penalty", l_capa_penalty);
	if  (c_err)  return(c_err);


	//flow increase
	c_err  =  eSetParameter(pcAlgorithm, "Flow increase", l_capa_incr);
	if  (c_err)  return(c_err);

	
	//flow increase every x generations
	c_err  =  eSetParameter(pcAlgorithm, "Flow increase every x generations", l_capa_gen_incr);
	if  (c_err)  return(c_err);


	//algorithm parameters

	//high level crossing
	c_err  =  eSetParameter(pcAlgorithm, "High level crossing", d_high_cross);
	if  (c_err)  return(c_err);

	//high level mutation
	c_err  =  eSetParameter(pcAlgorithm, "High level mutation", d_high_mut);
	if  (c_err)  return(c_err);


	//high level unordered crossing
	c_err  =  eSetParameter(pcAlgorithm, "High level crossing unordered", d_random_cross);
	if  (c_err)  return(c_err);


	//low level crossing
	c_err  =  eSetParameter(pcAlgorithm, "Low level crossing", d_low_cross);
	if  (c_err)  return(c_err);

	//low level mutation
	c_err  =  eSetParameter(pcAlgorithm, "Low level mutation", d_low_mut);
	if  (c_err)  return(c_err);


	//population size
	c_err  =  eSetParameter(pcAlgorithm, "Population size", l_pop_num * 4);
	if  (c_err)  return(c_err);


	if  (d_time_restriction  >  0)
	{
		c_err  =  eSetParameter(pcAlgorithm, "Time restriction", d_time_restriction);
		if  (c_err)  return(c_err);

		//GENERATION NUMBER!!!!
	}//if  (d_time_restriction  >  0)
	else
	{
		c_err  =  eSetParameter(pcAlgorithm, "Time restriction", d_time_restriction);
		if  (c_err)  return(c_err);

		//generation number
		c_err  =  eSetParameter(pcAlgorithm, "Generation number", l_gen_num);
		if  (c_err)  return(c_err);
	}//else  if  (d_time_restriction  >  0)


	//brainstorm radius
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm radius", l_brain_avr_len);
	if  (c_err)  return(c_err);

	//brainstorm turn on %
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm turn on %", d_brain_min_inc);
	if  (c_err)  return(c_err);

	//brainstorm duration
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm duration", l_brain_time_len);
	if  (c_err)  return(c_err);


	//brainstorm turning off
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm turning off", l_brain_finish_time);
	if  (c_err)  return(c_err);


	//brainstorm break
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm min break", l_brain_min_break);
	if  (c_err)  return(c_err);



	//algorithm running time
	FILE  *pf_pop_file;
	pf_pop_file  =  fopen(s_pop_fom_watch, "r+");

	if  (pf_pop_file  ==  NULL)
	{
		s_buf.Format("Unable to open population fitness tracking file (%s)", (LPCSTR) s_pop_fom_watch);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_pop_file  ==  NULL)
	
	int  i_buf;
	double  d_buf,  d_time, d_best_individual;
	char  pc_buf[100];

	fscanf(pf_pop_file, "\n");
	fscanf(pf_pop_file, "\n");

	while  (!feof(pf_pop_file))
	{
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%d", &i_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%s", pc_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_best_individual);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%d", &i_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_time);
	}//while  (!feof(pf_pop_file))
		
	fclose(pf_pop_file);
	pcResult->d_time  =  d_time;
	pcResult->d_fit_value  =  (1.0 / d_best_individual);
	pcResult->d_fit_value  =  pcResult->d_fit_value  - 1.0;
	pcResult->d_fit_value  =  Math::Round(pcResult->d_fit_value);

	FileInfo  *fi_rep  =  new  FileInfo(s_pop_fom_watch);
	System::DateTime  dt_creation;
	dt_creation  =  fi_rep->CreationTime;
	pcResult->dt_generated  =  dt_creation.ToFileTime();


	
	return(c_err);
}//CError  CSystem::e_load_result_params_hefan_1_0_header_2_0





CError  CSystem::e_load_result_params_vmea_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		)
{
	CError  c_err;

	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;

	double  d_max_time;
	bool  b_glue_infections, b_templ_fitness_check;
	int  i_pattern_pool_size;
	bool  b_the_same_pattern_check;
	int  i_preffered_pattern_length,  i_minimal_pattern_length;
	int  i_length_or_entrophy;
	bool  b_use_templates_at_vir_init;
	int  i_vir_gen;
	int  i_vir_pop_size;
	double  d_vir_pop_red;
	double  d_prob_cut,  d_prob_splice,  d_prob_mut,  d_prob_mut_rem_gene, d_prob_mut_add_gene;
	double  d_prob_low_cross, d_prob_low_mut;
	double  d_prob_init_mut;
	double  d_virus_virgitnity_rounds,	d_no_new_ct;

	

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );


	
	
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "max time", &s_info);
	if  (c_err)  return(c_err);
	d_max_time  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "glue infections", &s_info);
	if  (c_err)  return(c_err);
	b_glue_infections  =  atoi( (LPCSTR) s_info);	

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "template fitness check", &s_info);
	if  (c_err)  return(c_err);
	b_templ_fitness_check  =  atoi( (LPCSTR) s_info);	

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "pattern pool size", &s_info);
	if  (c_err)  return(c_err);
	i_pattern_pool_size  =  atoi( (LPCSTR) s_info);	

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "the same pattern check", &s_info);
	if  (c_err)  return(c_err);
	b_the_same_pattern_check  =  atoi( (LPCSTR) s_info);	

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "preferred pattern length", &s_info);
	if  (c_err)  return(c_err);
	i_preffered_pattern_length  =  atoi( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "minimal pattern length", &s_info);
	if  (c_err)  return(c_err);
	i_minimal_pattern_length  =  atoi( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "length or entrophy at pattern number check", &s_info);
	if  (c_err)  return(c_err);
	i_length_or_entrophy  =  atoi( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "use templates at virus init", &s_info);
	if  (c_err)  return(c_err);
	b_use_templates_at_vir_init  =  atoi( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus generations", &s_info);
	if  (c_err)  return(c_err);
	i_vir_gen  =  atoi( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus population", &s_info);
	if  (c_err)  return(c_err);
	i_vir_pop_size  =  atoi( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus population reduction", &s_info);
	if  (c_err)  return(c_err);
	d_vir_pop_red  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus prob cut", &s_info);
	if  (c_err)  return(c_err);
	d_prob_cut  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus prob splice", &s_info);
	if  (c_err)  return(c_err);
	d_prob_splice  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus prob mutation", &s_info);
	if  (c_err)  return(c_err);
	d_prob_mut  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus prob rem gene", &s_info);
	if  (c_err)  return(c_err);
	d_prob_mut_rem_gene  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus prob add gene", &s_info);
	if  (c_err)  return(c_err);
	d_prob_mut_add_gene  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus prob low cross", &s_info);
	if  (c_err)  return(c_err);
	d_prob_low_cross  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus prob low mut", &s_info);
	if  (c_err)  return(c_err);
	d_prob_low_mut  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus prob init mut", &s_info);
	if  (c_err)  return(c_err);
	d_prob_init_mut  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "virus virginity rounds", &s_info);
	if  (c_err)  return(c_err);
	d_virus_virgitnity_rounds  =  atof( (LPCSTR) s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "no new ct", &s_info);
	if  (c_err)  return(c_err);
	d_no_new_ct  =  atof( (LPCSTR) s_info);




	fclose(pfSettingsFile);
				
	
	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch;

	//now inserting params into the params window

	CString  s_buf;
	//general data

	//algorithm loading
	c_err  =  eGetAlgorithm(VMEA_NAME, pcAlgorithm);
	if  (c_err)  return(c_err);


	c_codb.vSetSqlConn(pcAlgorithm);
    c_err  =  pcAlgorithm->eRefreshParams();
	if  (c_err)  return(c_err);


	//fit function
	CCOFitFunc  c_fit_func(NULL);
	c_err  =  eGetFitFunc(s_fom_func, &c_fit_func);
	if  (c_err)  return(c_err);
	pcResult->i_fit_id  =  c_fit_func.iGetId();



	//net loading
	CCONet  c_net(NULL);
	FileInfo  *fi_net  =  new  FileInfo(s_topology);
	s_buf  =  fi_net->Name;

	int  i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_net_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_net_name  +=  s_buf.GetAt(ii);
	else
		s_net_name  =  s_buf;

	c_err  =  eGetNet(pcFdbRoot, &c_net,  s_net_name);
	if  (c_err)  return(c_err);



	//con loading
	CCONetConn  c_net_conn(NULL);
	FileInfo  *fi_con  =  new  FileInfo(s_con_file);
	s_buf  =  fi_con->Name;

	i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_con_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_con_name  +=  s_buf.GetAt(ii);
	else
		s_con_name  =  s_buf;

	c_codb.vSetSqlConn(&c_net);
	c_err  =  eGetCon(&c_net, s_con_name, &c_net_conn);
	if  (c_err)  return(c_err);

	pcResult->i_con_id  =  c_net_conn.iGetId();



	//initial solution
	if  (s_ini_file  !=  "")
	{
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 1.0);
		pvFiles->push_back(s_ini_file);
	}//if  (s_ini_file  !=  "")
	else
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 0);
	
	if  (c_err)  return(c_err);
	

	if  (s_res_file  !=  "")
	{
		pvFiles->push_back(s_res_file  +  ".rep");
		pvFiles->push_back(s_res_file  +  ".ful");
		pvFiles->push_back(s_res_file  +  ".vwd");
		pvFiles->push_back(s_res_file  +  ".vws");
	}//if  (s_info  !=  "")


	//population tracj file
	if  (s_pop_fom_watch  !=  "")
	{
		pvFiles->push_back(s_pop_fom_watch);
	}//if  (s_info  !=  "")



	//cloner repetations
	c_err  =  eSetParameter(pcAlgorithm, "Clone repetations", l_clo_rep);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "init shortest ways", l_shortest_ways_number);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "top individuals", l_res_num);
	if  (c_err)  return(c_err);

	//allow to exceed link capacity
	if  (b_allow_capacity_overloading)
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 1.0);
	else
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 0);
	if  (c_err)  return(c_err);


	//capa penalty
	c_err  =  eSetParameter(pcAlgorithm, "Exceed link capacity penalty", l_capa_penalty);
	if  (c_err)  return(c_err);





	c_err  =  eSetParameter(pcAlgorithm, "max time", d_max_time);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "glue infections", b_glue_infections);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "template fitness check", b_templ_fitness_check);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "pattern pool size", i_pattern_pool_size);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "the same pattern check", b_the_same_pattern_check);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "preferred pattern length", i_preffered_pattern_length);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "minimal pattern length", i_minimal_pattern_length);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "length or entrophy at pattern number check", i_length_or_entrophy);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "use templates at virus init", b_use_templates_at_vir_init);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus generations", i_vir_gen);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus population", i_vir_pop_size);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus population reduction", d_vir_pop_red);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus prob cut", d_prob_cut);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus prob splice", d_prob_splice);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus prob mutation", d_prob_mut);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus prob rem gene", d_prob_mut_rem_gene);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus prob add gene", d_prob_mut_add_gene);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus prob low cross", d_prob_low_cross);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus prob low mut", d_prob_low_mut);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus prob init mut", d_prob_init_mut);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "virus virginity rounds", d_virus_virgitnity_rounds);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "no new ct", d_no_new_ct);
	if  (c_err)  return(c_err);




	//algorithm running time
	FILE  *pf_pop_file;
	s_pop_fom_watch += "_RUN.txt";
	pf_pop_file  =  fopen(s_pop_fom_watch, "r+");

	
	if  (pf_pop_file  ==  NULL)
	{
		s_buf.Format("Unable to open population fitness tracking file (%s)", (LPCSTR) s_pop_fom_watch);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_pop_file  ==  NULL)
	
	int  i_buf;
	double  d_buf,  d_time, d_best_individual;
	char  pc_buf[100];

	fscanf(pf_pop_file, "\n");
	fscanf(pf_pop_file, "\n");

	CString  s_text_to_search,  s_comment, s_read_line;
	int  i_found;
	while  (!feof(pf_pop_file))
	{
		CHefanSystem::vReadLine(pf_pop_file, &s_read_line, &s_comment);
		
		//first check if it ct nummber refresh
		s_text_to_search  =  "best fitness:";
		i_found  =  s_read_line.Find(s_text_to_search);

		if  (i_found  >=  0)
			d_best_individual  =  CHefanSystem::dExtractFromString(s_read_line, i_found + s_text_to_search.GetLength());
		
		s_text_to_search  =  "[time passed:";
		i_found  =  s_read_line.Find(s_text_to_search);

		if  (i_found  >=  0)
			d_time  =  CHefanSystem::dExtractFromString(s_read_line, i_found + s_text_to_search.GetLength());
	}//while  (!feof(pf_pop_file))

			
	fclose(pf_pop_file);
	pcResult->d_time  =  d_time;
	pcResult->d_fit_value  =  (1.0 / d_best_individual);
	pcResult->d_fit_value  =  pcResult->d_fit_value  - 1.0;
	pcResult->d_fit_value  =  Math::Round(pcResult->d_fit_value);

	FileInfo  *fi_rep  =  new  FileInfo(s_pop_fom_watch);
	System::DateTime  dt_creation;
	dt_creation  =  fi_rep->CreationTime;
	pcResult->dt_generated  =  dt_creation.ToFileTime();


	
	return(c_err);
}//CError  CSystem::e_load_result_params_standard_ea_header_2_0







CError  CSystem::e_load_result_params_standard_ea_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		)
{
	CError  c_err;

	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;
	long  l_capa_incr, l_capa_gen_incr;
	double  d_high_cross,  d_high_mut,  d_random_cross;
	long  l_pop_num,  l_gen_num;
	double  d_time_restriction;

	long  l_brain_avr_len;
	double  d_brain_min_inc;
	long  l_brain_time_len,  l_brain_finish_time,  l_brain_min_break;


	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "flow increase", &s_info);
	if  (c_err)  return(c_err);
	l_capa_incr  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "flow increase every x generations", &s_info);
	if  (c_err)  return(c_err);
	l_capa_gen_incr  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_high_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_high_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level crossing unordered", &s_info);
	if  (c_err)  return(c_err);
	d_random_cross  =  atof( (LPCSTR)  s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Population size", &s_info);
	if  (c_err)  return(c_err);
	l_pop_num  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Generation number", &s_info);
	if  (c_err)  return(c_err);
	l_gen_num  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Time restriction", &s_info);
	if  (c_err)  return(c_err);
	d_time_restriction  =  atof( (LPCSTR)  s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm radius", &s_info);
	if  (c_err)  return(c_err);
	l_brain_avr_len  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm turn on perc", &s_info);
	if  (c_err)  return(c_err);
	d_brain_min_inc  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm duration", &s_info);
	if  (c_err)  return(c_err);
	l_brain_time_len  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm turning off", &s_info);
	if  (c_err)  return(c_err);
	l_brain_finish_time  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm min break", &s_info);
	if  (c_err)  return(c_err);
	l_brain_min_break  =  atol( (LPCSTR)  s_info );

	fclose(pfSettingsFile);
				
	//the population size nedds to be divided by 4 first
	l_pop_num  =  l_pop_num / 4;

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch;

	//now inserting params into the params window

	CString  s_buf;
	//general data

	//algorithm loading
	c_err  =  eGetAlgorithm(EA_NAME, pcAlgorithm);
	if  (c_err)  return(c_err);


	c_codb.vSetSqlConn(pcAlgorithm);
    c_err  =  pcAlgorithm->eRefreshParams();
	if  (c_err)  return(c_err);


	//fit function
	CCOFitFunc  c_fit_func(NULL);
	c_err  =  eGetFitFunc(s_fom_func, &c_fit_func);
	if  (c_err)  return(c_err);
	pcResult->i_fit_id  =  c_fit_func.iGetId();



	//net loading
	CCONet  c_net(NULL);
	FileInfo  *fi_net  =  new  FileInfo(s_topology);
	s_buf  =  fi_net->Name;

	int  i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_net_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_net_name  +=  s_buf.GetAt(ii);
	else
		s_net_name  =  s_buf;

	c_err  =  eGetNet(pcFdbRoot, &c_net,  s_net_name);
	if  (c_err)  return(c_err);



	//con loading
	CCONetConn  c_net_conn(NULL);
	FileInfo  *fi_con  =  new  FileInfo(s_con_file);
	s_buf  =  fi_con->Name;

	i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_con_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_con_name  +=  s_buf.GetAt(ii);
	else
		s_con_name  =  s_buf;

	c_codb.vSetSqlConn(&c_net);
	c_err  =  eGetCon(&c_net, s_con_name, &c_net_conn);
	if  (c_err)  return(c_err);

	pcResult->i_con_id  =  c_net_conn.iGetId();



	//initial solution
	if  (s_ini_file  !=  "")
	{
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 1.0);
		pvFiles->push_back(s_ini_file);
	}//if  (s_ini_file  !=  "")
	else
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 0);
	
	if  (c_err)  return(c_err);
	

	if  (s_res_file  !=  "")
	{
		pvFiles->push_back(s_res_file  +  ".rep");
		pvFiles->push_back(s_res_file  +  ".ful");
		pvFiles->push_back(s_res_file  +  ".vwd");
		pvFiles->push_back(s_res_file  +  ".vws");
	}//if  (s_info  !=  "")


	//population tracj file
	if  (s_pop_fom_watch  !=  "")
	{
		pvFiles->push_back(s_pop_fom_watch);
	}//if  (s_info  !=  "")



	//cloner repetations
	c_err  =  eSetParameter(pcAlgorithm, "Clone repetations", l_clo_rep);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "init shortest ways", l_shortest_ways_number);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "top individuals", l_res_num);
	if  (c_err)  return(c_err);


	//allow to exceed link capacity
	if  (b_allow_capacity_overloading)
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 1.0);
	else
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 0);
	if  (c_err)  return(c_err);


	//capa penalty
	c_err  =  eSetParameter(pcAlgorithm, "Exceed link capacity penalty", l_capa_penalty);
	if  (c_err)  return(c_err);


	//flow increase
	c_err  =  eSetParameter(pcAlgorithm, "Flow increase", l_capa_incr);
	if  (c_err)  return(c_err);

	
	//flow increase every x generations
	c_err  =  eSetParameter(pcAlgorithm, "Flow increase every x generations", l_capa_gen_incr);
	if  (c_err)  return(c_err);


	//algorithm parameters

	//high level crossing
	c_err  =  eSetParameter(pcAlgorithm, "High level crossing", d_high_cross);
	if  (c_err)  return(c_err);

	//high level mutation
	c_err  =  eSetParameter(pcAlgorithm, "High level mutation", d_high_mut);
	if  (c_err)  return(c_err);


	//high level unordered crossing
	c_err  =  eSetParameter(pcAlgorithm, "High level crossing unordered", d_random_cross);
	if  (c_err)  return(c_err);



	//population size
	c_err  =  eSetParameter(pcAlgorithm, "Population size", l_pop_num * 4);
	if  (c_err)  return(c_err);

	if  (d_time_restriction  >  0)
	{
		c_err  =  eSetParameter(pcAlgorithm, "Time restriction", d_time_restriction);
		if  (c_err)  return(c_err);

		//GENERATION NUMBER!!!!
	}//if  (d_time_restriction  >  0)
	else
	{
		c_err  =  eSetParameter(pcAlgorithm, "Time restriction", d_time_restriction);
		if  (c_err)  return(c_err);

		//generation number
		c_err  =  eSetParameter(pcAlgorithm, "Generation number", l_gen_num);
		if  (c_err)  return(c_err);
	}//else  if  (d_time_restriction  >  0)


	//brainstorm radius
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm radius", l_brain_avr_len);
	if  (c_err)  return(c_err);

	//brainstorm turn on %
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm turn on %", d_brain_min_inc);
	if  (c_err)  return(c_err);

	//brainstorm duration
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm duration", l_brain_time_len);
	if  (c_err)  return(c_err);


	//brainstorm turning off
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm turning off", l_brain_finish_time);
	if  (c_err)  return(c_err);


	//brainstorm break
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm min break", l_brain_min_break);
	if  (c_err)  return(c_err);



	//algorithm running time
	FILE  *pf_pop_file;
	pf_pop_file  =  fopen(s_pop_fom_watch, "r+");

	if  (pf_pop_file  ==  NULL)
	{
		s_buf.Format("Unable to open population fitness tracking file (%s)", (LPCSTR) s_pop_fom_watch);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_pop_file  ==  NULL)
	
	int  i_buf;
	double  d_buf,  d_time, d_best_individual;
	char  pc_buf[100];

	fscanf(pf_pop_file, "\n");
	fscanf(pf_pop_file, "\n");

	while  (!feof(pf_pop_file))
	{
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%d", &i_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%s", pc_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_best_individual);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%d", &i_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_time);
	}//while  (!feof(pf_pop_file))
		
	fclose(pf_pop_file);
	pcResult->d_time  =  d_time;
	pcResult->d_fit_value  =  (1.0 / d_best_individual);
	pcResult->d_fit_value  =  pcResult->d_fit_value  - 1.0;
	pcResult->d_fit_value  =  Math::Round(pcResult->d_fit_value);

	FileInfo  *fi_rep  =  new  FileInfo(s_pop_fom_watch);
	System::DateTime  dt_creation;
	dt_creation  =  fi_rep->CreationTime;
	pcResult->dt_generated  =  dt_creation.ToFileTime();


	
	return(c_err);
}//CError  CSystem::e_load_result_params_standard_ea_header_2_0




CError  CSystem::e_load_result_params_hefan_1_1_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		)
{
	CError  c_err;

	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number, l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;
	long  l_capa_incr, l_capa_gen_incr;
	double  d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross;
	long  l_pop_num,  l_gen_num;
	double  d_time_restriction;

	long  l_brain_avr_len;
	double  d_brain_min_inc;
	long  l_brain_time_len,  l_brain_finish_time,  l_brain_min_break;


	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "flow increase", &s_info);
	if  (c_err)  return(c_err);
	l_capa_incr  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "flow increase every x generations", &s_info);
	if  (c_err)  return(c_err);
	l_capa_gen_incr  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_high_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_high_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Low level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_low_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Low level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_low_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level crossing unordered", &s_info);
	if  (c_err)  return(c_err);
	d_random_cross  =  atof( (LPCSTR)  s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Population size", &s_info);
	if  (c_err)  return(c_err);
	l_pop_num  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Generation number", &s_info);
	if  (c_err)  return(c_err);
	l_gen_num  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Time restriction", &s_info);
	if  (c_err)  return(c_err);
	d_time_restriction  =  atof( (LPCSTR)  s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm radius", &s_info);
	if  (c_err)  return(c_err);
	l_brain_avr_len  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm turn on perc", &s_info);
	if  (c_err)  return(c_err);
	d_brain_min_inc  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm duration", &s_info);
	if  (c_err)  return(c_err);
	l_brain_time_len  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm turning off", &s_info);
	if  (c_err)  return(c_err);
	l_brain_finish_time  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm min break", &s_info);
	if  (c_err)  return(c_err);
	l_brain_min_break  =  atol( (LPCSTR)  s_info );

	fclose(pfSettingsFile);
				
	//the population size nedds to be divided by 4 first
	l_pop_num  =  l_pop_num / 4;

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch;

	//now inserting params into the params window

	CString  s_buf;
	//general data

	//algorithm loading
	c_err  =  eGetAlgorithm(HEFAN_1_1_NAME, pcAlgorithm);
	if  (c_err)  return(c_err);


	c_codb.vSetSqlConn(pcAlgorithm);
    c_err  =  pcAlgorithm->eRefreshParams();
	if  (c_err)  return(c_err);


	//fit function
	CCOFitFunc  c_fit_func(NULL);
	c_err  =  eGetFitFunc(s_fom_func, &c_fit_func);
	if  (c_err)  return(c_err);
	pcResult->i_fit_id  =  c_fit_func.iGetId();



	//net loading
	CCONet  c_net(NULL);
	FileInfo  *fi_net  =  new  FileInfo(s_topology);
	s_buf  =  fi_net->Name;

	int  i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_net_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_net_name  +=  s_buf.GetAt(ii);
	else
		s_net_name  =  s_buf;

	c_err  =  eGetNet(pcFdbRoot, &c_net,  s_net_name);
	if  (c_err)  return(c_err);



	//con loading
	CCONetConn  c_net_conn(NULL);
	FileInfo  *fi_con  =  new  FileInfo(s_con_file);
	s_buf  =  fi_con->Name;

	i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_con_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_con_name  +=  s_buf.GetAt(ii);
	else
		s_con_name  =  s_buf;

	c_codb.vSetSqlConn(&c_net);
	c_err  =  eGetCon(&c_net, s_con_name, &c_net_conn);
	if  (c_err)  return(c_err);

	pcResult->i_con_id  =  c_net_conn.iGetId();



	//initial solution
	if  (s_ini_file  !=  "")
	{
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 1.0);
		pvFiles->push_back(s_ini_file);
	}//if  (s_ini_file  !=  "")
	else
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 0);
	
	if  (c_err)  return(c_err);
	

	if  (s_res_file  !=  "")
	{
		pvFiles->push_back(s_res_file  +  ".rep");
		pvFiles->push_back(s_res_file  +  ".ful");
		pvFiles->push_back(s_res_file  +  ".vwd");
		pvFiles->push_back(s_res_file  +  ".vws");
	}//if  (s_info  !=  "")


	//population tracj file
	if  (s_pop_fom_watch  !=  "")
	{
		pvFiles->push_back(s_pop_fom_watch);
	}//if  (s_info  !=  "")



	//cloner repetations
	c_err  =  eSetParameter(pcAlgorithm, "Clone repetations", l_clo_rep);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "init shortest ways", l_shortest_ways_number);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "top individuals", l_res_num);
	if  (c_err)  return(c_err);


	//allow to exceed link capacity
	if  (b_allow_capacity_overloading)
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 1.0);
	else
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 0);
	if  (c_err)  return(c_err);


	//capa penalty
	c_err  =  eSetParameter(pcAlgorithm, "Exceed link capacity penalty", l_capa_penalty);
	if  (c_err)  return(c_err);


	//flow increase
	c_err  =  eSetParameter(pcAlgorithm, "Flow increase", l_capa_incr);
	if  (c_err)  return(c_err);

	
	//flow increase every x generations
	c_err  =  eSetParameter(pcAlgorithm, "Flow increase every x generations", l_capa_gen_incr);
	if  (c_err)  return(c_err);


	//algorithm parameters

	//high level crossing
	c_err  =  eSetParameter(pcAlgorithm, "High level crossing", d_high_cross);
	if  (c_err)  return(c_err);

	//high level mutation
	c_err  =  eSetParameter(pcAlgorithm, "High level mutation", d_high_mut);
	if  (c_err)  return(c_err);


	//high level unordered crossing
	c_err  =  eSetParameter(pcAlgorithm, "High level crossing unordered", d_random_cross);
	if  (c_err)  return(c_err);


	//low level crossing
	c_err  =  eSetParameter(pcAlgorithm, "Low level crossing", d_low_cross);
	if  (c_err)  return(c_err);

	//low level mutation
	c_err  =  eSetParameter(pcAlgorithm, "Low level mutation", d_low_mut);
	if  (c_err)  return(c_err);


	//population size
	c_err  =  eSetParameter(pcAlgorithm, "Population size", l_pop_num * 4);
	if  (c_err)  return(c_err);

	if  (d_time_restriction  >  0)
	{
		c_err  =  eSetParameter(pcAlgorithm, "Time restriction", d_time_restriction);
		if  (c_err)  return(c_err);

		//GENERATION NUMBER!!!!
	}//if  (d_time_restriction  >  0)
	else
	{
		c_err  =  eSetParameter(pcAlgorithm, "Time restriction", d_time_restriction);
		if  (c_err)  return(c_err);

		//generation number
		c_err  =  eSetParameter(pcAlgorithm, "Generation number", l_gen_num);
		if  (c_err)  return(c_err);
	}//else  if  (d_time_restriction  >  0)


	//brainstorm radius
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm radius", l_brain_avr_len);
	if  (c_err)  return(c_err);

	//brainstorm turn on %
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm turn on %", d_brain_min_inc);
	if  (c_err)  return(c_err);

	//brainstorm duration
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm duration", l_brain_time_len);
	if  (c_err)  return(c_err);


	//brainstorm turning off
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm turning off", l_brain_finish_time);
	if  (c_err)  return(c_err);


	//brainstorm break
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm min break", l_brain_min_break);
	if  (c_err)  return(c_err);



	//algorithm running time
	FILE  *pf_pop_file;
	pf_pop_file  =  fopen(s_pop_fom_watch, "r+");

	if  (pf_pop_file  ==  NULL)
	{
		s_buf.Format("Unable to open population fitness tracking file (%s)", (LPCSTR) s_pop_fom_watch);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_pop_file  ==  NULL)
	
	int  i_buf;
	double  d_buf,  d_time, d_best_individual;
	char  pc_buf[100];

	fscanf(pf_pop_file, "\n");
	fscanf(pf_pop_file, "\n");

	while  (!feof(pf_pop_file))
	{
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%d", &i_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%s", pc_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_best_individual);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%d", &i_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_time);
	}//while  (!feof(pf_pop_file))
		
	fclose(pf_pop_file);
	pcResult->d_time  =  d_time;
	pcResult->d_fit_value  =  (1.0 / d_best_individual);
	pcResult->d_fit_value  =  pcResult->d_fit_value  - 1.0;
	pcResult->d_fit_value  =  Math::Round(pcResult->d_fit_value);

	FileInfo  *fi_rep  =  new  FileInfo(s_pop_fom_watch);
	System::DateTime  dt_creation;
	dt_creation  =  fi_rep->CreationTime;
	pcResult->dt_generated  =  dt_creation.ToFileTime();


	
	return(c_err);
}//CError  CSystem::e_load_result_params_hefan_1_0_header_2_0





CError  CSystem::e_load_result_params_hefan_1_0_header_2_0
		(
		FILE  *pfSettingsFile,
		CString  sMotherDir,  CString  sSettingsFileDir,
		CCOFDbRoot  *pcFdbRoot, 
		vector <CString>  *pvFiles,
		CCOAlgorithm  *pcAlgorithm,
		CCOResult  *pcResult
		)
{
	CError  c_err;

	CString  s_info;

	CString  s_fom_func;
	CString  s_topology, s_con_file,  s_ini_file,  s_vw_file;
	CString  s_res_file,  s_pop_fom_watch;
	long  l_clo_rep,  l_shortest_ways_number,  l_res_num;
	bool  b_allow_capacity_overloading;
	long  l_capa_penalty;
	long  l_capa_incr, l_capa_gen_incr;
	double  d_high_cross,  d_high_mut,  d_low_cross,  d_low_mut, d_random_cross;
	long  l_pop_num,  l_gen_num;
	double  d_time_restriction;

	long  l_brain_avr_len;
	double  d_brain_min_inc;
	long  l_brain_time_len,  l_brain_finish_time,  l_brain_min_break;


	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "cost function", &s_fom_func);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "topology", &s_topology);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "connections", &s_con_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "start solution", &s_ini_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "VWaysDb", &s_vw_file);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "result files", &s_res_file);
	if  (c_err)  return(c_err);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "fitness tracking file", &s_pop_fom_watch);
	if  (c_err)  return(c_err);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "clone repetations", &s_info);
	if  (c_err)  return(c_err);
	l_clo_rep  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "init shortest ways", &s_info);
	if  (c_err)  return(c_err);
	l_shortest_ways_number  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "top individuals", &s_info);
	if  (c_err)  return(c_err);
	l_res_num  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "allow exceed link capacity", &s_info);
	if  (c_err)  return(c_err);
	if  (s_info.MakeLower()  ==  "allowed")
		b_allow_capacity_overloading  =  true;
	else
		b_allow_capacity_overloading  =  false;

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "exceed link capacity penalty", &s_info);
	if  (c_err)  return(c_err);
	l_capa_penalty  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "flow increase", &s_info);
	if  (c_err)  return(c_err);
	l_capa_incr  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "flow increase every x generations", &s_info);
	if  (c_err)  return(c_err);
	l_capa_gen_incr  =  atol( (LPCSTR)  s_info );

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_high_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_high_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Low level crossing", &s_info);
	if  (c_err)  return(c_err);
	d_low_cross  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Low level mutation", &s_info);
	if  (c_err)  return(c_err);
	d_low_mut  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "High level crossing unordered", &s_info);
	if  (c_err)  return(c_err);
	d_random_cross  =  atof( (LPCSTR)  s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Population size", &s_info);
	if  (c_err)  return(c_err);
	l_pop_num  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Generation number", &s_info);
	if  (c_err)  return(c_err);
	l_gen_num  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Time restriction", &s_info);
	if  (c_err)  return(c_err);
	d_time_restriction  =  atof( (LPCSTR)  s_info);

	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm radius", &s_info);
	if  (c_err)  return(c_err);
	l_brain_avr_len  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm turn on perc", &s_info);
	if  (c_err)  return(c_err);
	d_brain_min_inc  =  atof( (LPCSTR)  s_info);
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm duration", &s_info);
	if  (c_err)  return(c_err);
	l_brain_time_len  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm turning off", &s_info);
	if  (c_err)  return(c_err);
	l_brain_finish_time  =  atol( (LPCSTR)  s_info );
	c_err  =  CHefanSystem::eReadValue(pfSettingsFile,  "Brainstorm min break", &s_info);
	if  (c_err)  return(c_err);
	l_brain_min_break  =  atol( (LPCSTR)  s_info );

	fclose(pfSettingsFile);
				
	//the population size nedds to be divided by 4 first
	l_pop_num  =  l_pop_num / 4;

	//now we have to update the directory based values
	s_topology  =  sMotherDir  +  "\\"  +  s_topology;
	s_con_file  =  sMotherDir  +  "\\"  +  s_con_file;
	if  (s_ini_file  !=  "")
		s_ini_file  =  sMotherDir  +  "\\"  +  s_ini_file;
	if  (s_vw_file  !=  "")
		s_vw_file  =  sMotherDir  +  "\\"  +  s_vw_file;
	s_res_file  =  sSettingsFileDir  +  "\\"  +  s_res_file;
	s_pop_fom_watch  =  sSettingsFileDir  +  "\\"  +  s_pop_fom_watch;

	//now inserting params into the params window

	CString  s_buf;
	//general data

	//algorithm loading
	c_err  =  eGetAlgorithm(HEFAN_1_0_NAME, pcAlgorithm);
	if  (c_err)  return(c_err);


	c_codb.vSetSqlConn(pcAlgorithm);
    c_err  =  pcAlgorithm->eRefreshParams();
	if  (c_err)  return(c_err);


	//fit function
	CCOFitFunc  c_fit_func(NULL);
	c_err  =  eGetFitFunc(s_fom_func, &c_fit_func);
	if  (c_err)  return(c_err);
	pcResult->i_fit_id  =  c_fit_func.iGetId();



	//net loading
	CCONet  c_net(NULL);
	FileInfo  *fi_net  =  new  FileInfo(s_topology);
	s_buf  =  fi_net->Name;

	int  i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_net_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_net_name  +=  s_buf.GetAt(ii);
	else
		s_net_name  =  s_buf;

	c_err  =  eGetNet(pcFdbRoot, &c_net, s_net_name);
	if  (c_err)  return(c_err);



	//con loading
	CCONetConn  c_net_conn(NULL);
	FileInfo  *fi_con  =  new  FileInfo(s_con_file);
	s_buf  =  fi_con->Name;

	i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_con_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_con_name  +=  s_buf.GetAt(ii);
	else
		s_con_name  =  s_buf;

	c_codb.vSetSqlConn(&c_net);
	c_err  =  eGetCon(&c_net, s_con_name, &c_net_conn);
	if  (c_err)  return(c_err);

	pcResult->i_con_id  =  c_net_conn.iGetId();



	//initial solution
	if  (s_ini_file  !=  "")
	{
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 1.0);
		pvFiles->push_back(s_ini_file);
	}//if  (s_ini_file  !=  "")
	else
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 0);
	
	if  (c_err)  return(c_err);
	

	if  (s_res_file  !=  "")
	{
		pvFiles->push_back(s_res_file  +  ".rep");
		pvFiles->push_back(s_res_file  +  ".ful");
		pvFiles->push_back(s_res_file  +  ".vwd");
		pvFiles->push_back(s_res_file  +  ".vws");
	}//if  (s_info  !=  "")


	//population tracj file
	if  (s_pop_fom_watch  !=  "")
	{
		pvFiles->push_back(s_pop_fom_watch);
	}//if  (s_info  !=  "")



	//cloner repetations
	c_err  =  eSetParameter(pcAlgorithm, "Clone repetations", l_clo_rep);
	if  (c_err)  return(c_err);

	c_err  =  eSetParameter(pcAlgorithm, "init shortest ways", l_shortest_ways_number);
	if  (c_err)  return(c_err);


	c_err  =  eSetParameter(pcAlgorithm, "top individuals", l_res_num);
	if  (c_err)  return(c_err);


	//allow to exceed link capacity
	if  (b_allow_capacity_overloading)
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 1.0);
	else
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 0);
	if  (c_err)  return(c_err);


	//capa penalty
	c_err  =  eSetParameter(pcAlgorithm, "Exceed link capacity penalty", l_capa_penalty);
	if  (c_err)  return(c_err);


	//flow increase
	c_err  =  eSetParameter(pcAlgorithm, "Flow increase", l_capa_incr);
	if  (c_err)  return(c_err);

	
	//flow increase every x generations
	c_err  =  eSetParameter(pcAlgorithm, "Flow increase every x generations", l_capa_gen_incr);
	if  (c_err)  return(c_err);


	//algorithm parameters

	//high level crossing
	c_err  =  eSetParameter(pcAlgorithm, "High level crossing", d_high_cross);
	if  (c_err)  return(c_err);

	//high level mutation
	c_err  =  eSetParameter(pcAlgorithm, "High level mutation", d_high_mut);
	if  (c_err)  return(c_err);


	//high level unordered crossing
	c_err  =  eSetParameter(pcAlgorithm, "High level crossing unordered", d_random_cross);
	if  (c_err)  return(c_err);


	//low level crossing
	c_err  =  eSetParameter(pcAlgorithm, "Low level crossing", d_low_cross);
	if  (c_err)  return(c_err);

	//low level mutation
	c_err  =  eSetParameter(pcAlgorithm, "Low level mutation", d_low_mut);
	if  (c_err)  return(c_err);


	//population size
	c_err  =  eSetParameter(pcAlgorithm, "Population size", l_pop_num * 4);
	if  (c_err)  return(c_err);

	if  (d_time_restriction  >  0)
	{
		c_err  =  eSetParameter(pcAlgorithm, "Time restriction", d_time_restriction);
		if  (c_err)  return(c_err);

		//GENERATION NUMBER!!!!
	}//if  (d_time_restriction  >  0)
	else
	{
		c_err  =  eSetParameter(pcAlgorithm, "Time restriction", d_time_restriction);
		if  (c_err)  return(c_err);

		//generation number
		c_err  =  eSetParameter(pcAlgorithm, "Generation number", l_gen_num);
		if  (c_err)  return(c_err);
	}//else  if  (d_time_restriction  >  0)


	//brainstorm radius
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm radius", l_brain_avr_len);
	if  (c_err)  return(c_err);

	//brainstorm turn on %
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm turn on %", d_brain_min_inc);
	if  (c_err)  return(c_err);

	//brainstorm duration
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm duration", l_brain_time_len);
	if  (c_err)  return(c_err);


	//brainstorm turning off
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm turning off", l_brain_finish_time);
	if  (c_err)  return(c_err);


	//brainstorm break
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm min break", l_brain_min_break);
	if  (c_err)  return(c_err);



	//algorithm running time
	FILE  *pf_pop_file;
	pf_pop_file  =  fopen(s_pop_fom_watch, "r+");

	if  (pf_pop_file  ==  NULL)
	{
		s_buf.Format("Unable to open population fitness tracking file (%s)", (LPCSTR) s_pop_fom_watch);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_pop_file  ==  NULL)
	
	int  i_buf;
	double  d_buf,  d_time, d_best_individual;
	char  pc_buf[100];

	fscanf(pf_pop_file, "\n");
	fscanf(pf_pop_file, "\n");

	while  (!feof(pf_pop_file))
	{
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%d", &i_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%s", pc_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_best_individual);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%d", &i_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_buf);
		if  (!feof(pf_pop_file))  fscanf(pf_pop_file, "%lf", &d_time);
	}//while  (!feof(pf_pop_file))
		
	fclose(pf_pop_file);
	pcResult->d_time  =  d_time;
	pcResult->d_fit_value  =  (1.0 / d_best_individual);
	pcResult->d_fit_value  =  pcResult->d_fit_value  - 1.0;
	pcResult->d_fit_value  =  Math::Round(pcResult->d_fit_value);

	FileInfo  *fi_rep  =  new  FileInfo(s_pop_fom_watch);
	System::DateTime  dt_creation;
	dt_creation  =  fi_rep->CreationTime;
	pcResult->dt_generated  =  dt_creation.ToFileTime();


	
	return(c_err);
}//CError  CSystem::e_load_result_params_hefan_1_0_header_2_0




CError  CSystem::e_load_result_params_from_file_header_2_0
	(
	CString  sSettingsFile,
	CCOFDbRoot  *pcFdbRoot,
	vector <CString>  *pvFiles,
	CCOAlgorithm  *pcAlgorithm,
	CCOResult  *pcResult
	)
{
	CError  c_err;
	CString  s_buf;

	CString  s_mother_directory,  s_settings_file_directory;

	FileInfo  *pc_fi;
	pc_fi  =  new  FileInfo(sSettingsFile);
	s_settings_file_directory  =  pc_fi->Directory->FullName;
	s_mother_directory  =  (Directory::GetParent(s_settings_file_directory))->FullName;


	FILE  *pf_settings_file;
	pf_settings_file  =  fopen(sSettingsFile, "r+");
	if  (pf_settings_file  ==  NULL)
	{
		s_buf.Format("Unable to open file (%s)", (LPCSTR)  sSettingsFile);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_source  ==  NULL)


	CString  s_info,  s_comment;
	CHefanSystem::vReadLine(pf_settings_file, &s_info, &s_comment);//script version...
	CHefanSystem::vReadLine(pf_settings_file, &s_info, &s_comment);

	if  (s_comment.MakeLower()  !=  "algorithm")
	{
        c_err.vPutError("'algorithm' definition expected");	
		return(c_err);
	}//if  (s_comment.MakeLower()  !=  "algorithm")

	bool  b_algorithm_type_found  =  false;
    if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_load_result_params_hefan_1_0_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			pcFdbRoot,	pvFiles,
			pcAlgorithm,  pcResult
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)

	
	if  (s_info.MakeUpper()  ==  HEFAN_1_1_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_load_result_params_hefan_1_1_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			pcFdbRoot,	pvFiles,
			pcAlgorithm,  pcResult
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)


	if  ( (s_info.MakeUpper()  ==  HEFAN_2_0_NAME)||(s_info.MakeUpper()  ==  HEFAN_2_1_NAME)||(s_info.MakeUpper()  ==  HEFAN_2_2_NAME) )
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_load_result_params_hefan_2_0_header_2_0_and_2_1_and_2_2
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			pcFdbRoot,	pvFiles,
			pcAlgorithm,  pcResult,
			s_info.MakeUpper()
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)


	if  (s_info.MakeUpper()  ==  EA_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_load_result_params_standard_ea_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			pcFdbRoot,	pvFiles,
			pcAlgorithm,  pcResult
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)


	if  (s_info.MakeUpper()  ==  VMEA_NAME)
	{
		b_algorithm_type_found  =  true;
		c_err  =  e_load_result_params_vmea_header_2_0
			(
			pf_settings_file,
			s_mother_directory,  s_settings_file_directory,
			pcFdbRoot,	pvFiles,
			pcAlgorithm,  pcResult
			);
	}//if  (s_info.MakeUpper()  ==  HEFAN_1_0_NAME)

	if  (b_algorithm_type_found  ==  false)
	{
		s_buf.Format("Algorithm named '%s' not found", (LPCSTR) s_info.MakeUpper());
		c_err.vPutError(s_buf);
		fclose(pf_settings_file);
		return(c_err);	
	}//if  (b_algorithm_type_found  ==  false)

	fclose(pf_settings_file);
	return(c_err);
}//CError  CSystem::e_load_result_params_from_file_header_2_0













CError  CSystem::e_load_result_params_from_file_header_1_0
	(
	CString  sSettingsFile,
	CCOFDbRoot  *pcFdbRoot,
	vector <CString>  *pvFiles,
	CCOAlgorithm  *pcAlgorithm,
	CCOResult  *pcResult
	)
{
	CError  c_err;
	CString  s_info,  s_comments;
	CString  s_buf;

	//settings file opening first...
	FILE  *pf_settings;
	pf_settings  =  fopen(sSettingsFile, "r+");
	if  (pf_settings  == NULL)
	{
		c_err.vPutError("Unable to open file");
		return(c_err);	
	}//if  (pf_settings  == NULL)




	//algorithm loading
	c_err  =  eGetAlgorithm(HEFAN_1_0_NAME, pcAlgorithm);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	c_codb.vSetSqlConn(pcAlgorithm);
    c_err  =  pcAlgorithm->eRefreshParams();
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)
	

	//net loading
	CCONet  c_net(NULL);
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	FileInfo  *fi_net  =  new  FileInfo(s_info);
	s_buf  =  fi_net->Name;

	int  i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_net_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_net_name  +=  s_buf.GetAt(ii);
	else
		s_net_name  =  s_buf;

	c_err  =  eGetNet(pcFdbRoot, &c_net, s_net_name);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)



	//virt ways - just read it
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	


	//con loading
	CCONetConn  c_net_conn(NULL);
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	FileInfo  *fi_con  =  new  FileInfo(s_info);
	s_buf  =  fi_con->Name;

	i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_con_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_con_name  +=  s_buf.GetAt(ii);
	else
		s_con_name  =  s_buf;

	c_codb.vSetSqlConn(&c_net);
	c_err  =  eGetCon(&c_net, s_con_name, &c_net_conn);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	pcResult->i_con_id  =  c_net_conn.iGetId();


	//initial solution
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	//initial solution
	if  (s_info  !=  "")
	{
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 1.0);
		pvFiles->push_back(s_info);
	}//if  (s_ini_file  !=  "")
	else
		c_err  =  eSetParameter(pcAlgorithm, "Init solution", 0);


	//cloner repetations
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_repeat;
	d_repeat  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Clone repetations", d_repeat);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)


	//fit function
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	if  (s_info  ==  "1")  s_info  =  "LFN";
	if  (s_info  ==  "0")  s_info  =  "MWP";
	CCOFitFunc  c_fit_func(NULL);
	c_err  =  eGetFitFunc(s_info, &c_fit_func);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	pcResult->i_fit_id  =  c_fit_func.iGetId();


	//result files
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	if  (s_info  !=  "")
	{
		pvFiles->push_back(s_info  +  ".rep");
		pvFiles->push_back(s_info  +  ".ful");
		pvFiles->push_back(s_info  +  ".vwd");
		pvFiles->push_back(s_info  +  ".vws");
	}//if  (s_info  !=  "")


	//extracting fom...
	FILE  *pf_res_file;
	CString  s_rep_file_name;
	s_rep_file_name  =  s_info  +  ".rep";
	pf_res_file  =  fopen(s_rep_file_name,"r+");
	if  (pf_res_file  ==  NULL)
	{
		s_buf.Format("Couldnt open report file for fit value extraction (%s)", (LPCSTR) (s_info  +  ".rep"));
		c_err.vPutError(s_buf);
		fclose(pf_settings);
		return(c_err);
	}//if  (pf_res_file  ==  NULL)
	
	for  (int  ii = 0; ii < 9; ii++ )  CHefanSystem::vReadLine(pf_res_file, &s_info,  &s_comments);
	char  c_buf = ' ';
	for  (;c_buf  !=  ':';)  fscanf(pf_res_file,"%c",&c_buf);
	double d_fit;
	fscanf(pf_res_file,"%lf",&d_fit);
	fclose(pf_res_file);

	pcResult->d_fit_value  =  Math::Round((1.0 / d_fit)  - 1.0, 0);

	FileInfo  *fi_rep  =  new  FileInfo(s_rep_file_name);

	System::DateTime  dt_creation;
	dt_creation  =  fi_rep->CreationTime;
	pcResult->dt_generated  =  dt_creation.ToFileTime();

	



	//top individuals number
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_top_individuals;
	d_top_individuals  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Top individuals", d_top_individuals);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)


	//population tracj file
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	if  (s_info  !=  "")
	{
		pvFiles->push_back(s_info);
	}//if  (s_info  !=  "")


	if  ( !(File::Exists(s_info)) )
	{
		s_buf.Format("Population file not found (%s)", s_info);
		c_err.vPutError(s_buf);
		fclose(pf_settings);
		return(c_err);	
	}//if  ( !(File::Exists(s_info)) )
	
	FileInfo  *fi_pop  =  new  FileInfo(s_info);
	
	System::DateTime  dt_finished, dt_comput_start;
	dt_finished  =  fi_pop->LastWriteTime;
	dt_comput_start  =  fi_pop->CreationTime;
	
	System::TimeSpan  ts_interval  =  dt_finished  -  dt_comput_start;
	pcResult->d_time  =  ts_interval.TotalSeconds;


	//allow to exceed link capacity
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	if  (s_info  ==  "przekraczaj")
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 1.0);
	else
		c_err  =  eSetParameter(pcAlgorithm, "Allow exceed link capacity", 0);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	//exceed link capacity penalty
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_penalty;
	d_penalty  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Exceed link capacity penalty", d_penalty);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	//flow increase
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_flow_inc;
	d_flow_inc  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Flow increase", d_flow_inc);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	
	//flow increase every x generations
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_flow_inc_gen;
	d_flow_inc_gen  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Flow increase every x generations", d_flow_inc_gen);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)


	//high level crossing
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_hi_lvl_cross;
	d_hi_lvl_cross  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "High level crossing", d_hi_lvl_cross);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	//high level mutation
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_hi_lvl_mut;
	d_hi_lvl_mut  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "High level mutation", d_hi_lvl_mut);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)


	//low level crossing
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_low_lvl_cross;
	d_low_lvl_cross  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Low level crossing", d_low_lvl_cross);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	//low level mutation
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_low_lvl_mut;
	d_low_lvl_mut  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Low level mutation", d_low_lvl_mut);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)


	//high level unordered crossing
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_hi_lvl_unordered_cross;
	d_hi_lvl_unordered_cross  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "High level crossing unordered", d_hi_lvl_unordered_cross);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)


	//population size
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_pop_size;
	d_pop_size  =  atof( (LPCSTR) s_info);
	d_pop_size  *=  4.0;
	c_err  =  eSetParameter(pcAlgorithm, "Population size", d_pop_size);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)


	//generation number
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_gen_num;
	d_gen_num  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Generation number", d_gen_num);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)



	//brainstorm radius
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_brain_rad;
	d_brain_rad  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm radius", d_brain_rad);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	//brainstorm turn on %
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_brain_on;
	d_brain_on  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm turn on %", d_brain_on);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	//brainstorm duration
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_brain_duration;
	d_brain_duration  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm duration", d_brain_duration);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)

	//brainstorm turning off
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_brain_off;
	d_brain_off  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm turning off", d_brain_off);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)


	//brainstorm break
	CHefanSystem::vReadLine(pf_settings, &s_info,  &s_comments);
	double  d_brain_break;
	d_brain_break  =  atof( (LPCSTR) s_info);
	c_err  =  eSetParameter(pcAlgorithm, "Brainstorm min break", d_brain_break);
	if  (c_err)  
	{
		fclose(pf_settings);
		return(c_err);
	}//if  (c_err)



    fclose(pf_settings);
    return(c_err);
}//CError  CSystem::e_load_result_params_from_file_hefan_1_0(CString  sSettingsFile)



CError  CSystem::eLoadResultParamsFromFile
	(
	CString  sSettingsFile,
	CCOFDbRoot  *pcFdbRoot,
	vector <CString>  *pvFiles,
	CCOAlgorithm  *pcAlgorithm,
	CCOResult  *pcResult
	)
{
	CError  c_err;

	//first we do the parameter check-up
	if  (pcFdbRoot  ==  NULL)
	{
		c_err.vPutError("No fdb root assigned");
		c_err.vShowWindow();
		return(c_err);
	}//if  (pc_fdb_root  ==  NULL)


	int  i_header_type;
	c_err  =  CHefanSystem::eCheckHeader(sSettingsFile,  &i_header_type);
	if  (c_err)  return(c_err);

	bool  b_header_found;
	b_header_found  =  false;

	if  ( (b_header_found  ==  false)&&(i_header_type  ==  HEADER_TYPE_HEFAN_1_0) )
	{
		c_err  =  e_load_result_params_from_file_header_1_0
			(
			sSettingsFile, pcFdbRoot,
			pvFiles,
			pcAlgorithm,
			pcResult
			);
		b_header_found  =  true;
	}//if  ( (b_header_found  ==  false)&&(i_header_type  ==  HEADER_TYPE_HEFAN_1_0) )

	if  ( (b_header_found  ==  false)&&(i_header_type  ==  HEADER_TYPE_HEFAN_2_0) )
	{
		c_err  =  e_load_result_params_from_file_header_2_0
			(
			sSettingsFile, pcFdbRoot,
			pvFiles,
			pcAlgorithm,
			pcResult
			);
		b_header_found  =  true;	
	}//if  ( (b_header_found  ==  false)&&(i_header_type  ==  HEADER_TYPE_HEFAN_2_0) )

	else
		c_err.vPutError("Unknown header");

	


	return(c_err);
}//CError  CSystem::eLoadResultParamsFromFile



CError  CSystem::eLoadResultFromSolutionFile
	(
	CString  sSolutionFile,
	CCOFDbRoot  *pcFdbRoot,
	CString  sFFName,
	CCOResult  *pcResult,
	CCONet  *pcNet,  CCONetConn  *pcNetConn,  
	long  lPenalty
	)
{
	CError  c_err;

	//first we do the parameter check-up
	if  (pcFdbRoot  ==  NULL)
	{
		c_err.vPutError("No fdb root assigned");
		c_err.vShowWindow();
		return(c_err);
	}//if  (pc_fdb_root  ==  NULL)


	CString  s_buf;
	FileInfo  *fi_ini  =  new  FileInfo(sSolutionFile);
	s_buf  =  fi_ini->Name;

	int  i_dot_pos  =  0;
	if  (s_buf.GetAt(s_buf.GetLength() - 4)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 4;
	if  (s_buf.GetAt(s_buf.GetLength() - 3)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 3;
	if  (s_buf.GetAt(s_buf.GetLength() - 2)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 2;
	if  (s_buf.GetAt(s_buf.GetLength() - 1)  ==  '.')  i_dot_pos  =  s_buf.GetLength() - 1;

	CString  s_ini_name;
	if  (i_dot_pos  >  0)
		for  (int  ii = 0; ii < i_dot_pos; ii++)
			s_ini_name  +=  s_buf.GetAt(ii);
	else
		s_ini_name  =  s_buf;

	

	c_err  =  eGetNet(pcFdbRoot, pcNet, s_ini_name);
	if  (c_err)  return(c_err);
	c_err  =  eGetCon(pcNet, s_ini_name, pcNetConn);
	if  (c_err)  return(c_err);

	CHefanSystem  c_hef_sys;
	double  d_sol_fit;
	c_err  =  c_hef_sys.eGetSolutionFitness
		(
		pcFdbRoot->sGetRootDir() + "\\" + pcNet->sGetNetDir() + "\\" + pcNet->sGetName() + ".net", 
		pcFdbRoot->sGetRootDir() + "\\" + pcNet->sGetNetDir() + "\\" + pcNetConn->sGetConnDir() + "\\" + pcNetConn->sGetName() + ".con",
		sSolutionFile,
		sFFName,
		&d_sol_fit,  lPenalty
		);

	pcResult->d_fit_value  =  d_sol_fit;
	pcResult->dt_generated  =  fi_ini->CreationTime.ToFileTime();

	

	return(c_err);
}//CError  CSystem::eLoadResultFromSolutionFile



CError  CSystem::eSelectFDbRoot(vector <CCOFDbRoot *>  *pvFDbRoots, CString sSelectSQL)
{
	CError  c_err;


	if  (c_codb.bIsConnected()  ==  false)
	{
		c_codb.bLoadConnConf("config.txt");
		c_err  =  c_codb.eConnect();
	}//if  (c_kalk_db.bIsConnected()  ==  false)


	if  (c_err  ==  false)
	{
		c_err  =  c_codb.eSelectFDbRoot(pvFDbRoots, sSelectSQL);
	}//if  (c_kalk_db.bConnect())
	else
	{
		c_err.vShowWindow();
		return(c_err);
	}//else  if  (c_err  ==  false)
	
	return(c_err);
};//CError  CSystem::eSelectMeasure(vector <CKDbMeasure *>  *pvKDbMeasures, CString sSelectSQL)



CError  CSystem::eSelectNetworks(vector <CCONet *>  *pvCONetworks, CString sSelectSQL)
{
	CError  c_err;

	if  (c_codb.bIsConnected()  ==  false)
	{
		c_codb.bLoadConnConf("config.txt");
		c_err  =  c_codb.eConnect();
	}//if  (c_kalk_db.bIsConnected()  ==  false)


	if  (c_err  ==  false)
	{
		c_err  =  c_codb.eSelectCONets(pvCONetworks, sSelectSQL);
	}//if  (c_kalk_db.bConnect())
	else
	{
		c_err.vShowWindow();
		return(c_err);
	}//else  if  (c_err  ==  false)
	
	return(c_err);
}//CError  CSystem::eSelectNetwork(vector <CCONetwork *>  *pvCONetworks, CString sSelectSQL)




CError  CSystem::eSelectConnections(vector <CCONetConn *>  *pvCOConns, CString sSelectSQL)
{
	CError  c_err;

	if  (c_codb.bIsConnected()  ==  false)
	{
		c_codb.bLoadConnConf("config.txt");
		c_err  =  c_codb.eConnect();
	}//if  (c_kalk_db.bIsConnected()  ==  false)


	if  (c_err  ==  false)
	{
		c_err  =  c_codb.eSelectConnections(pvCOConns, sSelectSQL);
	}//if  (c_kalk_db.bConnect())
	else
	{
		c_err.vShowWindow();
		return(c_err);
	}//else  if  (c_err  ==  false)
	
	return(c_err);
}//CError  CSystem::eSelectNetwork(vector <CCONetwork *>  *pvCONetworks, CString sSelectSQL)




CError  CSystem::eSelectAlgorithms(vector <CCOAlgorithm *>  *pvCOAlgorithms, CString sSelectSQL)
{
	CError  c_err;


	if  (c_codb.bIsConnected()  ==  false)
	{
		c_codb.bLoadConnConf("config.txt");
		c_err  =  c_codb.eConnect();
	}//if  (c_kalk_db.bIsConnected()  ==  false)


	if  (c_err  ==  false)
	{
		c_err  =  c_codb.eSelectAlgorithms(pvCOAlgorithms, sSelectSQL);
	}//if  (c_kalk_db.bConnect())
	else
	{
		c_err.vShowWindow();
		return(c_err);
	}//else  if  (c_err  ==  false)
	
	return(c_err);
};//CError  CSystem::eSelectAlgorithms(vector <CCOAlgorithm *>  *pvCOAlgorithms, CString sSelectSQL)



CError  CSystem::eSelectFitFuncs(vector <CCOFitFunc *>  *pvCOFitFuncs, CString sSelectSQL)
{
	CError  c_err;


	if  (c_codb.bIsConnected()  ==  false)
	{
		c_codb.bLoadConnConf("config.txt");
		c_err  =  c_codb.eConnect();
	}//if  (c_kalk_db.bIsConnected()  ==  false)


	if  (c_err  ==  false)
	{
		c_err  =  c_codb.eSelectFitFuncs(pvCOFitFuncs, sSelectSQL);
	}//if  (c_kalk_db.bConnect())
	else
	{
		c_err.vShowWindow();
		return(c_err);
	}//else  if  (c_err  ==  false)
	
	return(c_err);
};//CError  CSystem::eSelectAlgorithms(vector <CCOFitFunc *>  *pvCOAlgorithms, CString sSelectSQL)




CError  CSystem::eSelectResults(vector <CCOResult *>  *pvCOResults, CString sSelectSQL)
{
	CError  c_err;


	if  (c_codb.bIsConnected()  ==  false)
	{
		c_codb.bLoadConnConf("config.txt");
		c_err  =  c_codb.eConnect();
	}//if  (c_kalk_db.bIsConnected()  ==  false)


	if  (c_err  ==  false)
	{
		c_err  =  c_codb.eSelectResults(pvCOResults, sSelectSQL);
	}//if  (c_kalk_db.bConnect())
	else
	{
		c_err.vShowWindow();
		return(c_err);
	}//else  if  (c_err  ==  false)
	
	return(c_err);

}//CError  CSystem::eSelectResults(vector <CCOResult *>  *pvCOResults, CString sSelectSQL)




CError  CSystem::eSelectResultsSets(vector <CCOResultSet *>  *pvCORSets, CString sSelectSQL)
{
	CError  c_err;


	if  (c_codb.bIsConnected()  ==  false)
	{
		c_codb.bLoadConnConf("config.txt");
		c_err  =  c_codb.eConnect();
	}//if  (c_kalk_db.bIsConnected()  ==  false)


	if  (c_err  ==  false)
	{
		c_err  =  c_codb.eSelectResultsSets(pvCORSets, sSelectSQL);
	}//if  (c_kalk_db.bConnect())
	else
	{
		c_err.vShowWindow();
		return(c_err);
	}//else  if  (c_err  ==  false)
	
	return(c_err);


}//CError  CSystem::eSelectResultsSets(vector <CCOResultSet *>  *pvCOComputers, CString sSelectSQL)




CError  CSystem::eSelectComputers(vector <CCOComputer *>  *pvCOComputers, CString sSelectSQL)
{
	CError  c_err;


	if  (c_codb.bIsConnected()  ==  false)
	{
		c_codb.bLoadConnConf("config.txt");
		c_err  =  c_codb.eConnect();
	}//if  (c_kalk_db.bIsConnected()  ==  false)


	if  (c_err  ==  false)
	{
		c_err  =  c_codb.eSelectComputers(pvCOComputers, sSelectSQL);
	}//if  (c_kalk_db.bConnect())
	else
	{
		c_err.vShowWindow();
		return(c_err);
	}//else  if  (c_err  ==  false)
	
	return(c_err);
};//CError  CSystem::eSelectComputers(vector <CCOComputer *>  *pvCOComputers, CString sSelectSQL)




CError  CSystem::eGenerateComputationSet_Comparison
	(
	CCOFDbRoot  *pcFDBRoot,
	CString  sIniFilesDir, CString  sIniFileExt,
	CString  sMainDir,
	vector  <CCOResult  *>  *pvResults0, vector  <CCOResult  *> *pvResults1
	)
{
	CError  c_err;
	CString  s_buf, s_conn_dir, s_res_path, s_res_name0, s_res_name1, s_settings_file_path;
	double  d_param_value;

	CString  s_conn_select;
	vector  <CCONetConn  *>  v_conns;

	CCONet  c_net(NULL);
	CCOFitFunc  c_fit_func(NULL);
	CCOAlgorithm  c_algorithm0(NULL);
	CCOAlgorithm  c_algorithm1(NULL);
	vSetSqlConn(&c_net);
	vSetSqlConn(&c_fit_func);
	vSetSqlConn(&c_algorithm0);
	vSetSqlConn(&c_algorithm1);
	
	
	Directory::CreateDirectory(sMainDir);

	FILE  *pf_main_file;
	CString  s_main_file_name = "all.txt";
	CString  s_main_file_path;
	s_main_file_path  =  sMainDir  +  "\\"  +  s_main_file_name;
	pf_main_file  =  fopen( (LPCSTR) s_main_file_path, "w+");
	if  (pf_main_file  ==  NULL)
	{
		s_buf.Format("Unable to creat main file (%s)", (LPCSTR) s_main_file_path);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_main_file  ==  NULL)

	fprintf(pf_main_file,  SCRIPT_VER_1_0);
	fprintf(pf_main_file,  "\n");	
	fprintf(pf_main_file,  "%s//root dir\n",  (LPCSTR)  sMainDir);




	for  (int ii = 0; ii < pvResults0->size(); ii++)
	{
		s_conn_select.Format("Select * from connections where con_id = '%d'", pvResults0->at(ii)->iGetConnId());
		eSelectConnections(&v_conns, s_conn_select);

		
		if  (v_conns.size() == 0)
			s_buf.Format
				(
				"%d\t %s\t BRAK CONNECTION!!!\n", 
				pvResults0->at(ii)->iGetId(), 
				pvResults0->at(ii)->sGetResultDir()
				);
		else
		{
			s_conn_dir  =  sMainDir  +  "\\"  +  v_conns.at(0)->sGetName();
			Directory::CreateDirectory(s_conn_dir);

			c_err  =  pcFDBRoot->eRefreshNets();
			if  (c_err  ==  false)
				c_err  =  eGetNet(pcFDBRoot, &c_net, "", v_conns.at(0)->iGetNetId() );
			if  (c_err)
			{
				fclose(pf_main_file);
				return(c_err);
			}//if  (c_err)


			s_buf  =  pcFDBRoot->sGetRootDir() + "\\" + c_net.sGetNetDir()  +  "\\"  +  c_net.sGetName() +  ".net";
			File::Copy(s_buf, s_conn_dir +  "\\"  +  c_net.sGetName() +  ".net", true);

			s_buf  =  pcFDBRoot->sGetRootDir() + "\\" + c_net.sGetNetDir()  +  "\\"  +  v_conns.at(0)->sGetConnDir()  +  "\\"  +  v_conns.at(0)->sGetName() +  ".con";
			File::Copy(s_buf, s_conn_dir  +  "\\"  +  v_conns.at(0)->sGetName() +  ".con", true);

			s_res_name0.Format("res_%.8d.ful", ii);
			s_res_path = s_conn_dir + "\\" + s_res_name0;
			s_buf  =  pcFDBRoot->sGetRootDir() + "\\" + c_net.sGetNetDir()  +  "\\"  +  v_conns.at(0)->sGetConnDir()  +  "\\"  +  pvResults0->at(ii)->sGetResultDir() + "\\result.ful";
			File::Copy(s_buf, s_res_path, true);


			//now getting all ini files apriopriate for this connection
			String* ps_files[]  =  Directory::GetFiles(sIniFilesDir, v_conns.at(0)->sGetName() + "."  +  sIniFileExt);
			int  i_count  =  ps_files->Count;
			CString  s_ini_file_name;
			for  (int ij = 0; ij < i_count; ij++)
			{
				FileInfo  *pf;
				pf  =  new  FileInfo(ps_files->get_Item(ij)->ToString());

				s_ini_file_name  =  pf->Name;
				s_buf  =  sIniFilesDir  +  "\\"  +  s_ini_file_name;

				File::Copy(s_buf, s_conn_dir  +  "\\"  +  s_ini_file_name, true);
			}//for  (int ii = 0; ii < ps_files->Count; ii++)

				
			
				

			if  (pvResults1  ==  NULL)
			{
				//NOW!!! we generate settings files and its directories
				s_buf.Format("set_%d.txt", ii);
				s_settings_file_path  =  s_conn_dir  +  "\\"  +  s_buf;
				FILE  *pf_settings;
				pf_settings  =  fopen( (LPCSTR) s_settings_file_path, "w+");
				fprintf(pf_main_file, "%s\\%s\n",v_conns.at(0)->sGetName(), s_buf);		


				if  (pf_settings  ==  NULL)
				{
					s_buf.Format("Unable to create settings file (%s)", (LPCSTR) s_settings_file_path);
					c_err.vPutError(s_buf);
					return(c_err);	
				}//if  (pf_main_file  ==  NULL)

				fprintf(pf_settings,  SCRIPT_VER_1_0);
				fprintf(pf_settings,  "\n");
				fprintf(pf_settings,  "%s//algorithm\n", RESULT_COMPARISON);


				
				eGetFitFunc("", &c_fit_func, pvResults0->at(ii)->iGetFitFuncId());
				fprintf(pf_settings,  c_fit_func.sGetName() + "//cost function\n");
				fprintf(pf_settings,  "FD INI//cost function\n");

				fprintf(pf_settings,  "\n");
				fprintf(pf_settings,  v_conns.at(0)->sGetName() + "\\" + c_net.sGetName() +  ".net"  +  "//topology\n");
				fprintf(pf_settings,  v_conns.at(0)->sGetName() + "\\" + v_conns.at(0)->sGetName() +  ".con"  +  "//connections\n");
				fprintf(pf_settings,  "\n");


				eGetAlgorithm("", &c_algorithm0, pvResults0->at(ii)->iGetAlgorithmId());
				fprintf(pf_settings,  c_algorithm0.sGetAlgorithmName() +  "//algorithm 1 name\n");
				fprintf(pf_settings,  v_conns.at(0)->sGetName() + "\\" + s_res_name0 +  "//algorithm 1 file\n");

				fprintf(pf_settings,  "FD INI//algorithm 2 name\n");
				fprintf(pf_settings,  v_conns.at(0)->sGetName() + "\\" + v_conns.at(0)->sGetName() + "."  +  sIniFileExt  +  "//algorithm 2 file\n");

				fprintf(pf_settings,  "result.txt//result file\n");

				

				fprintf(pf_settings,  "\n");
				fprintf(pf_settings,  "\n");
				c_err  =  c_algorithm0.eRefreshParams();
				if  (!c_err)  c_err  =  c_algorithm0.eRefreshParamsForResult(pvResults0->at(ii)->iGetId());
				if  (!c_err)  c_err  =  eGetParameter(&c_algorithm0, "Allow exceed link capacity",  &d_param_value);
				if  (c_err)
				{
					fclose(pf_main_file);
					return(c_err);			
				}//if  (c_err)
				if  (d_param_value  ==  1)
					fprintf(pf_settings,  "allowed//Allow exceed link capacity\n");
				else
					fprintf(pf_settings,  "NOT allowed//Allow exceed link capacity\n");

				c_err  =  eGetParameter(&c_algorithm0, "Exceed link capacity penalty",  &d_param_value);
				if  (c_err)
				{
					fclose(pf_main_file);
					return(c_err);			
				}//if  (c_err)
				fprintf(pf_settings,  "%.8lf//Exceed link capacity penalty\n", d_param_value);
				
				fclose(pf_settings);
			}//if  (pvResults1  ==  NULL)
			else
			{
				for  (int  ik = 0; ik < pvResults1->size(); ik++)
				{
					if  (pvResults0->at(ii)->iGetConnId() ==  pvResults1->at(ik)->iGetConnId())
					{
						s_res_name1.Format("res_%.8d_%.8d.ful", ii, ik);
						s_res_path = s_conn_dir + "\\" + s_res_name1;
						s_buf  =  pcFDBRoot->sGetRootDir() + "\\" + c_net.sGetNetDir()  +  "\\"  +  v_conns.at(0)->sGetConnDir()  +  "\\"  +  pvResults1->at(ik)->sGetResultDir() + "\\result.ful";
						File::Copy(s_buf, s_res_path, true);

						//NOW!!! we generate settings files and its directories
						s_buf.Format("set_%d_%d.txt", ii, ik);
						s_settings_file_path  =  s_conn_dir  +  "\\"  +  s_buf;
						FILE  *pf_settings;
						pf_settings  =  fopen( (LPCSTR) s_settings_file_path, "w+");
						fprintf(pf_main_file, "%s\\%s\n",v_conns.at(0)->sGetName(), s_buf);		


						if  (pf_settings  ==  NULL)
						{
							s_buf.Format("Unable to create settings file (%s)", (LPCSTR) s_settings_file_path);
							c_err.vPutError(s_buf);
							return(c_err);	
						}//if  (pf_main_file  ==  NULL)

						fprintf(pf_settings,  SCRIPT_VER_1_0);
						fprintf(pf_settings,  "\n");
						fprintf(pf_settings,  "%s//algorithm\n", RESULT_COMPARISON);


						eGetFitFunc("", &c_fit_func, pvResults0->at(ii)->iGetFitFuncId());
						fprintf(pf_settings,  c_fit_func.sGetName() + "//cost function\n");
						eGetFitFunc("", &c_fit_func, pvResults1->at(ik)->iGetFitFuncId());
						fprintf(pf_settings,  c_fit_func.sGetName() + "//cost function\n");

						fprintf(pf_settings,  "\n");
						fprintf(pf_settings,  v_conns.at(0)->sGetName() + "\\" + c_net.sGetName() +  ".net"  +  "//topology\n");
						fprintf(pf_settings,  v_conns.at(0)->sGetName() + "\\" + v_conns.at(0)->sGetName() +  ".con"  +  "//connections\n");
						fprintf(pf_settings,  "\n");


						eGetAlgorithm("", &c_algorithm0, pvResults0->at(ii)->iGetAlgorithmId());
						fprintf(pf_settings,  c_algorithm0.sGetAlgorithmName() +  "//algorithm 1 name\n");
						fprintf(pf_settings,  v_conns.at(0)->sGetName() + "\\" + s_res_name0 +  "//algorithm 1 file\n");

						eGetAlgorithm("", &c_algorithm1, pvResults1->at(ik)->iGetAlgorithmId());
						fprintf(pf_settings,  c_algorithm1.sGetAlgorithmName() +  "//algorithm 2 name\n");
						fprintf(pf_settings,  v_conns.at(0)->sGetName() + "\\" + s_res_name1 +  "//algorithm 2 file\n");

						fprintf(pf_settings,  "result.txt//result file\n");


						fprintf(pf_settings,  "\n");
						fprintf(pf_settings,  "\n");
						c_err  =  c_algorithm0.eRefreshParams();
						if  (!c_err)  c_err  =  c_algorithm0.eRefreshParamsForResult(pvResults0->at(ii)->iGetId());
						if  (!c_err)  c_err  =  eGetParameter(&c_algorithm0, "Allow exceed link capacity",  &d_param_value);
						if  (c_err)
						{
							fclose(pf_main_file);
							return(c_err);			
						}//if  (c_err)
						if  (d_param_value  ==  1)
							fprintf(pf_settings,  "allowed//Allow exceed link capacity\n");
						else
							fprintf(pf_settings,  "NOT allowed//Allow exceed link capacity\n");

						c_err  =  eGetParameter(&c_algorithm0, "Exceed link capacity penalty",  &d_param_value);
						if  (c_err)
						{
							fclose(pf_main_file);
							return(c_err);			
						}//if  (c_err)
						fprintf(pf_settings,  "%.8lf//Exceed link capacity penalty\n", d_param_value);
				
						fclose(pf_settings);
					}//if  (pvResults0->at(ik)->iGetConnId() ==  pvResults1->at(ik)->iGetConnId())
				}//for  (int  ik = 0; ik < pvResults1->size(); ik++)
			}//else  if  (pvResults1  ==  NULL)

					
			
		}//else if  (v_conns.size() == 0)

		v_conns.clear();

	}//for  (int ii = 0; ii < pvResults0->size(); ii++)

	fclose(pf_main_file);

	return(c_err);
}//CError  CSystem::eGenerateComputationSet_Comparison



CError  CSystem::eGenerateComputationSet_2_0
	(
	CCOFDbRoot  *pcFDBRoot,
	CString  sMainFile,
	CString  sIniFilesDir,  CString  sIniFileExt,  
	CString  sCreationDir,
	vector  <CCONetConn *>  *pvNetConns,
	vector  <CCOAlgorithm *>  *pvConfigurations,
	CString  sFitFuncName
	)
{
	CError  c_err;
	CString  s_buf;

	if  (pcFDBRoot  ==  NULL)
	{
		c_err.vPutError("No FDb root assigned!");
		return(c_err);		
	}//if  (pcFDBRoot  ==  NULL)

	FILE  *pf_main_file;

	CString  s_main_file_path;
	s_main_file_path  =  sCreationDir  +  "\\"  +  sMainFile;
	pf_main_file  =  fopen( (LPCSTR) s_main_file_path, "w+");
	if  (pf_main_file  ==  NULL)
	{
		s_buf.Format("Unable to creat main file (%s)", (LPCSTR) s_main_file_path);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_main_file  ==  NULL)

	fprintf(pf_main_file,  SCRIPT_VER_1_0);
	fprintf(pf_main_file,  "\n");	
	fprintf(pf_main_file,  "%s//root dir\n",  (LPCSTR)  sCreationDir);

	CString  s_conn_dir;
	CCONet  c_net(NULL);
	vSetSqlConn(&c_net);
	for  (int  ii = 0; ii < (int)  pvNetConns->size(); ii++)
	{
		s_conn_dir  =  sCreationDir  +  "\\"  +  pvNetConns->at(ii)->sGetName();
		Directory::CreateDirectory(s_conn_dir);

		c_err  =  pcFDBRoot->eRefreshNets();
		if  (c_err  ==  false)
			c_err  =  eGetNet(pcFDBRoot, &c_net, "", pvNetConns->at(ii)->iGetNetId());
		if  (c_err)
		{
			fclose(pf_main_file);
			return(c_err);
		}//if  (c_err)

		s_buf  =  pcFDBRoot->sGetRootDir() + "\\" + c_net.sGetNetDir()  +  "\\"  +  c_net.sGetName() +  ".net";
		File::Copy(s_buf, s_conn_dir +  "\\"  +  c_net.sGetName() +  ".net", true);

		s_buf  =  pcFDBRoot->sGetRootDir() + "\\" + c_net.sGetNetDir()  +  "\\"  +  pvNetConns->at(ii)->sGetConnDir()  +  "\\"  +  pvNetConns->at(ii)->sGetName() +  ".con";
		File::Copy(s_buf, s_conn_dir  +  "\\"  +  pvNetConns->at(ii)->sGetName() +  ".con", true);


		//now getting all ini files apriopriate for this connection
		String* ps_files[]  =  Directory::GetFiles(sIniFilesDir, pvNetConns->at(ii)->sGetName() + "."  +  sIniFileExt);
		int  i_count  =  ps_files->Count;
		CString  s_ini_file_name;
		for  (int ij = 0; ij < i_count; ij++)
		{
			FileInfo  *pf;
			pf  =  new  FileInfo(ps_files->get_Item(ij)->ToString());

			s_ini_file_name  =  pf->Name;
			s_buf  =  sIniFilesDir  +  "\\"  +  s_ini_file_name;

			File::Copy(s_buf, s_conn_dir  +  "\\"  +  s_ini_file_name, true);
		}//for  (int ii = 0; ii < ps_files->Count; ii++)

		
		
		
		//NOW!!! we generate settings files and its directories
		double  d_param_value;
		CString  s_settings_file_path;
		for  (int  ij = 0; ij < (int)  pvConfigurations->size(); ij++)
		{
			s_buf  =  sCreationDir  +  "\\"  +  pvNetConns->at(ii)->sGetName();
			s_buf.Format("%s\\%d", (LPCSTR)  s_buf,  ij);
			Directory::CreateDirectory(s_buf);
			s_settings_file_path  =  s_buf  +  "\\"  +  "settings.dat";
			FILE  *pf_settings;
			pf_settings  =  fopen( (LPCSTR) s_settings_file_path, "w+");


			if  (pf_settings  ==  NULL)
			{
				s_buf.Format("Unable to create settings file (%s)", (LPCSTR) s_settings_file_path);
				c_err.vPutError(s_buf);
				return(c_err);	
			}//if  (pf_main_file  ==  NULL)

			fprintf(pf_settings,  SCRIPT_VER_1_0);
			fprintf(pf_settings,  "\n");
			fprintf(pf_settings,  pvConfigurations->at(ij)->sGetAlgorithmName() + "//algorithm\n");
			fprintf(pf_settings,  sFitFuncName + "//cost function\n");

			fprintf(pf_settings,  "\n");
			fprintf(pf_settings,  c_net.sGetName() +  ".net"  +  "//topology\n");
			fprintf(pf_settings,  pvNetConns->at(ii)->sGetName() +  ".con"  +  "//connections\n");

			c_err  =  eGetParameter(pvConfigurations->at(ij), "Init solution",  &d_param_value);
			if  (c_err)
			{
				fclose(pf_main_file);
				return(c_err);			
			}//if  (c_err)

			if  (d_param_value  ==  0)
				fprintf(pf_settings,  "//start solution\n");
			else
				fprintf(pf_settings,  pvNetConns->at(ii)->sGetName() + "."  +  sIniFileExt  +  "//start solution\n");

			fprintf(pf_settings,  "//VWaysDb\n");
			fprintf(pf_settings,  "result//result files\n");
			fprintf(pf_settings,  "pop.dat//fitness tracking file\n");

			fprintf(pf_settings,  "\n");

			bool  b_parameter_saved;
			for  (int  ik = 0; ik < (int) pvConfigurations->at(ij)->pvGetParams()->size();  ik++)
			{
				b_parameter_saved  =  false;
				if  (
					(
					b_parameter_saved  ==  false
					)
					&&
					(
					pvConfigurations->at(ij)->pvGetParams()->at(ik)->sGetParamName().MakeLower()
					==
					"init solution"
					)
					)
				{
					b_parameter_saved  =  true;
					//do nothing...
				}//if  (

				if  (
					(
					b_parameter_saved  ==  false
					)
					&&
					(
					pvConfigurations->at(ij)->pvGetParams()->at(ik)->sGetParamName().MakeLower()
					==
					"allow exceed link capacity"
					)
					)
				{
					b_parameter_saved  =  true;
					if  (pvConfigurations->at(ij)->pvGetParams()->at(ik)->dGetParamValue()  ==  1.0)
						fprintf(pf_settings,  "allowed//%s\n",  (LPCSTR)  pvConfigurations->at(ij)->pvGetParams()->at(ik)->sGetParamName() );
					else
						fprintf(pf_settings,  "not allowed//%s\n",  (LPCSTR)  pvConfigurations->at(ij)->pvGetParams()->at(ik)->sGetParamName() );
				}//if  (
			


				if  (b_parameter_saved  ==  false)
				{
					b_parameter_saved  =  true;
					fprintf
						(
						pf_settings,  "%lf//%s\n",  
						pvConfigurations->at(ij)->pvGetParams()->at(ik)->dGetParamValue(),
						(LPCSTR)  pvConfigurations->at(ij)->pvGetParams()->at(ik)->sGetParamName() 
						);
				}//if  (b_parameter_saved  ==  false)

			
			}//for  (int  ik = 0; ik < pvNetConns->at(ii)->pvGetParams()->size();  ik++)

			

			fclose(pf_settings);

			fprintf(pf_main_file,  "%s\\%d\\settings.dat\n",  (LPCSTR)  pvNetConns->at(ii)->sGetName(), ij);
		
		}//for  (int  ij = 0; ij < (int)  pvConfigurations->size(); ij++)


	}//for  (int  ii = 0; ii < (int)  pvNetConns->size(); ii++)

	fclose(pf_main_file);

	return(c_err);
}//CError  CSystem::eGenerateComputationSet_2_0



CError  CSystem::eGenerateReportForResults
	(
	CString  sResultFile,
	vector  <CCOResult *>  *pvResults,
	int  iNormalize,
	bool  b_1IsMax
	)
{
	CError  c_err;
	CString  s_buf;


	CInfoWindow  *pc_info_dialog;
	pc_info_dialog  =  new  CInfoWindow;
	pc_info_dialog->Text  =  S"Generating report file - loading results...";

	//first we load result params for all results
	vector  <CCOAlgorithm  *>  v_algorithms_params;
	vector  <CCOAlgorithm  *>  v_alg_buf;
	for  (int  ii = 0; ii < (int) pvResults->size(); ii++)
	{
		//we dont delete v_alg_buf items, cause they all are in the v_algorithms_params list
		v_alg_buf.clear();

		s_buf.Format("Select * from algorithms  WHERE alg_id = %d", pvResults->at(ii)->iGetAlgorithmId());
		c_err  =  eSelectAlgorithms(&v_alg_buf, s_buf);

		if  (c_err)
		{
			for  (int ij = 0; ij < (int) v_alg_buf.size(); ij++)
				delete  v_alg_buf.at(ij);
			for  (int ij = 0; ij < (int) v_algorithms_params.size(); ij++)
				delete  v_algorithms_params.at(ij);
			
			return(c_err);
		}//if  (c_err)

		if  (v_alg_buf.size()  !=  1)
		{
			s_buf.Format("Unexpected number (%d) of algorithms for id (%d) found", v_alg_buf.size(), pvResults->at(ii)->iGetAlgorithmId());
			c_err.vPutError(s_buf);

			for  (int ij = 0; ij < (int) v_alg_buf.size(); ij++)
				delete  v_alg_buf.at(ij);
			for  (int ij = 0; ij < (int) v_algorithms_params.size(); ij++)
				delete  v_algorithms_params.at(ij);

			return(c_err);		
		}//if  (v_alg_buf.size()  !=  1)

		v_algorithms_params.push_back(v_alg_buf.at(0));

		c_err  =  v_algorithms_params.at(ii)->eRefreshParams();
		if  (c_err)
		{
			//we do not delete any v_alg_buf items at this point

			for  (int ij = 0; ij < (int) v_algorithms_params.size(); ij++)
				delete  v_algorithms_params.at(ij);
			return(c_err);
		}//if  (c_err)

		c_err  =  v_algorithms_params.at(ii)->eRefreshParamsForResult
			(pvResults->at(ii)->iGetId());

		if  (c_err)
		{
			//we do not delete any v_alg_buf items at this point

			for  (int ij = 0; ij < (int) v_algorithms_params.size(); ij++)
				delete  v_algorithms_params.at(ij);
			return(c_err);
		}//if  (c_err)


		pc_info_dialog->pbar_progres->Minimum = 0;
		pc_info_dialog->pbar_progres->Maximum = (int) pvResults->size();
		pc_info_dialog->pbar_progres->Value = ii;
		s_buf.Format("%d/%d results loaded", ii, (int) pvResults->size());
		pc_info_dialog->lab_text->Text  =  s_buf;
		pc_info_dialog->Refresh();
		pc_info_dialog->Show();
			
	}//for  (int  ii = 0; ii < (int) pvResults->size(); ii++)

	pc_info_dialog->pbar_progres->Minimum = 0;
	pc_info_dialog->pbar_progres->Maximum = (int) pvResults->size();
	pc_info_dialog->pbar_progres->Value = (int) pvResults->size();
	s_buf.Format("FINISHED! %d/%d results loaded", (int) pvResults->size(), (int) pvResults->size());
	pc_info_dialog->lab_text->Text  =  s_buf;
	pc_info_dialog->Refresh();
	pc_info_dialog->Show();
	Sleep(STANDARD_INFO_SLEEP);
	pc_info_dialog->Hide();


	pc_info_dialog->Text  =  S"Generating report file - finding columns...";
	//now we find results columns and rows
	vector  <int>  v_results_columns;
	vector  <int>  v_conn_configs_ids;
	bool  b_found;
	for  (int  ii = 0; ii < (int) pvResults->size(); ii++)
	{
		//first we check if the same PARAMETERS SET is not on the list already
		b_found  =  false;
		for  (int ij = 0; (ij < (int) v_results_columns.size())&&(b_found  ==  false); ij++)
		{
			if  (
				v_algorithms_params.at(ii)->iCompareParams
					(v_algorithms_params.at(v_results_columns.at(ij)))
				==
				0
				)
			{
				b_found  =  true;			
			}//if  (

		}//for  (int ij = 0; (ij < (int) v_results_columns.size())&&(b_found  ==  false); ij++)

		if  (b_found  ==  false)
		{
			v_results_columns.push_back(ii);		
		}//if  (b_found  ==  false)


		//second we check if the same CONNECTION CONFIGURATION is not on the list already
		b_found  =  false;
		for  (int ij = 0; (ij < (int) v_conn_configs_ids.size())&&(b_found  ==  false); ij++)
		{
			if  (
				pvResults->at(ii)->iGetConnId()
				==
				v_conn_configs_ids.at(ij)
				)
			{
				b_found  =  true;			
			}//if  (

		}//for  (int ij = 0; (ij < (int) v_results_columns.size())&&(b_found  ==  false); ij++)

		if  (b_found  ==  false)
		{
			v_conn_configs_ids.push_back(pvResults->at(ii)->iGetConnId());
		}//if  (b_found  ==  false)

		pc_info_dialog->pbar_progres->Minimum = 0;
		pc_info_dialog->pbar_progres->Maximum = (int) pvResults->size();
		pc_info_dialog->pbar_progres->Value = ii;
		s_buf.Format("%d/%d results checked", ii, (int) pvResults->size());
		pc_info_dialog->lab_text->Text  =  s_buf;
		pc_info_dialog->Refresh();
		pc_info_dialog->Show();
	
	}//for  (int  ii = 0; ii < (int) pvResults->size(); ii++)

	pc_info_dialog->pbar_progres->Minimum = 0;
	pc_info_dialog->pbar_progres->Maximum = (int) pvResults->size();
	pc_info_dialog->pbar_progres->Value = (int) pvResults->size();
	s_buf.Format("FINISHED! %d/%d results checked", (int) pvResults->size(), (int) pvResults->size());
	pc_info_dialog->lab_text->Text  =  s_buf;
	pc_info_dialog->Refresh();
	pc_info_dialog->Show();
	Sleep(STANDARD_INFO_SLEEP);
	pc_info_dialog->Hide();




	pc_info_dialog->Text  =  S"Generating report file - finding connections...";

	//getting conns objects for retrieving connections names
	vector  <CCONetConn *>  v_net_conns;
	for  (int  ii = 0; ii < (int) v_conn_configs_ids.size();  ii++)
	{
		s_buf.Format("Select * from connections where con_id = '%d'", v_conn_configs_ids.at(ii));
		c_err  =  eSelectConnections(&v_net_conns,  s_buf);
		
		if  (c_err)
		{
			for  (int ij = 0; ij < (int) v_algorithms_params.size(); ij++)
				delete  v_algorithms_params.at(ij);

			for  (int ij = 0; ij < (int) v_net_conns.size(); ij++)
				delete  v_net_conns.at(ij);
			return(c_err);		
		}//if  (c_err)


		if  (v_net_conns.size() != ii + 1)
		{
			s_buf.Format("Not appriopriate number of connections for id:%d found", v_conn_configs_ids.at(ii));
			c_err.vPutError(s_buf);

			for  (int ij = 0; ij < (int) v_algorithms_params.size(); ij++)
				delete  v_algorithms_params.at(ij);

			for  (int ij = 0; ij < (int) v_net_conns.size(); ij++)
				delete  v_net_conns.at(ij);
			return(c_err);		
		}//if  (v_net_conns.size() != ii + 1)


		pc_info_dialog->pbar_progres->Minimum = 0;
		pc_info_dialog->pbar_progres->Maximum = (int) pvResults->size();
		pc_info_dialog->pbar_progres->Value = ii;
		s_buf.Format("%d/%d results checked", ii, (int) pvResults->size());
		pc_info_dialog->lab_text->Text  =  s_buf;
		pc_info_dialog->Refresh();
		pc_info_dialog->Show();
	
	}//for  (int  ii = 0; ii < (int) v_conn_configs_ids.size();  ii++)


	pc_info_dialog->pbar_progres->Minimum = 0;
	pc_info_dialog->pbar_progres->Maximum = (int) pvResults->size();
	pc_info_dialog->pbar_progres->Value = (int) pvResults->size();
	s_buf.Format("FINISHED! %d/%d results checked", (int) pvResults->size(), (int) pvResults->size());
	pc_info_dialog->lab_text->Text  =  s_buf;
	pc_info_dialog->Refresh();
	pc_info_dialog->Show();
	Sleep(STANDARD_INFO_SLEEP);
	pc_info_dialog->Hide();


	c_err  =  e_generate_report_file
		(
		sResultFile,  
		pvResults, &v_algorithms_params, &v_net_conns,
		&v_results_columns,
		22, true, false, iNormalize, b_1IsMax
		);

	

	for  (int ij = 0; ij < (int) v_algorithms_params.size(); ij++)
		delete  v_algorithms_params.at(ij);

	for  (int ij = 0; ij < (int) v_net_conns.size(); ij++)
		delete  v_net_conns.at(ij);


	return(c_err);
};//CError  CSystem::eGenerateReportForResults



void  CSystem::v_normalize(double  *pdRowResults,  int  *piCellResultsNumber, int  iSize,  int  iNormalize, bool  b_1IsMax)
{
	if  (iNormalize  ==  NORMALIZE_NO)  return;


	//first we divide the proper number if the cell results number is > 1
	for  (int  ii = 0; ii < iSize;  ii++)
	{
		if  (piCellResultsNumber[ii]  >  1)
			pdRowResults[ii]  =  pdRowResults[ii]  /  piCellResultsNumber[ii];

		if  (piCellResultsNumber[ii]  ==  0)
			pdRowResults[ii]  =  0;	
	}//for  (int  ii = 0; ii < iSize;  ii++)

	//second we find the smallest number
	double  d_smallest  =  0;
	if  (iSize  >  0)  d_smallest  =  pdRowResults[0];
	for  (int  ii = 0; ii < iSize;  ii++)
	{
		if  (piCellResultsNumber[ii]  >  0)
			if  (d_smallest  >  pdRowResults[ii])  d_smallest  =  pdRowResults[ii];	
	}//for  (int  ii = 0; ii < iSize;  ii++)


	//third we normalize
	double  d_sum  =  0;//for NORMALIZE_WINNER_TAKES_ALL_WAGED
	for  (int  ii = 0; ii < iSize;  ii++)
	{
		if  (pdRowResults[ii]  >  0)
		{
			pdRowResults[ii]  =  (pdRowResults[ii]  -  d_smallest)  /  pdRowResults[ii];
			pdRowResults[ii]  =  1.0  -  pdRowResults[ii];

			if  ( (iNormalize  ==  NORMALIZE_WINNER_TAKES_ALL)||(iNormalize  ==  NORMALIZE_WINNER_TAKES_ALL_WAGED) )
			{
				if  (pdRowResults[ii]  <  1)  pdRowResults[ii]  =  0;			
			}//if  ( (iNormalize  ==  NORMALIZE_WINNER_TAKES_ALL)||(iNormalize  ==  NORMALIZE_WINNER_TAKES_ALL_WAGED) )

		}//if  (d_smallest  >  0)
		else
		{
			pdRowResults[ii]  = 1;
		}//else  if  (d_smallest  >  0)

		d_sum  +=  pdRowResults[ii];	
	}//for  (int  ii = 0; ii < iSize;  ii++)


	if  (iNormalize  ==  NORMALIZE_WINNER_TAKES_ALL_WAGED)
	{
		for  (int  ii = 0; ii < iSize;  ii++)
		{
			pdRowResults[ii]  =  pdRowResults[ii]  /  d_sum;
		}//for  (int  ii = 0; ii < iSize;  ii++)	
	}//if  (iNormalize  ==  NORMALIZE_WINNER_TAKES_ALL_WAGED)

	for  (int  ii = 0; ii < iSize;  ii++)
	{
		if  (b_1IsMax  ==  false)  
		{
			pdRowResults[ii]  =  1.0 - pdRowResults[ii];
		}//if  (b_1IsMax  ==  false)
	}//for  (int  ii = 0; ii < iSize;  ii++)


}//void  CSystem::v_normalize(double  *pdRowResults,  int  *piCellResultsNumber, int  iSize)




CError  CSystem::e_generate_report_file
	(
	CString  sResultFile,  
	vector  <CCOResult *>  *pvResults,  vector  <CCOAlgorithm *>  *pvAlgorithmsParams, 
	vector  <CCONetConn *>  *pvNetConns,  vector  <int>  *pvResultsColumns,
	int  iCellTextLenght,  bool  bExcelVersion,  bool  bShowNumberOfResults,  int  iNormalize, bool  b_1IsMax
	)
{
	CError  c_err;
	CString  s_buf;

	//now we open the file and create report
	FILE  *pf_report_file;
	pf_report_file  =  fopen(  (LPCSTR) sResultFile,  "w+");
	if  (pf_report_file  ==  NULL)
	{
		s_buf.Format("Unable to open specified file (%s)", (LPCSTR) sResultFile);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (pf_report_file  ==  NULL)

	CString  s_cell_text;


	s_cell_text  =  "connections\\configs";
	fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);
	for  (int il = s_cell_text.GetLength(); il < iCellTextLenght; il++)
		fprintf(pf_report_file,  " ");
	if  (bExcelVersion)  fprintf(pf_report_file,  "\t");


	for  (int  ii = 0; ii < (int) pvResultsColumns->size();  ii++)
	{
		s_cell_text.Format("  Config %d",  ii);
		fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);
		for  (int il = s_cell_text.GetLength(); il < iCellTextLenght; il++)
			fprintf(pf_report_file,  " ");	

		if  (bExcelVersion)  fprintf(pf_report_file,  "\t");
	}//for  (int  ii = 0; ii < (int) pvResultsColumns->size();  ii++)
	fprintf(pf_report_file, "\n");
	fprintf(pf_report_file, "\n");



	double  *pd_row_results;
	double  *pd_row_sum_results;
	int  *pi_cell_results_number;


	pd_row_results  =  new  double[pvResultsColumns->size()];
	pd_row_sum_results  =  new  double[pvResultsColumns->size()];
	pi_cell_results_number  =  new  int[pvResultsColumns->size()];
	for  (int  ii = 0; ii < (int) pvResultsColumns->size();  ii++)
		pd_row_sum_results[ii]  =  0;
	

	
	CInfoWindow  *pc_info_dialog;
	pc_info_dialog  =  new  CInfoWindow;
	pc_info_dialog->Text  =  S"Generating report file - generating report...";


	double  d_cell_results_sum;
	int  i_cell_results_number;
	for  (int  ii = 0; ii < (int) pvNetConns->size();  ii++)
	{
		s_buf.Format("Generating report file for connection %s", (LPCSTR) pvNetConns->at(ii)->sGetName());
		pc_info_dialog->Text  =  (System::String *) s_buf;


		s_cell_text  =  pvNetConns->at(ii)->sGetName();
		fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);

		//now makeing the cell to have proper length
		for  (int il = s_cell_text.GetLength(); il < iCellTextLenght; il++)
			fprintf(pf_report_file,  " ");
		if  (bExcelVersion)  fprintf(pf_report_file,  "\t");


		d_cell_results_sum  =  0;
		i_cell_results_number  =  0;
		
		for  (int  ij = 0; ij < (int) pvResultsColumns->size();  ij++)
		{
			d_cell_results_sum  =  0;
			i_cell_results_number  =  0;

			for  (int  ik = 0; ik < (int) pvResults->size();  ik++)
			{
				if  (

					(
					pvAlgorithmsParams->at(ik)->iCompareParams
						(
						pvAlgorithmsParams->at(pvResultsColumns->at(ij))
						)
					==
					0
					)
					&&
					(
					pvNetConns->at(ii)->iGetId()  ==  pvResults->at(ik)->iGetConnId()
					)

					)
				{
					d_cell_results_sum  +=  pvResults->at(ik)->dGetFitVal();
					i_cell_results_number++;
				}//if  (
			
			}//for  (int  ik = 0; ik < (int) pvResults->size();  ik++)

			pd_row_results[ij]  =  d_cell_results_sum;
			pi_cell_results_number[ij]  =  i_cell_results_number;

			


			pc_info_dialog->pbar_progres->Minimum = 0;
			pc_info_dialog->pbar_progres->Maximum = (int) pvResultsColumns->size();
			pc_info_dialog->pbar_progres->Value = ij;
			s_buf.Format("%d/%d results loaded", ij, (int) pvResultsColumns->size());
			pc_info_dialog->lab_text->Text  =  s_buf;
			pc_info_dialog->Refresh();
			pc_info_dialog->Show();

			
		}//for  (int  ij = 0; ij < (int) pvResultsColumns->size();  ij++)



		//now normalize()
		if  (iNormalize  !=  NORMALIZE_NO)  v_normalize(pd_row_results,  pi_cell_results_number, pvResultsColumns->size(), iNormalize, b_1IsMax);

		

		//now we print the row into the file...
		for  (int  ij = 0; ij < (int) pvResultsColumns->size();  ij++)
		{

			pd_row_sum_results[ij]  +=  pd_row_results[ij]  /  pi_cell_results_number[ij];

			if  (pi_cell_results_number[ij]  ==  1)
			{
				s_cell_text.Format("  %16.8lf", pd_row_results[ij]);
				fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);
			}//if  (i_cell_results_number  ==  1)

			if  (pi_cell_results_number[ij]  >  1)
			{
				d_cell_results_sum  =  pd_row_results[ij]  /  pi_cell_results_number[ij];
				if  (bShowNumberOfResults)
					s_cell_text.Format("%d*%16.8lf", pi_cell_results_number[ij], pd_row_results[ij]);
				else
					s_cell_text.Format("  %16.8lf", pd_row_results[ij]);

				fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);
			}//if  (i_cell_results_number  ==  1)

			if  (pi_cell_results_number[ij]  <  1)
			{
				s_cell_text  =  "";
				for  (int il = 0; il < iCellTextLenght / 2 - 1; il++)
					s_cell_text  +=  " ";

				s_cell_text +=  "N/A";
				fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);
			}//if  (i_cell_results_number  ==  1)

			//now makeing the cell to have proper length
			for  (int il = s_cell_text.GetLength(); il < iCellTextLenght; il++)
				fprintf(pf_report_file,  " ");
			if  (bExcelVersion)  fprintf(pf_report_file,  "\t");

		}//for  (int  ij = 0; ij < (int) pvResultsColumns->size();  ij++)*/


		fprintf(pf_report_file, "\n");
		fprintf(pf_report_file, "\n");
	}//for  (int  ii = 0; ii < (int) v_net_conns.size();  ii++)

	fprintf(pf_report_file, "\n");

	//now printing the row sum results
	s_cell_text  =  "SUMMARIZE:";
	fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);
	//now makeing the cell to have proper length
	for  (int il = s_cell_text.GetLength(); il < iCellTextLenght; il++)
		fprintf(pf_report_file,  " ");
	if  (bExcelVersion)  fprintf(pf_report_file,  "\t");

	double  d_max,  d_min;
	if  (pvResultsColumns->size()  > 0)  
	{
		d_max  =  pd_row_sum_results[0];
		d_min  =  pd_row_sum_results[0];
	}//if  (pvResultsColumns->size()  > 0)
	else
	{
		d_max  =  0;
		d_min  =  0;
	}//else  if  (pvResultsColumns->size()  > 0) 

	//now we print the row sums into the file...
	for  (int  ij = 0; ij < (int) pvResultsColumns->size();  ij++)
	{
		if  (d_max  <  pd_row_sum_results[ij])  d_max  =  pd_row_sum_results[ij];
		if  (d_min  >  pd_row_sum_results[ij])  d_min  =  pd_row_sum_results[ij];
		
		s_cell_text.Format("  %16.8lf", pd_row_sum_results[ij]);
		fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);

		for  (int il = s_cell_text.GetLength(); il < iCellTextLenght; il++)
			fprintf(pf_report_file,  " ");
		if  (bExcelVersion)  fprintf(pf_report_file,  "\t");
	}//for  (int  ij = 0; ij < (int) pvResultsColumns->size();  ij++)

	fprintf(pf_report_file, "\n");
	fprintf(pf_report_file, "\n");




	//now printing average the row sum results
	s_cell_text  =  "AVG. SUMM:";
	fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);
	//now makeing the cell to have proper length
	for  (int il = s_cell_text.GetLength(); il < iCellTextLenght; il++)
		fprintf(pf_report_file,  " ");
	if  (bExcelVersion)  fprintf(pf_report_file,  "\t");

	//now we print the row sums into the file...
	for  (int  ij = 0; ij < (int) pvResultsColumns->size();  ij++)
	{
		s_cell_text.Format("  %16.8lf", pd_row_sum_results[ij] / (int) pvNetConns->size());
		fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);

		for  (int il = s_cell_text.GetLength(); il < iCellTextLenght; il++)
			fprintf(pf_report_file,  " ");
		if  (bExcelVersion)  fprintf(pf_report_file,  "\t");
	}//for  (int  ij = 0; ij < (int) pvResultsColumns->size();  ij++)

	fprintf(pf_report_file, "\n");



	//now marking the best configuration(s)
	s_cell_text  =  "";
	fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);
	//now makeing the cell to have proper length
	for  (int il = s_cell_text.GetLength(); il < iCellTextLenght; il++)
		fprintf(pf_report_file,  " ");
	if  (bExcelVersion)  fprintf(pf_report_file,  "\t");

	for  (int  ij = 0; ij < (int) pvResultsColumns->size();  ij++)
	{
		s_cell_text  = "";

		if  (d_max  ==  pd_row_sum_results[ij])  s_cell_text  = "       MAX";
		if  (d_min  ==  pd_row_sum_results[ij])  s_cell_text  = "       MIN";

		fprintf(pf_report_file, "%s", (LPCSTR) s_cell_text);

		for  (int il = s_cell_text.GetLength(); il < iCellTextLenght; il++)
			fprintf(pf_report_file,  " ");
		if  (bExcelVersion)  fprintf(pf_report_file,  "\t");
	}//for  (int  ij = 0; ij < (int) pvResultsColumns->size();  ij++)

	fprintf(pf_report_file, "\n");
	fprintf(pf_report_file, "\n");
	fprintf(pf_report_file, "\n");
	fprintf(pf_report_file, "\n");

	pc_info_dialog->Hide();


	delete  []  pd_row_results;
	delete  []  pd_row_sum_results;
	delete  []  pi_cell_results_number;




	//configuration desriptions (legend)
	fprintf(pf_report_file,  "LEGEND:\n\n\n");
	for  (int  ii = 0; ii < (int) pvResultsColumns->size();  ii++)
	{
		fprintf(pf_report_file,  "Config %d  ",  ii);

		fprintf(pf_report_file,  "%s  ",  (LPCSTR)  pvAlgorithmsParams->at(pvResultsColumns->at(ii))->sGetAlgorithmName());

		for  (
			int  ij = 0; 
			ij < (int) pvAlgorithmsParams->at(pvResultsColumns->at(ii))->pvGetParams()->size();
			ij++)
		{
			fprintf
				(
				pf_report_file,  "'%s'=%lf   ",  
				(LPCSTR)  pvAlgorithmsParams->at(pvResultsColumns->at(ii))->pvGetParams()->at(ij)->sGetParamName(),
				pvAlgorithmsParams->at(pvResultsColumns->at(ii))->pvGetParams()->at(ij)->dGetParamValue()
				);
		}//for  (*/

		fprintf(pf_report_file, "\n");
	
	}//for  (int  ii = 0; ii < (int) v_results_columns.size();  ii++)



	fprintf(pf_report_file, "\n");
	fprintf(pf_report_file, "\n");
	
	fclose(pf_report_file);

	return(c_err);
}//CError  CSystem::e_generate_report_file



