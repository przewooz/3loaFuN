#pragma once


//tools
#include  "atlstr.h"  //CString
#include  "system.h"




using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for ConnectionOptions
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CConnOpt : public System::Windows::Forms::Form
	{
	public: 
		CConnOpt(CSystem *pcSystem)
		{
			pc_system  =  pcSystem;
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::TextBox *  editHost;
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::Label *  label2;

	private: System::Windows::Forms::Label *  label3;

	private: System::Windows::Forms::Label *  label4;


	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::Button *  butOk;
	private: System::Windows::Forms::Button *  butConnTest;





	private:

		CSystem *pc_system;
		
		
		System::Windows::Forms::TextBox *  editPasswd;
		System::Windows::Forms::TextBox *  editUser;
		System::Windows::Forms::TextBox *  editDatabase;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->editHost = new System::Windows::Forms::TextBox();
			this->label1 = new System::Windows::Forms::Label();
			this->label2 = new System::Windows::Forms::Label();
			this->editDatabase = new System::Windows::Forms::TextBox();
			this->label3 = new System::Windows::Forms::Label();
			this->editPasswd = new System::Windows::Forms::TextBox();
			this->label4 = new System::Windows::Forms::Label();
			this->editUser = new System::Windows::Forms::TextBox();
			this->butOk = new System::Windows::Forms::Button();
			this->butCancel = new System::Windows::Forms::Button();
			this->butConnTest = new System::Windows::Forms::Button();
			this->SuspendLayout();
			// 
			// editHost
			// 
			this->editHost->Location = System::Drawing::Point(72, 28);
			this->editHost->Name = S"editHost";
			this->editHost->TabIndex = 0;
			this->editHost->Text = S"";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, (System::Byte)238);
			this->label1->Location = System::Drawing::Point(32, 32);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(31, 16);
			this->label1->TabIndex = 1;
			this->label1->Text = S"Host:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, (System::Byte)238);
			this->label2->Location = System::Drawing::Point(208, 32);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(56, 16);
			this->label2->TabIndex = 3;
			this->label2->Text = S"Database:";
			// 
			// editDatabase
			// 
			this->editDatabase->Location = System::Drawing::Point(272, 28);
			this->editDatabase->Name = S"editDatabase";
			this->editDatabase->TabIndex = 2;
			this->editDatabase->Text = S"";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, (System::Byte)238);
			this->label3->Location = System::Drawing::Point(208, 88);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(57, 16);
			this->label3->TabIndex = 7;
			this->label3->Text = S"Password:";
			// 
			// editPasswd
			// 
			this->editPasswd->Location = System::Drawing::Point(272, 84);
			this->editPasswd->Name = S"editPasswd";
			this->editPasswd->TabIndex = 6;
			this->editPasswd->Text = S"";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, (System::Byte)238);
			this->label4->Location = System::Drawing::Point(32, 88);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(31, 16);
			this->label4->TabIndex = 5;
			this->label4->Text = S"User:";
			// 
			// editUser
			// 
			this->editUser->Location = System::Drawing::Point(72, 84);
			this->editUser->Name = S"editUser";
			this->editUser->TabIndex = 4;
			this->editUser->Text = S"";
			// 
			// butOk
			// 
			this->butOk->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->butOk->Location = System::Drawing::Point(288, 168);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 8;
			this->butOk->Text = S"OK";
			this->butOk->Click += new System::EventHandler(this, &CConnOpt::butOk_Click);
			// 
			// butCancel
			// 
			this->butCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->butCancel->Location = System::Drawing::Point(384, 168);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 9;
			this->butCancel->Text = S"Cancel";
			// 
			// butConnTest
			// 
			this->butConnTest->Location = System::Drawing::Point(288, 120);
			this->butConnTest->Name = S"butConnTest";
			this->butConnTest->Size = System::Drawing::Size(171, 23);
			this->butConnTest->TabIndex = 10;
			this->butConnTest->Text = S"Connection test";
			this->butConnTest->Click += new System::EventHandler(this, &CConnOpt::butConnTest_Click);
			// 
			// cConnOpt
			// 
			this->AcceptButton = this->butOk;
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->CancelButton = this->butCancel;
			this->ClientSize = System::Drawing::Size(472, 205);
			this->Controls->Add(this->butConnTest);
			this->Controls->Add(this->butCancel);
			this->Controls->Add(this->butOk);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->editPasswd);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->editUser);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->editDatabase);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->editHost);
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = S"cConnOpt";
			this->SizeGripStyle = System::Windows::Forms::SizeGripStyle::Hide;
			this->Text = S"Connection Options";
			this->Paint += new System::Windows::Forms::PaintEventHandler(this, &CConnOpt::CConnOpt_Paint);
			this->ResumeLayout(false);

		}		
	

		System::Void butConnTest_Click(System::Object *  sender, System::EventArgs *  e);
		System::Void butOk_Click(System::Object *  sender, System::EventArgs *  e);
		System::Void CConnOpt_Paint(System::Object *  sender, System::Windows::Forms::PaintEventArgs *  e);

};
};//namespace CONetAdmin