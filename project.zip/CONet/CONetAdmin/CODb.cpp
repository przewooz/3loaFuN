#include "stdafx.h"
#include "CODb.h"

#include  "system.h"

using  namespace  CONetDbTools;
using namespace TopologyTranslator;
using namespace System::IO;


#pragma warning(disable:4996)

//------------------implementation of object CCODb----------------------------------------
CCODb::CCODb()
{
	
}//CCODb::CCODb(CMySqlControl  *pcSqlConn)


CCODb::~CCODb()
{

}//CCODb::~CCODb()




bool  CCODb::bSaveConnConf(CString  sConfigFile)
{
	FILE  *pf_buf;

	pf_buf  =  fopen(sConfigFile,"w+");

	if  (pf_buf  ==  NULL)  return(false);

	fprintf(pf_buf, "#Kalkulator produktow ver. prot 1.0\n");
	fprintf(pf_buf, "%s\\\\Hostname\n", c_sql_conn.sGetHost() );
	fprintf(pf_buf, "%s\\\\Database name\n", c_sql_conn.sGetDbName() );
	fprintf(pf_buf, "%s\\\\Username\n", c_sql_conn.sGetUser() );
	fprintf(pf_buf, "%s\\\\Password\n", c_sql_conn.sGetPasswd() );
	
	fclose(pf_buf);
	return(true);
}//bool  CCODb::b_save_conn_to_file()



bool  CCODb::bLoadConnConf(CString  sConfigFile)
{
	FILE  *pf_buf;

	pf_buf  =  fopen(sConfigFile,"r");
	if  (pf_buf  ==  NULL)  return(false);

    bool  b_res;
	b_res  =  b_load_conn_conf(pf_buf);


	fclose(pf_buf);
	return(b_res);
}//bool  CCODb::b_load_conn_from_file()



bool  CCODb::b_load_conn_conf(FILE  *pfSource)
{
	s_read_line(pfSource);//this wil be a header line with version

	c_sql_conn.vSetHost(s_read_line(pfSource));
	c_sql_conn.vSetDbName(s_read_line(pfSource));
	c_sql_conn.vSetUser(s_read_line(pfSource));
	c_sql_conn.vSetPasswd(s_read_line(pfSource));
	
	return(true);
}//bool  CCODb::b_load_conn_conf(FILE  *pfSource)



CString  CCODb::s_read_line(FILE  *pfSource)
{
	char  c_buf, c_comment_buf;
	CString  s_res;

	bool  b_comment  =  false;


	//init
	c_buf  =  'a';
	c_comment_buf  =  'a';
	s_res  =  "";
	while( (!feof(pfSource))&&(c_buf != '\n') )
	{
		fscanf(pfSource, "%c",&c_buf);

		if  (b_comment  ==  false)
		{
		
			if  (c_buf  ==  '\\') //everything that after comment sign '//' is ignored
			{
				if  (c_comment_buf  ==  '\\')
					b_comment  =  true;
				else
					c_comment_buf  =  '\\';
				
			}//if  (c_buf  ==  '\\')
			else
			{
				if  (c_comment_buf  ==  '\\')  s_res  =  s_res  +  c_comment_buf; //if something was bufferred we have to give it back
				s_res  =  s_res  +  c_buf;
				c_comment_buf  =  'a';//we have to reset the comment buffer
			}//else  if  (c_buf  ==  '\\')

		}//if  (b_comment  ==  false)

	}//while( (!eof(pfSource))&&(c_buf != '\n') )

	return(s_res);
}//CString  CCODb::s_read_line(FILE  *pfSource)




void  CCODb::vSetSqlConn(CCODbComponent  *pcComp)
{
	pcComp->vSetConnetcion(&c_sql_conn);
}//void  CCODb::vSetSqlConn(CCODbComponent  *pcComp)




void  CCODb::vGetConnParams(CString  *psNewHostName, CString  *psNewDbName, CString  *psNewUser, CString  *psNewPasswd)
{
	*psNewHostName  =  c_sql_conn.sGetHost();
	*psNewDbName  =  c_sql_conn.sGetDbName();
	*psNewUser  =  c_sql_conn.sGetUser();
	*psNewPasswd  =  c_sql_conn.sGetPasswd();
}//void  CCODb::vGetConnParams(CString  *psNewHostName, CString  *psNewDbName, CString  *psNewUser, CString  *psNewPasswd)



bool  CCODb::bTestDbConnection(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd)
{
	CError  c_err;

	CMySqlControl  c_sql_temp;

	
	c_sql_temp.vSetAll(sNewHostName, sNewDbName, sNewUser, sNewPasswd);
	c_err  =  c_sql_temp.eConnect();

	if  (c_err)
	{
		c_err.vShowWindow();;
		return(false);
	}//if  (c_err)
	else
	{
		c_sql_temp.vDisconnect();	
		return(true);
	}//else  if  (c_err)

}//bool  CCODb::bTestDbConnection(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd)



CError  CCODb::eConnect(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd)
{
	if  (c_sql_conn.bIsConnected())  c_sql_conn.vDisconnect();

	CError  c_err;
	c_sql_conn.vSetAll(sNewHostName, sNewDbName, sNewUser, sNewPasswd);

	c_err  =  eConnect();
	
	return(c_err);
}//bool  CCODb::bConnect(CString  sNewHostName, CString  sNewDbName, CString  sNewUser, CString  sNewPasswd)
		


CError  CCODb::eConnect()
{
	if  (c_sql_conn.bIsConnected())  c_sql_conn.vDisconnect();

	CError  c_err;
	c_err  =  c_sql_conn.eConnect();

	return(c_err);
}//CError  CCODb::eConnect()



CError  CCODb::eSelectFDbRoot(vector <CCOFDbRoot *>  *pvFDbRoots, CString sSelectSQL)
{
	CError  c_err;


	vector <void *>  v_fdb_components;
	c_err  =  c_sql_conn.eSelectComponent(&v_fdb_components, sSelectSQL, CODB_COMP_TYPE_FDB_ROOT);

	if  (c_err  ==  false)
	{
		if  (v_fdb_components.empty()  ==  false)
		{
			for  (int  ii = 0; ii < (int)  v_fdb_components.size(); ii++)
			{
				pvFDbRoots->push_back( (CCOFDbRoot *) v_fdb_components.at(ii));
			}//for  (int  ii = 0; ii < (int)  v_kdb_components.size(); ii++)
		}//if  (v_kdb_components.empty()  ==  false)
	}//if  (c_err  ==  false)


	return(c_err);
};//CError  CCODb::eSelectFDbRoot(vector <CCOFDbRoot *>  *pvFDbRoots, CString sSelectSQL)



CError  CCODb::eSelectCONets(vector <CCONet *>  *pvCONets, CString sSelectSQL)
{
	CError  c_err;


	vector <void *>  v_co_db_components;
	c_err  =  c_sql_conn.eSelectComponent(&v_co_db_components, sSelectSQL, CODB_COMP_TYPE_NETOWRK);

	if  (c_err  ==  false)
	{
		if  (v_co_db_components.empty()  ==  false)
		{
			for  (int  ii = 0; ii < (int)  v_co_db_components.size(); ii++)
			{
				pvCONets->push_back( (CCONet *) v_co_db_components.at(ii));
			}//for  (int  ii = 0; ii < (int)  v_kdb_components.size(); ii++)
		}//if  (v_kdb_components.empty()  ==  false)
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCODb::eSelectCONets(vector <CCONet *>  *pvCONets, CString sSelectSQL)



CError  CCODb::eSelectConnections(vector <CCONetConn *>  *pvCOConns, CString sSelectSQL)
{
	CError  c_err;


	vector <void *>  v_co_db_components;
	c_err  =  c_sql_conn.eSelectComponent(&v_co_db_components, sSelectSQL, CODB_COMP_TYPE_NETOWRK_CONN);

	if  (c_err  ==  false)
	{
		if  (v_co_db_components.empty()  ==  false)
		{
			for  (int  ii = 0; ii < (int)  v_co_db_components.size(); ii++)
			{
				pvCOConns->push_back( (CCONetConn *) v_co_db_components.at(ii));
			}//for  (int  ii = 0; ii < (int)  v_kdb_components.size(); ii++)
		}//if  (v_kdb_components.empty()  ==  false)
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCODb::eSelectConnections(vector <CCONetConn *>  *pvCOConns, CString sSelectSQL)



CError  CCODb::eSelectAlgorithms(vector <CCOAlgorithm *>  *pvCOAlgorithms, CString sSelectSQL)
{
	CError  c_err;


	vector <void *>  v_co_db_components;
	c_err  =  c_sql_conn.eSelectComponent(&v_co_db_components, sSelectSQL, CODB_COMP_TYPE_ALGORITHM);

	if  (c_err  ==  false)
	{
		if  (v_co_db_components.empty()  ==  false)
		{
			for  (int  ii = 0; ii < (int)  v_co_db_components.size(); ii++)
			{
				pvCOAlgorithms->push_back( (CCOAlgorithm *) v_co_db_components.at(ii));
			}//for  (int  ii = 0; ii < (int)  v_kdb_components.size(); ii++)
		}//if  (v_kdb_components.empty()  ==  false)
	}//if  (c_err  ==  false)


	return(c_err);

}//CError  CCODb::eSelectCONets(vector <CCONet *>  *pvCONets, CString sSelectSQL)



CError  CCODb::eSelectFitFuncs(vector <CCOFitFunc *>  *pvCOFitFuncs, CString sSelectSQL)
{
	CError  c_err;


	vector <void *>  v_co_db_components;
	c_err  =  c_sql_conn.eSelectComponent(&v_co_db_components, sSelectSQL, CODB_COMP_TYPE_FIT_FUNC);

	if  (c_err  ==  false)
	{
		if  (v_co_db_components.empty()  ==  false)
		{
			for  (int  ii = 0; ii < (int)  v_co_db_components.size(); ii++)
			{
				pvCOFitFuncs->push_back( (CCOFitFunc *) v_co_db_components.at(ii));
			}//for  (int  ii = 0; ii < (int)  v_kdb_components.size(); ii++)
		}//if  (v_kdb_components.empty()  ==  false)
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCODb::eSelectFitFuncs(vector <CCOFitFunc *>  *pvCOFitFuncs, CString sSelectSQL)



CError  CCODb::eSelectComputers(vector <CCOComputer *>  *pvCOComputers, CString sSelectSQL)
{
	CError  c_err;


	vector <void *>  v_co_db_components;
	c_err  =  c_sql_conn.eSelectComponent(&v_co_db_components, sSelectSQL, CODB_COMP_TYPE_COMPUTER);

	if  (c_err  ==  false)
	{
		if  (v_co_db_components.empty()  ==  false)
		{
			for  (int  ii = 0; ii < (int)  v_co_db_components.size(); ii++)
			{
				pvCOComputers->push_back( (CCOComputer *) v_co_db_components.at(ii));
			}//for  (int  ii = 0; ii < (int)  v_kdb_components.size(); ii++)
		}//if  (v_kdb_components.empty()  ==  false)
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCODb::eSelectComputers(vector <CCOComputer *>  *pvCOComputers, CString sSelectSQL)



CError  CCODb::eSelectResultsSets(vector <CCOResultSet *>  *pvCORSets, CString sSelectSQL)
{
	CError  c_err;


	vector <void *>  v_co_db_components;
	c_err  =  c_sql_conn.eSelectComponent(&v_co_db_components, sSelectSQL, CODB_COMP_TYPE_RESULT_SET);

	if  (c_err  ==  false)
	{
		if  (v_co_db_components.empty()  ==  false)
		{
			for  (int  ii = 0; ii < (int)  v_co_db_components.size(); ii++)
			{
				pvCORSets->push_back( (CCOResultSet *) v_co_db_components.at(ii));
			}//for  (int  ii = 0; ii < (int)  v_kdb_components.size(); ii++)
		}//if  (v_kdb_components.empty()  ==  false)
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCODb::eSelectResultsSets(vector <CCOResultSet *>  *pvCORSets, CString sSelectSQL)



CError  CCODb::eSelectResults(vector <CCOResult *>  *pvCOResults, CString sSelectSQL)
{
	CError  c_err;


	vector <void *>  v_co_db_components;
	c_err  =  c_sql_conn.eSelectComponent(&v_co_db_components, sSelectSQL, CODB_COMP_TYPE_RESULT);

	if  (c_err  ==  false)
	{
		if  (v_co_db_components.empty()  ==  false)
		{
			for  (int  ii = 0; ii < (int)  v_co_db_components.size(); ii++)
			{
				pvCOResults->push_back( (CCOResult *) v_co_db_components.at(ii));
			}//for  (int  ii = 0; ii < (int)  v_kdb_components.size(); ii++)
		}//if  (v_kdb_components.empty()  ==  false)
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCODb::eSelectResults(vector <CCOResult *>  *pvCOResults, CString sSelectSQL)


//------------------implementation of object CCOFDbRoot----------------------------------------
CCOFDbRoot::CCOFDbRoot(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)
{
	i_id  =  -1;
	s_root_dir  =  "";
	s_fdb_name  =  "";
}//CCOFDbRoot::CCOFDbRoot()




CCOFDbRoot::~CCOFDbRoot()
{
	for  (int  ii = 0; ii < (int)  v_nets.size(); ii++)
	{
		delete  v_nets.at(ii);
	}//for  (int  ii = 0; ii < (int)  v_nets.size(); ii++)
}//CCOFDbRoot::~CCOFDbRoot()


bool  CCOFDbRoot::operator==(CCODbComponent &cOtherComponent)
{
	
	if  (iGetType()  !=  cOtherComponent.iGetType())  return(false);

	if  (iGetId()  ==  cOtherComponent.iGetId())  
		return(true);
	else
		return(false);

	return(false);
}//bool  CCOFDbRoot::operator==(CCODbComponent &cOtherComponent)


void  CCOFDbRoot::operator=(CCOFDbRoot &cOtherFdb)
{
	i_id  =  cOtherFdb.i_id;
	s_root_dir  =  cOtherFdb.s_root_dir;
	s_fdb_name  =  cOtherFdb.s_fdb_name;
}//void  CCOFDbRoot::operator=(CCOFDbRoot &cOtherFdb)


CError  CCOFDbRoot::eRefresh()
{
	CError  c_err;
	vector <void *>  v_temp_fdb_root;

	if  (i_id  >  0)
	{
		CString  s_select_sql;
		s_select_sql.Format("Select * from fdb_root where root_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_temp_fdb_root, s_select_sql,  iGetType());

		if  (c_err  ==  false)
		{
			if  (v_temp_fdb_root.size()  ==  1)
			{
                *this  =  *((CCOFDbRoot *) v_temp_fdb_root.at(0));
			}//if  (v_temp_fdb_root.size()  ==  1)
			else
			{
				CString  s_buf;
				s_buf.Format("%d fdb root obejcts with id %d found", v_temp_fdb_root.size(), i_id);
				c_err.vPutError(s_buf);
			}//else  if  (v_temp_fdb_root.size()  ==  1)
		}//if  (c_err  ==  false)
		
	}//if  (i_id  >  0)

	for  (int  ii = 0; ii < (int)  v_temp_fdb_root.size(); ii++)
	{
		delete (CCOFDbRoot *) v_temp_fdb_root.at(ii);
	}//for  (int  ii = 0; ii < v_temp_fdb_root.size(); ii++)

	return(c_err);    
}//CCOFDbRoot::eRefresh()



void  CCOFDbRoot::vGetData
	(
	int  *pi_id,
	CString  *ps_root_dir, CString  *ps_fdb_name
	)
{
	*pi_id  =  i_id;
	*ps_root_dir  =  s_root_dir;
	*ps_fdb_name  =  s_fdb_name;
}//void  CCOFDbRoot::vGetData



CError  CCOFDbRoot::eLoad(gcroot<MySqlDataReader*> pcReader)
{
	CError  c_err;

	i_id  =  pcReader->GetInt32(0);
	s_root_dir  =  pcReader->GetString(1);
	s_fdb_name  =  pcReader->GetString(2);

	return(c_err);
}//CError  CCOFDbRoot::eLoad(MySqlDataReader *pcReader)


CString  CCOFDbRoot::sGetControlString()
{
	CString  s_res;

	s_res.Format
		(
		"Select * from fdb_root \
		where	\
		root_id  =  '%d' and	\
		fdb_root_name  =  '%s' and	\
		root_dir  =  '%s'",  

		i_id, 
		CMySqlControl::sFormatForSQL(s_fdb_name), 
		CMySqlControl::sFormatForSQL(s_root_dir)
		);
	return(s_res);
}//CString  CCOFDbRoot::sGetControlString()





CError  CCOFDbRoot::eUpdate(CString  s_new_fdb_root_dir,	CString  s_new_fdb_name)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_add_sql, vs_update_sql;

	CString  s_control, s_add, s_update;



	if  (i_id  <  0)
	{
		s_control.Format
		(
		"Select * from fdb_root \
		where	\
		root_dir = '%s'",
		CMySqlControl::sFormatForSQL(s_new_fdb_root_dir)		
		);

		vs_control_sql.push_back(s_control);


		s_add.Format
		(
		"Insert into fdb_root \
		(  \
		fdb_root_name,  root_dir \
		) \
		values \
		( \
		'%s','%s' \
		)",  
		
		CMySqlControl::sFormatForSQL(s_new_fdb_name),  CMySqlControl::sFormatForSQL(s_new_fdb_root_dir)
		);

		vs_add_sql.push_back(s_add);

		c_err  =  pc_conn->eAddDb(&vs_control_sql,  &vs_add_sql, "SELECT root_id FROM fdb_root order by root_id desc limit 0,1", &i_id);

	}//if  (i_id  <  0)
	else
	{
		s_control  =  sGetControlString();
	
		vs_control_sql.push_back(s_control);


		s_update.Format
		(
		"update fdb_root \
		set \
		fdb_root_name = '%s',  root_dir = '%s'  \
		where  \
		root_id = '%d'",
		

		CMySqlControl::sFormatForSQL(s_new_fdb_name),  CMySqlControl::sFormatForSQL(s_new_fdb_root_dir),
		i_id
		);

		vs_update_sql.push_back(s_update);

		c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_update_sql);
	
	}//else  if  (i_id  <  0)


	if  (c_err  ==  false)
	{
		s_fdb_name  =  s_new_fdb_name;
		s_root_dir  =  s_new_fdb_root_dir;
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCOFDbRoot::eUpdate





CError  CCOFDbRoot::eRemove()
{
	CError  c_err;

	//now removing fdb from database
	vector  <CString>  vs_control_sql,  vs_remove_sql;

	CString  s_control, s_remove;

	s_control  =  sGetControlString();
	vs_control_sql.push_back(s_control);


	s_remove.Format("Delete from params where result_id = ANY (SELECT result_id from results where con_id = ANY (SELECT con_id from connections where net_id = ANY (SELECT net_id from networks where root_id = '%d') ) )", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from results where con_id = ANY (SELECT con_id from connections where net_id = ANY (SELECT net_id from networks where root_id = '%d') )", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from connections where net_id = ANY (SELECT net_id from networks where root_id = '%d')", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from networks where root_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from fdb_root where root_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);
	


	c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_remove_sql);

	if  (c_err  ==  false)  i_id  =  -1;
	if  (c_err)  return(c_err);
    
	//and finally deleting directory with it whole contents
	try  {Directory::Delete(s_root_dir, true);}
	catch(Exception *p_ex)
	{
		CString  s_buf;
		s_buf.Format("An error occured while copying a file\nError: %s",  p_ex->Message);
		c_err.vPutError(s_buf);	
	}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};


	return(c_err);
};//CError  CCOFDbRoot::eRemove(CMySqlControl  *pcSqlConn)  




CError  CCOFDbRoot::eRefreshNets()
{
	CError  c_err;

	for  (int  ii = 0; ii < (int)  v_nets.size(); ii++)
	{
		delete  v_nets.at(ii);	
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)
	v_nets.clear();

	if  (i_id  >  0)
	{
		vector <void *>  v_co_components;
		CString  s_select_sql;
		s_select_sql.Format("Select * from networks where root_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_co_components, s_select_sql,  CODB_COMP_TYPE_NETOWRK);

		if  (c_err  ==  false)
		{
			if  (v_co_components.empty()  ==  false)
			{
				for  (int  ii = 0; ii < (int)  v_co_components.size(); ii++)
				{
					v_nets.push_back( (CCONet *) v_co_components.at(ii));
				}//for  (int  ii = 0; ii < pvsAdbUsers->size(); ii++)
			}//if  (v_kdb_components.empty()  ==  false)
		}//if  (c_err  ==  false)	
	}//if  (i_id  >  0)

	return(c_err);
}//CError  CCOFDbRoot::eRefreshNets()



CError  CCOFDbRoot::eRemoveNetwork(int  iNetIndex)
{
	CError  c_err;

	if  ( (iNetIndex  <  (int)  v_nets.size())&&(iNetIndex  >=  0) )
	{
		c_err  =  v_nets.at(iNetIndex)->eRemove(s_root_dir);	
	}//if  ( (iNetIndex  <  (int)  v_nets->size())&&(iNetIndex  >=  0) )
	else
	{
		c_err.vPutError("Index exceeds list length");
		return(c_err);	
	}//else  if  ( (iNetIndex  <  (int)  v_nets->size())&&(iNetIndex  >=  0) )

	return(c_err);
}//CError  CCOFDbRoot::eRemoveNetwork(int  iNetIndex)



CError  CCOFDbRoot::eAddNetwork
	(
	CString  sFileName,
	int  iControlNumNodes,  int  iControlNumEdges,
	CString  sNetName,	CString  sNetComments
	)
{
	CError  c_err;

	CTopologyTranslator  c_net_buf;
	CString  s_buf;

	if  (File::Exists(sFileName)  ==  false)
	{
		c_err.vPutError("File not exist!");
		return(c_err);	
	}//if  (File::Exists(sFileName)  ==  false)


	if  (
		c_net_buf.iLoadTopologyFile(sFileName,  &s_buf)
		!=  1
		)  
	{
		c_err.vPutError("Unable to load .net file");
		return(c_err);
	}//if  (

	CNETsimulatorSimplyfied  *pc_net;
	pc_net  =  (CNETsimulatorSimplyfied  *)  c_net_buf.pcGetSim();

	int  i_nodes_num,  i_edges_num;

	i_nodes_num  =  pc_net->lGetNodesNum();
	i_edges_num  =  pc_net->lGetLinksNum();

	if  (i_nodes_num  !=  iControlNumNodes)
	{
		s_buf.Format("The number of nodes changed %d != %d", iControlNumNodes, i_nodes_num);
		c_err.vPutError(s_buf);
		return(c_err);
	}//if  (i_nodes_num  !=  iControlNumNodes)

	if  (i_edges_num  !=  iControlNumEdges)
	{
		s_buf.Format("The number of edges changed %d != %d", iControlNumEdges, i_edges_num);
		c_err.vPutError(s_buf);
		return(c_err);
	}//if  (i_nodes_num  !=  iControlNumNodes)



    //now creating a network in db
	CCONet  c_net(pc_conn);

	c_err  =  c_net.eUpdate(i_id, i_nodes_num, i_edges_num, sNetName, "", "", sNetComments);
	if  (c_err)  
	{
		c_net.eRemove();
		return(c_err);
	}//if  (c_err)


	//now preparing a directory and copying a file
	int  i_new_net_id;
	i_new_net_id  =  c_net.iGetId();

	CString  s_new_catalog_name;
	s_new_catalog_name.Format("%.8d", i_new_net_id);
	
	

	if  (Directory::Exists(s_root_dir + "\\" + s_new_catalog_name))
	{
		c_net.eRemove();
		s_buf.Format("Error directory already exists and may be used: %s", s_root_dir + "\\" + s_new_catalog_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (Directory:Exists(s_root_dir + "\\" + s_new_catalog_name))

	
	try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_root_dir + "\\" + s_new_catalog_name);}
	catch(Exception *p_ex)
	{
		s_buf.Format("An error occured while creating a directory\nError: %s",  p_ex->Message);
		c_err.vPutError(s_buf);	
	}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};
	if  (c_err)
	{
		c_net.eRemove();
		return(c_err);	
	}//if  (c_err)

	FileInfo  *pc_fi  =  new  FileInfo(sFileName);
	CString  s_file_name;
	s_file_name  =  pc_fi->Name;

	try  {File::Copy(sFileName, s_root_dir + "\\" + s_new_catalog_name + "\\" + s_file_name);}
	catch(Exception *p_ex)
	{
		s_buf.Format("An error occured while copying a file\nError: %s",  p_ex->Message);
		c_err.vPutError(s_buf);	
	}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};
	if  (c_err)
	{
		c_net.eRemove();
		return(c_err);	
	}//if  (c_err)

	c_err  =  c_net.eUpdate(i_id, i_nodes_num, i_edges_num, sNetName, s_file_name, s_new_catalog_name, sNetComments);

	if  (c_err)
	{
		try  {Directory::Delete(s_root_dir + "\\" + s_new_catalog_name, true);}
		catch(Exception *p_ex)
		{
			s_buf.Format("An error occured while deleting a directory\nError: %s",  p_ex->Message);
			c_err.vPutError(s_buf);	
		}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};

		c_net.eRemove();
		return(c_err);
	}//if  (c_err)
		
					
	return(c_err);
}//CError  CCOFDbRoot::eAddNetwork







//------------------implementation of object CCONet----------------------------------------
CCONet::CCONet(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)
{
	//object data
	i_id  =  -1;
	i_root_id  =  -1;

	i_num_nodes  =  0;
	i_num_edges  =  0;

	s_net_name  =  "";
	s_net_file  =  "";
	s_net_dir  =  "";
	s_net_comments  =  "";
	
	dt_added  =  0;
}//CCONet::CCONet()




CCONet::~CCONet()
{
	for  (int  ii = 0; ii < (int)  v_net_conns.size(); ii++)
	{
		delete  v_net_conns.at(ii);
	}//for  (int  ii = 0; ii < (int)  v_net_conns.size(); ii++)
}//CCONet::~CCONet()


bool  CCONet::operator==(CCODbComponent &cOtherComponent)
{
	
	if  (iGetType()  !=  cOtherComponent.iGetType())  return(false);

	if  (iGetId()  ==  cOtherComponent.iGetId())  
		return(true);
	else
		return(false);

	return(false);
}//bool  CCONet::operator==(CCODbComponent &cOtherComponent)



void  CCONet::operator=(CCONet &cOtherNet)
{
	i_id  =  cOtherNet.i_id;
	i_root_id  =  cOtherNet.i_root_id;
	i_num_nodes  =  cOtherNet.i_num_nodes;
	i_num_edges  =  cOtherNet.i_num_edges;
	s_net_name  =  cOtherNet.s_net_name;
	s_net_file  =  cOtherNet.s_net_file;
	s_net_dir  =  cOtherNet.s_net_dir;
	s_net_comments  =  cOtherNet.s_net_comments;
	dt_added  =  cOtherNet.dt_added;
}//void  CCONet::operator=(CCONet &cOtherNet)


CError  CCONet::eRefresh()
{
	CError  c_err;
	vector <void *>  v_temp_net;

	if  (i_id  >  0)
	{
		CString  s_select_sql;
		s_select_sql.Format("Select * from fdb_root where root_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_temp_net, s_select_sql,  iGetType());

		if  (c_err  ==  false)
		{
			if  (v_temp_net.size()  ==  1)
			{
                *this  =  *((CCONet *) v_temp_net.at(0));
			}//if  (v_temp_net.size()  ==  1)
			else
			{
				CString  s_buf;
				s_buf.Format("%d network obejcts with id %d found", v_temp_net.size(), i_id);
				c_err.vPutError(s_buf);
			}//else  if  (v_temp_net.size()  ==  1)
		}//if  (c_err  ==  false)
		
	}//if  (i_id  >  0)

	for  (int  ii = 0; ii < (int)  v_temp_net.size(); ii++)
	{
		delete (CCONet *) v_temp_net.at(ii);
	}//for  (int  ii = 0; ii < pvsAdbUsers->size(); ii++)

	return(c_err);
}//CCONet::eRefresh()



void  CCONet::vGetData
	(
	int  *pi_id,
	int  *pi_root_id,
	int  *pi_num_nodes,  int  *pi_num_edges,
	CString  *ps_net_name,  CString  *ps_net_file,  CString  *ps_net_dir,
	CString  *ps_net_comments,
	__int64  *pdt_added
	)
{
	*pi_id  =  i_id;
	*pi_root_id  =  i_root_id;

	*pi_num_nodes  =  i_num_nodes;
	*pi_num_edges  =  i_num_edges;

	*ps_net_name  =  s_net_name;
	*ps_net_file  =  s_net_file;
	*ps_net_dir  =  s_net_dir;
	*ps_net_comments  =  s_net_comments;
	
	*pdt_added  =  dt_added;
}//void  CCONet::vGetData



CError  CCONet::eLoad(gcroot<MySqlDataReader*> pcReader)
{
	CError  c_err;

	i_id  =  pcReader->GetInt32(0);
	i_root_id  =  pcReader->GetInt32(pcReader->GetOrdinal("root_id"));

	i_num_nodes  =  pcReader->GetInt32(pcReader->GetOrdinal("num_nodes"));
	i_num_edges  =  pcReader->GetInt32(pcReader->GetOrdinal("num_edges"));

	s_net_name  =  pcReader->GetString(pcReader->GetOrdinal("net_name"));
	s_net_file  =  pcReader->GetString(pcReader->GetOrdinal("net_file"));
	s_net_dir  =  pcReader->GetString(pcReader->GetOrdinal("net_dir"));
	s_net_comments  =  pcReader->GetString(pcReader->GetOrdinal("net_comments"));
	
	System::DateTime  dt_buf;
	dt_buf  =  pcReader->GetDateTime(pcReader->GetOrdinal("added"));
	dt_added =  dt_buf.ToFileTime();
	
	return(c_err);
}//CError  CCONet::eLoad(MySqlDataReader *pcReader)


CString  CCONet::sGetControlString()
{
	CString  s_res;

	System::DateTime  dt_buf;
	dt_buf  =  System::DateTime::FromFileTime(dt_added);

	s_res.Format
		(
		"Select * from networks \
		where	\
		net_id  =  '%d' and	\
		root_id  =  '%d' and	\
		num_nodes  =  '%d' and	num_edges  =  '%d' and \
		net_name  =  '%s' and	net_file  =  '%s' and  net_dir  =  '%s' and \
		net_comments  =  '%s' and \
		added  =  '%s'",  

		i_id, 
		i_root_id,
		i_num_nodes,  i_num_edges,
		CMySqlControl::sFormatForSQL(s_net_name),  CMySqlControl::sFormatForSQL(s_net_file),  CMySqlControl::sFormatForSQL(s_net_dir),
		CMySqlControl::sFormatForSQL(s_net_comments),
		CMySqlControl::sFormatForSQL(dt_buf.ToString())
		);

	return(s_res);
}//CString  CCONet::sGetControlString()



CError  CCONet::eUpdate
	(
	int  i_new_num_nodes,  int  i_new_num_edges,
	CString  s_new_net_name,  CString  s_new_net_file,  CString  s_new_net_dir,
	CString  s_new_net_comments
	)
{
	CError  c_err;
	c_err  =  eUpdate
		(
		i_root_id,
		i_new_num_nodes,  i_new_num_edges,
		s_new_net_name,  s_new_net_file,  s_new_net_dir,
		s_new_net_comments
		);
	return(c_err);
}//CError  CCONet::eUpdate


CError  CCONet::eUpdate
	(
	int  i_new_root_id,
	int  i_new_num_nodes,  int  i_new_num_edges,
	CString  s_new_net_name,  CString  s_new_net_file,  CString  s_new_net_dir,
	CString  s_new_net_comments
	)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_add_sql, vs_update_sql;

	CString  s_control, s_add, s_update;



	if  (i_id  <  0)
	{
		s_control.Format
		(
		"Select * from networks \
		where	\
		root_id  =  '%d' and	\
		(net_name  =  '%s' or  net_file  =  '%s') ",  

		i_new_root_id,
		CMySqlControl::sFormatForSQL(s_new_net_name),  CMySqlControl::sFormatForSQL(s_new_net_file)
		);

		vs_control_sql.push_back(s_control);


		System::DateTime  dt_buf;
		dt_buf  =  System::DateTime::get_Now();
		
		s_add.Format
			(
			"Insert into networks \
			(  \
			root_id,  \
			num_nodes, num_edges, \
			net_name,  net_file,  net_dir,  \
			net_comments,  \
			added  \
			) \
			values \
			( \
			'%d', \
			'%d', '%d', \
			'%s', '%s', '%s', \
			'%s',  \
			'%s'  \
			)",  
			
			i_new_root_id,
			i_new_num_nodes,  i_new_num_edges,
			CMySqlControl::sFormatForSQL(s_new_net_name),  CMySqlControl::sFormatForSQL(s_new_net_file),  CMySqlControl::sFormatForSQL(s_new_net_dir),
			CMySqlControl::sFormatForSQL(s_new_net_comments),
			CMySqlControl::sFormatForSQL(dt_buf.ToString())
			);

		vs_add_sql.push_back(s_add);

		c_err  =  pc_conn->eAddDb(&vs_control_sql,  &vs_add_sql, "SELECT net_id FROM networks order by net_id desc limit 0,1", &i_id);

		if  (c_err  ==  false)  dt_added =  dt_buf.ToFileTime();

	}//if  (i_id  <  0)
	else
	{
		s_control  =  sGetControlString();
	
		vs_control_sql.push_back(s_control);


		s_update.Format
		(
		"update networks \
		set \
		root_id  =  '%d',	\
		num_nodes  =  '%d', num_edges  =  '%d', \
		net_name  =  '%s',	net_file  =  '%s', net_dir  =  '%s', \
		net_comments  =  '%s' \
		where  \
		net_id  =  '%d'",
		

		i_new_root_id,
		i_new_num_nodes,  i_new_num_edges,
		CMySqlControl::sFormatForSQL(s_new_net_name),  CMySqlControl::sFormatForSQL(s_new_net_file),  CMySqlControl::sFormatForSQL(s_new_net_dir),
		CMySqlControl::sFormatForSQL(s_new_net_comments),
		i_id
		);

		vs_update_sql.push_back(s_update);

		c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_update_sql);
	
	}//else  if  (i_id  <  0)


	if  (c_err  ==  false)
	{
		i_root_id  =  i_new_root_id;
		i_num_nodes  =  i_new_num_nodes;
		i_num_edges  =  i_new_num_edges;
		s_net_name  =  s_new_net_name;
		s_net_file  =  s_new_net_file;
		s_net_dir  =  s_new_net_dir;
		s_net_comments  =  s_new_net_comments;
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCONet::eUpdate(CString  s_new_fdb_root_dir,	CString  s_new_fdb_name)



CError  CCONet::eRemove(CString  sRootDir)
{
	CError  c_err;


	c_err  =  eRemove();
	if  (c_err)  return(c_err);
    
	try  {Directory::Delete(sRootDir + "\\" + s_net_dir, true);}
	catch(Exception *p_ex)
	{
		CString  s_buf;
		s_buf.Format("An error occured while deleting a file\nError: %s",  p_ex->Message);
		c_err.vPutError(s_buf);	
	}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};

	return(c_err);
}//CError  CCONet::eRemove(CString  sRootDir)




CError  CCONet::eRemove()
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_remove_sql;

	CString  s_control, s_remove;

	
	s_control  =  sGetControlString();
	vs_control_sql.push_back(s_control);


	s_remove.Format("Delete from params where result_id = ANY (SELECT result_id from results where con_id = ANY (SELECT con_id from connections where net_id = '%d') )", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from results where con_id = (SELECT con_id from connections where net_id = '%d')", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from connections where net_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from networks where net_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);

	
	c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_remove_sql);

	if  (c_err  ==  false)  i_id  =  -1;

	return(c_err);
};//CError  CCONet::eRemove(CMySqlControl  *pcSqlConn)  



CError  CCONet::eRemoveNetConn(CString  sRootDir,  int  iNetConnIndex)
{
	CError  c_err;

	if  ( (iNetConnIndex  <  (int)  v_net_conns.size())&&(iNetConnIndex  >=  0) )
	{
		c_err  =  v_net_conns.at(iNetConnIndex)->eRemove(sRootDir + "\\" + s_net_dir);	
	}//if  ( (iNetIndex  <  (int)  v_nets->size())&&(iNetIndex  >=  0) )
	else
	{
		c_err.vPutError("Index exceeds list length");
		return(c_err);	
	}//else  if  ( (iNetIndex  <  (int)  v_nets->size())&&(iNetIndex  >=  0) )

	return(c_err);
}//CError  CCONet::eRemoveNetConn(int  iNetConnIndex)



CError  CCONet::eAddNetConn
	(
	CString  sRootDir,
	CString  sConnFile,
	CString  sConnName
	)
{
	CError  c_err;

	CTopologyTranslator  c_net_buf;
	CString  s_buf;

	if  (File::Exists(sConnFile)  ==  false)
	{
		c_err.vPutError("File not exist!");
		return(c_err);	
	}//if  (File::Exists(sFileName)  ==  false)


	//now creating a network in db
	CCONetConn  c_net_conn(pc_conn);

	c_err  =  c_net_conn.eUpdate(i_id, sConnName, "", "");
	if  (c_err)  
	{
		c_net_conn.eRemove();
		return(c_err);
	}//if  (c_err)


	//now preparing a directory and copying a file
	int  i_new_conn_id;
	i_new_conn_id  =  c_net_conn.iGetId();

	CString  s_new_catalog_name;
	s_new_catalog_name.Format("%.8d", i_new_conn_id);
	
	

	if  (Directory::Exists(sRootDir + "\\" + s_net_dir + "\\" + s_new_catalog_name))
	{
		c_net_conn.eRemove();
		s_buf.Format("Error directory already exists and may be used: %s", sRootDir + "\\" + s_net_dir + "\\" + s_new_catalog_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (Directory:Exists(s_root_dir + "\\" + s_new_catalog_name))

	
	try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(sRootDir + "\\" + s_net_dir + "\\" + s_new_catalog_name);}
	catch(Exception *p_ex)
	{
		s_buf.Format("An error occured while creating a directory\nError: %s",  p_ex->Message);
		c_err.vPutError(s_buf);	
	}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};
	if  (c_err)
	{
		c_net_conn.eRemove();
		return(c_err);	
	}//if  (c_err)

	FileInfo  *pc_fi  =  new  FileInfo(sConnFile);
	CString  s_file_name;
	s_file_name  =  pc_fi->Name;

	try  {File::Copy(sConnFile, sRootDir + "\\" + s_net_dir + "\\" + s_new_catalog_name + "\\" + s_file_name);}
	catch(Exception *p_ex)
	{
		s_buf.Format("An error occured while copying a file\nError: %s",  p_ex->Message);
		c_err.vPutError(s_buf);	
	}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};
	if  (c_err)
	{
		c_net_conn.eRemove();
		return(c_err);	
	}//if  (c_err)

	c_err  =  c_net_conn.eUpdate(i_id, sConnName, s_file_name, s_new_catalog_name);

	if  (c_err)
	{
		try  {Directory::Delete(sRootDir + "\\" + s_net_dir + "\\" + s_new_catalog_name, true);}
		catch(Exception *p_ex)
		{
			s_buf.Format("An error occured while deleting a directory\nError: %s",  p_ex->Message);
			c_err.vPutError(s_buf);	
		}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};

		c_net_conn.eRemove();
		return(c_err);
	}//if  (c_err)
		
					
	return(c_err);
}//CError  CCONet::eAddNetConn



CError  CCONet::eRefreshNetConns()
{
	CError  c_err;

	for  (int  ii = 0; ii < (int)  v_net_conns.size(); ii++)
	{
		delete  v_net_conns.at(ii);
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)
	v_net_conns.clear();

	if  (i_id  >  0)
	{
		vector <void *>  v_co_components;
		CString  s_select_sql;
		s_select_sql.Format("Select * from connections where net_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_co_components, s_select_sql,  CODB_COMP_TYPE_NETOWRK_CONN);

		if  (c_err  ==  false)
		{
			if  (v_co_components.empty()  ==  false)
			{
				for  (int  ii = 0; ii < (int)  v_co_components.size(); ii++)
				{
					v_net_conns.push_back( (CCONetConn *) v_co_components.at(ii));
				}//for  (int  ii = 0; ii < pvsAdbUsers->size(); ii++)
			}//if  (v_kdb_components.empty()  ==  false)
		}//if  (c_err  ==  false)	
	}//if  (i_id  >  0)

	return(c_err);
}//CError  CCONet::eRefreshNetConns()


//------------------implementation of object CCONet----------------------------------------
CCONetConn::CCONetConn(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)
{
	//object data
	i_id  =  -1;
	i_net_id  =  -1;
	s_conn_name  =  "";
	s_conn_file  =  "";
	s_conn_dir  =  "";
}//CCONetConn::CCONetConn(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)




CCONetConn::~CCONetConn()
{

}//CCONetConn::~CCONetConn()


CString  CCONetConn::sGetControlString()
{
	CString  s_res;

	s_res.Format
		(
		"Select * from connections \
		where	\
		con_id  =  '%d' and	\
		net_id  =  '%d' and	\
		con_file  =  '%s' and	con_dir  =  '%s' and  con_name  =  '%s' \
		",  

		i_id,
		i_net_id,
		CMySqlControl::sFormatForSQL(s_conn_file),  CMySqlControl::sFormatForSQL(s_conn_dir),  CMySqlControl::sFormatForSQL(s_conn_name)
		);

	return(s_res);
}//CString  CCONetConn::sGetControlString()



CError  CCONetConn::eLoad(gcroot<MySqlDataReader *> pcReader)
{
	CError  c_err;

	i_id  =  pcReader->GetInt32(0);
	i_net_id  =  pcReader->GetInt32(pcReader->GetOrdinal("net_id"));

	s_conn_dir  =  pcReader->GetString(pcReader->GetOrdinal("con_dir"));
	s_conn_file  =  pcReader->GetString(pcReader->GetOrdinal("con_file"));
	s_conn_name  =  pcReader->GetString(pcReader->GetOrdinal("con_name"));

	return(c_err);
}//CError  CCONetConn::eLoad(gcroot<MySqlDataReader *> pcReader)



void  CCONetConn::vRemove
	(
	vector  <CString>  *pvsControlSql,  
	vector  <CString>  *pvsRemoveSql
	)
{
	CString  s_control, s_remove;


	s_control  =  sGetControlString();
	pvsControlSql->push_back(s_control);


	s_remove.Format("Delete from params where result_id = ANY (SELECT result_id from results where con_id = '%d')", i_id);
	pvsRemoveSql->push_back(s_remove);
	s_remove.Format("Delete from results where con_id = '%d'", i_id);
	pvsRemoveSql->push_back(s_remove);
	s_remove.Format("Delete from connections where con_id = '%d'", i_id);
	pvsRemoveSql->push_back(s_remove);
}//CError  CCONetConn::vRemove


CError  CCONetConn::eRemove()
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_remove_sql;

	vRemove(&vs_control_sql,  &vs_remove_sql);

	c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_remove_sql);

	if  (c_err  ==  false)  i_id  =  -1;

	return(c_err);
}//CError  CCONetConn::eRemove()



CError  CCONetConn::eRemove(CString  sNetDir)
{
	CError  c_err;


	c_err  =  eRemove();
	if  (c_err)  return(c_err);
    
	try  {Directory::Delete(sNetDir + "\\" + s_conn_dir, true);}
	catch(Exception *p_ex)
	{
		CString  s_buf;
		s_buf.Format("An error occured while deleting a file\nError: %s",  p_ex->Message);
		c_err.vPutError(s_buf);	
	}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};

	return(c_err);
}//CError  CCONetConn::eRemove(CString  sNetDir)



CError  CCONetConn::eRefreshResults()
{
	CError  c_err;

	for  (int  ii = 0; ii < (int)  v_results.size(); ii++)
	{
		delete  v_results.at(ii);
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)
	v_results.clear();

	if  (i_id  >  0)
	{
		vector <void *>  v_co_components;
		CString  s_select_sql;
		s_select_sql.Format("Select * from results where con_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_co_components, s_select_sql,  CODB_COMP_TYPE_RESULT);

		if  (c_err  ==  false)
		{
			if  (v_co_components.empty()  ==  false)
			{
				for  (int  ii = 0; ii < (int)  v_co_components.size(); ii++)
				{
					v_results.push_back( (CCOResult *) v_co_components.at(ii));
				}//for  (int  ii = 0; ii < pvsAdbUsers->size(); ii++)
			}//if  (v_kdb_components.empty()  ==  false)
		}//if  (c_err  ==  false)	
	}//if  (i_id  >  0)

	return(c_err);

}//CError  CCONetConn::eRefreshResults()



CError  CCONetConn::eAddResult
	(
	CString  sRootDir,
	CString  sNetDir,
	int  iFitId, int iCompId, int iRSetId,
	CString  sResComments,  
	double  dFitValue,
	double  dTime, __int64  dtGenerated,
	vector <CString>  *pvFiles, CCOAlgorithm  *pcAlgorithm
	)
{
	CError  c_err;

	CString  s_buf;


	//now creating a result in db
	CCOResult  c_result(pc_conn);

	c_err  =  c_result.eUpdate
		(
		i_id, iFitId, pcAlgorithm->iGetId(), iCompId, iRSetId,
		"", 
		"",  
		0.0,
		-1, dtGenerated
		);

	if  (c_err)  
	{
		c_result.eRemove();
		return(c_err);
	}//if  (c_err)


	//now preparing a directory and copying a file
	int  i_new_result_id;
	i_new_result_id  =  c_result.iGetId();

	CString  s_new_catalog_name;
	s_new_catalog_name.Format("%.8d", i_new_result_id);
	
	

	if  (Directory::Exists(sRootDir + "\\" + sNetDir + "\\" + s_conn_dir + "\\" + s_new_catalog_name))
	{
		c_result.eRemove();
		s_buf.Format("Error directory already exists and may be used: %s", sRootDir + "\\" + sNetDir + "\\" + s_conn_dir + "\\" + s_new_catalog_name);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (Directory::Exists(sRootDir + "\\" + sNetDir + "\\" + s_conn_dir + s_new_catalog_name))

	
	try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(sRootDir + "\\" + sNetDir + "\\" + s_conn_dir + "\\" + s_new_catalog_name);}
	catch(Exception *p_ex)
	{
		s_buf.Format("An error occured while creating a directory\nError: %s",  p_ex->Message);
		c_err.vPutError(s_buf);	
	}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};
	if  (c_err)
	{
		c_result.eRemove();
		return(c_err);	
	}//if  (c_err)

	c_err  =  c_result.eUpdate
		(
		s_new_catalog_name, 
		sResComments,  dFitValue, dTime
		);

	if  (c_err)
	{
		try  {Directory::Delete(sRootDir + "\\" + sNetDir + "\\" + s_conn_dir + "\\" + s_new_catalog_name, true);}
		catch(Exception *p_ex)
		{
			s_buf.Format("An error occured while deleting a directory\nError: %s",  p_ex->Message);
			c_err.vPutError(s_buf);	
		}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};

		c_result.eRemove();
		return(c_err);
	}//if  (c_err)


	CError  c_file_add_err;
	for  (int ii = 0; ii < (int)  pvFiles->size(); ii++)
	{
		c_file_add_err  =  c_result.eAddFile(sRootDir, sNetDir, s_conn_dir, pvFiles->at(ii));

		if  (c_file_add_err)
		{
            //c_file_add_err.vShowWindow();
		}//if  (c_file_add_err)
	}//for  (int ii = 0; ii (int)  pvFiles->size(); ii++)


	c_err  =  pcAlgorithm->eUpdateParamsForResult(c_result.iGetId());

	return(c_err);
}//CError  CCONetConn::eAddResult



CError  CCONetConn::eRemoveResult(CString  sRootDir,  CString  sNetDir, int iResultIndex)
{
	CError  c_err;

	if  ( (iResultIndex  <  (int)  v_results.size())&&(iResultIndex  >=  0) )
	{
		c_err  =  v_results.at(iResultIndex)->eRemove(sRootDir + "\\" + sNetDir + "\\" + s_conn_dir);	
	}//if  ( (iNetIndex  <  (int)  v_nets->size())&&(iNetIndex  >=  0) )
	else
	{
		c_err.vPutError("Index exceeds list length");
		return(c_err);	
	}//else  if  ( (iNetIndex  <  (int)  v_nets->size())&&(iNetIndex  >=  0) )

	return(c_err);

}//CError  CCONetConn::eRemoveResult(CString  sRootDir,  CString  sNetDir, int iResultIndex)


CError  CCONetConn::eRefresh()
{
	CError  c_err;
	vector <void *>  v_temp_net_conn;

	if  (i_id  >  0)
	{
		CString  s_select_sql;
		s_select_sql.Format("Select * from connections where con_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_temp_net_conn, s_select_sql,  iGetType());

		if  (c_err  ==  false)
		{
			if  (v_temp_net_conn.size()  ==  1)
			{
                *this  =  *((CCONetConn *) v_temp_net_conn.at(0));
			}//if  (v_kdb_components.size()  ==  1)
			else
			{
				CString  s_buf;
				s_buf.Format("%d network connection obejcts with id %d", v_temp_net_conn.size(), i_id);
				c_err.vPutError(s_buf);
			}//else  if  (v_temp_net_conn.size()  ==  1)
		}//if  (c_err  ==  false)
		
	}//if  (i_id  >  0)

	for  (int  ii = 0; ii < (int)  v_temp_net_conn.size(); ii++)
	{
		delete (CCONetConn *) v_temp_net_conn.at(ii);
	}//for  (int  ii = 0; ii < v_temp_net_conn.size(); ii++)

	return(c_err);    
}//CError  CCONetConn::eRefresh()



void  CCONetConn::vGetData
	(
	int  *pi_id,
	int  *pi_net_id,
	CString  *ps_conn_name,
	CString  *ps_conn_file,  CString  *ps_conn_dir
	)
{
	*pi_id  =  i_id;
	*pi_net_id  =  i_net_id;
	*ps_conn_name  =  s_conn_name;
	*ps_conn_file  =  s_conn_file;
	*ps_conn_dir  =  s_conn_dir;
}//void  CCONetConn::vGetData



CError  CCONetConn::eUpdate
	(
	int  i_new_net_id,
	CString  s_new_conn_name,
	CString  s_new_conn_file,  CString  s_new_conn_dir
	)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_add_sql, vs_update_sql;

	CString  s_control, s_add, s_update;



	if  (i_id  <  0)
	{
		s_control.Format
		(
		"Select * from connections \
		where	\
		net_id  =  '%d' and	\
		(con_name  =  '%s' or  con_file  =  '%s') ",  

		i_new_net_id,
		CMySqlControl::sFormatForSQL(s_new_conn_name),  CMySqlControl::sFormatForSQL(s_new_conn_file)
		);

		vs_control_sql.push_back(s_control);


		s_add.Format
			(
			"Insert into connections \
			(  \
			net_id,  \
			con_name,  con_file,  con_dir  \
			) \
			values \
			( \
			'%d', \
			'%s', '%s', '%s' \
			)",  
			
			i_new_net_id,
			CMySqlControl::sFormatForSQL(s_new_conn_name),  CMySqlControl::sFormatForSQL(s_new_conn_file),  CMySqlControl::sFormatForSQL(s_new_conn_dir)
			);

		vs_add_sql.push_back(s_add);

		c_err  =  pc_conn->eAddDb(&vs_control_sql,  &vs_add_sql, "SELECT con_id FROM connections order by con_id desc limit 0,1", &i_id);

	}//if  (i_id  <  0)
	else
	{
		s_control  =  sGetControlString();
	
		vs_control_sql.push_back(s_control);


		s_update.Format
		(
		"update connections \
		set \
		net_id  =  '%d',	\
		con_name  =  '%s',	con_file  =  '%s', con_dir  =  '%s' \
		where  \
		con_id  =  '%d'",
		

		i_new_net_id,
		CMySqlControl::sFormatForSQL(s_new_conn_name),  CMySqlControl::sFormatForSQL(s_new_conn_file),  CMySqlControl::sFormatForSQL(s_new_conn_dir),
		i_id
		);

		vs_update_sql.push_back(s_update);

		c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_update_sql);
	
	}//else  if  (i_id  <  0)


	if  (c_err  ==  false)
	{
		i_net_id  =  i_new_net_id,
		s_conn_name  =  s_new_conn_name;
		s_conn_file  =  s_new_conn_file;
		s_conn_dir  =  s_new_conn_dir;
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCONetConn::eUpdate



CError  CCONetConn::eUpdate(CString  s_new_conn_name)
{
	CError  c_err;
	c_err  =  eUpdate
		(
		i_net_id,
		s_new_conn_name,  s_conn_file,  s_conn_dir
		);
	return(c_err);

}//CError  CCONetConn::eUpdate(CString  s_new_name)


bool  CCONetConn::operator==(CCODbComponent &cOtherComponent)
{
	
	if  (iGetType()  !=  cOtherComponent.iGetType())  return(false);

	if  (iGetId()  ==  cOtherComponent.iGetId())  
		return(true);
	else
		return(false);

	return(false);
}//bool  CCONetConn::operator==(CCODbComponent &cOtherComponent)



void  CCONetConn::operator=(CCONetConn &cOtherConn)
{
	i_id  =  cOtherConn.i_id;
	i_net_id  =  cOtherConn.i_net_id;
	s_conn_name  =  cOtherConn.s_conn_name;
	s_conn_file  =  cOtherConn.s_conn_file;
	s_conn_dir  =  cOtherConn.s_conn_dir;
}//void  CCONetConn::operator=(CCONetConn &cOtherConn)




//------------------implementation of object CCOAlgorithm----------------------------------------
CCOAlgorithm::CCOAlgorithm(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)
{
	//object data
	i_id  =  -1;
	s_alg_name  =  "";
	s_alg_comments  =  "";

}//CCOAlgorithm::CCOAlgorithm(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)




CCOAlgorithm::~CCOAlgorithm()
{
	for  (int  ii = 0; ii < (int)  v_alg_params.size(); ii++)
	{
		delete  v_alg_params.at(ii);
	}//for  (int  ii = 0; ii < (int)  v_net_conns.size(); ii++)
}//CCOAlgorithm::~CCOAlgorithm()


CString  CCOAlgorithm::sGetControlString()
{
	CString  s_res;

	s_res.Format
		(
		"Select * from algorithms \
		where	\
		alg_id  =  '%d' and	\
		alg_name  =  '%s' and	alg_comments  =  '%s' \
		",  

		i_id,
		CMySqlControl::sFormatForSQL(s_alg_name),  CMySqlControl::sFormatForSQL(s_alg_comments)
		);

	return(s_res);
}//CString  CCOAlgorithm::sGetControlString()



CError  CCOAlgorithm::eLoad(gcroot<MySqlDataReader *> pcReader)
{
	CError  c_err;

	i_id  =  pcReader->GetInt32(0);

	s_alg_name  =  pcReader->GetString(pcReader->GetOrdinal("alg_name"));
	s_alg_comments  =  pcReader->GetString(pcReader->GetOrdinal("alg_comments"));

	return(c_err);
}//CError  CCOAlgorithm::eLoad(gcroot<MySqlDataReader *> pcReader)



CError  CCOAlgorithm::eRemove()
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_remove_sql;

	CString  s_control, s_remove;


	s_control  =  sGetControlString();
	vs_control_sql.push_back(s_control);


	s_remove.Format("Delete from params where alg_param_id = ANY (SELECT alg_param_id from alg_param where alg_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from alg_param where alg_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from algorithms where alg_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);

	


	c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_remove_sql);

	if  (c_err  ==  false)  i_id  =  -1;

	return(c_err);
}//CError  CCOAlgorithm::eRemove()


//0 equal  1-not equal
int  CCOAlgorithm::iCompareParams(CCOAlgorithm  *pcOtherAlgorithm)
{

	if  (i_id  !=  pcOtherAlgorithm->i_id)  return(1);
	if  (v_alg_params.size()  !=  pcOtherAlgorithm->v_alg_params.size())  return(1);


	for  (int  ii = 0; ii < (int) v_alg_params.size(); ii++)
	{
		if  (
			v_alg_params.at(ii)->sGetParamName()  
			!=  
			pcOtherAlgorithm->v_alg_params.at(ii)->sGetParamName()  
			)
			return(1);

		if  (
			v_alg_params.at(ii)->dGetParamValue()
			!=  
			pcOtherAlgorithm->v_alg_params.at(ii)->dGetParamValue()
			)
			return(1);
	
	}//for  (int  ii = 0; ii < (int) v_alg_params.size(); ii++)

	return(0);
}//int  CCOAlgorithm::iCompareParams(CCOAlgorithm  *pcOtherAlgorithm)




CError  CCOAlgorithm::eAddParam(CString  sParamName, double dDefaultValue)
{
	CError  c_err;

	CString  s_buf;

	
	if  (i_id  >  0)
	{
		CCOAlgorithmParam  c_alg_param(pc_conn);

		c_err  =  c_alg_param.eUpdate(i_id, sParamName, dDefaultValue);
		if  (c_err)  
		{
			c_alg_param.eRemove();
			return(c_err);
		}//if  (c_err)
	}//if  (i_id  >  0)
	else
	{
		CCOAlgorithmParam  *pc_alg_param;
		pc_alg_param  =  new  CCOAlgorithmParam(pc_conn);

		pc_alg_param->s_param_name  =  sParamName;
		pc_alg_param->d_param_default  =  dDefaultValue;

		v_alg_params.push_back(pc_alg_param);
	}//else  if  (i_id  >  0)

	return(c_err);
}//CError  CCOAlgorithm::eAddParam(CString  sParamName, double dDefaultValue)




CError  CCOAlgorithm::eRemoveParam(int  iParamIndex)
{
	CError  c_err;

	if  ( (iParamIndex  <  (int)  v_alg_params.size())&&(iParamIndex  >=  0) )
	{
		c_err  =  v_alg_params.at(iParamIndex)->eRemove();	
	}//if  ( (iNetIndex  <  (int)  v_nets->size())&&(iNetIndex  >=  0) )
	else
	{
		c_err.vPutError("Index exceeds list length");
		return(c_err);	
	}//else  if  ( (iNetIndex  <  (int)  v_nets->size())&&(iNetIndex  >=  0) )

	return(c_err);
}//CError  CCOAlgorithm::eRemoveParam(int  iParamIndex)




CError  CCOAlgorithm::eUpdateParamsForResult(int  iResultId)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_remove_sql;

	CString  s_remove;

	s_remove.Format("Delete from params where result_id = '%d'", iResultId);
	vs_remove_sql.push_back(s_remove);
	c_err  =  pc_conn->eUpdateDb(&vs_control_sql,  &vs_remove_sql);
	if  (c_err)  return(c_err);



	for  (int ii = 0; ii < (int) v_alg_params.size(); ii++)
	{
		//we NEED to reset id, because we deleted algPramValues aoutside its objects
		if  (v_alg_params.at(ii)->pc_alg_par_val  !=  NULL)
			v_alg_params.at(ii)->pc_alg_par_val->i_id  =  -1;

		if  (c_err  ==  false)
			c_err  =  v_alg_params.at(ii)->eUpdateParamValue
				(v_alg_params.at(ii)->dGetParamValue(), iResultId);
	}//for  (int ii = 0; ii < (int) v_alg_params.size(); ii++)

	return(c_err);
}//CError  CCOAlgorithm::eUpdateParamsForAlgorithm(int  iAlgorithmId)



CError  CCOAlgorithm::eRefreshParamsForResult(int  iResultId)
{
	CError  c_err;

	vector  <void *>  v_params;
	CString  s_buf;

	s_buf.Format
		(
		"Select * from params where alg_param_id = \
		ANY (SELECT alg_param_id from alg_param where alg_id = '%d') \
		and result_id = '%d'",

		i_id, iResultId		
		);

	c_err  =  pc_conn->eSelectComponent(&v_params, s_buf, CODB_COMP_TYPE_ALGORITHM_PARAMETER_VALUE);

	if  (c_err)  
	{
		for  (int ii = 0; ii < (int) v_params.size(); ii++)
			delete  v_params.at(ii);
		return(c_err);
	}//if  (c_err)  

	for  (int ii = 0; ii < (int) v_alg_params.size(); ii++)
	{
		if  (v_alg_params.at(ii)->pc_alg_par_val  !=  NULL)
		{
			delete  v_alg_params.at(ii)->pc_alg_par_val;
			v_alg_params.at(ii)->pc_alg_par_val  =  NULL;
		}//if  (v_alg_params.at(ii)->pc_alg_par_val  !=  NULL)
	}//for  (int ii = 0; ii < (int) v_alg_params.size(); ii++)


	int  i_param_id;
	int  i_alg_param_id,  i_result_id;
	double  d_param_value;

	bool  b_found;
	for  (int ii = 0; ii < (int) v_params.size(); ii++)
	{
		((CCOAlgorithmParamValue*) v_params.at(ii))->vGetData
			(
			&i_param_id,
			&i_alg_param_id,  &i_result_id,
			&d_param_value
			);

		b_found  =  false;
		for  (int ij = 0; (ij < (int) v_alg_params.size())&&(b_found  ==  false); ij++)
		{
            if  (v_alg_params.at(ij)->iGetId()  ==  i_alg_param_id)
			{
				v_alg_params.at(ij)->pc_alg_par_val =
					(CCOAlgorithmParamValue*) v_params.at(ii);

				b_found  =  true;
			}//if  (v_alg_params.at(ij)->iGetId()  ==  i_alg_param_id)
		}//for  (int ij = 0; ij < (int) v_params.size(); ij++)

		if  (b_found  ==  false)
		{
			for  (int ij = 0; ij < (int) v_alg_params.size(); ij++)
			{
				delete  v_alg_params.at(ij)->pc_alg_par_val;
				v_alg_params.at(ij)->pc_alg_par_val  =  NULL;
			}//for  (int ij = 0; ij < (int) v_alg_params.size(); ij++)

			for  (int ij = 0; ij < (int) v_params.size(); ij++)
			{
				delete  (CCOAlgorithmParamValue*)  v_params.at(ij);
			}//for  (int ij = 0; ij < (int) v_alg_params.size(); ij++)

			s_buf.Format("Parameter not found in the algorith list (id:%d)", i_alg_param_id);
			c_err.vPutError(s_buf);
			return(c_err);
		}//if  (b_found  ==  false)
	}//for  (int ii = 0; ii < (int) v_alg_params.size(); ii++)
	
	return(c_err);
}//CError  CCOAlgorithm::eRefreshParamsForAlgorithm(int  iAlgorithmId)



CError  CCOAlgorithm::eRefreshParams()
{
	CError  c_err;

	//if object doesn not exist we can not refresh!
	if  (i_id  <  0)  return(c_err);

	for  (int  ii = 0; ii < (int)  v_alg_params.size(); ii++)
	{
		delete  v_alg_params.at(ii);
	}//for  (int  ii = 0; ii < i_fdb_size; ii++)
	v_alg_params.clear();

	if  (i_id  >  0)
	{
		vector <void *>  v_co_components;
		CString  s_select_sql;
		s_select_sql.Format("Select * from alg_param where alg_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_co_components, s_select_sql,  CODB_COMP_TYPE_ALGORITHM_PARAMETER);

		if  (c_err  ==  false)
		{
			if  (v_co_components.empty()  ==  false)
			{
				for  (int  ii = 0; ii < (int)  v_co_components.size(); ii++)
				{
					v_alg_params.push_back( (CCOAlgorithmParam *) v_co_components.at(ii));
				}//for  (int  ii = 0; ii < pvsAdbUsers->size(); ii++)
			}//if  (v_kdb_components.empty()  ==  false)
		}//if  (c_err  ==  false)	
	}//if  (i_id  >  0)

	return(c_err);
}//CError  CCOAlgorithm::eRefreshParams()



CError  CCOAlgorithm::eRefresh()
{
	CError  c_err;
	vector <void *>  v_temp_alg;

	if  (i_id  >  0)
	{
		CString  s_select_sql;
		s_select_sql.Format("Select * from algorithms where alg_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_temp_alg, s_select_sql,  iGetType());

		if  (c_err  ==  false)
		{
			if  (v_temp_alg.size()  ==  1)
			{
                *this  =  *((CCOAlgorithm *) v_temp_alg.at(0));
			}//if  (v_kdb_components.size()  ==  1)
			else
			{
				CString  s_buf;
				s_buf.Format("%d algorithm obejcts with id %d found", v_temp_alg.size(), i_id);
				c_err.vPutError(s_buf);
			}//else  if  (v_temp_net_conn.size()  ==  1)
		}//if  (c_err  ==  false)
		
	}//if  (i_id  >  0)

	for  (int  ii = 0; ii < (int)  v_temp_alg.size(); ii++)
	{
		delete (CCOAlgorithm *) v_temp_alg.at(ii);
	}//for  (int  ii = 0; ii < v_temp_alg.size(); ii++)

	return(c_err);    
}//CError  CCOAlgorithm::eRefresh()



void  CCOAlgorithm::vGetData
	(
	int  *pi_id,
	CString  *ps_alg_name,
	CString  *ps_alg_comments
	)
{
	*pi_id  =  i_id;
	*ps_alg_name  =  s_alg_name;
	*ps_alg_comments  =  s_alg_comments;
}//void  CCOAlgorithm::vGetData



CError  CCOAlgorithm::eUpdate
	(
	CString  s_new_alg_name,
	CString  s_new_alg_comments
	)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_add_sql, vs_update_sql;

	CString  s_control, s_add, s_update;



	if  (i_id  <  0)
	{
		s_control.Format
		(
		"Select * from algorithms \
		where	\
		alg_name  =  '%s'",

		CMySqlControl::sFormatForSQL(s_new_alg_name)
		);

		vs_control_sql.push_back(s_control);


		s_add.Format
			(
			"Insert into algorithms \
			(  \
			alg_name,  alg_comments  \
			) \
			values \
			( \
			'%s', '%s'\
			)",  
			
			CMySqlControl::sFormatForSQL(s_new_alg_name),  CMySqlControl::sFormatForSQL(s_new_alg_comments)
			);

		vs_add_sql.push_back(s_add);

		c_err  =  pc_conn->eAddDb(&vs_control_sql,  &vs_add_sql, "SELECT alg_id FROM algorithms order by alg_id desc limit 0,1", &i_id);

		if  (c_err  ==  false)
		{
			for  (int ii = 0; ii < (int)  v_alg_params.size();  ii++)
			{
				if  (c_err  ==  false)
				{
					c_err  =  v_alg_params.at(ii)->eUpdate
						(
						i_id, 
						v_alg_params.at(ii)->s_param_name,
						v_alg_params.at(ii)->d_param_default
						);
				
				}//if  (c_err  ==  false)
			
			}//for  (int ii = 0; ii < (int)  v_alg_params.size();  ii++)
		}//if  (c_err  ==  false)

	}//if  (i_id  <  0)
	else
	{
		s_control  =  sGetControlString();
	
		vs_control_sql.push_back(s_control);


		s_update.Format
		(
		"update algorithms \
		set \
		alg_name  =  '%s',	alg_comments  =  '%s' \
		where  \
		alg_id  =  '%d'",
		
		CMySqlControl::sFormatForSQL(s_new_alg_name),  CMySqlControl::sFormatForSQL(s_new_alg_comments),
		i_id
		);

		vs_update_sql.push_back(s_update);

		c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_update_sql);
	
	}//else  if  (i_id  <  0)


	if  (c_err  ==  false)
	{
		s_alg_name  =  s_new_alg_name;
		s_alg_comments  =  s_new_alg_comments;
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCOAlgorithm::eUpdate



bool  CCOAlgorithm::operator==(CCODbComponent &cOtherComponent)
{
	
	if  (iGetType()  !=  cOtherComponent.iGetType())  return(false);

	if  (iGetId()  ==  cOtherComponent.iGetId())  
		return(true);
	else
		return(false);

	return(false);
}//bool  CCOAlgorithm::operator==(CCODbComponent &cOtherComponent)


void  CCOAlgorithm::operator=(CCOAlgorithm &cOtherAlgorithm)
{
	i_id  =  cOtherAlgorithm.i_id;
	s_alg_name  =  cOtherAlgorithm.s_alg_name;
	s_alg_comments  =  cOtherAlgorithm.s_alg_comments;
}//void  CCOAlgorithm::operator=(CCOAlgorithm &cOtherAlgorithm)



//------------------implementation of object CCOAlgorithmParam----------------------------------------
CCOAlgorithmParam::CCOAlgorithmParam(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)
{
	//object data
	i_id  =  -1;
	i_alg_id  =  -1;
	s_param_name  =  "";
	d_param_default  =  0.0;

	pc_alg_par_val  =  NULL;
}//CCOAlgorithmParam::CCOAlgorithmParam(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)




CCOAlgorithmParam::~CCOAlgorithmParam()
{
	if  (pc_alg_par_val  !=  NULL)  delete  pc_alg_par_val;

}//CCOAlgorithmParam::~CCOAlgorithmParam()


CString  CCOAlgorithmParam::sGetControlString()
{
	CString  s_res;

	s_res.Format
		(
		"Select * from alg_param \
		where	\
		alg_param_id  =  '%d' and	\
		alg_id  =  '%d' and	\
		param_name  =  '%s' and	param_default  =  '%lf' \
		",  

		i_id,
		i_alg_id,
		CMySqlControl::sFormatForSQL(s_param_name),  d_param_default
		);

	return(s_res);
}//CString  CCOAlgorithmParam::sGetControlString()



CError  CCOAlgorithmParam::eLoad(gcroot<MySqlDataReader *> pcReader)
{
	CError  c_err;

	i_id  =  pcReader->GetInt32(0);
	i_alg_id  =  pcReader->GetInt32(pcReader->GetOrdinal("alg_id"));

	s_param_name  =  pcReader->GetString(pcReader->GetOrdinal("param_name"));
	d_param_default  =  pcReader->GetDouble(pcReader->GetOrdinal("param_default"));

	return(c_err);
}//CError  CCOAlgorithmParam::eLoad(gcroot<MySqlDataReader *> pcReader)



CError  CCOAlgorithmParam::eRemove()
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_remove_sql;

	CString  s_control, s_remove;


	s_control  =  sGetControlString();
	vs_control_sql.push_back(s_control);


	s_remove.Format("Delete from params where alg_param_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from alg_param where alg_param_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);
	

	c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_remove_sql);

	if  (c_err  ==  false)  i_id  =  -1;

	return(c_err);
}//CError  CCOAlgorithmParam::eRemove()



CError  CCOAlgorithmParam::eRefresh()
{
	CError  c_err;
	vector <void *>  v_temp_alg_param;

	if  (i_id  >  0)
	{
		CString  s_select_sql;
		s_select_sql.Format("Select * from alg_param where alg_param_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_temp_alg_param, s_select_sql,  iGetType());

		if  (c_err  ==  false)
		{
			if  (v_temp_alg_param.size()  ==  1)
			{
                *this  =  *((CCOAlgorithmParam *) v_temp_alg_param.at(0));
			}//if  (v_kdb_components.size()  ==  1)
			else
			{
				CString  s_buf;
				s_buf.Format("%d algorithm prameter obejcts with id %d found", v_temp_alg_param.size(), i_id);
				c_err.vPutError(s_buf);
			}//else  if  (v_temp_net_conn.size()  ==  1)
		}//if  (c_err  ==  false)
		
	}//if  (i_id  >  0)

	for  (int  ii = 0; ii < (int)  v_temp_alg_param.size(); ii++)
	{
		delete (CCOAlgorithmParam *) v_temp_alg_param.at(ii);
	}//for  (int  ii = 0; ii < v_temp_alg.size(); ii++)

	return(c_err);    
}//CError  CCOAlgorithmParam::eRefresh()



double  CCOAlgorithmParam::dGetParamValue()
{
	if  (pc_alg_par_val  !=  NULL)
	{
		return(pc_alg_par_val->dGetParamValue());	
	}//if  (pc_alg_par_val  !=  NULL)

	return(d_param_default);
}//double  CCOAlgorithmParam::dGetParamValue()



CError  CCOAlgorithmParam::eSetParamValue
	(
	double  d_new_param_value, int iResultId
	)
{
	CError  c_err;

	if  (pc_alg_par_val  ==  NULL)
	{
		pc_alg_par_val  =  new  CCOAlgorithmParamValue(pc_conn);
	}//if  (pc_alg_par_val  !=  NULL)
		
	c_err  =  pc_alg_par_val->eSetParamValue(d_new_param_value, i_id, iResultId);

	return(c_err);
}//CError  CCOAlgorithmParam::eSetParamValue



CError  CCOAlgorithmParam::eUpdateParamValue
	(
	double  d_new_param_value, int iResultId
	)
{
	CError  c_err;

	if  (pc_alg_par_val  ==  NULL)
	{
		pc_alg_par_val  =  new  CCOAlgorithmParamValue(pc_conn);
	}//if  (pc_alg_par_val  !=  NULL)
		
	c_err  =  pc_alg_par_val->eUpdate(d_new_param_value, i_id, iResultId);

	return(c_err);

}//CError  CCOAlgorithmParam::eUpdateParamValue


void  CCOAlgorithmParam::vGetData
	(
	int  *pi_id,
	int  *pi_alg_id,
	CString  *ps_param_name,
	double  *pd_param_default
	)
{
	*pi_id  =  i_id;
	*pi_alg_id  =  i_alg_id;
	*ps_param_name  =  s_param_name;
	*pd_param_default  =  d_param_default;
}//void  CCOAlgorithmParam::vGetData

CError  CCOAlgorithmParam::eUpdate
	(
	int  i_new_alg_id,
	CString  s_new_param_name,
	double  d_new_param_default
	)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_add_sql, vs_update_sql;

	CString  s_control, s_add, s_update;



	if  (i_id  <  0)
	{
		s_control.Format
		(
		"Select * from alg_param \
		where	\
		param_name  =  '%s' and alg_id = '%d'",

		CMySqlControl::sFormatForSQL(s_new_param_name),
		i_new_alg_id
		);

		vs_control_sql.push_back(s_control);


		s_add.Format
			(
			"Insert into alg_param \
			(  \
			alg_id,  param_name,  param_default  \
			) \
			values \
			( \
			'%d', '%s', '%lf' \
			)",  
			
			i_new_alg_id,
			CMySqlControl::sFormatForSQL(s_new_param_name),  d_new_param_default
			);

		vs_add_sql.push_back(s_add);

		c_err  =  pc_conn->eAddDb(&vs_control_sql,  &vs_add_sql, "SELECT alg_id FROM algorithms order by alg_id desc limit 0,1", &i_id);

	}//if  (i_id  <  0)
	else
	{
		s_control  =  sGetControlString();
	
		vs_control_sql.push_back(s_control);


		s_update.Format
		(
		"update alg_param \
		set \
		alg_id  =  '%d',	param_name  =  '%s', \
		param_default  =  '%lf' \
		where  \
		alg_param_id  =  '%d'",
		
		i_new_alg_id,
		CMySqlControl::sFormatForSQL(s_new_param_name),
		d_new_param_default,

		i_id
		);

		vs_update_sql.push_back(s_update);

		c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_update_sql);
	
	}//else  if  (i_id  <  0)


	if  (c_err  ==  false)
	{
		i_alg_id  =  i_new_alg_id;
		s_param_name  =  s_new_param_name;
		d_param_default  =  d_new_param_default;
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCOAlgorithmParam::eUpdate



bool  CCOAlgorithmParam::operator==(CCODbComponent &cOtherComponent)
{
	
	if  (iGetType()  !=  cOtherComponent.iGetType())  return(false);

	if  (iGetId()  ==  cOtherComponent.iGetId())  
		return(true);
	else
		return(false);

	return(false);
}//bool  CCOAlgorithmParam::operator==(CCODbComponent &cOtherComponent)







//------------------implementation of object CCOFitFunc----------------------------------------
CCOFitFunc::CCOFitFunc(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)
{
	//object data
	i_id  =  -1;
	s_ff_name  =  "";
	s_ff_comments  =  "";

}//CCOFitFunc::CCOFitFunc(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)




CCOFitFunc::~CCOFitFunc()
{

}//CCOFitFunc::~CCOFitFunc()


CString  CCOFitFunc::sGetControlString()
{
	CString  s_res;

	s_res.Format
		(
		"Select * from fit_func \
		where	\
		fit_id  =  '%d' and	\
		fit_name  =  '%s' and	fit_comments  =  '%s' \
		",  

		i_id,
		CMySqlControl::sFormatForSQL(s_ff_name),  CMySqlControl::sFormatForSQL(s_ff_comments)
		);

	return(s_res);
}//CString  CCOFitFunc::sGetControlString()



CError  CCOFitFunc::eLoad(gcroot<MySqlDataReader *> pcReader)
{
	CError  c_err;

	i_id  =  pcReader->GetInt32(0);

	s_ff_name  =  pcReader->GetString(pcReader->GetOrdinal("fit_name"));
	s_ff_comments  =  pcReader->GetString(pcReader->GetOrdinal("fit_comments"));

	return(c_err);
}//CError  CCOFitFunc::eLoad(gcroot<MySqlDataReader *> pcReader)



CError  CCOFitFunc::eRemove()
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_remove_sql;

	CString  s_control, s_remove;


	s_control  =  sGetControlString();
	vs_control_sql.push_back(s_control);


	s_remove.Format("Delete from fit_func where fit_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);


	c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_remove_sql);

	if  (c_err  ==  false)  i_id  =  -1;

	return(c_err);
}//CError  CCOFitFunc::eRemove()



CError  CCOFitFunc::eRefresh()
{
	CError  c_err;
	vector <void *>  v_temp_ff;

	if  (i_id  >  0)
	{
		CString  s_select_sql;
		s_select_sql.Format("Select * from fit_func where fit_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_temp_ff, s_select_sql,  iGetType());

		if  (c_err  ==  false)
		{
			if  (v_temp_ff.size()  ==  1)
			{
                *this  =  *((CCOFitFunc *) v_temp_ff.at(0));
			}//if  (v_kdb_components.size()  ==  1)
			else
			{
				CString  s_buf;
				s_buf.Format("%d fittnes function obejcts with id %d found", v_temp_ff.size(), i_id);
				c_err.vPutError(s_buf);
			}//else  if  (v_temp_ff.size()  ==  1)
		}//if  (c_err  ==  false)
		
	}//if  (i_id  >  0)

	for  (int  ii = 0; ii < (int)  v_temp_ff.size(); ii++)
	{
		delete (CCOFitFunc *) v_temp_ff.at(ii);
	}//for  (int  ii = 0; ii < v_temp_ff.size(); ii++)

	return(c_err);    
}//CError  CCOFitFunc::eRefresh()



void  CCOFitFunc::vGetData
	(
	int  *pi_id,
	CString  *ps_ff_name,
	CString  *ps_ff_comments
	)
{
	*pi_id  =  i_id;
	*ps_ff_name  =  s_ff_name;
	*ps_ff_comments  =  s_ff_comments;
}//void  CCOFitFunc::vGetData



CError  CCOFitFunc::eUpdate
	(
	CString  s_new_ff_name,
	CString  s_new_ff_comments
	)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_add_sql, vs_update_sql;

	CString  s_control, s_add, s_update;



	if  (i_id  <  0)
	{
		s_control.Format
		(
		"Select * from fit_func \
		where	\
		fit_name  =  '%s'",

		CMySqlControl::sFormatForSQL(s_new_ff_name)
		);

		vs_control_sql.push_back(s_control);


		s_add.Format
			(
			"Insert into fit_func \
			(  \
			fit_name,  fit_comments  \
			) \
			values \
			( \
			'%s', '%s'\
			)",  
			
			CMySqlControl::sFormatForSQL(s_new_ff_name),  CMySqlControl::sFormatForSQL(s_new_ff_comments)
			);

		vs_add_sql.push_back(s_add);

		c_err  =  pc_conn->eAddDb(&vs_control_sql,  &vs_add_sql, "SELECT fit_id FROM fit_func order by fit_id desc limit 0,1", &i_id);

	}//if  (i_id  <  0)
	else
	{
		s_control  =  sGetControlString();
	
		vs_control_sql.push_back(s_control);


		s_update.Format
		(
		"update fit_func \
		set \
		fit_name  =  '%s',	fit_comments  =  '%s' \
		where  \
		fit_id  =  '%d'",
		
		CMySqlControl::sFormatForSQL(s_new_ff_name),  CMySqlControl::sFormatForSQL(s_new_ff_comments),
		i_id
		);

		vs_update_sql.push_back(s_update);

		c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_update_sql);
	
	}//else  if  (i_id  <  0)


	if  (c_err  ==  false)
	{
		s_ff_name  =  s_new_ff_name;
		s_ff_comments  =  s_new_ff_comments;
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCOFitFunc::eUpdate



bool  CCOFitFunc::operator==(CCODbComponent &cOtherComponent)
{
	
	if  (iGetType()  !=  cOtherComponent.iGetType())  return(false);

	if  (iGetId()  ==  cOtherComponent.iGetId())  
		return(true);
	else
		return(false);

	return(false);
}//bool  CCOFitFunc::operator==(CCODbComponent &cOtherComponent)




void  CCOFitFunc::operator=(CCOFitFunc &cOtherFitFunc)
{
	i_id  =  cOtherFitFunc.i_id;
	s_ff_name  =  cOtherFitFunc.s_ff_name;
	s_ff_comments  =  cOtherFitFunc.s_ff_comments;
}//void  CCOFitFunc::operator=(CCOFitFunc &cOtherFitFunc)




//------------------implementation of object CCOComputer----------------------------------------
CCOComputer::CCOComputer(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)
{
	//object data
	i_id  =  -1;
	s_comp_name  =  "";
	s_comp_comments  =  "";

}//CCOComputer::CCOComputer(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)




CCOComputer::~CCOComputer()
{

}//CCOComputer::~CCOComputer()


CString  CCOComputer::sGetControlString()
{
	CString  s_res;

	s_res.Format
		(
		"Select * from computers \
		where	\
		comp_id  =  '%d' and	\
		comp_name  =  '%s' and	comp_comments  =  '%s' \
		",  

		i_id,
		CMySqlControl::sFormatForSQL(s_comp_name),  CMySqlControl::sFormatForSQL(s_comp_comments)
		);

	return(s_res);
}//CString  CCOComputer::sGetControlString()



CError  CCOComputer::eLoad(gcroot<MySqlDataReader *> pcReader)
{
	CError  c_err;

	i_id  =  pcReader->GetInt32(0);

	s_comp_name  =  pcReader->GetString(pcReader->GetOrdinal("comp_name"));
	s_comp_comments  =  pcReader->GetString(pcReader->GetOrdinal("comp_comments"));

	return(c_err);
}//CError  CCOComputer::eLoad(gcroot<MySqlDataReader *> pcReader)



CError  CCOComputer::eRemove()
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_remove_sql;

	CString  s_control, s_remove;


	s_control  =  sGetControlString();
	vs_control_sql.push_back(s_control);


	s_remove.Format("Delete from computers where comp_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);


	c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_remove_sql);

	if  (c_err  ==  false)  i_id  =  -1;

	return(c_err);
}//CError  CCOComputer::eRemove()



CError  CCOComputer::eRefresh()
{
	CError  c_err;
	vector <void *>  v_temp_comp;

	if  (i_id  >  0)
	{
		CString  s_select_sql;
		s_select_sql.Format("Select * from computers where comp_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_temp_comp, s_select_sql,  iGetType());

		if  (c_err  ==  false)
		{
			if  (v_temp_comp.size()  ==  1)
			{
                *this  =  *((CCOComputer *) v_temp_comp.at(0));
			}//if  (v_kdb_components.size()  ==  1)
			else
			{
				CString  s_buf;
				s_buf.Format("%d computer obejcts with id %d found", v_temp_comp.size(), i_id);
				c_err.vPutError(s_buf);
			}//else  if  (v_temp_comp.size()  ==  1)
		}//if  (c_err  ==  false)
		
	}//if  (i_id  >  0)

	for  (int  ii = 0; ii < (int)  v_temp_comp.size(); ii++)
	{
		delete (CCOComputer *) v_temp_comp.at(ii);
	}//for  (int  ii = 0; ii < v_temp_comp.size(); ii++)

	return(c_err);    
}//CError  CCOComputer::eRefresh()



void  CCOComputer::vGetData
	(
	int  *pi_id,
	CString  *ps_comp_name,
	CString  *ps_comp_comments
	)
{
	*pi_id  =  i_id;
	*ps_comp_name  =  s_comp_name;
	*ps_comp_comments  =  s_comp_comments;
}//void  CCOComputer::vGetData



CError  CCOComputer::eUpdate
	(
	CString  s_new_comp_name,
	CString  s_new_comp_comments
	)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_add_sql, vs_update_sql;

	CString  s_control, s_add, s_update;



	if  (i_id  <  0)
	{
		s_control.Format
		(
		"Select * from computers \
		where	\
		comp_name  =  '%s'",

		CMySqlControl::sFormatForSQL(s_new_comp_name)
		);

		vs_control_sql.push_back(s_control);


		s_add.Format
			(
			"Insert into computers \
			(  \
			comp_name,  comp_comments  \
			) \
			values \
			( \
			'%s', '%s'\
			)",  
			
			CMySqlControl::sFormatForSQL(s_new_comp_name),  CMySqlControl::sFormatForSQL(s_new_comp_comments)
			);

		vs_add_sql.push_back(s_add);

		c_err  =  pc_conn->eAddDb(&vs_control_sql,  &vs_add_sql, "SELECT comp_id FROM computers order by comp_id desc limit 0,1", &i_id);

	}//if  (i_id  <  0)
	else
	{
		s_control  =  sGetControlString();
	
		vs_control_sql.push_back(s_control);


		s_update.Format
		(
		"update computers \
		set \
		comp_name  =  '%s',	comp_comments  =  '%s' \
		where  \
		comp_id  =  '%d'",
		
		CMySqlControl::sFormatForSQL(s_new_comp_name),  CMySqlControl::sFormatForSQL(s_new_comp_comments),
		i_id
		);

		vs_update_sql.push_back(s_update);

		c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_update_sql);
	
	}//else  if  (i_id  <  0)


	if  (c_err  ==  false)
	{
		s_comp_name  =  s_new_comp_name;
		s_comp_comments  =  s_new_comp_comments;
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCOComputer::eUpdate



bool  CCOComputer::operator==(CCODbComponent &cOtherComponent)
{
	
	if  (iGetType()  !=  cOtherComponent.iGetType())  return(false);

	if  (iGetId()  ==  cOtherComponent.iGetId())  
		return(true);
	else
		return(false);

	return(false);
}//bool  CCOComputer::operator==(CCODbComponent &cOtherComponent)





//------------------implementation of object CCOResult----------------------------------------
CCOResult::CCOResult(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)
{
	//object data
	i_id  =  -1;
	i_con_id  =  -1;
	i_fit_id  =  -1;
	i_alg_id  =  -1;
	i_comp_id  =  -1;
	s_res_dir  =  "";
	s_res_comments  =  "";
	d_fit_value  =  0;
	d_time  =  0.0;
	dt_generated  =  0;

}//CCOResult::CCOResult(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)




CCOResult::~CCOResult()
{

}//CCOResult::~CCOResult()


CString  CCOResult::sGetControlString()
{
	CString  s_res;

	System::DateTime  dt_buf;
	dt_buf  =  System::DateTime::FromFileTime(dt_generated);

	s_res.Format
		(
		"Select * from results \
		where	\
		result_id = '%d' and \
		con_id  =  '%d' and \
		fit_id  =  '%d'  and \
		alg_id  =  '%d' and \
		comp_id  =  '%d' and \
		res_dir  =  '%s' and  res_comments = '%s' and \
		fit_val  =  '%.16lf' and time  =  '%lf' and \
		generated  =  '%s' \
		",  

		i_id,
		i_con_id, i_fit_id, i_alg_id, i_comp_id,
		CMySqlControl::sFormatForSQL(s_res_dir), CMySqlControl::sFormatForSQL(s_res_comments),
		d_fit_value,
		d_time,
		CMySqlControl::sFormatForSQL(dt_buf.ToString())
		);

	
	return(s_res);
}//CString  CCOResult::sGetControlString()



CError  CCOResult::eLoad(gcroot<MySqlDataReader *> pcReader)
{
	CError  c_err;

	i_id  =  pcReader->GetInt32(0);

	i_con_id  =  pcReader->GetInt32(pcReader->GetOrdinal("con_id"));
	i_fit_id  =  pcReader->GetInt32(pcReader->GetOrdinal("fit_id"));
	i_alg_id  =  pcReader->GetInt32(pcReader->GetOrdinal("alg_id"));
	i_comp_id  =  pcReader->GetInt32(pcReader->GetOrdinal("comp_id"));
	i_rset_id  =  pcReader->GetInt32(pcReader->GetOrdinal("results_set_id"));

	s_res_dir  =  pcReader->GetString(pcReader->GetOrdinal("res_dir"));
	s_res_comments  =  pcReader->GetString(pcReader->GetOrdinal("res_comments"));

	d_fit_value  =  pcReader->GetDouble(pcReader->GetOrdinal("fit_val"));
	d_time  =  pcReader->GetDouble(pcReader->GetOrdinal("time"));

	System::DateTime  dt_buf;
	dt_buf  =  pcReader->GetDateTime(pcReader->GetOrdinal("generated"));
	dt_generated  =  dt_buf.ToFileTime();

	return(c_err);
}//CError  CCOResult::eLoad(gcroot<MySqlDataReader *> pcReader)



CError  CCOResult::eRemove()
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_remove_sql;

	CString  s_control, s_remove;


	s_control  =  sGetControlString();
	//vs_control_sql.push_back(s_control);


	s_remove.Format("Delete from params where result_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);
	s_remove.Format("Delete from results where result_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);


	c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_remove_sql);

	if  (c_err  ==  false)  i_id  =  -1;

	return(c_err);
}//CError  CCOResult::eRemove()



CError  CCOResult::eRemove(CString  sConnDir)
{
	CError  c_err;


	c_err  =  eRemove();
	if  (c_err)  return(c_err);
    
	try  {Directory::Delete(sConnDir + "\\" + s_res_dir, true);}
	catch(Exception *p_ex)
	{
		CString  s_buf;
		s_buf.Format("An error occured while deleting a directory\nError: %s",  p_ex->Message);
		c_err.vPutError(s_buf);	
	}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};

	return(c_err);
}//CError  CCONetConn::eRemove(CString  sNetDir)




CError  CCOResult::eRefresh()
{
	CError  c_err;
	vector <void *>  v_temp_result;

	if  (i_id  >  0)
	{
		CString  s_select_sql;
		s_select_sql.Format("Select * from results where result_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_temp_result, s_select_sql,  iGetType());

		if  (c_err  ==  false)
		{
			if  (v_temp_result.size()  ==  1)
			{
                *this  =  *((CCOResult *) v_temp_result.at(0));
			}//if  (v_kdb_components.size()  ==  1)
			else
			{
				CString  s_buf;
				s_buf.Format("%d result obejcts with id %d found", v_temp_result.size(), i_id);
				c_err.vPutError(s_buf);
			}//else  if  (v_temp_comp.size()  ==  1)
		}//if  (c_err  ==  false)
		
	}//if  (i_id  >  0)

	for  (int  ii = 0; ii < (int)  v_temp_result.size(); ii++)
	{
		delete (CCOResult *) v_temp_result.at(ii);
	}//for  (int  ii = 0; ii < v_temp_comp.size(); ii++)

	return(c_err);    
}//CError  CCOResult::eRefresh()



void  CCOResult::vGetData
	(
	int  *pi_id,
	int *pi_con_id, int *pi_fit_id, int *pi_alg_id, int *pi_comp_id, int *pi_rset_id,
	CString  *ps_res_dir, CString  *ps_res_comments,
	double  *pd_fit_value,
	double  *pd_time,
	__int64  *pdt_generated
	)
{
	*pi_id  =  i_id;
	*pi_con_id  =  i_con_id;
	*pi_fit_id  =  i_fit_id;
	*pi_alg_id  =  i_alg_id;
	*pi_comp_id  =  i_comp_id;
	*pi_rset_id  =  i_rset_id;
	
	*ps_res_dir  =  s_res_dir;
	*ps_res_comments  =  s_res_comments;
	
	*pd_fit_value  =  d_fit_value;
	
	*pd_time  =  d_time;
	*pdt_generated  =  dt_generated;

}//void  CCOResult::vGetData



CError  CCOResult::eGetFiles(CString  sRootDir,  CString  sNetDir, CString   sConnDir, vector <CString>  *pvFiles)
{
	CError  c_err;

	if  (i_id  <  0)
	{
		c_err.vPutError("Object does not exist");
		return(c_err);	
	}//if  (i_id  <  0)


	CString  s_buf;

	s_buf  =  sRootDir + "\\" + sNetDir + "\\" + sConnDir + "\\" + s_res_dir;

	if  (Directory::Exists(sRootDir + "\\" + sNetDir + "\\" + sConnDir + "\\" + s_res_dir)  ==  false)
	{
		s_buf.Format("Directory does not exists: %s", sRootDir + "\\" + sNetDir + "\\" + sConnDir + "\\" + s_res_dir);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (Directory::Exists(sRootDir + "\\" + sNetDir + "\\" + s_conn_dir + s_new_catalog_name))


	String* ps_files[]  =  Directory::GetFiles(sRootDir + "\\" + sNetDir + "\\" + sConnDir + "\\" + s_res_dir);

	int  i_count  =  ps_files->Count;

	for  (int ii = 0; ii < i_count; ii++)
	{
		FileInfo  *pf;
		pf  =  new  FileInfo(ps_files->get_Item(ii)->ToString());

		s_buf  =  pf->Name;
		pvFiles->push_back(s_buf);
	
	}//for  (int ii = 0; ii < ps_files->Count; ii++)

	return(c_err);
}//CError  CCOResult::eGetFiles(CString  sRootDir,  CString  sNetDir, CString   sConnDir, vector <CString>  *pvFiles)





CError  CCOResult::eRemoveFile(CString  sRootDir,  CString  sNetDir, CString   sConnDir, CString  sFileToRemove)
{
	CError  c_err;

	FileInfo  *pc_fi  =  new  FileInfo
		(
		sRootDir + "\\" + sNetDir + "\\" + sConnDir + "\\" + s_res_dir + "\\" + sFileToRemove
		);

	
	if  (pc_fi->Exists  ==  false)
	{
		c_err.vPutError("File not exists");
		return(c_err);	
	}//if  (pc_fi->Exists  ==  false)

	try  {pc_fi->Delete();}
	catch  (Exception  *pe)
	{
		CString  s_buf;	
		s_buf.Format("Operation failed because of:\n%s", pe->Message);
		c_err.vPutError(s_buf);
	}//catch  (Exception  *pe)

	return(c_err);	
}//CError  CCOResult::eRemoveFile(CString  sRootDir,  CString  sNetDir, CString   sConnDir, CString  sFileToRemove)



CError  CCOResult::eAddFile(CString  sRootDir,  CString  sNetDir, CString   sConnDir, CString  sFileToAdd, bool  bOverwrite)
{
	CError  c_err;

	CString  s_buf;

	if  (Directory::Exists(sRootDir + "\\" + sNetDir + "\\" + sConnDir + "\\" + s_res_dir)  ==  false)
	{
		s_buf.Format("Directory does not exists: %s", sRootDir + "\\" + sNetDir + "\\" + sConnDir + "\\" + s_res_dir);
		c_err.vPutError(s_buf);
		return(c_err);	
	}//if  (Directory::Exists(sRootDir + "\\" + sNetDir + "\\" + s_conn_dir + s_new_catalog_name))


	FileInfo  *pc_fi  =  new  FileInfo(sFileToAdd);
	CString  s_file_name;
	s_file_name  =  pc_fi->Name;


	try  {File::Copy(sFileToAdd, sRootDir + "\\" + sNetDir + "\\" + sConnDir + "\\" + s_res_dir + "\\" + s_file_name, bOverwrite);}
	catch(Exception *p_ex)
	{
		s_buf.Format("An error occured while copying a file\nError: %s",  p_ex->Message);
		c_err.vPutError(s_buf);	
	}//catch  try  {DirectoryInfo* pc_di  =  Directory::CreateDirectory(s_full_dir);};

	return(c_err);
}//CError  CCOResult::eAddFile(CString  sRootDir,  CString  sNetDir, CString  sFileToAdd)



CError  CCOResult::eUpdate
	(
	CString  s_new_res_dir,  CString  s_new_res_comments,
	double  d_new_fit_value,
	double  d_new_time
	)
{
	CError  c_err;

	c_err  =  eUpdate
		(
		i_con_id, i_fit_id, i_alg_id, i_comp_id,  i_rset_id,
		s_new_res_dir, s_new_res_comments,
		d_new_fit_value,
		d_new_time,
		dt_generated
		);

	return(c_err);
}//CError  CCOResult::eUpdate


CError  CCOResult::eUpdate
	(
	int i_new_con_id, int i_new_fit_id, int i_new_alg_id, int i_new_comp_id, int i_new_rset_id,
	CString  s_new_res_dir, CString  s_new_res_comments,
	double  d_new_fit_value,
	double  d_new_time,
	__int64  dt_new_generated
	)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_add_sql, vs_update_sql;

	CString  s_control, s_add, s_update;



	if  (i_id  <  0)
	{
		System::DateTime  dt_buf;
		dt_buf  =  System::DateTime::FromFileTime(dt_new_generated);

		s_add.Format
			(
			"Insert into results \
			(  \
			con_id,	fit_id, alg_id, comp_id, results_set_id, \
			res_dir, res_comments, \
			fit_val, time, \
			generated \
			) \
			values \
			( \
			'%d', '%d', '%d', '%d', '%d', \
			'%s', '%s', \
			'%.16lf', '%lf', \
			'%s' \
			)",  
			
			i_new_con_id, i_new_fit_id, i_new_alg_id, i_new_comp_id, i_new_rset_id,
			CMySqlControl::sFormatForSQL(s_new_res_dir), CMySqlControl::sFormatForSQL(s_new_res_comments),
			d_new_fit_value, d_new_time,
			CMySqlControl::sFormatForSQL(dt_buf.ToString())
			);

		vs_add_sql.push_back(s_add);

		c_err  =  pc_conn->eAddDb(&vs_control_sql,  &vs_add_sql, "SELECT result_id FROM results order by result_id desc limit 0,1", &i_id);

	}//if  (i_id  <  0)
	else
	{
		s_control  =  sGetControlString();
	
		vs_control_sql.push_back(s_control);

		System::DateTime  dt_buf;
		dt_buf  =  System::DateTime::FromFileTime(dt_new_generated);

		s_update.Format
		(
		"update results \
		set \
		con_id  =  '%d',	fit_id  =  '%d', alg_id  =  '%d', comp_id  =  '%d', results_set_id  =  '%d', \
		res_dir  =  '%s', res_comments  =  '%s', \
		fit_val  =  '%.16lf', time  =  '%lf', \
		generated  =  '%s' \
		where  \
		result_id  =  '%d'",
		
		i_new_con_id, i_new_fit_id, i_new_alg_id, i_new_comp_id, i_new_rset_id,
		CMySqlControl::sFormatForSQL(s_new_res_dir), CMySqlControl::sFormatForSQL(s_new_res_comments),
		d_new_fit_value, d_new_time,
		CMySqlControl::sFormatForSQL(dt_buf.ToString()),

		i_id
		);

		vs_update_sql.push_back(s_update);

		c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_update_sql);
	
	}//else  if  (i_id  <  0)


	if  (c_err  ==  false)
	{
		i_con_id  =  i_new_con_id;
		i_fit_id  =  i_new_fit_id;
		i_alg_id  =  i_new_alg_id;
		i_comp_id  =  i_new_comp_id;
		i_rset_id  =  i_new_rset_id;
		
		s_res_dir  =  s_new_res_dir;
		s_res_comments  =  s_new_res_comments;
		
		d_fit_value  =  d_new_fit_value;
		
		d_time  =  d_new_time;
		dt_generated  =  dt_new_generated;
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCOResult::eUpdate



bool  CCOResult::operator==(CCODbComponent &cOtherComponent)
{
	
	if  (iGetType()  !=  cOtherComponent.iGetType())  return(false);

	if  (iGetId()  ==  cOtherComponent.iGetId())  
		return(true);
	else
		return(false);

	return(false);
}//bool  CCOResult::operator==(CCODbComponent &cOtherComponent)




//------------------implementation of object CCOAlgorithmParamValue----------------------------------------
CCOAlgorithmParamValue::CCOAlgorithmParamValue(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)
{
	//object data
	i_id  =  -1;
	i_alg_param_id  =  -1;
	i_result_id  =  -1;
	
	d_param_value  =  0.0;

}//CCOAlgorithmParamValue::CCOAlgorithmParamValue(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)




CCOAlgorithmParamValue::~CCOAlgorithmParamValue()
{

}//CCOAlgorithmParamValue::~CCOAlgorithmParamValue()


CString  CCOAlgorithmParamValue::sGetControlString()
{
	CString  s_res;

	s_res.Format
		(
		"Select * from params \
		where	\
		param_id  =  '%d' and	\
		param_val  =  '%lf' \
		",  

		i_id,
		d_param_value
		);

	return(s_res);
}//CString  CCOAlgorithmParamValue::sGetControlString()



CError  CCOAlgorithmParamValue::eLoad(gcroot<MySqlDataReader *> pcReader)
{
	CError  c_err;

	i_id  =  pcReader->GetInt32(0);

	i_alg_param_id  =  pcReader->GetInt32(pcReader->GetOrdinal("alg_param_id"));
	i_result_id  =  pcReader->GetInt32(pcReader->GetOrdinal("result_id"));

	d_param_value  =  pcReader->GetDouble(pcReader->GetOrdinal("param_val"));
	
	return(c_err);
}//CError  CCOAlgorithmParamValue::eLoad(gcroot<MySqlDataReader *> pcReader)



CError  CCOAlgorithmParamValue::eRemove()
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_remove_sql;

	CString  s_control, s_remove;


	s_control  =  sGetControlString();
	vs_control_sql.push_back(s_control);


	s_remove.Format("Delete from params where param_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);


	c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_remove_sql);

	if  (c_err  ==  false)  i_id  =  -1;

	return(c_err);
}//CError  CCOAlgorithmParamValue::eRemove()



CError  CCOAlgorithmParamValue::eRefresh()
{
	CError  c_err;
	vector <void *>  v_temp_comp;

	if  (i_id  >  0)
	{
		CString  s_select_sql;
		s_select_sql.Format("Select * from params where param_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_temp_comp, s_select_sql,  iGetType());

		if  (c_err  ==  false)
		{
			if  (v_temp_comp.size()  ==  1)
			{
                *this  =  *((CCOAlgorithmParamValue *) v_temp_comp.at(0));
			}//if  (v_kdb_components.size()  ==  1)
			else
			{
				CString  s_buf;
				s_buf.Format("%d parameter obejcts with id %d found", v_temp_comp.size(), i_id);
				c_err.vPutError(s_buf);
			}//else  if  (v_temp_comp.size()  ==  1)
		}//if  (c_err  ==  false)
		
	}//if  (i_id  >  0)

	for  (int  ii = 0; ii < (int)  v_temp_comp.size(); ii++)
	{
		delete (CCOAlgorithmParamValue *) v_temp_comp.at(ii);
	}//for  (int  ii = 0; ii < v_temp_comp.size(); ii++)

	return(c_err);    
}//CError  CCOAlgorithmParamValue::eRefresh()



void  CCOAlgorithmParamValue::vGetData
	(
	int  *pi_id,
	int  *pi_alg_param_id,  int  *pi_result_id,
	double  *pd_param_value
	)
{
	*pi_id  =  i_id;
	*pi_alg_param_id  =  i_alg_param_id;
	*pi_result_id  =  i_result_id;
	*pd_param_value  =  d_param_value;
}//void  CCOAlgorithmParamValue::vGetData



//does the same thing that eUpdateParamValue, but it does not write to db
CError  CCOAlgorithmParamValue::eSetParamValue
	(
	double  d_new_param_value,
	int  iAlgParamId, int iResultId
	)
{
	CError  c_err;

	if  (i_id  >=  0)
	{
		if  ( (iAlgParamId  !=  i_alg_param_id)||(iResultId  !=  i_result_id) )
		{
			c_err.vPutError("Algorithm and result differs for this parameter!");
			return(c_err);		
		}//if  ( (AlgParamId  !=  i_alg_param_id)||(iResultId  !=  i_result_id) )

	}//if  (i_id  >=  0)

	d_param_value  =  d_new_param_value;
	i_alg_param_id  =  iAlgParamId;
	i_result_id  =  iResultId;

	return(c_err);
}//CError  CCOAlgorithmParamValue::eSetParamValue



CError  CCOAlgorithmParamValue::eUpdate
	(
	double  d_new_param_value,
	int  iAlgParamId, int iResultId
	)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_add_sql, vs_update_sql;

	CString  s_control, s_add, s_update;



	if  (i_id  <  0)
	{
		s_control.Format
		(
		"Select * from params \
		where	\
		alg_param_id  =  '%d' and \
		result_id = '%d'",

		iAlgParamId, iResultId
		);

		vs_control_sql.push_back(s_control);


		s_add.Format
			(
			"Insert into params \
			(  \
			alg_param_id,  result_id, param_val  \
			) \
			values \
			( \
			'%d', '%d', '%lf'\
			)",  
			
			iAlgParamId, iResultId, d_new_param_value
			);

		vs_add_sql.push_back(s_add);

		c_err  =  pc_conn->eAddDb(&vs_control_sql,  &vs_add_sql, "SELECT param_id FROM params order by param_id desc limit 0,1", &i_id);

	}//if  (i_id  <  0)
	else
	{
		if  ( (iAlgParamId  !=  i_alg_param_id)||(iResultId  !=  i_result_id) )
		{
			c_err.vPutError("Algorithm and result differs for this parameter!");
			return(c_err);		
		}//if  ( (AlgParamId  !=  i_alg_param_id)||(iResultId  !=  i_result_id) )

		s_control  =  sGetControlString();
	
		vs_control_sql.push_back(s_control);


		s_update.Format
		(
		"update params \
		set \
		param_val = '%lf' \
		where  \
		param_id  =  '%d'",
		
		d_new_param_value,
		i_id
		);

		vs_update_sql.push_back(s_update);

		c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_update_sql);
	
	}//else  if  (i_id  <  0)


	if  (c_err  ==  false)
	{
		d_param_value  =  d_new_param_value;

		i_alg_param_id  =  iAlgParamId;
		i_result_id  =  iResultId;
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCOAlgorithmParamValue::eUpdate



bool  CCOAlgorithmParamValue::operator==(CCODbComponent &cOtherComponent)
{
	
	if  (iGetType()  !=  cOtherComponent.iGetType())  return(false);

	if  (iGetId()  ==  cOtherComponent.iGetId())  
		return(true);
	else
		return(false);

	return(false);
}//bool  CCOAlgorithmParamValue::operator==(CCODbComponent &cOtherComponent)




//------------------implementation of object CCOResultSet----------------------------------------
CCOResultSet::CCOResultSet(CMySqlControl  *pcNewConn): CCODbComponent(pcNewConn)
{
	//object data
	i_id  =  -1;
	s_rset_name  =  "";
	s_rset_comments  =  "";

}//CCOResultSet::CCOResultSet(CMySqlControl  *pcNewConn): CCODbrsetonent(pcNewConn)




CCOResultSet::~CCOResultSet()
{

}//CCOResultSet::~CCOResultSet()


CString  CCOResultSet::sGetControlString()
{
	CString  s_res;

	s_res.Format
		(
		"Select * from results_sets \
		where	\
		results_set_id  =  '%d' and	\
		name  =  '%s' and	comments  =  '%s' \
		",  

		i_id,
		CMySqlControl::sFormatForSQL(s_rset_name),  CMySqlControl::sFormatForSQL(s_rset_comments)
		);

	return(s_res);
}//CString  CCOResultSet::sGetControlString()



CError  CCOResultSet::eLoad(gcroot<MySqlDataReader *> pcReader)
{
	CError  c_err;

	i_id  =  pcReader->GetInt32(0);

	s_rset_name  =  pcReader->GetString(pcReader->GetOrdinal("name"));
	s_rset_comments  =  pcReader->GetString(pcReader->GetOrdinal("comments"));

	return(c_err);
}//CError  CCOResultSet::eLoad(gcroot<MySqlDataReader *> pcReader)



CError  CCOResultSet::eRemoveWithResults(CSystem  *pcSystem)
{
	CError  c_err;
    vector  <void  *>  v_results;
	CString  s_select;

	s_select.Format("Select * from results where results_set_id = '%d'", i_id);
	c_err  =  pc_conn->eSelectComponent(&v_results,  s_select, CODB_COMP_TYPE_RESULT);

	if  (c_err)
	{
		for  (int  ii = 0; ii < (int)  v_results.size(); ii++)
			delete  (CCOResult *)  v_results.at(ii);
		return(c_err);	
	}//if  (c_err)


	CError  c_temp_err;
	CString  s_buf;
	CCOFDbRoot  c_root(NULL);
	CCONet  c_net(NULL);
	CCONetConn  c_conn(NULL);

	for  (int  ii = 0;  ii < (int) v_results.size(); ii++)
	{
		c_temp_err  =  pcSystem->eFindFDbNetworkAndConnForResult
			(
			(CCOResult  *)  v_results.at(ii),
			&c_root,  &c_net,  &c_conn
			);

		if  (c_temp_err)
		{
			c_err  =  c_temp_err;		
		}//if  (c_temp_err)
		else
		{
			s_buf  =  c_root.sGetRootDir() + "\\" + c_net.sGetNetDir() + "\\" + c_conn.sGetConnDir();
			c_temp_err  =  ((CCOResult  *)  v_results.at(ii) )->eRemove(s_buf);

			if  (c_temp_err)  c_err  =  c_temp_err;
		}//else  if  (c_temp_err)
	}//for  (int  ii = 0;  ii < (int) v_results.size(); ii++)

	if  (c_err)  return(c_err);

	c_err  =  eRemove();


	return(c_err);

}//CError  CCOResultSet::eRemoveWithResults()



CError  CCOResultSet::eRemove()
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_remove_sql;

	CString  s_control, s_remove;


	s_control  =  sGetControlString();
	vs_control_sql.push_back(s_control);


	s_remove.Format("Delete from results_sets where results_set_id = '%d'", i_id);
	vs_remove_sql.push_back(s_remove);


	c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_remove_sql);

	if  (c_err  ==  false)  i_id  =  -1;

	return(c_err);
}//CError  CCOResultSet::eRemove()



CError  CCOResultSet::eRefresh()
{
	CError  c_err;
	vector <void *>  v_temp_rset;

	if  (i_id  >  0)
	{
		CString  s_select_sql;
		s_select_sql.Format("Select * from results_sets where results_set_id = '%d'", i_id);
		c_err  =  pc_conn->eSelectComponent(&v_temp_rset, s_select_sql,  iGetType());

		if  (c_err  ==  false)
		{
			if  (v_temp_rset.size()  ==  1)
			{
                *this  =  *((CCOResultSet *) v_temp_rset.at(0));
			}//if  (v_kdb_rsetonents.size()  ==  1)
			else
			{
				CString  s_buf;
				s_buf.Format("%d results_sets obejcts with id %d found", v_temp_rset.size(), i_id);
				c_err.vPutError(s_buf);
			}//else  if  (v_temp_rset.size()  ==  1)
		}//if  (c_err  ==  false)
		
	}//if  (i_id  >  0)

	for  (int  ii = 0; ii < (int)  v_temp_rset.size(); ii++)
	{
		delete (CCOResultSet *) v_temp_rset.at(ii);
	}//for  (int  ii = 0; ii < v_temp_rset.size(); ii++)

	return(c_err);    
}//CError  CCOResultSet::eRefresh()



void  CCOResultSet::vGetData
	(
	int  *pi_id,
	CString  *ps_rset_name,
	CString  *ps_rset_comments
	)
{
	*pi_id  =  i_id;
	*ps_rset_name  =  s_rset_name;
	*ps_rset_comments  =  s_rset_comments;
}//void  CCOResultSet::vGetData



CError  CCOResultSet::eUpdate
	(
	CString  s_new_rset_name,
	CString  s_new_rset_comments
	)
{
	CError  c_err;

	vector  <CString>  vs_control_sql,  vs_add_sql, vs_update_sql;

	CString  s_control, s_add, s_update;



	if  (i_id  <  0)
	{
		s_control.Format
		(
		"Select * from results_sets \
		where	\
		name  =  '%s'",

		CMySqlControl::sFormatForSQL(s_new_rset_name)
		);

		vs_control_sql.push_back(s_control);


		s_add.Format
			(
			"Insert into results_sets \
			(  \
			name,  comments  \
			) \
			values \
			( \
			'%s', '%s'\
			)",  
			
			CMySqlControl::sFormatForSQL(s_new_rset_name),  CMySqlControl::sFormatForSQL(s_new_rset_comments)
			);

		vs_add_sql.push_back(s_add);

		c_err  =  pc_conn->eAddDb(&vs_control_sql,  &vs_add_sql, "SELECT results_set_id FROM results_sets order by results_set_id desc limit 0,1", &i_id);

	}//if  (i_id  <  0)
	else
	{
		s_control  =  sGetControlString();
	
		vs_control_sql.push_back(s_control);


		s_update.Format
		(
		"update results_sets \
		set \
		name  =  '%s',	comments  =  '%s' \
		where  \
		results_set_id  =  '%d'",
		
		CMySqlControl::sFormatForSQL(s_new_rset_name),  CMySqlControl::sFormatForSQL(s_new_rset_comments),
		i_id
		);

		vs_update_sql.push_back(s_update);

		c_err  =  pc_conn->eUpdateDb(&vs_control_sql, &vs_update_sql);
	
	}//else  if  (i_id  <  0)


	if  (c_err  ==  false)
	{
		s_rset_name  =  s_new_rset_name;
		s_rset_comments  =  s_new_rset_comments;
	}//if  (c_err  ==  false)


	return(c_err);
}//CError  CCOResultSet::eUpdate



bool  CCOResultSet::operator==(CCODbComponent &cOtherComponent)
{
	
	if  (iGetType()  !=  cOtherComponent.iGetType())  return(false);

	if  (iGetId()  ==  cOtherComponent.iGetId())  
		return(true);
	else
		return(false);

	return(false);
};//bool  CCOResultSet::operator==(CCODbrsetonent &cOtherrsetonent)










