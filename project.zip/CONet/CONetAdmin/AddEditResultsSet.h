#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace CONetAdmin
{
	/// <summary> 
	/// Summary for AddEditResultsSet
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class CAddEditResultsSet : public System::Windows::Forms::Form
	{
	public: 
		CAddEditResultsSet(void)
		{
			InitializeComponent();
		}
        
	protected: 
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::Button *  butCancel;
	private: System::Windows::Forms::Button *  butOk;

	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::Label *  label1;
	public: System::Windows::Forms::TextBox *  textRSetName;
	public: System::Windows::Forms::TextBox *  textRSetComm;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container* components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->butCancel = new System::Windows::Forms::Button();
			this->butOk = new System::Windows::Forms::Button();
			this->textRSetName = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->label1 = new System::Windows::Forms::Label();
			this->textRSetComm = new System::Windows::Forms::TextBox();
			this->SuspendLayout();
			// 
			// butCancel
			// 
			this->butCancel->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->butCancel->Location = System::Drawing::Point(376, 248);
			this->butCancel->Name = S"butCancel";
			this->butCancel->TabIndex = 44;
			this->butCancel->Text = S"Cancel";
			// 
			// butOk
			// 
			this->butOk->DialogResult = System::Windows::Forms::DialogResult::OK;
			this->butOk->Location = System::Drawing::Point(288, 248);
			this->butOk->Name = S"butOk";
			this->butOk->TabIndex = 43;
			this->butOk->Text = S"OK";
			// 
			// textRSetName
			// 
			this->textRSetName->Location = System::Drawing::Point(40, 40);
			this->textRSetName->Name = S"textRSetName";
			this->textRSetName->Size = System::Drawing::Size(304, 20);
			this->textRSetName->TabIndex = 41;
			this->textRSetName->Text = S"";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(16, 16);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(97, 16);
			this->label2->TabIndex = 40;
			this->label2->Text = S"Results Set name:";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(16, 80);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(120, 16);
			this->label1->TabIndex = 39;
			this->label1->Text = S"Results Set comments:";
			// 
			// textRSetComm
			// 
			this->textRSetComm->Location = System::Drawing::Point(40, 104);
			this->textRSetComm->Multiline = true;
			this->textRSetComm->Name = S"textRSetComm";
			this->textRSetComm->Size = System::Drawing::Size(304, 128);
			this->textRSetComm->TabIndex = 42;
			this->textRSetComm->Text = S"";
			// 
			// CAddEditResultsSet
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
			this->ClientSize = System::Drawing::Size(472, 285);
			this->Controls->Add(this->butCancel);
			this->Controls->Add(this->butOk);
			this->Controls->Add(this->textRSetName);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textRSetComm);
			this->Name = S"CAddEditResultsSet";
			this->Text = S"AddEditResultsSet";
			this->ResumeLayout(false);

		}		
	};
};//namespace CONetAdmin